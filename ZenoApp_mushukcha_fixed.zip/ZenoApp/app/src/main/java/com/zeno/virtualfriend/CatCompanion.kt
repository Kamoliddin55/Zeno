package com.zeno.virtualfriend

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** ZENO uchun yengil, internet talab qilmaydigan 2D virtual mushukcha. */
class CatCompanionView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("zeno_cat", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private var fur = Color.rgb(255, 190, 45)
    private var hunger = prefs.getInt("hunger", 82)
    private var sleep = prefs.getInt("sleep", 88)
    private var mood = prefs.getInt("mood", 78)
    private var sleeping = prefs.getBoolean("sleeping", false)
    private var lastTick = prefs.getLong("last_tick", System.currentTimeMillis())
    private var x = 0f
    private var direction = 1f
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var downAt = 0L
    private var lastMove = System.currentTimeMillis()
    private var animTime = 0f
    private var eatingUntil = 0L
    private var blinkUntil = 0L
    private val colors = intArrayOf(Color.rgb(255,190,45))

    init {
        contentDescription = "ZENO virtual mushukchasi. Bosib silash, uzoq bosib menyuni ochish mumkin."
        isClickable = true
        prefs.edit().putInt("fur", fur).apply()
        updateNeeds()
        post(object : Runnable {
            override fun run() {
                animTime += 0.16f
                if (!dragging && !sleeping && System.currentTimeMillis() > eatingUntil && width > 0) {
                    x += direction * 1.1f * density
                    val edge = max(0f, (parent as? View)?.width?.toFloat()?.minus(width) ?: 0f)
                    if (x < 0f) { x = 0f; direction = 1f }
                    if (x > edge) { x = edge; direction = -1f }
                    translationX = x
                }
                if (System.currentTimeMillis() % 4200L < 100L) blinkUntil = System.currentTimeMillis() + 180L
                updateNeeds()
                invalidate()
                postDelayed(this, 50L)
            }
        })
    }

    private fun updateNeeds() {
        val now = System.currentTimeMillis()
        val steps = ((now - lastTick) / 60000L).toInt()
        if (steps > 0) {
            hunger = max(0, hunger - steps)
            if (!sleeping) sleep = max(0, sleep - steps) else sleep = min(100, sleep + steps * 2)
            if (sleeping && sleep >= 100) sleeping = false
            if (hunger < 25 || sleep < 20) mood = max(0, mood - steps)
            lastTick += steps * 60000L
            save()
        }
    }

    private fun save() { prefs.edit().putInt("fur", fur).putInt("hunger", hunger).putInt("sleep", sleep).putInt("mood", mood).putBoolean("sleeping", sleeping).putLong("last_tick", lastTick).apply() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        canvas.save()
        val cx = w * .5f
        val now = System.currentTimeMillis()
        val eating = now < eatingUntil
        val walking = !sleeping && !dragging && !eating
        val bounce = if (walking) kotlin.math.abs(kotlin.math.sin(animTime * 2.5f)) * 2.5f * density else 0f
        val cy = h * .58f - bounce + if (sleeping) 3f * density else 0f
        val scale = min(w, h) * .42f
        // dumaloq tana va bosh
        paint.color = fur; paint.style = Paint.Style.FILL
        canvas.drawOval(RectF(cx-scale*.76f, cy-scale*.10f, cx+scale*.76f, cy+scale*1.08f), paint)
        // oq qorincha
        paint.color = Color.rgb(255, 246, 222)
        canvas.drawOval(RectF(cx-scale*.43f, cy+scale*.34f, cx+scale*.43f, cy+scale*.99f), paint)
        paint.color = fur
        canvas.drawCircle(cx, cy-scale*.35f, scale*.78f, paint)
        // quloqlar
        val ears = Path().apply { moveTo(cx-scale*.62f,cy-scale*.72f); lineTo(cx-scale*.75f,cy-scale*1.45f); lineTo(cx-scale*.12f,cy-scale*1.02f); close(); moveTo(cx+scale*.62f,cy-scale*.72f); lineTo(cx+scale*.75f,cy-scale*1.45f); lineTo(cx+scale*.12f,cy-scale*1.02f); close() }
        canvas.drawPath(ears, paint)
        paint.color = Color.rgb(242,145,160)
        val inner = Path().apply { moveTo(cx-scale*.54f,cy-scale*.88f); lineTo(cx-scale*.62f,cy-scale*1.28f); lineTo(cx-scale*.25f,cy-scale*1.02f); close(); moveTo(cx+scale*.54f,cy-scale*.88f); lineTo(cx+scale*.62f,cy-scale*1.28f); lineTo(cx+scale*.25f,cy-scale*1.02f); close() }
        canvas.drawPath(inner, paint)
        // oq tumshuq va yashil ko‘zlar
        paint.color = Color.rgb(255, 246, 222)
        canvas.drawCircle(cx-scale*.15f, cy-scale*.17f, scale*.16f, paint)
        canvas.drawCircle(cx+scale*.15f, cy-scale*.17f, scale*.16f, paint)
        paint.color = Color.rgb(235,125,145); canvas.drawCircle(cx,cy-scale*.17f,scale*.09f,paint)
        paint.color = Color.rgb(65,48,48); paint.style = Paint.Style.STROKE; paint.strokeWidth = max(1f,scale*.025f)
        val smile = Path().apply { moveTo(cx,cy-scale*.10f); quadTo(cx-scale*.12f,cy+scale*.04f,cx-scale*.23f,cy-scale*.02f); moveTo(cx,cy-scale*.10f); quadTo(cx+scale*.12f,cy+scale*.04f,cx+scale*.23f,cy-scale*.02f) }
        canvas.drawPath(smile,paint); paint.style = Paint.Style.FILL
        // Ko‘zlar: uxlaganda yumilgan, vaqti-vaqti bilan pirpiraydi
        paint.color = Color.rgb(55, 145, 78)
        if (sleeping || now < blinkUntil) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = max(1f, scale*.035f)
            canvas.drawLine(cx-scale*.38f, cy-scale*.42f, cx-scale*.18f, cy-scale*.42f, paint)
            canvas.drawLine(cx+scale*.18f, cy-scale*.42f, cx+scale*.38f, cy-scale*.42f, paint)
            paint.style = Paint.Style.FILL
        } else {
            canvas.drawCircle(cx-scale*.28f,cy-scale*.42f,scale*.09f,paint); canvas.drawCircle(cx+scale*.28f,cy-scale*.42f,scale*.09f,paint)
            paint.color = Color.rgb(30, 70, 45); canvas.drawCircle(cx-scale*.28f,cy-scale*.42f,scale*.04f,paint); canvas.drawCircle(cx+scale*.28f,cy-scale*.42f,scale*.04f,paint)
        }
        // oyoqchalar yurishda navbatma-navbat qimirlaydi
        paint.color = fur
        val legSwing = if (walking) kotlin.math.sin(animTime * 5f) * scale * .10f else 0f
        canvas.drawOval(RectF(cx-scale*.55f,cy+scale*.72f+legSwing,cx-scale*.12f,cy+scale*1.12f+legSwing),paint)
        canvas.drawOval(RectF(cx+scale*.12f,cy+scale*.72f-legSwing,cx+scale*.55f,cy+scale*1.12f-legSwing),paint)
        // dum doim mayin qimirlaydi
        paint.style = Paint.Style.STROKE; paint.strokeWidth = scale*.16f; paint.strokeCap = Paint.Cap.ROUND
        val wag = if (sleeping) 0f else kotlin.math.sin(animTime * 3.4f) * .18f
        val tail = Path().apply { moveTo(cx+scale*.55f,cy+scale*.65f); cubicTo(cx+scale*(1.15f+wag),cy+scale*.7f,cx+scale*(1.0f+wag),cy-scale*.15f,cx+scale*(.82f+wag),cy-scale*.05f) }
        canvas.drawPath(tail,paint); paint.style = Paint.Style.FILL
        if (eating) {
            paint.color = Color.rgb(245, 145, 45)
            canvas.drawOval(RectF(cx+scale*.62f, cy+scale*.48f, cx+scale*1.02f, cy+scale*.72f), paint)
            paint.color = Color.WHITE; paint.textSize = scale*.24f; paint.textAlign = Paint.Align.CENTER
            canvas.drawText("🍖", cx+scale*.82f, cy+scale*.45f, paint)
        }
        // holat belgisi
        paint.color = Color.WHITE; paint.textSize = 12f*density; paint.textAlign = Paint.Align.CENTER
        canvas.drawText(if (sleeping) "💤" else if (hunger < 25) "🍗" else if (mood > 75) "♥" else "•", cx, h*.13f, paint)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { downX=event.rawX; downY=event.rawY; startX=x; downAt=System.currentTimeMillis(); dragging=false; return true }
            MotionEvent.ACTION_MOVE -> { if (kotlin.math.abs(event.rawX-downX)>8*density) { dragging=true; x=(startX+event.rawX-downX).coerceIn(0f, max(0f,((parent as? View)?.width?.toFloat() ?: width.toFloat())-width)); translationX = x; invalidate() }; return true }
            MotionEvent.ACTION_UP -> { if (!dragging) { if (System.currentTimeMillis()-downAt >= 600L) showActions() else pet(); lastMove=System.currentTimeMillis() }; return true }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    private fun pet() { mood=min(100,mood+12); if (sleeping) sleeping=false; save(); invalidate() }
    private fun feedCat() { hunger=min(100,hunger+35); mood=min(100,mood+5); sleeping=false; eatingUntil=System.currentTimeMillis()+2200L; save(); invalidate() }

    private fun showStatus(message: String = "") {
        val status = "Kayfiyat: $mood/100\nOchlik: $hunger/100\nUyqu: $sleep/100\n" + if (sleeping) "Holati: uxlayapti 💤" else "Holati: uyg‘oq 🐱"
        AlertDialog.Builder(context).setTitle("ZENO mushukchasi 🐱").setMessage((if(message.isBlank()) "" else "$message\n\n")+status)
            .setPositiveButton("Silash ❤️") { _,_-> mood=min(100,mood+12); sleeping=false; save(); invalidate() }
            .setNeutralButton("Ovqat berish 🍖") { _,_-> feedCat() }
            .setNegativeButton("Boshqa") { _,_-> showActions() }.show()
    }

    private fun showActions() {
        val options = arrayOf(if(sleeping) "Uyg‘otish ☀️" else "Uxlatish 💤", "Sariq rangni tiklash 💛", "Holatini ko‘rish 📊", "Ovqat berish 🍗")
        AlertDialog.Builder(context).setTitle("Mushukcha").setItems(options) { _,which ->
            when(which) {
                0 -> { sleeping=!sleeping; if(sleeping) sleep=max(10,sleep); save(); invalidate() }
                1 -> { fur = Color.rgb(255, 190, 45); save(); invalidate(); showStatus("Mushukchang sariq rangda 💛") }
                2 -> showStatus()
                3 -> feedCat()
            }
        }.show()
    }

}
