package com.zeno.virtualfriend

import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** ZENO uchun qisqa, to'liq ekranli ochilish sahifasi. */
class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val openMain = Runnable {
        // Yangi (eskirmagan) usul: fade animatsiyasi startActivity bilan birga beriladi
        val options = ActivityOptions.makeCustomAnimation(
            this, android.R.anim.fade_in, android.R.anim.fade_out
        )
        startActivity(Intent(this, MainActivity::class.java), options.toBundle())
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Kesik (notch) bor ekranlarda ham rasm to'liq ekran bo'lsin
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContentView(R.layout.activity_splash)

        // Rasm biroz kattaroq holatdan yumshoq paydo bo'lib, joyiga o'tiradi
        findViewById<ImageView>(R.id.splashImage)?.let { img ->
            img.alpha = 0f
            img.scaleX = 1.05f
            img.scaleY = 1.05f
            img.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600L).start()
        }

        // "ZENO" yozuvi pastdan, xira va g'ubor holatda ko'tarilib, tiniqlashib chiqadi
        findViewById<ImageView>(R.id.splashWordmark)?.let { wm ->
            val interp = DecelerateInterpolator(1.6f)
            wm.alpha = 0f
            wm.translationY = resources.displayMetrics.heightPixels * 0.07f
            wm.animate().alpha(1f).translationY(0f)
                .setStartDelay(150L).setDuration(950L).setInterpolator(interp).start()
            if (Build.VERSION.SDK_INT >= 31) {
                // Android 12+: g'uborlik asta-sekin yo'qoladi (tiniqlashadi)
                ValueAnimator.ofFloat(28f, 0f).apply {
                    startDelay = 150L
                    duration = 950L
                    interpolator = interp
                    addUpdateListener { a ->
                        val r = a.animatedValue as Float
                        wm.setRenderEffect(
                            if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null
                        )
                    }
                    start()
                }
            }
        }

        // Status va navigatsiya panelini yashirish (eskirgan systemUiVisibility o'rniga)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        // Ekran aylanganda (qayta yaratilganda) taymer ikki marta ishga tushmasin
        handler.removeCallbacks(openMain)
        handler.postDelayed(openMain, 1600L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(openMain)
        super.onDestroy()
    }
}
