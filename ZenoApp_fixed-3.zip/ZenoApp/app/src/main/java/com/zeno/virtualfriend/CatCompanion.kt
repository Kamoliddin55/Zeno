package com.zeno.virtualfriend

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Pikselli rasm (matn qatorlari) -> Bitmap. */
private fun pixelBitmap(rows: Array<String>): Bitmap {
    val h = rows.size
    val w = rows.maxOf { it.length }
    val px = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until rows[y].length) {
            px[y * w + x] = CatSprites.palette[rows[y][x]] ?: 0
        }
    }
    return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

/** Bitta "piksel" ekranda necha fizik piksel bo'lishi. */
private fun pixelCell(context: Context): Int =
    max(2, (2.6f * context.resources.displayMetrics.density).roundToInt())

/** Mushukcha va ovqat idishini chat oynasiga qo'shadi. */
object CatCompanion {
    fun attach(activity: Activity, frame: FrameLayout) {
        val d = activity.resources.displayMetrics.density
        val cat = CatCompanionView(activity)
        val drawer = FoodDrawerView(activity)
        cat.drawer = drawer
        val bottom = (76 * d).toInt()
        drawer.elevation = 10f * d
        cat.elevation = 12f * d
        // Avval idish, uning ustidan mushuk (bosh idish ustida ko'rinsin)
        frame.addView(
            drawer,
            FrameLayout.LayoutParams(drawer.viewWidth, drawer.viewHeight, Gravity.BOTTOM or Gravity.END).apply {
                bottomMargin = bottom
            }
        )
        frame.addView(
            cat,
            FrameLayout.LayoutParams(cat.viewWidth, cat.viewHeight, Gravity.BOTTOM or Gravity.START).apply {
                bottomMargin = bottom
            }
        )
    }
}

/**
 * Pikselli sariq mushukcha: o'tiradi, yuradi, uxlaydi va idishdan ovqat yeydi.
 * Bosish — silash, uzoq bosish — menyu, sudrash — joyini o'zgartirish.
 */
class CatCompanionView(context: Context) : View(context) {
    private enum class St { SIT, WALK, GO_EAT, EAT, SLEEP, HELD }

    private val cell = pixelCell(context)
    val viewWidth = 40 * cell
    val viewHeight = 46 * cell
    var drawer: FoodDrawerView? = null

    private val prefs = context.getSharedPreferences("zeno_cat", Context.MODE_PRIVATE)
    private val density = resources.displayMetrics.density
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = Color.rgb(77, 124, 240)
        textAlign = Paint.Align.CENTER
    }

    private val sitFrames = arrayOf(pixelBitmap(CatSprites.SIT_A), pixelBitmap(CatSprites.SIT_B))
    private val sitBlink = arrayOf(pixelBitmap(CatSprites.SIT_A_BLINK), pixelBitmap(CatSprites.SIT_B_BLINK))
    private val walkFrames = arrayOf(pixelBitmap(CatSprites.WALK_A), pixelBitmap(CatSprites.WALK_B))
    private val eatFrames = arrayOf(pixelBitmap(CatSprites.EAT_A), pixelBitmap(CatSprites.EAT_B))
    private val sleepFrames = arrayOf(pixelBitmap(CatSprites.SLEEP_A), pixelBitmap(CatSprites.SLEEP_B))
    private val heartBmp = pixelBitmap(CatSprites.HEART)
    private val exclBmp = pixelBitmap(CatSprites.EXCL)

    private var hunger = prefs.getInt("hunger", 82)
    private var sleepNeed = prefs.getInt("sleep", 88)
    private var mood = prefs.getInt("mood", 78)
    private var sleeping = prefs.getBoolean("sleeping", false)
    private var lastTick = prefs.getLong("last_tick", System.currentTimeMillis())

    private var state = if (sleeping) St.SLEEP else St.SIT
    private var stateUntil = 0L
    private var facingRight = true
    private var x = 0f
    private var animTime = 0f
    private var eatEnd = 0L
    private var blinkUntil = 0L
    private var nextBlink = 0L
    private val hearts = ArrayList<Long>()

    private var downX = 0f
    private var startX = 0f
    private var dragging = false
    private var longPressed = false
    private val longPress = Runnable {
        if (!dragging) {
            longPressed = true
            showMenu()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            tick()
            postDelayed(this, 50L)
        }
    }

    init {
        contentDescription = "ZENO virtual mushukchasi. Bosib silash, uzoq bosib menyuni ochish mumkin."
        isClickable = true
        // Xiaomi/MIUI "majburiy qorong'u rejim" mushukning sariq rangini to'q qilib yubormasin
        if (android.os.Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(loop)
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }

    private fun parentWidth(): Int = (parent as? View)?.width ?: 0

    private fun eatTargetX(pw: Int, maxX: Float): Float {
        val d = drawer ?: return x
        return (pw - d.mouthFromRight - 37 * cell).toFloat().coerceIn(0f, maxX)
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        animTime += 0.05f
        updateNeeds(now)
        val pw = parentWidth()
        if (width == 0 || pw == 0) return
        val maxX = max(0f, (pw - width).toFloat())
        if (state != St.HELD) decide(now, pw, maxX)
        val step = 1.1f * density
        when (state) {
            St.WALK -> {
                x += if (facingRight) step else -step
                if (x <= 0f) { x = 0f; facingRight = true }
                else if (x >= maxX) { x = maxX; facingRight = false }
            }
            St.GO_EAT -> {
                val dx = eatTargetX(pw, maxX) - x
                if (abs(dx) > cell * 2f) {
                    x += if (dx > 0f) step * 1.7f else -step * 1.7f
                    facingRight = dx > 0f
                }
            }
            else -> {}
        }
        x = x.coerceIn(0f, maxX)
        translationX = x
        if (now > nextBlink) {
            blinkUntil = now + 180L
            nextBlink = now + 2500L + Random.nextLong(3500L)
        }
        invalidate()
    }

    private fun decide(now: Long, pw: Int, maxX: Float) {
        if (sleeping) {
            if (state != St.SLEEP) state = St.SLEEP
            return
        }
        if (state == St.SLEEP) {
            state = St.SIT
            stateUntil = now + 2500L
        }
        when (state) {
            St.EAT -> if (now >= eatEnd) finishEating(now)
            St.GO_EAT -> {
                val d = drawer
                if (d == null || !d.canServe() || hunger > 90) {
                    state = St.SIT
                    stateUntil = now + 2000L
                } else if (abs(eatTargetX(pw, maxX) - x) <= cell * 2f) {
                    state = St.EAT
                    facingRight = true
                    eatEnd = now + 3600L
                }
            }
            else -> {
                val d = drawer
                if (d != null && d.canServe() && hunger <= 90) {
                    state = St.GO_EAT
                    return
                }
                if (sleepNeed < 15) {
                    sleeping = true
                    state = St.SLEEP
                    save()
                    return
                }
                if (now >= stateUntil) {
                    if (state == St.SIT && Random.nextInt(100) < 60) {
                        state = St.WALK
                        facingRight = Random.nextBoolean()
                        stateUntil = now + 2500L + Random.nextLong(3500L)
                    } else {
                        state = St.SIT
                        stateUntil = now + 2500L + Random.nextLong(4000L)
                    }
                }
            }
        }
    }

    private fun finishEating(now: Long) {
        hunger = min(100, hunger + 35)
        mood = min(100, mood + 5)
        drawer?.consume()
        hearts.add(now)
        state = St.SIT
        stateUntil = now + 2500L
        save()
    }

    private fun updateNeeds(now: Long) {
        val steps = ((now - lastTick) / 60000L).toInt()
        if (steps > 0) {
            hunger = max(0, hunger - steps)
            sleepNeed = if (!sleeping) max(0, sleepNeed - steps) else min(100, sleepNeed + steps * 2)
            if (sleeping && sleepNeed >= 100) sleeping = false
            if (hunger < 25 || sleepNeed < 20) mood = max(0, mood - steps)
            lastTick += steps * 60000L
            save()
        }
    }

    private fun save() {
        prefs.edit()
            .putInt("hunger", hunger)
            .putInt("sleep", sleepNeed)
            .putInt("mood", mood)
            .putBoolean("sleeping", sleeping)
            .putLong("last_tick", lastTick)
            .apply()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        var bmp: Bitmap
        var flip = false
        when (state) {
            St.SLEEP -> bmp = sleepFrames[(animTime / 1.2f).toInt() % 2]
            St.WALK, St.GO_EAT -> {
                bmp = walkFrames[(animTime / 0.25f).toInt() % 2]
                flip = !facingRight
            }
            St.EAT -> bmp = eatFrames[(animTime / 0.3f).toInt() % 2]
            else -> {
                val tf = (animTime / 0.7f).toInt() % 2
                bmp = if (now < blinkUntil) sitBlink[tf] else sitFrames[tf]
            }
        }
        val dst = Rect(0, 10 * cell, 40 * cell, 46 * cell)
        if (flip) {
            canvas.save()
            canvas.scale(-1f, 1f, width / 2f, 0f)
            canvas.drawBitmap(bmp, null, dst, paint)
            canvas.restore()
        } else {
            canvas.drawBitmap(bmp, null, dst, paint)
        }
        // yuraklar (silaganda / yegandan keyin)
        val it = hearts.iterator()
        while (it.hasNext()) {
            val t0 = it.next()
            val age = (now - t0) / 1400f
            if (age >= 1f) { it.remove(); continue }
            val top = ((9f - age * 8f) * cell).toInt()
            paint.alpha = ((1f - age) * 255f).toInt()
            canvas.drawBitmap(heartBmp, null, Rect(17 * cell, top, 24 * cell, top + 6 * cell), paint)
        }
        paint.alpha = 255
        // uxlaganda "z"
        if (state == St.SLEEP) {
            for (i in 0..2) {
                val phase = (animTime * 0.4f + i / 3f) % 1f
                textPaint.textSize = (3f + i) * cell
                textPaint.alpha = ((1f - phase) * 255f).toInt()
                canvas.drawText("z", (12f + phase * 8f) * cell, (27f - phase * 17f) * cell, textPaint)
            }
            textPaint.alpha = 255
        }
        // och qolganda "!"
        if (hunger < 25 && state != St.SLEEP && (animTime * 2f).toInt() % 2 == 0) {
            canvas.drawBitmap(exclBmp, null, Rect(33 * cell, 2 * cell, 36 * cell, 10 * cell), paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // Mushukdan tashqaridagi (shaffof) joyga tegilsa, chat o'zi ishlayversin
                val inside = event.x >= 3 * cell && event.x <= 37 * cell && event.y >= 10 * cell
                if (!inside) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.rawX
                startX = x
                dragging = false
                longPressed = false
                postDelayed(longPress, 600L)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.rawX - downX) > 8 * density) {
                    if (!dragging) {
                        dragging = true
                        removeCallbacks(longPress)
                        state = St.HELD
                    }
                    val pw = parentWidth().let { if (it > 0) it else width }
                    x = (startX + event.rawX - downX).coerceIn(0f, max(0f, (pw - width).toFloat()))
                    translationX = x
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (dragging) {
                    state = if (sleeping) St.SLEEP else St.SIT
                    stateUntil = System.currentTimeMillis() + 2500L
                } else if (!longPressed) {
                    pet()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) state = if (sleeping) St.SLEEP else St.SIT
                dragging = false
                return true
            }
        }
        return true
    }

    private fun pet() {
        val now = System.currentTimeMillis()
        mood = min(100, mood + 12)
        if (sleeping) {
            sleeping = false
            state = St.SIT
            stateUntil = now + 2000L
        }
        hearts.add(now)
        save()
        invalidate()
    }

    private fun showStatus() {
        val status = "Kayfiyat: $mood/100\nOchlik: $hunger/100\nUyqu: $sleepNeed/100\n" +
            if (sleeping) "Holati: uxlayapti" else "Holati: uyg‘oq"
        AlertDialog.Builder(context).setTitle("ZENO mushukchasi").setMessage(status)
            .setPositiveButton("OK", null).show()
    }

    private fun showMenu() {
        val d = drawer
        val options = arrayOf(
            if (sleeping) "Uyg‘otish" else "Uxlatish",
            if (d != null && d.isOpen) "Ovqat idishini yopish" else "Ovqat idishini ochish",
            "Holatini ko‘rish"
        )
        AlertDialog.Builder(context).setTitle("Mushukcha").setItems(options) { _, which ->
            when (which) {
                0 -> {
                    sleeping = !sleeping
                    if (sleeping) sleepNeed = max(10, sleepNeed)
                    state = if (sleeping) St.SLEEP else St.SIT
                    stateUntil = System.currentTimeMillis() + 2000L
                    save()
                }
                1 -> drawer?.toggle()
                2 -> showStatus()
            }
        }.show()
    }
}

/**
 * Ilova chetidan biroz chiqib turgan strelkali tutqich. Uni tortsangiz, ichida ovqati bor idish chiqadi;
 * mushukcha och bo'lsa, shu yerga kelib yeydi.
 */
class FoodDrawerView(context: Context) : View(context) {
    private val cell = pixelCell(context)
    private val density = resources.displayMetrics.density
    private val handleW = 10 * cell
    val viewWidth = 38 * cell
    val viewHeight = 22 * cell
    private val closedTx = (viewWidth - handleW).toFloat()

    /** Ekranning o'ng chetidan mushukning og'zi turishi kerak bo'lgan masofa. */
    val mouthFromRight = 22 * cell

    var isOpen = false
        private set
    private var food = 3

    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val bowls = arrayOf(
        pixelBitmap(CatSprites.BOWL_0), pixelBitmap(CatSprites.BOWL_1),
        pixelBitmap(CatSprites.BOWL_2), pixelBitmap(CatSprites.BOWL_3)
    )
    private val handleBmp = pixelBitmap(CatSprites.HANDLE)

    private var downRaw = 0f
    private var startTx = 0f
    private var downLocalX = 0f
    private var moved = false

    init {
        contentDescription = "Mushukcha ovqat idishi. Strelkani tortsangiz, idish chiqadi."
        isClickable = true
        translationX = closedTx
        if (android.os.Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
    }

    fun canServe(): Boolean = isOpen && food > 0 && translationX < closedTx * 0.15f

    fun consume() {
        if (food > 0) food--
        invalidate()
    }

    fun toggle() = setOpen(!isOpen)

    private fun setOpen(open: Boolean) {
        if (open && !isOpen) food = 3
        isOpen = open
        animate().cancel()
        animate().translationX(if (open) 0f else closedTx).setDuration(200L).start()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bowl = bowls[food.coerceIn(0, 3)]
        canvas.drawBitmap(bowl, null, Rect(handleW, viewHeight - 20 * cell, handleW + 28 * cell, viewHeight), paint)
        val hTop = viewHeight - 17 * cell
        val hDst = Rect(0, hTop, handleW, hTop + 14 * cell)
        if (isOpen) {
            canvas.save()
            canvas.scale(-1f, 1f, handleW / 2f, 0f)
            canvas.drawBitmap(handleBmp, null, hDst, paint)
            canvas.restore()
        } else {
            canvas.drawBitmap(handleBmp, null, hDst, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animate().cancel()
                downRaw = e.rawX
                startTx = translationX
                downLocalX = e.x
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRaw
                if (abs(dx) > 6 * density) moved = true
                if (moved) translationX = (startTx + dx).coerceIn(0f, closedTx)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    setOpen(translationX < closedTx * 0.5f)
                } else if (downLocalX < handleW) {
                    toggle()
                } else if (isOpen && food == 0) {
                    food = 3
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                setOpen(isOpen)
                return true
            }
        }
        return true
    }
}
