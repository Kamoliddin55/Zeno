package com.zeno.virtualfriend

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.SoundPool
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Pikselli rasm (matn qatorlari) -> Bitmap. */
private fun pixelBitmap(rows: Array<String>): Bitmap {
    val h = rows.size
    val w = rows.maxOf { it.length }
    val px = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until rows[y].length) {
            px[y * w + x] = CatSprites.palette[rows[y][x]] ?: 0
        }
    }
    return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

/** Bitta "piksel" ekranda necha fizik piksel bo'lishi. */
private fun pixelCell(context: Context): Int =
    max(2, (2.6f * context.resources.displayMetrics.density).roundToInt())

/** Mushukcha va ovqat idishini ekranga qo'shadi (chat va sozlamalar ekranlariga). */
object CatCompanion {
    /** Chat ekrani: mushukcha yozuv maydoni ustida yuradi. */
    fun attach(activity: Activity, frame: FrameLayout, bottomDp: Int = 76, page: String = "chat"): CatCompanionView {
        val d = activity.resources.displayMetrics.density
        val cat = CatCompanionView(activity, page)
        val drawer = FoodDrawerView(activity)
        cat.drawer = drawer
        val bottom = (bottomDp * d).toInt()
        drawer.elevation = 10f * d
        cat.elevation = 12f * d
        // Avval idish, uning ustidan mushuk (bosh idish ustida ko'rinsin)
        frame.addView(
            drawer,
            FrameLayout.LayoutParams(drawer.viewWidth, drawer.viewHeight, Gravity.BOTTOM or Gravity.END).apply {
                bottomMargin = bottom
            }
        )
        frame.addView(
            cat,
            FrameLayout.LayoutParams(cat.viewWidth, cat.viewHeight, Gravity.BOTTOM or Gravity.START).apply {
                bottomMargin = bottom
            }
        )
        return cat
    }

    /** Sozlamalar kabi boshqa ekranlarga ham mushukchani qo'shadi (xuddi shu mushukcha, xuddi shu holat). */
    fun attachToScreen(activity: Activity, bottomDp: Int = 16, page: String = "settings"): CatCompanionView? {
        val frame = activity.findViewById<FrameLayout>(android.R.id.content) ?: return null
        return attach(activity, frame, bottomDp, page)
    }

    /** Mushukcha boshqa sahifada yursa, uni chatga chaqiradi. Chaqirilgan bo'lsa true. */
    fun callCat(ctx: Context): Boolean {
        val prefs = ctx.getSharedPreferences("zeno_cat", Context.MODE_PRIVATE)
        if (prefs.getString("cat_page", "chat") == "chat") return false
        prefs.edit().putString("cat_page", "chat").putBoolean("arrive", true).putLong("cat_until", 0L).apply()
        return true
    }
}

/**
 * Pikselli sariq mushukcha. U o'z hayoti bilan yashaydi:
 *  - o'zi yuradi, uxlaydi, ovqat yeydi;
 *  - dam olgan bo'lsa, ko'rinib turgan xabarlar ustiga sakrab chiqib, ustida yuradi, uxlaydi yoki pastga tushadi;
 *  - ba'zan chatdan sozlamalarga (yoki aksincha) o'zi yurib ketadi — ketgan sahifada ko'rinmaydi;
 *  - uxlayotganda siz xabar yozsangiz, ko'zini yarim ochib uyquchan qaraydi.
 * Ushlab sudrash — istalgan joyga (jumladan xabar ustiga) ko'tarib qo'yish; qo'yib yuborsangiz pastga tushadi
 * va xabarning ustiga duch kelsa, o'sha yerda qoladi. Bosish — silash; uzoq bosish — menyu.
 */
class CatCompanionView(context: Context, private val page: String = "chat") : View(context) {
    private enum class St { SIT, WALK, GO_EAT, EAT, SLEEP, HELD, FALL, JUMP, PERCH, LEAVE, ENTER, GROOM, YAWN, STRETCH, MEOW }

    private val cell = pixelCell(context)
    val viewWidth = 40 * cell
    val viewHeight = 46 * cell
    var drawer: FoodDrawerView? = null

    /** Mushukcha ustiga chiqishi mumkin bo'lgan ko'rinuvchi xabarlar (faqat chat ekranida beriladi). */
    var perchFinder: (() -> List<View>)? = null

    /** Mushukcha biror xabar ustiga o'tirganda (view) yoki tushganda (null) chaqiriladi. */
    var perchListener: ((View?) -> Unit)? = null

    /** Mushukcha xabar ustiga sig'ishi uchun kerakli bo'sh joy balandligi (piksel). */
    val roomPx: Int get() = 34 * cell

    private val prefs = context.getSharedPreferences("zeno_cat", Context.MODE_PRIVATE)
    private val density = resources.displayMetrics.density
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = Color.rgb(77, 124, 240)
        textAlign = Paint.Align.CENTER
    }

    private val sitFrames = arrayOf(pixelBitmap(CatSprites.SIT_A), pixelBitmap(CatSprites.SIT_B))
    private val sitBlink = arrayOf(pixelBitmap(CatSprites.SIT_A_BLINK), pixelBitmap(CatSprites.SIT_B_BLINK))
    private val sitDrowsy = pixelBitmap(CatSprites.SIT_DROWSY)
    private val walkFrames = arrayOf(
        pixelBitmap(CatSprites.WALK_A), pixelBitmap(CatSprites.WALK_B),
        pixelBitmap(CatSprites.WALK_C), pixelBitmap(CatSprites.WALK_D)
    )
    // sakrash kadrlari: cho'kkalash, sakrab chiqish, eng tepada, tushish; va qo'nish
    private val jumpFrames = arrayOf(
        pixelBitmap(CatSprites.JUMP_A), pixelBitmap(CatSprites.JUMP_B),
        pixelBitmap(CatSprites.JUMP_C), pixelBitmap(CatSprites.JUMP_D)
    )
    private val landBmp = pixelBitmap(CatSprites.LAND_A)
    // qiziqarli kadrlar: esnash, yalanish (o'zini tozalash), cho'zilish
    private val yawnFrames = arrayOf(pixelBitmap(CatSprites.YAWN_A), pixelBitmap(CatSprites.YAWN_B))
    private val lickFrames = arrayOf(pixelBitmap(CatSprites.LICK_A), pixelBitmap(CatSprites.LICK_B))
    private val stretchFrames = arrayOf(pixelBitmap(CatSprites.STRETCH_A), pixelBitmap(CatSprites.STRETCH_B))
    private val meowFrames = arrayOf(pixelBitmap(CatSprites.MEOW_A), pixelBitmap(CatSprites.MEOW_B))
    private val eatFrames = arrayOf(pixelBitmap(CatSprites.EAT_A), pixelBitmap(CatSprites.EAT_B))
    private val sleepFrames = arrayOf(pixelBitmap(CatSprites.SLEEP_A), pixelBitmap(CatSprites.SLEEP_B))
    private val sleepHalf = pixelBitmap(CatSprites.SLEEP_C)
    private val sleepSlit = pixelBitmap(CatSprites.SLEEP_D)
    private val heartBmp = pixelBitmap(CatSprites.HEART)
    private val exclBmp = pixelBitmap(CatSprites.EXCL)

    private var hunger = prefs.getInt("hunger", 82)
    private var sleepNeed = prefs.getInt("sleep", 88)
    private var mood = prefs.getInt("mood", 78)
    private var sleeping = prefs.getBoolean("sleeping", false)
    private var lastTick = prefs.getLong("last_tick", System.currentTimeMillis())

    private var state = if (sleeping) St.SLEEP else St.SIT
    private var stateUntil = 0L
    private var facingRight = true
    private var x = 0f
    /** Mushukcha "polidan" necha piksel tepada (ko'tarilganda, xabar ustida yoki tushayotganda). */
    private var lift = 0f
    private var vy = 0f
    private var needSync = true
    private var wasHere = true
    private var animTime = 0f
    private var eatEnd = 0L
    private var blinkUntil = 0L
    private var nextBlink = 0L
    private val hearts = ArrayList<Long>()

    // sahifalar orasida yurish
    private var leaveAt = System.currentTimeMillis() + 240_000L

    // xabarlar ustida yurish
    private var perch: View? = null
    private var notified: View? = null
    private var perchWalking = false
    private var perchWalkEnd = 0L
    private var perchDir = 1
    private var perchDecideAt = 0L
    private var perchEndAt = 0L
    private var nextJumpAt = System.currentTimeMillis() + 20000L
    private var jumpStart = 0L
    private var jumpDur = 700L
    private var jumpX0 = 0f
    private var jumpX1 = 0f
    private var jumpL0 = 0f
    private var jumpL1 = 0f
    private var jumpArc = 0f
    private var jumpToFloor = false
    private var landAt = 0L

    // uxlashdan oldin: esnaydi -> yalanadi -> uxlaydi
    private var sleepRoutine = false
    /** Shu uyqu qisqa "mudroq" (nap) bo'lsa true: bir ozdan keyin o'zi uyg'onib, cho'ziladi. */
    private var napPending = false
    private var napUntil = 0L
    /** Sozlamalarga/chatga mudrash uchun kirib kelganda true. */
    private var napOnArrival = false
    private var perchGroomUntil = 0L
    private var perchPendingSleep = false

    // miyovlash: ovoz va "Miyov!" pufagi
    private var soundPool: SoundPool? = null
    private val meowIds = ArrayList<Int>()
    private val meowReady = HashSet<Int>()
    private var soundOn = prefs.getBoolean("cat_sound", true)
    private var lastMeowAt = 0L
    private var meowUntil = 0L
    private var meowText = "Miyov!"
    private val meowTexts = arrayOf("Miyov!", "Miyu~", "Miyov-miyov!", "Mrrr...", "Miyov?")
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bubbleText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = Color.rgb(45, 55, 72)
        textAlign = Paint.Align.CENTER
    }
    private val landDur = 220L

    /** Foydalanuvchi oxirgi marta xabar yozgan payt (uyquchan ko'z uchun). */
    private var lastTypeAt = 0L

    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startLift = 0f
    private var dragging = false
    private var longPressed = false
    private val longPress = Runnable {
        if (!dragging) {
            longPressed = true
            showMenu()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            tick()
            postDelayed(this, 50L)
        }
    }

    init {
        contentDescription = "ZENO virtual mushukchasi. Bosib silash, uzoq bosib menyuni ochish, ushlab ko'tarish mumkin."
        isClickable = true
        // Xiaomi/MIUI "majburiy qorong'u rejim" mushukning sariq rangini to'q qilib yubormasin
        if (android.os.Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
    }

    /** Foydalanuvchi xabar yozayotganini bildiradi (mushukcha uyquchan qaraydi). */
    fun noteTyping() {
        lastTypeAt = System.currentTimeMillis()
    }

    private fun initSound() {
        if (soundPool != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val sp = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
            sp.setOnLoadCompleteListener { _, id, status -> if (status == 0) meowReady.add(id) }
            meowIds.add(sp.load(context, R.raw.meow1, 1))
            meowIds.add(sp.load(context, R.raw.meow2, 1))
            meowIds.add(sp.load(context, R.raw.meow3, 1))
            meowIds.add(sp.load(context, R.raw.meow4, 1))
            soundPool = sp
        } catch (e: Throwable) {
            soundPool = null
        }
    }

    /** Mushukcha miyovlaydi: "Miyov!" pufagi chiqadi va (ovoz yoqilgan bo'lsa) ovoz eshitiladi. */
    private fun meow(now: Long, force: Boolean = false) {
        if (!force && now - lastMeowAt < 6000L) return
        lastMeowAt = now
        meowText = meowTexts[Random.nextInt(meowTexts.size)]
        meowUntil = now + 1600L
        if (soundOn) {
            initSound()
            val id = if (meowIds.isEmpty()) null else meowIds[Random.nextInt(meowIds.size)]
            if (id != null && meowReady.contains(id)) {
                soundPool?.play(id, 0.8f, 0.8f, 1, 0, 0.92f + Random.nextFloat() * 0.16f)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        initSound()
        needSync = true
        removeCallbacks(loop)
        post(loop)
    }

    override fun onDetachedFromWindow() {
        soundPool?.release()
        soundPool = null
        meowIds.clear()
        meowReady.clear()
        saveX()
        removeCallbacks(loop)
        removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }

    /** Ekran ko'rinmay qolsa (boshqa ekran ochilsa) tsikl to'xtaydi, qaytsa joy va holat yangilanadi. */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(loop)
        if (visibility == VISIBLE) {
            needSync = true
            post(loop)
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (!hasWindowFocus) saveX()
    }

    private fun parentWidth(): Int = (parent as? View)?.width ?: 0

    /** Mushukcha ko'tarilishi mumkin bo'lgan eng baland joy (piksel). */
    private fun maxLift(): Float {
        val p = parent as? View ?: return 0f
        val bm = (layoutParams as? FrameLayout.LayoutParams)?.bottomMargin ?: 0
        return max(0f, (p.height - bm - height).toFloat())
    }

    private fun saveX() {
        val pw = parentWidth()
        val maxX = max(0f, (pw - width).toFloat())
        if (pw <= 0 || width <= 0 || maxX <= 0f) return
        prefs.edit().putFloat("x_frac", (x / maxX).coerceIn(0f, 1f)).apply()
    }

    /** Boshqa ekranda o'zgargan holat va joyni yuklaydi, "arrive" bo'lsa chetdan kirib keladi. */
    private fun syncFromPrefs(now: Long, pw: Int) {
        hunger = prefs.getInt("hunger", hunger)
        sleepNeed = prefs.getInt("sleep", sleepNeed)
        mood = prefs.getInt("mood", mood)
        sleeping = prefs.getBoolean("sleeping", sleeping)
        lastTick = prefs.getLong("last_tick", lastTick)
        drawer?.syncFromPrefs()
        val maxX = max(0f, (pw - width).toFloat())
        lift = 0f
        vy = 0f
        perch = null
        perchWalking = false
        leaveAt = now + if (page == "chat") 150_000L + Random.nextLong(150_000L) else 40_000L + Random.nextLong(80_000L)
        nextJumpAt = max(nextJumpAt, now + 8000L)
        if (prefs.getBoolean("arrive", false)) {
            napOnArrival = prefs.getBoolean("cat_nap", false)
            prefs.edit().putBoolean("arrive", false).putBoolean("cat_nap", false).apply()
            if (sleeping) {
                x = Random.nextFloat() * maxX
                state = St.SLEEP
            } else {
                facingRight = Random.nextBoolean()
                x = if (facingRight) -width * 0.7f else maxX + width * 0.7f
                state = St.ENTER
            }
        } else {
            val f = prefs.getFloat("x_frac", -1f)
            if (f >= 0f) x = (f * maxX).coerceIn(0f, maxX)
            state = if (sleeping) St.SLEEP else St.SIT
            stateUntil = now + 1500L
        }
    }

    // ---------------------------------------------------------------- xabarlar ustiga chiqish

    /** Xabar (yoki boshqa ko'rinish) yuzasi: [chap, o'ng, mushukcha oyoqlari shu yerda tursa kerak bo'lgan "lift"]. */
    private fun perchRect(v: View): FloatArray? {
        val p = parent as? View ?: return null
        if (!v.isShown || v.width <= 0 || v.height <= 0) return null
        val a = IntArray(2)
        val b = IntArray(2)
        v.getLocationInWindow(a)
        p.getLocationInWindow(b)
        val bm = (layoutParams as? FrameLayout.LayoutParams)?.bottomMargin ?: 0
        val left = (a[0] - b[0]).toFloat()
        val top = (a[1] - b[1]).toFloat()
        return floatArrayOf(left, left + v.width, p.height - bm - top)
    }

    private fun startJump(now: Long, tx: Float, tl: Float, target: View?, toFloor: Boolean) {
        jumpX0 = x
        jumpX1 = tx
        jumpL0 = lift
        jumpL1 = tl
        jumpToFloor = toFloor
        jumpArc = (if (toFloor) 6 else 14) * cell.toFloat()
        perch = target
        perchWalking = false
        // avval joyida cho'kkalab tayyorlanadi, keyin sakraydi
        jumpStart = now + (if (toFloor) 160L else 300L)
        jumpDur = 600L + min(500L, (abs(tx - x) / density * 1.5f).toLong()) +
            min(300L, (abs(tl - lift) / density * 0.8f).toLong())
        facingRight = tx >= x
        state = St.JUMP
    }

    /** Ko'rinib turgan xabarlardan biriga sakrashni boshlaydi. Mos xabar topilmasa false. */
    private fun tryJump(now: Long, near: Boolean = false): Boolean {
        val finder = perchFinder ?: return false
        val pw = parentWidth()
        if (pw <= 0 || width <= 0) return false
        val maxX = max(0f, (pw - width).toFloat())
        val list = try { finder() } catch (e: Throwable) { emptyList<View>() }
        val ok = ArrayList<Pair<View, FloatArray>>()
        val limit = maxLift()
        for (v in list) {
            if (v === perch) continue
            val r = perchRect(v) ?: continue
            if (r[1] - r[0] < 12 * cell) continue
            if (r[2] < 8 * cell || r[2] > limit) continue
            ok.add(Pair(v, r))
        }
        if (ok.isEmpty()) return false
        val pick = if (near) (ok.minByOrNull { abs(it.second[2] - lift) } ?: ok[0]) else ok[Random.nextInt(ok.size)]
        val r = pick.second
        val spare = max(0f, (r[1] - r[0]) - 12 * cell)
        val cx = r[0] + 6 * cell + Random.nextFloat() * spare
        val tx = (cx - width / 2f).coerceIn(0f, maxX)
        startJump(now, tx, r[2], pick.first, false)
        return true
    }

    /** Xabar ustidan pastga (polga) sakrab tushadi. */
    private fun startDescend(now: Long) {
        val pw = parentWidth()
        val maxX = max(0f, (pw - width).toFloat())
        val dx = (Random.nextFloat() * 2f - 1f) * 10 * cell
        startJump(now, (x + dx).coerceIn(0f, maxX), 0f, null, true)
    }

    /** Tushayotgan mushukcha biror xabarning ustki chetidan o'tib ketsa, shu xabar ustida qoladi. */
    private fun findLanding(prev: Float, cur: Float): Pair<View, Float>? {
        val finder = perchFinder ?: return null
        val list = try { finder() } catch (e: Throwable) { return null }
        val cx = x + width / 2f
        var best: Pair<View, Float>? = null
        for (v in list) {
            val r = perchRect(v) ?: continue
            if (r[2] <= 2 * cell) continue
            if (cx < r[0] + 2 * cell || cx > r[1] - 2 * cell) continue
            if (prev >= r[2] && cur <= r[2]) {
                val b = best
                if (b == null || r[2] > b.second) best = Pair(v, r[2])
            }
        }
        return best
    }

    private fun landPerch(now: Long, byUser: Boolean) {
        landAt = now
        state = St.PERCH
        perchWalking = false
        perchDecideAt = now + if (byUser) 5000L + Random.nextLong(7000L) else 4000L + Random.nextLong(5000L)
        perchEndAt = now + 40_000L + Random.nextLong(50_000L)
        if (!byUser) hearts.add(now)
        else if (Random.nextInt(100) < 30) meow(now)
    }

    /** Xabar suriklib ketdi (yoki yo'qoldi): mushukcha yiqilmaydi, yaqin xabarga sakraydi yoki pastga sakrab tushadi. */
    private fun lostPerch(now: Long) {
        perch = null
        perchWalking = false
        if (!sleeping && tryJump(now, true)) return
        startDescend(now)
    }

    /**
     * Chat surilganda chaqiriladi: xabar ustidagi mushukcha xabar bilan birga, xuddi shu kadrda siljiydi
     * (50 ms lik tsikl kutilmaydi — shuning uchun titramaydi).
     */
    fun onContentMoved() {
        if (state != St.PERCH) return
        val pv = perch ?: return
        val r = perchRect(pv) ?: return
        if (r[2] < 0f || r[2] > maxLift()) return
        lift = r[2]
        translationY = -lift
    }

    private fun endPerch(now: Long) {
        perch = null
        perchWalking = false
        state = St.FALL
        vy = 0f
        nextJumpAt = now + 12_000L + Random.nextLong(18_000L)
    }

    /** Xabar ustidagi mushukcha o'zi hal qiladi: uxlaydi, yuradi, boshqa xabarga sakraydi yoki pastga tushadi. */
    private fun perchDecide(now: Long, r: FloatArray) {
        val d = drawer
        val hungry = d != null && d.canServe() && hunger <= 90
        if (hungry || now >= perchEndAt) {
            startDescend(now)
            return
        }
        val roll = Random.nextInt(100)
        val sleepy = sleepNeed < 45
        when {
            sleepy && roll < 40 -> {
                // uxlashdan oldin o'zini yalab tozalaydi
                perchPendingSleep = true
                perchGroomUntil = now + 4500L
            }
            roll < 35 -> {
                perchWalking = true
                perchDir = if (Random.nextBoolean()) 1 else -1
                perchWalkEnd = now + 2000L + Random.nextLong(3000L)
                perchDecideAt = perchWalkEnd + 1500L + Random.nextLong(2500L)
            }
            roll < 65 -> {
                if (!(sleepNeed >= 40 && tryJump(now))) {
                    perchDecideAt = now + 4000L + Random.nextLong(5000L)
                }
            }
            roll < 82 -> startDescend(now)
            else -> perchDecideAt = now + 4000L + Random.nextLong(5000L)
        }
    }

    private fun startLeave() {
        val pw = parentWidth()
        val maxX = max(0f, (pw - width).toFloat())
        facingRight = x > maxX / 2f
        state = St.LEAVE
    }

    /** Mushukcha ekran chetidan chiqib ketdi: boshqa sahifaga o'tadi. */
    private fun finishLeave(now: Long) {
        val other = if (page == "chat") "settings" else "chat"
        // ba'zan mudrab olish uchun ketadi: u yerda esnab, yalanib, uxlaydi
        val nap = !sleeping && Random.nextInt(100) < 55
        prefs.edit()
            .putString("cat_page", other)
            .putLong("cat_until", now + if (nap) 150_000L + Random.nextLong(150_000L) else 40_000L + Random.nextLong(60_000L))
            .putBoolean("arrive", true)
            .putBoolean("cat_nap", nap)
            .apply()
        state = if (sleeping) St.SLEEP else St.SIT
        stateUntil = now + 1000L
        wasHere = false
        visibility = View.INVISIBLE
    }

    // ---------------------------------------------------------------- asosiy tsikl

    private fun eatTargetX(pw: Int, maxX: Float): Float {
        val d = drawer ?: return x
        return (pw - d.mouthFromRight - 37 * cell).toFloat().coerceIn(0f, maxX)
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        animTime += 0.05f

        // Mushukcha qaysi sahifada ekanini o'zi hal qiladi. Boshqa sahifada bo'lsa, bu yerda ko'rinmaydi.
        var here = prefs.getString("cat_page", "chat") == page
        if (!here && page == "chat" && now >= prefs.getLong("cat_until", 0L)) {
            // sayohatdan uyiga (chatga) qaytadi
            val ed = prefs.edit().putString("cat_page", page).putBoolean("arrive", true)
            if (prefs.getBoolean("cat_nap", false)) {
                // ko'rinmagan joyda mudrab olgan: dam olib qaytadi
                ed.putBoolean("cat_nap", false).putInt("sleep", min(100, prefs.getInt("sleep", sleepNeed) + 35))
            }
            ed.apply()
            here = true
        }
        if (!here) {
            if (visibility != View.INVISIBLE) visibility = View.INVISIBLE
            wasHere = false
            return
        }
        if (!wasHere || visibility != View.VISIBLE) {
            wasHere = true
            visibility = View.VISIBLE
            needSync = true
        }

        updateNeeds(now)
        val pw = parentWidth()
        if (width == 0 || pw == 0) return
        if (needSync && state != St.HELD) {
            needSync = false
            syncFromPrefs(now, pw)
        }
        val maxX = max(0f, (pw - width).toFloat())
        if (state != St.HELD && state != St.FALL && state != St.JUMP && state != St.PERCH &&
            state != St.LEAVE && state != St.ENTER) decide(now, pw, maxX)
        val step = 1.1f * density
        when (state) {
            St.WALK -> {
                x += if (facingRight) step else -step
                if (x <= 0f) { x = 0f; facingRight = true }
                else if (x >= maxX) { x = maxX; facingRight = false }
            }
            St.GO_EAT -> {
                val dx = eatTargetX(pw, maxX) - x
                if (abs(dx) > cell * 2f) {
                    x += if (dx > 0f) step * 1.7f else -step * 1.7f
                    facingRight = dx > 0f
                }
            }
            St.ENTER -> {
                x += if (facingRight) step * 1.4f else -step * 1.4f
                if (x >= 0f && x <= maxX) {
                    if (napOnArrival) {
                        napOnArrival = false
                        startSleepRoutine(now, true)
                    } else {
                        state = St.WALK
                        stateUntil = now + 1500L + Random.nextLong(2000L)
                    }
                }
            }
            St.LEAVE -> {
                x += if (facingRight) step * 1.4f else -step * 1.4f
                if (x <= -width * 0.75f || x >= maxX + width * 0.75f) finishLeave(now)
            }
            St.JUMP -> {
                val pv = perch
                val live = if (!jumpToFloor && pv != null) perchRect(pv) else null
                if (!jumpToFloor && (live == null || live[2] < 4 * cell || live[2] > maxLift())) {
                    perch = null
                    startDescend(now)
                } else {
                    if (live != null) jumpL1 = live[2]
                    val tr = (now - jumpStart).toFloat() / jumpDur
                    val t = tr.coerceIn(0f, 1f)
                    if (tr >= 0f) {
                        x = jumpX0 + (jumpX1 - jumpX0) * t
                        val arc = 4f * jumpArc * t * (1f - t)
                        lift = (jumpL0 + (jumpL1 - jumpL0) * t + arc).coerceIn(0f, maxLift())
                    }
                    if (tr >= 1f) {
                        if (jumpToFloor) {
                            lift = 0f
                            landAt = now
                            state = if (sleeping) St.SLEEP else St.SIT
                            stateUntil = now + 2000L
                            nextJumpAt = now + 12_000L + Random.nextLong(18_000L)
                        } else {
                            lift = jumpL1.coerceIn(0f, maxLift())
                            landPerch(now, false)
                        }
                    }
                }
            }
            St.PERCH -> {
                val pv = perch
                val r = if (pv != null) perchRect(pv) else null
                if (r == null || r[2] < 4 * cell || r[2] > maxLift()) {
                    lostPerch(now)
                } else {
                    lift = r[2]
                    if (sleeping) {
                        // uxlayotgan mushukcha uyg'ongach, bir oz o'tirib, keyin qaror qiladi
                        perchWalking = false
                        perchDecideAt = max(perchDecideAt, now + 4000L)
                    } else {
                        if (perchWalking) {
                            x += perchDir * step * 0.8f
                            facingRight = perchDir > 0
                            val minC = r[0] + 3 * cell
                            val maxC = r[1] - 3 * cell
                            val cx = x + width / 2f
                            if (maxC > minC) {
                                if (cx < minC) { x += minC - cx; perchDir = 1 }
                                else if (cx > maxC) { x -= cx - maxC; perchDir = -1 }
                            }
                            if (now >= perchWalkEnd) perchWalking = false
                        }
                        if (perchPendingSleep && now >= perchGroomUntil) {
                            perchPendingSleep = false
                            sleeping = true
                            save()
                        }
                        if (state == St.PERCH && now >= perchDecideAt && !perchWalking &&
                            !perchPendingSleep && now >= perchGroomUntil) perchDecide(now, r)
                    }
                }
            }
            St.FALL -> {
                val prev = lift
                vy += 1.8f * density
                lift -= vy
                val land = findLanding(prev, lift)
                if (land != null) {
                    perch = land.first
                    lift = land.second
                    vy = 0f
                    landPerch(now, true)
                    saveX()
                } else if (lift <= 0f) {
                    lift = 0f
                    vy = 0f
                    landAt = now
                    state = if (sleeping) St.SLEEP else St.SIT
                    stateUntil = now + 1800L
                    saveX()
                }
            }
            else -> {}
        }
        val ext = state == St.ENTER || state == St.LEAVE
        x = x.coerceIn(if (ext) -width * 0.8f else 0f, if (ext) maxX + width * 0.8f else maxX)
        translationX = x
        translationY = -lift
        if (now > nextBlink) {
            blinkUntil = now + 180L
            nextBlink = now + 2500L + Random.nextLong(3500L)
        }
        // xabar ustida o'tirgan / tushgan holatni chatga bildirish (bo'sh joy ochish uchun)
        val want = if (state == St.PERCH) perch else null
        if (want !== notified) {
            notified = want
            perchListener?.invoke(want)
        }
        invalidate()
    }

    /** Uxlashdan oldin mushuk avval esnaydi, keyin o'zini yalab tozalaydi, so'ng uxlaydi. */
    private fun startSleepRoutine(now: Long, nap: Boolean) {
        sleepRoutine = true
        napPending = nap
        state = St.YAWN
        stateUntil = now + 1800L
    }

    /** Esnash / yalanish / cho'zilish tugaganda. */
    private fun endGesture(now: Long) {
        if (state == St.YAWN && sleepRoutine) {
            state = St.GROOM
            stateUntil = now + 4500L + Random.nextLong(1500L)
        } else if (state == St.GROOM && sleepRoutine) {
            sleepRoutine = false
            sleeping = true
            if (napPending) {
                napUntil = now + 60_000L + Random.nextLong(60_000L)
                napPending = false
            }
            state = St.SLEEP
            save()
        } else {
            state = St.SIT
            stateUntil = now + 2000L + Random.nextLong(2500L)
        }
    }

    private fun decide(now: Long, pw: Int, maxX: Float) {
        if (sleeping) {
            // qisqa mudroqdan o'zi uyg'onadi va cho'ziladi
            if (napUntil > 0L && now >= napUntil) {
                napUntil = 0L
                sleeping = false
                sleepNeed = max(sleepNeed, 65)
                state = St.STRETCH
                stateUntil = now + 2400L
                meow(now)
                save()
                return
            }
            if (state != St.SLEEP) state = St.SLEEP
            return
        }
        if (state == St.SLEEP) {
            state = St.SIT
            stateUntil = now + 2500L
        }
        when (state) {
            St.EAT -> if (now >= eatEnd) finishEating(now)
            St.YAWN, St.GROOM, St.STRETCH, St.MEOW -> if (now >= stateUntil) endGesture(now)
            St.GO_EAT -> {
                val d = drawer
                if (d == null || !d.canServe() || hunger > 90) {
                    state = St.SIT
                    stateUntil = now + 2000L
                } else if (abs(eatTargetX(pw, maxX) - x) <= cell * 2f) {
                    state = St.EAT
                    facingRight = true
                    eatEnd = now + 3600L
                }
            }
            else -> {
                val d = drawer
                if (d != null && d.canServe() && hunger <= 90) {
                    state = St.GO_EAT
                    meow(now)
                    return
                }
                // och qolsa, vaqti-vaqti bilan miyovlab turadi
                if (hunger < 25 && state != St.EAT && now - lastMeowAt > 25_000L) meow(now)
                if (sleepNeed < 15) {
                    startSleepRoutine(now, false)
                    return
                }
                if ((state == St.SIT || state == St.WALK) && lift <= 0f) {
                    val typing = now - lastTypeAt < 8000L
                    // yozayotganingizda ketib qolmaydi
                    if (!typing && now >= leaveAt) {
                        startLeave()
                        return
                    }
                    // dam olgan (uyqusi kelmagan) bo'lsa, xabarlar ustiga chiqib yuradi
                    if (perchFinder != null && sleepNeed >= 40 && now >= nextJumpAt) {
                        nextJumpAt = now + 15000L
                        if (tryJump(now)) return
                    }
                }
                if (now >= stateUntil) {
                    val r = Random.nextInt(100)
                    when {
                        state == St.SIT && r < 40 -> {
                            state = St.WALK
                            facingRight = Random.nextBoolean()
                            stateUntil = now + 2500L + Random.nextLong(3500L)
                        }
                        // o'zini yalab tozalaydi
                        state == St.SIT && r < 52 -> {
                            state = St.GROOM
                            stateUntil = now + 4000L + Random.nextLong(2500L)
                        }
                        state == St.SIT && r < 60 -> {
                            state = St.STRETCH
                            stateUntil = now + 2400L
                        }
                        state == St.SIT && r < 65 -> {
                            state = St.YAWN
                            stateUntil = now + 1800L
                        }
                        // uyqusi kelsa, mudrab olishga yotadi
                        state == St.SIT && r < 70 && sleepNeed < 45 -> startSleepRoutine(now, true)
                        state == St.SIT && r < 76 -> {
                            state = St.MEOW
                            stateUntil = now + 1300L
                            meow(now)
                        }
                        else -> {
                            state = St.SIT
                            stateUntil = now + 2500L + Random.nextLong(4000L)
                        }
                    }
                }
            }
        }
    }

    private fun finishEating(now: Long) {
        hunger = min(100, hunger + 35)
        mood = min(100, mood + 5)
        drawer?.consume()
        hearts.add(now)
        state = St.SIT
        stateUntil = now + 2500L
        save()
    }

    private fun updateNeeds(now: Long) {
        val steps = ((now - lastTick) / 60000L).toInt()
        if (steps > 0) {
            hunger = max(0, hunger - steps)
            sleepNeed = if (!sleeping) max(0, sleepNeed - steps) else min(100, sleepNeed + steps * 2)
            if (sleeping && sleepNeed >= 100) sleeping = false
            if (hunger < 25 || sleepNeed < 20) mood = max(0, mood - steps)
            lastTick += steps * 60000L
            save()
        }
    }

    private fun save() {
        prefs.edit()
            .putInt("hunger", hunger)
            .putInt("sleep", sleepNeed)
            .putInt("mood", mood)
            .putBoolean("sleeping", sleeping)
            .putLong("last_tick", lastTick)
            .apply()
    }

    // ---------------------------------------------------------------- chizish

    /** Uxlayotgan mushukcha: yozayotgan bo'lsangiz, ko'zini yarim ochib, yana yumib uyquchan turadi. */
    private fun sleepBitmap(typing: Boolean): Bitmap {
        if (!typing) return sleepFrames[(animTime / 1.2f).toInt() % 2]
        val c = animTime % 2.8f
        return when {
            c < 1.0f -> sleepHalf
            c < 1.35f -> sleepSlit
            c < 2.1f -> sleepHalf
            else -> sleepFrames[0]
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.currentTimeMillis()
        val typing = now - lastTypeAt < 5000L
        val asleep = (state == St.SLEEP) || (state == St.PERCH && sleeping)
        var bmp: Bitmap
        var flip = false
        var rot = 0f
        when (state) {
            St.SLEEP -> bmp = sleepBitmap(typing)
            St.WALK, St.GO_EAT, St.ENTER, St.LEAVE -> {
                bmp = walkFrames[(animTime / 0.14f).toInt() % 4]
                flip = !facingRight
            }
            St.EAT -> bmp = eatFrames[(animTime / 0.3f).toInt() % 2]
            St.GROOM -> bmp = lickFrames[(animTime / 0.35f).toInt() % 2]
            St.MEOW -> bmp = meowFrames[(animTime / 0.2f).toInt() % 2]
            St.STRETCH -> bmp = stretchFrames[(animTime / 0.6f).toInt() % 2]
            St.YAWN -> bmp = yawnFrames[if (stateUntil - now > 900L) 0 else 1]
            St.HELD -> {
                // ushlab ko'tarilgan mushukcha — oyoqlari osilib, biroz chayqaladi
                bmp = sitFrames[(animTime / 0.3f).toInt() % 2]
                rot = sin(animTime * 7f) * 7f
            }
            St.FALL -> bmp = sitFrames[0]
            St.JUMP -> {
                val tr = (now - jumpStart).toFloat() / jumpDur
                bmp = when {
                    tr < 0f -> if ((now / 90L) % 2L == 0L) jumpFrames[0] else landBmp
                    tr < 0.35f -> jumpFrames[1]
                    tr < 0.62f -> jumpFrames[2]
                    else -> jumpFrames[3]
                }
                flip = !facingRight
            }
            St.PERCH -> {
                if (sleeping) {
                    bmp = sleepBitmap(typing)
                } else if (perchPendingSleep && now < perchGroomUntil) {
                    bmp = lickFrames[(animTime / 0.35f).toInt() % 2]
                } else if (perchWalking) {
                    bmp = walkFrames[(animTime / 0.18f).toInt() % 4]
                    flip = !facingRight
                } else {
                    val tf = (animTime / 0.7f).toInt() % 2
                    bmp = if (typing && sleepNeed < 35) {
                        if (animTime % 3.0f in 1.6f..2.0f) sitBlink[0] else sitDrowsy
                    } else sitFrames[tf]
                }
            }
            else -> {
                val tf = (animTime / 0.7f).toInt() % 2
                bmp = if (typing && sleepNeed < 35) {
                    // uyqusi kelgan mushukcha: ko'zi yarim yopiq, ora-sira butunlay yumiladi
                    if (animTime % 3.0f in 1.6f..2.0f) sitBlink[0] else sitDrowsy
                } else if (now < blinkUntil) sitBlink[tf] else sitFrames[tf]
            }
        }
        val dst = Rect(0, 10 * cell, 40 * cell, 46 * cell)
        // Qo'nganda qisqa vaqt cho'kkalab turadi
        if (now - landAt < landDur && !asleep && !perchWalking &&
            (state == St.SIT || state == St.PERCH)) {
            bmp = landBmp
            flip = !facingRight
        }
        canvas.save()
        if (rot != 0f) canvas.rotate(rot, width / 2f, 12f * cell)
        if (flip) canvas.scale(-1f, 1f, width / 2f, 0f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
        // yuraklar (silaganda / yegandan keyin)
        val it = hearts.iterator()
        while (it.hasNext()) {
            val t0 = it.next()
            val age = (now - t0) / 1400f
            if (age >= 1f) { it.remove(); continue }
            val top = ((9f - age * 8f) * cell).toInt()
            paint.alpha = ((1f - age) * 255f).toInt()
            canvas.drawBitmap(heartBmp, null, Rect(17 * cell, top, 24 * cell, top + 6 * cell), paint)
        }
        paint.alpha = 255
        // miyovlaganda "Miyov!" pufagi
        if (now < meowUntil) {
            val fade = ((meowUntil - now) / 400f).coerceIn(0f, 1f)
            bubbleText.textSize = 3.3f * cell
            val tw = bubbleText.measureText(meowText)
            val bw = tw + 3.5f * cell
            val bh = 5.6f * cell
            val lo = bw / 2f + cell
            val cxm = (if (flip) 14f * cell else 27f * cell).coerceIn(lo, max(lo, width - bw / 2f - cell))
            val top = 0.6f * cell
            bubblePaint.style = Paint.Style.FILL
            bubblePaint.color = Color.argb((235 * fade).toInt(), 255, 255, 255)
            canvas.drawRoundRect(cxm - bw / 2f, top, cxm + bw / 2f, top + bh, 2.4f * cell, 2.4f * cell, bubblePaint)
            bubblePaint.style = Paint.Style.STROKE
            bubblePaint.strokeWidth = 0.35f * cell
            bubblePaint.color = Color.argb((255 * fade).toInt(), 150, 160, 175)
            canvas.drawRoundRect(cxm - bw / 2f, top, cxm + bw / 2f, top + bh, 2.4f * cell, 2.4f * cell, bubblePaint)
            bubbleText.alpha = (255 * fade).toInt()
            canvas.drawText(meowText, cxm, top + bh / 2f + 1.1f * cell, bubbleText)
        }
        // uxlaganda "z"
        if (asleep) {
            for (i in 0..2) {
                val phase = (animTime * 0.4f + i / 3f) % 1f
                textPaint.textSize = (3f + i) * cell
                textPaint.alpha = ((1f - phase) * 255f).toInt()
                canvas.drawText("z", (12f + phase * 8f) * cell, (27f - phase * 17f) * cell, textPaint)
            }
            textPaint.alpha = 255
        }
        // och qolganda "!"
        if (hunger < 25 && !asleep && (animTime * 2f).toInt() % 2 == 0) {
            canvas.drawBitmap(exclBmp, null, Rect(33 * cell, 2 * cell, 36 * cell, 10 * cell), paint)
        }
    }

    // ---------------------------------------------------------------- teginish

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // Mushukdan tashqaridagi (shaffof) joyga tegilsa, chat o'zi ishlayversin
                val inside = event.x >= 3 * cell && event.x <= 37 * cell && event.y >= 10 * cell
                if (!inside) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.rawX
                downY = event.rawY
                startX = x
                startLift = lift
                dragging = false
                longPressed = false
                if (state == St.FALL || state == St.JUMP) {
                    // havodagi mushukchani ushlab olish mumkin
                    perch = null
                    state = St.HELD
                    dragging = true
                } else {
                    postDelayed(longPress, 600L)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx, dy) > 8 * density) {
                    dragging = true
                    removeCallbacks(longPress)
                    perch = null
                    perchWalking = false
                    state = St.HELD
                }
                if (dragging) {
                    val pw = parentWidth().let { if (it > 0) it else width }
                    x = (startX + dx).coerceIn(0f, max(0f, (pw - width).toFloat()))
                    lift = (startLift - dy).coerceIn(0f, maxLift())
                    translationX = x
                    translationY = -lift
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (dragging) release()
                else if (!longPressed) pet()
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) release()
                dragging = false
                return true
            }
        }
        return true
    }

    /** Qo'yib yuborilganda: balandda bo'lsa pastga tushadi (xabarga duch kelsa, o'sha ustida qoladi). */
    private fun release() {
        saveX()
        if (lift > 1f) {
            state = St.FALL
            vy = 0f
        } else {
            lift = 0f
            translationY = 0f
            state = if (sleeping) St.SLEEP else St.SIT
            stateUntil = System.currentTimeMillis() + 2500L
        }
    }

    private fun pet() {
        val now = System.currentTimeMillis()
        mood = min(100, mood + 12)
        if (sleeping) {
            sleeping = false
            if (state == St.SLEEP) {
                state = St.SIT
                stateUntil = now + 2000L
            }
            perchDecideAt = now + 4000L
        }
        hearts.add(now)
        if (!sleeping && Random.nextInt(100) < 40) meow(now)
        napUntil = 0L
        sleepRoutine = false
        save()
        invalidate()
    }

    private fun setSleeping(v: Boolean) {
        val now = System.currentTimeMillis()
        if (v && !sleeping && (state == St.SIT || state == St.WALK)) {
            // avval esnaydi va yalanadi, keyin uxlaydi
            sleepNeed = max(10, sleepNeed)
            startSleepRoutine(now, false)
            return
        }
        if (v && !sleeping && state == St.PERCH) {
            perchPendingSleep = true
            perchGroomUntil = now + 4500L
            return
        }
        sleeping = v
        sleepRoutine = false
        napUntil = 0L
        if (v) sleepNeed = max(10, sleepNeed)
        if (state == St.SIT || state == St.WALK || state == St.SLEEP || state == St.EAT || state == St.GO_EAT ||
            state == St.GROOM || state == St.YAWN || state == St.STRETCH) {
            state = if (v) St.SLEEP else St.SIT
            stateUntil = now + 2000L
        }
        perchDecideAt = now + 4000L
        save()
    }

    private fun showStatus() {
        val status = "Kayfiyat: $mood/100\nOchlik: $hunger/100\nUyqu: $sleepNeed/100\n" +
            if (sleeping) "Holati: uxlayapti" else "Holati: uyg‘oq"
        AlertDialog.Builder(context).setTitle("ZENO mushukchasi").setMessage(status)
            .setPositiveButton("OK", null).show()
    }

    /** Mushukchani uyiga (chat oynasiga, chap pastki burchakka) qaytaradi. Sozlamalarda bo'lsa, chatga qaytadi. */
    private fun goHome() {
        prefs.edit().putFloat("x_frac", 0f).putBoolean("arrive", false).putString("cat_page", "chat").apply()
        x = 0f
        lift = 0f
        vy = 0f
        perch = null
        perchWalking = false
        translationX = 0f
        translationY = 0f
        state = if (sleeping) St.SLEEP else St.SIT
        stateUntil = System.currentTimeMillis() + 2000L
        invalidate()
        val act = context as? Activity
        if (act is SettingsActivity) act.finish()
    }

    /** Mushukcha sozlamalar ekraniga kirib, u yerda yuradi. */
    private fun visitSettings() {
        saveX()
        prefs.edit()
            .putString("cat_page", "settings")
            .putLong("cat_until", System.currentTimeMillis() + 25_000L)
            .putBoolean("arrive", true)
            .apply()
        context.startActivity(Intent(context, SettingsActivity::class.java))
    }

    private fun showMenu() {
        val d = drawer
        val inSettings = (context as? Activity) is SettingsActivity
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        labels.add(if (sleeping) "Uyg‘otish" else "Uxlatish")
        actions.add { setSleeping(!sleeping) }
        labels.add(if (d != null && d.isOpen) "Ovqat idishini yopish" else "Ovqat idishini ochish")
        actions.add { drawer?.toggle() }
        labels.add("Holatini ko‘rish")
        actions.add { showStatus() }
        labels.add(if (inSettings) "Uyiga qaytarish (chatga)" else "Uyiga qaytarish")
        actions.add { goHome() }
        labels.add("Miyovlatish")
        actions.add { meow(System.currentTimeMillis(), true) }
        labels.add(if (soundOn) "Ovozni o‘chirish" else "Ovozni yoqish")
        actions.add {
            soundOn = !soundOn
            prefs.edit().putBoolean("cat_sound", soundOn).apply()
            Toast.makeText(context, if (soundOn) "Mushukcha ovozi yoqildi" else "Mushukcha ovozi o‘chirildi", Toast.LENGTH_SHORT).show()
        }
        if (perchFinder != null) {
            labels.add("Xabar ustiga sakrash")
            actions.add {
                if (sleeping) {
                    Toast.makeText(context, "Mushukcha uxlayapti", Toast.LENGTH_SHORT).show()
                } else if (!(state == St.SIT || state == St.WALK || state == St.PERCH) ||
                    !tryJump(System.currentTimeMillis())) {
                    Toast.makeText(context, "Sakrash uchun mos xabar topilmadi", Toast.LENGTH_SHORT).show()
                }
            }
        }
        if (!inSettings) {
            labels.add("Sozlamalarga kirib yurish")
            actions.add { visitSettings() }
        }
        AlertDialog.Builder(context).setTitle("Mushukcha")
            .setItems(labels.toTypedArray()) { _, which -> actions.getOrNull(which)?.invoke() }
            .show()
    }
}

/**
 * Ilova chetidan biroz chiqib turgan strelkali tutqich. Uni tortsangiz, ichida ovqati bor idish chiqadi;
 * mushukcha och bo'lsa, shu yerga kelib yeydi.
 */
class FoodDrawerView(context: Context) : View(context) {
    private val cell = pixelCell(context)
    private val density = resources.displayMetrics.density
    private val handleW = 10 * cell
    val viewWidth = 38 * cell
    val viewHeight = 22 * cell
    private val closedTx = (viewWidth - handleW).toFloat()

    /** Ekranning o'ng chetidan mushukning og'zi turishi kerak bo'lgan masofa. */
    val mouthFromRight = 22 * cell

    private val prefs = context.getSharedPreferences("zeno_cat", Context.MODE_PRIVATE)

    var isOpen = false
        private set
    private var food = 3

    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val bowls = arrayOf(
        pixelBitmap(CatSprites.BOWL_0), pixelBitmap(CatSprites.BOWL_1),
        pixelBitmap(CatSprites.BOWL_2), pixelBitmap(CatSprites.BOWL_3)
    )
    private val handleBmp = pixelBitmap(CatSprites.HANDLE)

    private var downRaw = 0f
    private var startTx = 0f
    private var downLocalX = 0f
    private var moved = false

    init {
        contentDescription = "Mushukcha ovqat idishi. Strelkani tortsangiz, idish chiqadi."
        isClickable = true
        food = prefs.getInt("food", 3).coerceIn(0, 3)
        isOpen = prefs.getBoolean("drawer_open", false)
        translationX = if (isOpen) 0f else closedTx
        if (android.os.Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
    }

    private fun saveState() {
        prefs.edit().putInt("food", food).putBoolean("drawer_open", isOpen).apply()
    }

    /** Boshqa ekrandagi (chat/sozlamalar) idish holatini yuklaydi. */
    fun syncFromPrefs() {
        food = prefs.getInt("food", food).coerceIn(0, 3)
        isOpen = prefs.getBoolean("drawer_open", isOpen)
        animate().cancel()
        translationX = if (isOpen) 0f else closedTx
        invalidate()
    }

    fun canServe(): Boolean = isOpen && food > 0 && translationX < closedTx * 0.15f

    fun consume() {
        if (food > 0) food--
        saveState()
        invalidate()
    }

    fun toggle() = setOpen(!isOpen)

    private fun setOpen(open: Boolean) {
        if (open && !isOpen) food = 3
        isOpen = open
        saveState()
        animate().cancel()
        animate().translationX(if (open) 0f else closedTx).setDuration(200L).start()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bowl = bowls[food.coerceIn(0, 3)]
        canvas.drawBitmap(bowl, null, Rect(handleW, viewHeight - 20 * cell, handleW + 28 * cell, viewHeight), paint)
        val hTop = viewHeight - 17 * cell
        val hDst = Rect(0, hTop, handleW, hTop + 14 * cell)
        if (isOpen) {
            canvas.save()
            canvas.scale(-1f, 1f, handleW / 2f, 0f)
            canvas.drawBitmap(handleBmp, null, hDst, paint)
            canvas.restore()
        } else {
            canvas.drawBitmap(handleBmp, null, hDst, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animate().cancel()
                downRaw = e.rawX
                startTx = translationX
                downLocalX = e.x
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRaw
                if (abs(dx) > 6 * density) moved = true
                if (moved) translationX = (startTx + dx).coerceIn(0f, closedTx)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    setOpen(translationX < closedTx * 0.5f)
                } else if (downLocalX < handleW) {
                    toggle()
                } else if (isOpen && food == 0) {
                    food = 3
                    saveState()
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                setOpen(isOpen)
                return true
            }
        }
        return true
    }
}
