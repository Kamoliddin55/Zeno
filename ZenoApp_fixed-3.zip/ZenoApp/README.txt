ZENO — telefonga o'rnatish

1) Android Studio'ni oching: File > Open > shu "ZenoApp" papkasini tanlang.
2) Gradle sinxronlanishini kuting (birinchi marta bir necha daqiqa, internet kerak).
3) Telefonda: Sozlamalar > Telefon haqida > "Build raqami"ni 7 marta bosing,
   so'ng Dasturchi sozlamalari > "USB orqali nosozliklarni tuzatish"ni yoqing.
4) Telefonni USB bilan ulang, ruxsat bering, Android Studio'da yashil ▶ (Run) tugmasini bosing.

APK fayl olish (boshqa telefonga yuborish uchun):
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   Fayl: app/build/outputs/apk/debug/app-debug.apk
   Telefonda faylni oching va "Noma'lum manbalardan o'rnatish"ga ruxsat bering.

Birinchi ishga tushirgandan keyin: Sozlamalar (menyu) ichida bildirishnoma,
foydalanish statistikasi, batareya cheklovi va avtostart ruxsatlarini yoqing.

KOMPYUTERSIZ (faqat telefon bilan):
1) github.com'da bepul akkaunt oching, yangi repository yarating.
2) "Add file > Upload files" orqali shu papkadagi hamma fayllarni (.github papkasi bilan) yuklang.
3) "Actions" bo'limiga kiring, "APK yig'ish" ishini kuting (5-10 daqiqa).
4) Tugagach, ish ichidagi "Zeno-APK" faylini yuklab oling, zipdan chiqarib, app-debug.apk ni o'rnating.


Eslatma: ilgari README'da "10 000 yozuvli ichki baza" haqida yozilgan edi — bu eskirgan.
Hozirgi holat pastdagi "ICHKI BAZA" bo'limida: ilova ichida faqat suhbat uchun zarur narsalar bor,
qolgan bilimlar foydalanuvchining .txt fayllaridan o'qiladi.


Bildirishnoma rasmlari:
- Sozlamalar > "Bildirishnoma rasmlari (o'ng tomonda)" bo'limida har bir bildirishnoma turi uchun
  galereyadan o'z rasmingizni tanlang ("Rasm" tugmasi), olib tashlash uchun "✕" bosing.
- "Hammasi uchun umumiy rasm" — rasmi tanlanmagan turlar uchun zaxira rasm.


Maqsad va xotira funksiyalari:
- Suhbatda: maqsad: Ingliz tili | 18:00 — maqsadni har kuni shu vaqtga eslatma bilan saqlaydi.
- Oddiy jumlada ham aytish mumkin: Har kuni 18:00 da ingliz tilini o‘rganaman.
- maqsadlarim — ochiq maqsadlarni ko‘rish; tayyor 1 — maqsadni bajarilgan deb belgilash.
- eslab qol: <matn> — xotiraga qo‘lda saqlash; /xotira — ko‘rish; /unut <raqam> — o‘chirish.
- Sozlamalar ichida maqsad qo‘shish va xotiraga ma’lumotni qo‘lda saqlash tugmalari ham bor.
- Eslatmalar fon rejimidagi tekshiruvga bog‘liq; Android/MIUI batareya cheklovlari sababli aniq daqiqada kelishi kafolatlanmaydi. Bildirishnoma ruxsati, avtostart va batareya sozlamalarini tekshiring.

--- BILIMLAR FAYLLARI ---
ZENO savol-javoblarni oddiy .txt fayllardan o'qiydi (APK ichida emas).
Format (namuna: bilimlar_namuna/namuna.txt):
  Bo'lim: Anime                 (ixtiyoriy)
  |One Piece|                   (mavzu; nomi - asosiy kalit)
  Kalit: van pis, luffy, zoro   (mavzuning qo'shimcha kalitlari)
  Savol: Luffy kim?
  Javob: ...
Suhbatda mavzu kaliti aytilsa shu mavzu faollashadi va keyingi 10 ta xabar davomida
savollar avval shu mavzu ichidan qidiriladi. Topilmasa "aniq emas" deydi.
Mavzuni almashtirish: |Naruto| yoki mavzu kalitini aytish. Boshqa buyruqlar:
mavzular, mavzu, mavzu yo'q.
Sozlamalar -> "Bilimlar fayllari" bo'limida papka tanlanadi.

--- ICHKI BAZA ---
Ilova ichida faqat suhbat uchun kerakli narsalar qoldirilgan: salomlashish va oddiy gaplar,
maslahat/motivatsiya javoblari, hisob-kitob funksiyalari (foiz, BMI, tenglama, birlik o'girish va h.k.).
Maktab, o'yin, islom, umumiy bilim, til va texnologiya ma'lumotlari olib tashlangan —
ularni foydalanuvchi o'zining .txt fayllari orqali qo'shadi.

--- PAPKA TUZILMASI ---
Tanlangan papka ichidagi ichki papkalar ham o'qiladi:
  Zeno-Papka/Anime/One Piece.txt        -> bo'lim: Anime, mavzu: One Piece
  Zeno-Papka/Anime/One Piece/baza.txt   -> bo'lim: Anime, mavzu: One Piece
Faylda |Mavzu| yozilgan bo'lsa, shu yozuv ustun turadi.

--- BUILD HAQIDA ---
Loyihada gradlew / gradle-wrapper.jar yo'q. Android Studio o'zi Gradle'ni sozlaydi,
GitHub Actions ham Gradle 8.7 ni o'zi o'rnatadi (.github/workflows/build.yml).
Qo'lda ./gradlew kerak bo'lsa, Android Studio terminalida: gradle wrapper

YANGI: 2D virtual mushukcha
- Chat oynasi ustida yuradi, barmoq bilan sudrab joyini o'zgartirish mumkin.
- Bir marta bosish mushukchani silaydi; uzoq bosish menyuni ochadi.
- Menyudan ovqat berish, uxlatish/uyg'otish, rangini tanlash va holatini ko'rish mumkin.
- Ochlik, uyqu va kayfiyat qiymatlari telefon xotirasida saqlanadi.

Mushukcha tuzatishlari:
- Mushukcha endi View.translationX bilan harakatlanadi (oldin o'z chegarasidan chiqib kesilib ketardi va bosib bo'lmasdi).
- Uxlaganda/pirpiraganda ochiq ko'zlar ham chizilib qolishi tuzatildi.
- Uyqu 100 ga yetganda mushuk o'zi uyg'onadi.
- MIUI/majburiy qorong'u rejimda mushukcha to'q jigarrang bo'lib qolishi tuzatildi (isForceDarkAllowed = false).

PIKSELLI MUSHUKCHA (yangi dizayn):
- Sariq pikselli mushuk: o'tiradi (dumini qimirlatadi, pirpiraydi), yuradi, uxlaydi (z-z-z) va ovqat yeydi.
- Ilova o'ng chetidan strelkali ko'k tutqich biroz chiqib turadi. Uni bosing yoki chapga torting —
  ichida ovqat solingan idish chiqadi. Mushuk och bo'lsa, o'zi kelib yeydi (har safar bir porsiya, jami 3 porsiya).
  Idish bo'shab qolsa, bo'sh idishni bosing yoki strelkani yopib qayta oching — yangi ovqat solinadi.
- Mushukni bosing — silaysiz (yuracha); uzoq bosing — menyu (uxlatish, idishni ochish/yopish, holat); sudrab joyini o'zgartiring.
- Mushukning ochlik/uyqu/kayfiyati telefon xotirasida saqlanadi. Rasmlar CatSprites.kt ichida (kod bilan chiziladi, fayl kerak emas).

YANGI: savol tavsiyalari
- Savolda mavzu kaliti aytilsa (masalan "bomdod"), lekin savol aniq bo'lmasa, ZENO shu mavzudagi savollar ro'yxatini ko'rsatadi.
- Faol mavzu bo'lib javob topilmasa ham, shu mavzuning savollari tavsiya qilinadi.
- Qisqa xabarda ("namoz", "tahorat") so'z bir nechta mavzuga mos kelsa, mavzular ro'yxati chiqadi.

MUSHUKCHA YANGILANISHI (2):
- Yon tomondan ko'rinishi qayta chizildi: yurish 4 kadr, yangi ovqat yeyish va uxlash rasmlari (uxlaganda dumi kesilmaydi).
- Mushukchani ushlab istalgan tomonga, jumladan tepaga ko'tarish mumkin. Qo'yib yuborsangiz, pastga tushadi (havoda qaytadan ushlab olsa ham bo'ladi).
- Mushukcha sozlamalar ekranida ham yuradi. Uzoq bosib menyuni oching:
    "Sozlamalarga kirib yurish" — mushukcha sozlamalarga chap tomondan kirib keladi;
    "Uyiga qaytarish" — mushukcha chat oynasidagi uyiga (chap pastki burchak) qaytadi; sozlamalarda bo'lsa, chatga o'tadi.
- Mushukning joyi va ovqat idishi holati ikkala ekran orasida saqlanadi.

MUSHUKCHA XABAR USTIGA SAKRAYDI:
- Chat ekranida mushukcha taxminan 45-90 soniyada bir marta ko'rinib turgan xabarlardan biri ustiga sakrab chiqadi,
  u yerda bir necha soniya o'tiradi va pastga sakrab tushadi (ochiq qolsa yoki och bo'lsa, ertaroq tushadi).
- Chat suriladigan bo'lsa, mushukcha xabar bilan birga yuradi; xabar ko'rinmay qolsa, pastga tushadi.
- Xabar ustidagi mushukchani ushlab olib, boshqa joyga qo'yish mumkin.
- Hoziroq ko'rish uchun: mushukchani uzoq bosib, menyudan "Xabar ustiga sakrash"ni tanlang.

ALOQA (bog'liq mavzular) VA RAQAM BILAN TANLASH:
- Mavzu ostiga "Aloqa:" qatorini yozing:
      |Somon qalpoqlilar|
      Kalit: luffy komandasi, ekipaj
      Aloqa: Zoro, Nami, Usopp
  "Luffy komandasi haqida" desangiz, ZENO shu mavzuning va bog'langan mavzularning savollarini raqamlab chiqaradi:
      1. Zoro kim?
      2. Nami kim?
      ...
  Siz faqat raqamni yozasiz (masalan: 2) va ZENO shu savolga javob beradi.
- Raqam ro'yxat chiqqandan keyin 5 daqiqa davomida ishlaydi. Faqat raqam yozilgan xabar tanlash hisoblanadi.
- Aloqa: dagi nom mavzu nomi bilan bir xil bo'lishi kerak. Topilmasa, Sozlamalardagi muammolar ro'yxatida ko'rinadi.
- Aloqa bir tomonlama: Zoro mavzusidan ham Luffy komandasiga o'tish kerak bo'lsa, Zoro ostiga ham "Aloqa:" yozing.
- Savol aniq bo'lmasa va so'z bir nechta mavzuga mos kelsa, mavzular ham raqamlab chiqadi.

MUSHUKCHA — O'Z HAYOTI (3):
- Mushukcha qayerga borishini o'zi hal qiladi: ba'zan ekran chetidan chiqib sozlamalar sahifasiga ketadi
  (chatda ko'rinmay qoladi), 40-100 soniyadan so'ng chetdan yurib qaytib keladi. Yozayotganingizda ketmaydi.
  Sozlamalarni ochsangiz, u yerda bo'lsa, ko'rasiz. Chatda "mushuk kel" deb yozsangiz, chaqiriladi.
- Xabarlar ustida: dam olgan mushukcha xabar ustiga sakrab chiqadi, ustida yuradi, boshqa xabarga sakraydi,
  uxlaydi yoki pastga sakrab tushadi. Xabar ustiga chiqqanda xabarlar orasida unga joy ochiladi.
- Ushlab ko'tarib, xabar ustiga tushirsangiz — o'sha yerda qoladi (xohlasa uxlaydi, xohlasa pastga tushadi).
  Uxlab yotgan mushukni ko'tarib qo'ysangiz, qo'ygan joyingizda uxlayveradi.
- Uxlab yotganda xabar yozsangiz, mushukcha ko'zini yarim ochib, uyquchan qaraydi va yana yumadi.
  Uyqusi kelgan (uyqu darajasi past) mushukcha o'tirganda ham ko'zi yarim yopiq turadi.

RASM QO'SHISH (bilimlar fayllarida):
- Javob dan keyin "Rasm:" qatori yozing:
      Savol: Tahorat qanday olinadi?
      Javob: ...
      Rasm: tahorat_tartibi.png
- Rasm fayli (.png, .jpg, .jpeg, .webp) bilimlar papkasining istalgan joyida (txt bilan bir papkada ham) turishi mumkin.
  Fayl nomi bo'yicha topiladi. Rasm javob pufagining tagida chiqadi.
- Rasm topilmasa, javob matni rasmsiz chiqadi.

MUSHUKCHA (4): TITRASH TUZATILDI, SAKRASH HARAKATLARI
- Xabar ustidagi mushukcha endi chat surilganda xabar bilan birga, xuddi shu kadrda siljiydi (oldin 50 ms tsiklda orqada qolib titrardi).
- Xabar surilib ketsa yoki ko'rinmay qolsa, mushukcha yiqilib tushmaydi: o'sha balandlikka yaqin boshqa xabarga sakraydi yoki pastga sakrab tushadi.
- Sakrash uchun alohida rasmlar chizildi: cho'kkalash, sakrab chiqish, eng tepada (oyoqlar yig'ilgan), tushish (oyoqlar oldinga) va qo'nish.
- Mushukcha endi tez-tez (12-30 soniyada) boshqa xabarlarga sakrab yuradi.
- Sakrashdan oldin mushukcha joyida ~0,3 soniya cho'kkalab (dumbasini qimirlatib) tayyorlanadi, keyin sakraydi.

MUSHUKCHA (5): QIZIQARLI HARAKATLAR, MUDRASH VA MIYOVLASH
- Yangi kadrlar: yalanish (o'zini tozalash), esnash, cho'zilish, miyovlash.
- Uxlashdan oldin mushukcha avval esnaydi, keyin yalanib tozalanadi, so'ng uxlaydi.
- Mushukcha meni kutmasdan o'zi sozlamalar sahifasiga "mudrab olgani" ketishi mumkin: u yerda esnaydi, yalanadi, uxlaydi
  (taxminan 1-2 daqiqa), uyg'ongach cho'ziladi. Sozlamalarni o'sha paytda ochsangiz, uni ko'rasiz.
  Ko'rinmagan joyda mudrab olsa, dam olib qaytadi.
- Miyovlash: "Miyov!" pufagi + ovoz (res/raw/meow1..4.wav, sintez qilingan; o'zingizning miyov yozuvingiz bilan almashtirsangiz bo'ladi). Mushukcha miyovlaydi:
  silaganda, och qolganda, ovqatga borayotganda, ko'tarib qo'ygandan keyin va ba'zan o'zi.
  Menyudan "Miyovlatish" va "Ovozni o'chirish/yoqish" mumkin.

YANGI IKONKA (F variant): neon halqa, toj kiygan mushuk va orqada Z.
- res/drawable-nodpi/ic_launcher_bg.png, ic_launcher_fg.png, ic_launcher_mono.png (Android 13 "mavzuli" ikonka uchun oq siluet)
- res/mipmap-anydpi-v26/ic_launcher.xml va ic_launcher_round.xml yangilandi. Eski ic_launcher_foreground.xml olib tashlandi.

YANGI OCHILISH RASMI: toj kiygan piksel mushuk, neon halqa, ZENO yozuvi (res/drawable-nodpi/zeno_splash.webp, 941x1672).
Ochilganda rasm 0,6 soniya ichida yumshoq paydo bo'ladi (SplashActivity). Umumiy ko'rsatilish vaqti avvalgidek 1,6 soniya.

OCHILISH RASMI (2): "Do'st va hamroh" va "ZENO yuklanmoqda..." yozuvlari olib tashlandi.
"ZENO" yozuvi alohida qatlam (res/drawable-nodpi/zeno_wordmark.png, layout: splashWordmark):
pastdan xira va g'ubor holda ko'tarilib, tiniqlashib chiqadi (0,15 s kutadi, 0,95 s davom etadi). G'uborlik Android 12+ da ishlaydi,
eski telefonlarda xira holdan ravshanlashish va ko'tarilish ishlaydi.
