ZENO — telefonga o'rnatish

1) Android Studio'ni oching: File > Open > shu "ZenoApp" papkasini tanlang.
2) Gradle sinxronlanishini kuting (birinchi marta bir necha daqiqa, internet kerak).
3) Telefonda: Sozlamalar > Telefon haqida > "Build raqami"ni 7 marta bosing,
   so'ng Dasturchi sozlamalari > "USB orqali nosozliklarni tuzatish"ni yoqing.
4) Telefonni USB bilan ulang, ruxsat bering, Android Studio'da yashil ▶ (Run) tugmasini bosing.

APK fayl olish (boshqa telefonga yuborish uchun):
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   Fayl: app/build/outputs/apk/debug/app-debug.apk
   Telefonda faylni oching va "Noma'lum manbalardan o'rnatish"ga ruxsat bering.

Birinchi ishga tushirgandan keyin: Sozlamalar (menyu) ichida bildirishnoma,
foydalanish statistikasi, batareya cheklovi va avtostart ruxsatlarini yoqing.

KOMPYUTERSIZ (faqat telefon bilan):
1) github.com'da bepul akkaunt oching, yangi repository yarating.
2) "Add file > Upload files" orqali shu papkadagi hamma fayllarni (.github papkasi bilan) yuklang.
3) "Actions" bo'limiga kiring, "APK yig'ish" ishini kuting (5-10 daqiqa).
4) Tugagach, ish ichidagi "Zeno-APK" faylini yuklab oling, zipdan chiqarib, app-debug.apk ni o'rnating.


Eslatma: ilgari README'da "10 000 yozuvli ichki baza" haqida yozilgan edi — bu eskirgan.
Hozirgi holat pastdagi "ICHKI BAZA" bo'limida: ilova ichida faqat suhbat uchun zarur narsalar bor,
qolgan bilimlar foydalanuvchining .txt fayllaridan o'qiladi.


Bildirishnoma rasmlari:
- Sozlamalar > "Bildirishnoma rasmlari (o'ng tomonda)" bo'limida har bir bildirishnoma turi uchun
  galereyadan o'z rasmingizni tanlang ("Rasm" tugmasi), olib tashlash uchun "✕" bosing.
- "Hammasi uchun umumiy rasm" — rasmi tanlanmagan turlar uchun zaxira rasm.


Maqsad va xotira funksiyalari:
- Suhbatda: maqsad: Ingliz tili | 18:00 — maqsadni har kuni shu vaqtga eslatma bilan saqlaydi.
- Oddiy jumlada ham aytish mumkin: Har kuni 18:00 da ingliz tilini o‘rganaman.
- maqsadlarim — ochiq maqsadlarni ko‘rish; tayyor 1 — maqsadni bajarilgan deb belgilash.
- eslab qol: <matn> — xotiraga qo‘lda saqlash; /xotira — ko‘rish; /unut <raqam> — o‘chirish.
- Sozlamalar ichida maqsad qo‘shish va xotiraga ma’lumotni qo‘lda saqlash tugmalari ham bor.
- Eslatmalar fon rejimidagi tekshiruvga bog‘liq; Android/MIUI batareya cheklovlari sababli aniq daqiqada kelishi kafolatlanmaydi. Bildirishnoma ruxsati, avtostart va batareya sozlamalarini tekshiring.

--- BILIMLAR FAYLLARI ---
ZENO savol-javoblarni oddiy .txt fayllardan o'qiydi (APK ichida emas).
Format (namuna: bilimlar_namuna/namuna.txt):
  Bo'lim: Anime                 (ixtiyoriy)
  |One Piece|                   (mavzu; nomi - asosiy kalit)
  Kalit: van pis, luffy, zoro   (mavzuning qo'shimcha kalitlari)
  Savol: Luffy kim?
  Javob: ...
Suhbatda mavzu kaliti aytilsa shu mavzu faollashadi va keyingi 10 ta xabar davomida
savollar avval shu mavzu ichidan qidiriladi. Topilmasa "aniq emas" deydi.
Mavzuni almashtirish: |Naruto| yoki mavzu kalitini aytish. Boshqa buyruqlar:
mavzular, mavzu, mavzu yo'q.
Sozlamalar -> "Bilimlar fayllari" bo'limida papka tanlanadi.

--- ICHKI BAZA ---
Ilova ichida faqat suhbat uchun kerakli narsalar qoldirilgan: salomlashish va oddiy gaplar,
maslahat/motivatsiya javoblari, hisob-kitob funksiyalari (foiz, BMI, tenglama, birlik o'girish va h.k.).
Maktab, o'yin, islom, umumiy bilim, til va texnologiya ma'lumotlari olib tashlangan —
ularni foydalanuvchi o'zining .txt fayllari orqali qo'shadi.

--- PAPKA TUZILMASI ---
Tanlangan papka ichidagi ichki papkalar ham o'qiladi:
  Zeno-Papka/Anime/One Piece.txt        -> bo'lim: Anime, mavzu: One Piece
  Zeno-Papka/Anime/One Piece/baza.txt   -> bo'lim: Anime, mavzu: One Piece
Faylda |Mavzu| yozilgan bo'lsa, shu yozuv ustun turadi.

--- BUILD HAQIDA ---
Loyihada gradlew / gradle-wrapper.jar yo'q. Android Studio o'zi Gradle'ni sozlaydi,
GitHub Actions ham Gradle 8.7 ni o'zi o'rnatadi (.github/workflows/build.yml).
Qo'lda ./gradlew kerak bo'lsa, Android Studio terminalida: gradle wrapper

YANGI: 2D virtual mushukcha
- Chat oynasi ustida yuradi, barmoq bilan sudrab joyini o'zgartirish mumkin.
- Bir marta bosish mushukchani silaydi; uzoq bosish menyuni ochadi.
- Menyudan ovqat berish, uxlatish/uyg'otish, rangini tanlash va holatini ko'rish mumkin.
- Ochlik, uyqu va kayfiyat qiymatlari telefon xotirasida saqlanadi.

Mushukcha tuzatishlari:
- Mushukcha endi View.translationX bilan harakatlanadi (oldin o'z chegarasidan chiqib kesilib ketardi va bosib bo'lmasdi).
- Uxlaganda/pirpiraganda ochiq ko'zlar ham chizilib qolishi tuzatildi.
- Uyqu 100 ga yetganda mushuk o'zi uyg'onadi.
- MIUI/majburiy qorong'u rejimda mushukcha to'q jigarrang bo'lib qolishi tuzatildi (isForceDarkAllowed = false).

PIKSELLI MUSHUKCHA (yangi dizayn):
- Sariq pikselli mushuk: o'tiradi (dumini qimirlatadi, pirpiraydi), yuradi, uxlaydi (z-z-z) va ovqat yeydi.
- Ilova o'ng chetidan strelkali ko'k tutqich biroz chiqib turadi. Uni bosing yoki chapga torting —
  ichida ovqat solingan idish chiqadi. Mushuk och bo'lsa, o'zi kelib yeydi (har safar bir porsiya, jami 3 porsiya).
  Idish bo'shab qolsa, bo'sh idishni bosing yoki strelkani yopib qayta oching — yangi ovqat solinadi.
- Mushukni bosing — silaysiz (yuracha); uzoq bosing — menyu (uxlatish, idishni ochish/yopish, holat); sudrab joyini o'zgartiring.
- Mushukning ochlik/uyqu/kayfiyati telefon xotirasida saqlanadi. Rasmlar CatSprites.kt ichida (kod bilan chiziladi, fayl kerak emas).

YANGI: savol tavsiyalari
- Savolda mavzu kaliti aytilsa (masalan "bomdod"), lekin savol aniq bo'lmasa, ZENO shu mavzudagi savollar ro'yxatini ko'rsatadi.
- Faol mavzu bo'lib javob topilmasa ham, shu mavzuning savollari tavsiya qilinadi.
- Qisqa xabarda ("namoz", "tahorat") so'z bir nechta mavzuga mos kelsa, mavzular ro'yxati chiqadi.

MUSHUKCHA YANGILANISHI (2):
- Yon tomondan ko'rinishi qayta chizildi: yurish 4 kadr, yangi ovqat yeyish va uxlash rasmlari (uxlaganda dumi kesilmaydi).
- Mushukchani ushlab istalgan tomonga, jumladan tepaga ko'tarish mumkin. Qo'yib yuborsangiz, pastga tushadi (havoda qaytadan ushlab olsa ham bo'ladi).
- Mushukcha sozlamalar ekranida ham yuradi. Uzoq bosib menyuni oching:
    "Sozlamalarga kirib yurish" — mushukcha sozlamalarga chap tomondan kirib keladi;
    "Uyiga qaytarish" — mushukcha chat oynasidagi uyiga (chap pastki burchak) qaytadi; sozlamalarda bo'lsa, chatga o'tadi.
- Mushukning joyi va ovqat idishi holati ikkala ekran orasida saqlanadi.

MUSHUKCHA XABAR USTIGA SAKRAYDI:
- Chat ekranida mushukcha taxminan 45-90 soniyada bir marta ko'rinib turgan xabarlardan biri ustiga sakrab chiqadi,
  u yerda bir necha soniya o'tiradi va pastga sakrab tushadi (ochiq qolsa yoki och bo'lsa, ertaroq tushadi).
- Chat suriladigan bo'lsa, mushukcha xabar bilan birga yuradi; xabar ko'rinmay qolsa, pastga tushadi.
- Xabar ustidagi mushukchani ushlab olib, boshqa joyga qo'yish mumkin.
- Hoziroq ko'rish uchun: mushukchani uzoq bosib, menyudan "Xabar ustiga sakrash"ni tanlang.

ALOQA (bog'liq mavzular) VA RAQAM BILAN TANLASH:
- Mavzu ostiga "Aloqa:" qatorini yozing:
      |Somon qalpoqlilar|
      Kalit: luffy komandasi, ekipaj
      Aloqa: Zoro, Nami, Usopp
  "Luffy komandasi haqida" desangiz, ZENO shu mavzuning va bog'langan mavzularning savollarini raqamlab chiqaradi:
      1. Zoro kim?
      2. Nami kim?
      ...
  Siz faqat raqamni yozasiz (masalan: 2) va ZENO shu savolga javob beradi.
- Raqam ro'yxat chiqqandan keyin 5 daqiqa davomida ishlaydi. Faqat raqam yozilgan xabar tanlash hisoblanadi.
- Aloqa: dagi nom mavzu nomi bilan bir xil bo'lishi kerak. Topilmasa, Sozlamalardagi muammolar ro'yxatida ko'rinadi.
- Aloqa bir tomonlama: Zoro mavzusidan ham Luffy komandasiga o'tish kerak bo'lsa, Zoro ostiga ham "Aloqa:" yozing.
- Savol aniq bo'lmasa va so'z bir nechta mavzuga mos kelsa, mavzular ham raqamlab chiqadi.

MUSHUKCHA — O'Z HAYOTI (3):
- Mushukcha qayerga borishini o'zi hal qiladi: ba'zan ekran chetidan chiqib sozlamalar sahifasiga ketadi
  (chatda ko'rinmay qoladi), 40-100 soniyadan so'ng chetdan yurib qaytib keladi. Yozayotganingizda ketmaydi.
  Sozlamalarni ochsangiz, u yerda bo'lsa, ko'rasiz. Chatda "mushuk kel" deb yozsangiz, chaqiriladi.
- Xabarlar ustida: dam olgan mushukcha xabar ustiga sakrab chiqadi, ustida yuradi, boshqa xabarga sakraydi,
  uxlaydi yoki pastga sakrab tushadi. Xabar ustiga chiqqanda xabarlar orasida unga joy ochiladi.
- Ushlab ko'tarib, xabar ustiga tushirsangiz — o'sha yerda qoladi (xohlasa uxlaydi, xohlasa pastga tushadi).
  Uxlab yotgan mushukni ko'tarib qo'ysangiz, qo'ygan joyingizda uxlayveradi.
- Uxlab yotganda xabar yozsangiz, mushukcha ko'zini yarim ochib, uyquchan qaraydi va yana yumadi.
  Uyqusi kelgan (uyqu darajasi past) mushukcha o'tirganda ham ko'zi yarim yopiq turadi.
