package com.zeno.virtualfriend

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import java.io.File
import java.io.InputStream
import java.util.Locale
import kotlin.math.ln
import kotlin.math.min

/**
 * Foydalanuvchining o‘z bilimlar fayllari (oddiy .txt) — APK ichida emas, alohida saqlanadi.
 *
 * Fayl formati:
 *   Bo'lim: Anime                 (ixtiyoriy; bo‘lmasa fayl nomi bo‘lim bo‘ladi)
 *   |One Piece|                   (yangi mavzu — uning asosiy kaliti)
 *   Kalit: luffy, zoro, van pis   (mavzuning qo‘shimcha kalitlari, ixtiyoriy)
 *   Aloqa: Zoro, Nami             (bog‘liq mavzular, ixtiyoriy — savol aniq bo‘lmasa, ularning savollari ham ko‘rsatiladi)
 *
 *   Savol: Luffy kim?
 *   Savol: Luffy haqida ayt       (ixtiyoriy — boshqacha yozilishi)
 *   Javob: Monkey D. Luffy — ...  (javob keyingi qatorlarga davom etishi mumkin)
 *
 * Mavzu ko‘rsatilmagan yozuvlar "umumiy" hisoblanadi.
 *
 * Suhbatda: mavzu kaliti aytilsa (yoki |Naruto| yozilsa) shu mavzu faollashadi va keyingi
 * CONTEXT_MESSAGES ta xabar davomida savollar avvalo shu mavzu ichidan qidiriladi.
 *
 * Fayllar ikki joydan o‘qiladi: sozlamalarda tanlangan papka (SAF) va
 * ilovaning o‘z papkasi: Android/data/<paket>/files/bilimlar
 */
object UserKb {

    private const val TAG = "UserKb"
    private const val MAX_FILE_BYTES = 5_000_000
    private const val MAX_ENTRIES = 200_000
    private const val MAX_PROBLEMS = 60

    /** Mavzu necha xabar davomida eslab qolinadi. */
    private const val CONTEXT_MESSAGES = 10
    private const val CONTEXT_MAX_MS = 30L * 60L * 1000L

    /** Raqamli ro'yxatdan tanlash uchun ro'yxat qancha vaqt eslab qolinadi. */
    private const val PENDING_MAX_MS = 5L * 60L * 1000L

    class Problem(val file: String, val line: Int, val msg: String)

    class Status(
        val files: Int,
        val entries: Int,
        val topics: Int,
        val problems: List<Problem>,
        val treeSet: Boolean,
        val appDir: String,
        val perFile: List<Pair<String, Int>> = emptyList(),
        val folders: Int = 0,
        val skipped: List<String> = emptyList()
    )

    private class Variant(val full: String, val tokens: List<String>)
    private class Entry(val file: String, val line: Int, val answer: String, val variants: List<Variant>, val topic: Int, val title: String = "")

    private class Topic(val section: String, val name: String, val nameTokens: List<String>) {
        val keys = ArrayList<List<String>>()
        var count = 0
        /** Faylda "Aloqa:" bilan yozilgan bog'liq mavzu nomlari. */
        val linkNames = ArrayList<String>()
        /** Aloqa nomlari topilgach, mavzu indekslari. */
        var links: IntArray = IntArray(0)
    }

    private class Src(val name: String, val size: Long, val mod: Long, val section: String?, val topic: String?, val open: () -> InputStream?)

    private val lock = Any()
    private val scanLock = Any()
    private var scanFolders = 0
    private val scanSkipped = ArrayList<String>()
    private var entries: List<Entry> = emptyList()
    private var topics: List<Topic> = emptyList()
    private var exact: Map<String, IntArray> = emptyMap()
    private var index: Map<String, IntArray> = emptyMap()
    private var df: Map<String, Int> = emptyMap()
    private var sig: String? = null
    private var status = Status(0, 0, 0, emptyList(), false, "")

    // oxirgi ko'rsatilgan raqamli ro'yxat (foydalanuvchi "3" deb yozib tanlashi uchun)
    private var pendEntries = IntArray(0)
    private var pendTopics = IntArray(0)
    private var pendTs = 0L

    // joriy suhbat mavzusi
    private var active = -1
    private var remaining = 0
    private var lastTs = 0L

    // ---------------------------------------------------------------- umumiy API

    /**
     * Foydalanuvchi xabariga mos javob topilsa — matnini, topilmasa null qaytaradi.
     * Mavzu buyruqlari (|Naruto|, mavzular, mavzu yo‘q) ham shu yerda ishlanadi.
     * Hech qachon xato tashlamaydi.
     */
    fun answer(ctx: Context, question: String): String? {
        return try {
            ensureFresh(ctx.applicationContext, false)
            synchronized(lock) { respond(question) }
        } catch (e: Throwable) {
            Log.e(TAG, "answer xatosi", e)
            null
        }
    }

    /**
     * Joriy mavzu faol bo‘lib, savolga hech qayerdan javob topilmasa, "aniq emas" xabari.
     * Mavzu faol bo‘lmasa null.
     */
    fun unsureReply(ctx: Context): String? {
        return try {
            synchronized(lock) {
                if (active < 0 || active >= topics.size) return null
                var m = "Bu haqda «${topics[active].name}» mavzusida aniq ma’lumotim yo‘q."
                val sg = suggestions(active)
                if (sg.isNotEmpty()) m += " Mana bu savollarni berib ko‘ring:\n$sg\n"
                if (topics.size > 1) m += " Boshqa mavzu uchun |mavzu nomi| deb yozing (masalan, ${hint()})."
                m
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** Fayllarni qayta o‘qiydi. */
    fun reload(ctx: Context): Status {
        return try {
            ensureFresh(ctx.applicationContext, true)
            status
        } catch (e: Throwable) {
            Log.e(TAG, "reload xatosi", e)
            status
        }
    }

    fun status(): Status = status

    fun appDir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val d = File(base, "bilimlar")
        try {
            d.mkdirs()
        } catch (e: Exception) {
            Log.e(TAG, "papka yaratilmadi", e)
        }
        return d
    }

    /** Namuna fayl yaratadi (mavjud faylni hech qachon bosib ketmaydi). Foydalanuvchiga xabar qaytaradi. */
    fun createSample(ctx: Context): String {
        val c = ctx.applicationContext
        val text = SAMPLE
        val tree = treeUri(c)
        if (tree != null) {
            try {
                val treeId = DocumentsContract.getTreeDocumentId(tree)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, treeId)
                val exists = listTree(c, tree, false).any { it.name.equals("namuna.txt", true) }
                if (exists) return "namuna.txt tanlangan papkada allaqachon bor."
                val doc = DocumentsContract.createDocument(c.contentResolver, parent, "text/plain", "namuna.txt")
                if (doc != null) {
                    c.contentResolver.openOutputStream(doc, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    return "namuna.txt tanlangan papkada yaratildi."
                }
            } catch (e: Throwable) {
                Log.e(TAG, "namunani papkada yaratib bo‘lmadi", e)
            }
        }
        return try {
            val f = File(appDir(c), "namuna.txt")
            if (f.exists()) "namuna.txt ilova papkasida allaqachon bor."
            else {
                f.writeText(text, Charsets.UTF_8)
                "namuna.txt ilova papkasida yaratildi."
            }
        } catch (e: Throwable) {
            "Namuna faylni yaratib bo‘lmadi."
        }
    }

    // ---------------------------------------------------------------- manbalar

    private fun treeUri(ctx: Context): Uri? {
        val s = ZenoPrefs(ctx).kbTree
        if (s.isBlank()) return null
        return try {
            Uri.parse(s)
        } catch (e: Exception) {
            null
        }
    }

    private fun fileStem(name: String): String =
        name.substringAfterLast('/').removeSuffix(".txt").removeSuffix(".TXT").replace('_', ' ').trim()

    /**
     * Papka tuzilmasidan bo‘lim va mavzuni aniqlaydi:
     *  - fayl bevosita ildizda: bo‘lim/mavzu fayl ichidagi yozuvlardan olinadi;
     *  - 1 ta papka ichida (Anime/One Piece.txt): bo‘lim = papka, mavzu = fayl nomi;
     *  - 2+ papka ichida (Anime/One Piece/baza.txt): bo‘lim = birinchi papka, mavzu = oxirgi papka.
     */
    private fun meta(folders: List<String>, fileName: String): Pair<String?, String?> {
        return when {
            folders.isEmpty() -> Pair(null, null)
            folders.size == 1 -> Pair(folders[0], fileStem(fileName).ifEmpty { null })
            else -> Pair(folders[0], folders[folders.size - 1])
        }
    }

    private fun listTree(ctx: Context, tree: Uri, recursive: Boolean = true): List<Src> {
        val out = ArrayList<Src>()
        try {
            walkTree(ctx, tree, DocumentsContract.getTreeDocumentId(tree), emptyList(), 0, recursive, out)
        } catch (e: Throwable) {
            Log.e(TAG, "papkani o‘qib bo‘lmadi", e)
        }
        return out
    }

    private fun walkTree(
        ctx: Context, tree: Uri, docId: String, folders: List<String>,
        depth: Int, recursive: Boolean, out: ArrayList<Src>
    ) {
        if (depth > 6 || out.size > 3000) return
        scanFolders++
        val dirs = ArrayList<Pair<String, String>>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_SIZE
            )
            ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (recursive && !name.startsWith(".")) dirs.add(Pair(id, name))
                        continue
                    }
                    if (!name.endsWith(".txt", ignoreCase = true)) {
                        if (!name.startsWith(".") && scanSkipped.size < 15) scanSkipped.add((folders + name).joinToString("/"))
                        continue
                    }
                    val mod = if (c.isNull(3)) 0L else c.getLong(3)
                    val size = if (c.isNull(4)) 0L else c.getLong(4)
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    val (sec, top) = meta(folders, name)
                    val shown = (folders + name).joinToString("/")
                    out.add(Src(shown, size, mod, sec, top) { ctx.contentResolver.openInputStream(docUri) })
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "papkani o‘qib bo‘lmadi", e)
        }
        for ((id, name) in dirs) walkTree(ctx, tree, id, folders + name, depth + 1, recursive, out)
    }

    private fun collect(ctx: Context): List<Src> {
        return synchronized(scanLock) {
            scanFolders = 0
            scanSkipped.clear()
            val out = ArrayList<Src>()
            try {
                val root = appDir(ctx)
                val all = root.walkTopDown().maxDepth(7).take(6000).toList()
                for (f in all) {
                    if (f.isDirectory) {
                        if (f != root) scanFolders++
                        continue
                    }
                    if (f.name.startsWith(".")) continue
                    val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                    if (!f.name.endsWith(".txt", ignoreCase = true)) {
                        if (scanSkipped.size < 15) scanSkipped.add(rel)
                        continue
                    }
                    if (out.size >= 3000) break
                    val folders = rel.split('/').dropLast(1)
                    val (sec, top) = meta(folders, f.name)
                    out.add(Src(rel, f.length(), f.lastModified(), sec, top) { f.inputStream() })
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ilova papkasi o‘qilmadi", e)
            }
            out.sortBy { it.name.lowercase(Locale.ROOT) }
            val tree = treeUri(ctx)
            if (tree != null) out.addAll(listTree(ctx, tree).sortedBy { it.name.lowercase(Locale.ROOT) })
            out
        }
    }

    // ---------------------------------------------------------------- yuklash

    /** Fayllar o‘zgarganmi — har xabarda emas, kamida shuncha vaqtda bir marta tekshiriladi. */
    private const val CHECK_INTERVAL_MS = 15_000L
    @Volatile private var lastCheck = 0L

    /** Ilovaga qaytganda (fon oqimida) fayllar o‘zgarganini darhol tekshiradi. */
    fun refresh(ctx: Context) {
        try {
            ensureFresh(ctx.applicationContext, false, true)
        } catch (e: Throwable) {
            Log.e(TAG, "refresh xatosi", e)
        }
    }

    private fun ensureFresh(ctx: Context, force: Boolean, bypassThrottle: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && !bypassThrottle && sig != null && now - lastCheck < CHECK_INTERVAL_MS) return
        lastCheck = now
        val srcs = collect(ctx)
        val newSig = srcs.joinToString("|") { "${it.name}:${it.size}:${it.mod}" } + "#" + (treeUri(ctx)?.toString() ?: "")
        synchronized(lock) {
            if (!force && newSig == sig) return
            build(ctx, srcs)
            sig = newSig
        }
    }

    private fun readLimited(s: InputStream): Pair<String, Boolean> {
        val buf = java.io.ByteArrayOutputStream()
        val tmp = ByteArray(8192)
        var total = 0
        var cut = false
        s.use { ins ->
            while (true) {
                val n = ins.read(tmp)
                if (n < 0) break
                if (total + n > MAX_FILE_BYTES) {
                    buf.write(tmp, 0, MAX_FILE_BYTES - total)
                    cut = true
                    break
                }
                buf.write(tmp, 0, n)
                total += n
            }
        }
        val bytes = buf.toByteArray()
        var t = when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            else -> String(bytes, Charsets.UTF_8)
        }
        if (t.startsWith("\uFEFF")) t = t.substring(1)
        return Pair(t, cut)
    }

    // "Savol:", "Savol -", "S:", "Q:" ...  /  "Javob:", "Javob -", "J:", "A:" ...
    private val reSavol = Regex("^\\s*(?:(?:savol|савол|question)\\s*[:：\\-–—=]|[sq]\\s*[:：])\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val reJavob = Regex("^\\s*(?:(?:javob|жавоб|answer)\\s*[:：\\-–—=]|[ja]\\s*[:：])\\s*(.*)$", RegexOption.IGNORE_CASE)
    /** Bir qatorda "Savol: ... Javob: ..." yozilgan bo‘lsa, ajratib olish uchun. */
    private val reInline = Regex("\\s+(?:javob|жавоб|answer)\\s*[:：]\\s*", RegexOption.IGNORE_CASE)
    /** Qator boshidagi raqam yoki belgi: "1. ", "2) ", "- ", "• " */
    private val rePrefix = Regex("^\\s*(?:\\d{1,4}\\s*[.)\\]:\\-]\\s*|[-•*▪►]\\s+)")
    /** "Javob" so‘zidan keyin ikki nuqta unutilgan holat (faqat Savol qatoridan keyin qabul qilinadi). */
    private val reJavobLoose = Regex("^\\s*(?:javob|жавоб|answer)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val reAloqa = Regex("^\\s*(?:aloqa|aloqalar|bog[‘'’`]?liq|bog[‘'’`]?lanish|related|links?)\\s*[:：]\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val reKalit = Regex("^\\s*(?:kalit|калит|keywords?)\\s*[:：]\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val reBolim = Regex("^\\s*(?:bo['‘’ʻʼ`´]?lim|бўлим|булим|section)\\s*[:：]\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val reMavzuLine = Regex("^\\s*\\|\\s*(.+?)\\s*\\|?\\s*$")
    private val reMavzuKey = Regex("^\\s*(?:mavzu|тема|topic)\\s*[:：]\\s*(.*)$", RegexOption.IGNORE_CASE)

    private class Draft(val line: Int) {
        val questions = ArrayList<String>()
        val keywords = ArrayList<String>()
        val answer = StringBuilder()
        var hasAnswer = false
    }

    private fun defaultSection(fileName: String): String {
        val base = fileName.removeSuffix(".txt").removeSuffix(".TXT").replace('_', ' ').trim()
        return if (base.isEmpty()) "Umumiy" else base.replaceFirstChar { it.uppercase() }
    }

    private fun build(ctx: Context, srcs: List<Src>) {
        val all = ArrayList<Entry>()
        val tps = ArrayList<Topic>()
        val topicByName = HashMap<String, Int>()
        val dup = HashMap<String, Int>()
        val problems = ArrayList<Problem>()
        val perFile = ArrayList<Pair<String, Int>>()
        var fileCount = 0
        var badCount = 0

        fun problem(file: String, line: Int, msg: String) {
            badCount++
            if (problems.size < MAX_PROBLEMS) problems.add(Problem(file, line, msg))
        }

        fun topicFor(name: String, section: String): Int {
            val key = norm(name)
            topicByName[key]?.let { return it }
            val t = Topic(section, name.trim(), tokens(key))
            if (t.nameTokens.isNotEmpty()) t.keys.add(t.nameTokens)
            tps.add(t)
            topicByName[key] = tps.size - 1
            return tps.size - 1
        }

        for (src in srcs) {
            if (all.size >= MAX_ENTRIES) break
            // README va boshqa yo‘riqnoma fayllari bilim bazasi emas.
            // Ularni Savol/Javob formatida tekshirmaymiz va xato sifatida ko‘rsatmaymiz.
            val baseName = src.name.substringAfterLast('/').substringAfterLast('\\').trim()
            if (baseName.equals("README.txt", ignoreCase = true) ||
                baseName.equals("README.md", ignoreCase = true) ||
                baseName.equals("LICENSE.txt", ignoreCase = true)) {
                continue
            }
            var text = ""
            var readOk = false
            try {
                val ins = src.open()
                if (ins == null) {
                    problem(src.name, 0, "faylni ochib bo‘lmadi")
                } else {
                    val (t, cut) = readLimited(ins)
                    text = t
                    readOk = true
                    if (cut) problem(src.name, 0, "fayl juda katta, faqat boshi o‘qildi")
                }
            } catch (e: Throwable) {
                problem(src.name, 0, "faylni o‘qib bo‘lmadi")
            }
            if (!readOk) continue
            fileCount++
            val before = all.size
            if (text.isBlank()) {
                perFile.add(Pair(src.name, 0))
                continue
            }

            var section = src.section ?: defaultSection(src.name.substringAfterLast('/'))
            // Papka ichidagi faylda |Mavzu| yozilmagan bo‘lsa, mavzu papka/fayl nomidan olinadi.
            val hasTopicLine = text.split('\n').any { ln0 ->
                val t0 = ln0.trim()
                t0.startsWith("|") || reMavzuKey.containsMatchIn(ln0)
            }
            val autoName: String? = if (src.topic != null && !hasTopicLine) src.topic else null
            var curTopic = if (autoName != null) topicFor(autoName, section) else -1
            var cur: Draft? = null

            fun finish() {
                val d = cur ?: return
                cur = null
                val ans = d.answer.toString().trim()
                if (d.questions.isEmpty() || ans.isEmpty()) {
                    problem(src.name, d.line, "Savol uchun Javob yozilmagan")
                    return
                }
                val vars = ArrayList<Variant>()
                for (q in d.questions) {
                    val full = norm(q)
                    if (full.isNotEmpty()) vars.add(Variant(full, tokens(full)))
                }
                for (k in d.keywords) {
                    val full = norm(k)
                    if (full.isNotEmpty()) vars.add(Variant(full, tokens(full)))
                }
                if (vars.isEmpty()) {
                    problem(src.name, d.line, "Savol matni bo‘sh")
                    return
                }
                if (all.size >= MAX_ENTRIES) return
                val ei = all.size
                // takror savollarni aniqlash (bir xil mavzuda bir xil savol, boshqa javob)
                for (q in d.questions) {
                    val full = norm(q)
                    if (full.isEmpty()) continue
                    val dk = "$curTopic|$full"
                    val prev = dup[dk]
                    if (prev == null) dup[dk] = ei
                    else if (all[prev].answer != ans) {
                        problem(src.name, d.line, "«${q.trim()}» savoli takrorlangan (${all[prev].file}, ${all[prev].line}-qator) — javoblar har xil")
                    }
                }
                all.add(Entry(src.name, d.line, ans, vars, curTopic, d.questions.firstOrNull()?.trim() ?: ""))
                if (curTopic >= 0) tps[curTopic].count++
            }

            val lines = text.split("\n")
            for ((i, rawLine) in lines.withIndex()) {
                val ln = i + 1
                val line = rawLine.trimEnd('\r')
                val trimmed = line.trim()
                if (trimmed.startsWith("#") || trimmed.startsWith("//")) continue

                val mb = reBolim.find(line)
                if (mb != null) {
                    finish()
                    val v = mb.groupValues[1].trim()
                    if (v.isEmpty()) problem(src.name, ln, "Bo‘lim: dan keyin nom yo‘q")
                    else {
                        section = v
                        curTopic = if (autoName != null) topicFor(autoName, section) else -1
                    }
                    continue
                }
                val mm = if (trimmed.startsWith("|")) reMavzuLine.find(line) else reMavzuKey.find(line)
                if (mm != null) {
                    finish()
                    val v = mm.groupValues[1].trim().trim('|').trim()
                    if (v.isEmpty()) problem(src.name, ln, "Mavzu nomi bo‘sh")
                    else curTopic = topicFor(v, section)
                    continue
                }

                val probe = rePrefix.replaceFirst(line, "")
                val ms = reSavol.find(probe)
                if (ms != null) {
                    var q = ms.groupValues[1].trim()
                    var inlineAns = ""
                    val inl = reInline.find(q)
                    if (inl != null) {
                        inlineAns = q.substring(inl.range.last + 1).trim()
                        q = q.substring(0, inl.range.first).trim()
                    }
                    val d = cur
                    if (d == null || d.hasAnswer) {
                        finish()
                        cur = Draft(ln)
                    }
                    if (q.isEmpty()) problem(src.name, ln, "Savol: dan keyin matn yo‘q")
                    else cur!!.questions.add(q)
                    if (inlineAns.isNotEmpty() && cur != null) {
                        cur!!.answer.append(inlineAns)
                        cur!!.hasAnswer = true
                    }
                    continue
                }
                val mj = reJavob.find(probe)
                if (mj != null) {
                    val d = cur
                    if (d == null || d.questions.isEmpty()) {
                        problem(src.name, ln, "Javob: dan oldin Savol: yo‘q")
                        continue
                    }
                    if (d.hasAnswer && d.answer.isNotEmpty()) d.answer.append('\n')
                    d.answer.append(mj.groupValues[1].trim())
                    d.hasAnswer = true
                    continue
                }
                val ma = reAloqa.find(probe)
                if (ma != null) {
                    val parts = ma.groupValues[1].split(',', ';').map { it.trim().trim('|').trim() }.filter { it.isNotEmpty() }
                    if (curTopic < 0) {
                        problem(src.name, ln, "Aloqa: dan oldin |Mavzu| yo‘q")
                    } else {
                        finish()
                        for (nm in parts) tps[curTopic].linkNames.add(nm)
                    }
                    continue
                }
                val mk = reKalit.find(probe)
                if (mk != null) {
                    val parts = mk.groupValues[1].split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
                    val d = cur
                    if (d != null) {
                        parts.forEach { d.keywords.add(it) }
                    } else if (curTopic >= 0) {
                        for (p in parts) {
                            val tk = tokens(norm(p))
                            if (tk.isNotEmpty()) tps[curTopic].keys.add(tk)
                        }
                    } else {
                        problem(src.name, ln, "Kalit: dan oldin Savol: yoki |Mavzu| yo‘q")
                    }
                    continue
                }
                val dq = cur
                if (dq != null && !dq.hasAnswer && dq.questions.isNotEmpty()) {
                    val ml = reJavobLoose.find(probe)
                    if (ml != null) {
                        dq.answer.append(ml.groupValues[1].trim())
                        dq.hasAnswer = true
                        continue
                    }
                }
                // oddiy qator
                val d = cur
                if (d != null && d.hasAnswer) {
                    // javobning davomi (bo‘sh qator abzats bo‘ladi)
                    if (trimmed.isEmpty()) {
                        if (d.answer.isNotEmpty() && !d.answer.endsWith("\n\n")) d.answer.append('\n')
                    } else {
                        if (d.answer.isNotEmpty() && !d.answer.endsWith("\n")) d.answer.append('\n')
                        d.answer.append(trimmed)
                    }
                } else if (trimmed.isNotEmpty()) {
                    problem(src.name, ln, "tushunarsiz qator (Savol:/Javob: yoki |Mavzu| bilan boshlanishi kerak)")
                }
            }
            finish()
            val added = all.size - before
            perFile.add(Pair(src.name, added))
            if (added == 0) problem(src.name, 0, "hech qanday yozuv topilmadi — Savol: va Javob: qatorlarini tekshiring")
        }

        // indekslar
        val dfMap = HashMap<String, Int>()
        val idxMap = HashMap<String, MutableList<Int>>()
        val exactMap = HashMap<String, MutableList<Int>>()
        for ((ei, e) in all.withIndex()) {
            val seen = HashSet<String>()
            val keys = HashSet<String>()
            for (v in e.variants) {
                val lst = exactMap.getOrPut(v.full) { ArrayList() }
                if (lst.isEmpty() || lst[lst.size - 1] != ei) lst.add(ei)
                for (t in v.tokens) {
                    if (seen.add(t)) dfMap[t] = (dfMap[t] ?: 0) + 1
                    keys.add(key(t))
                }
            }
            for (k in keys) idxMap.getOrPut(k) { ArrayList() }.add(ei)
        }
        var scanFoldersCopy = 0
        var scanSkippedCopy: List<String> = emptyList()
        synchronized(scanLock) {
            scanFoldersCopy = scanFolders
            scanSkippedCopy = ArrayList(scanSkipped)
        }
        // "Aloqa:" nomlarini mavzu indekslariga aylantirish
        for ((ti, tp) in tps.withIndex()) {
            if (tp.linkNames.isEmpty()) continue
            val res = ArrayList<Int>()
            for (nm in tp.linkNames) {
                val k = norm(nm)
                var idx = topicByName[k] ?: -1
                if (idx < 0) {
                    val tk = tokens(k)
                    if (tk.isNotEmpty()) {
                        idx = tps.indexOfFirst { o -> o.keys.any { kk -> kk.isNotEmpty() && kk.size == tk.size && kk.all { x -> best(x, tk) >= 0.85 } } }
                    }
                }
                if (idx < 0) problem("(aloqa)", 0, "«${tp.name}» mavzusidagi Aloqa: «$nm» mavzusi topilmadi")
                else if (idx != ti && !res.contains(idx)) res.add(idx)
            }
            tp.links = res.toIntArray()
        }
        entries = all
        topics = tps
        pendEntries = IntArray(0)
        pendTopics = IntArray(0)
        exact = exactMap.mapValues { it.value.toIntArray() }
        df = dfMap
        index = idxMap.mapValues { it.value.toIntArray() }
        active = -1
        remaining = 0
        status = Status(
            fileCount, all.size, tps.size, problems,
            treeUri(ctx) != null, appDir(ctx).absolutePath, perFile, scanFoldersCopy, scanSkippedCopy
        )
        if (badCount > problems.size) {
            Log.w(TAG, "yana ${badCount - problems.size} ta muammo ko‘rsatilmadi")
        }
    }

    // ---------------------------------------------------------------- matnni tayyorlash

    private val reJunk = Regex("[^\\p{L}\\p{N} ]")
    private val reSpaces = Regex("\\s+")

    private val stops = setOf(
        "nima", "nimadir", "nimaga", "nimani", "nimaning", "nimalar", "nimasi", "nimaligi",
        "kim", "kimdir", "kimning", "kimga", "kimligi", "qanday", "qanaqa", "qaysi", "qancha", "necha",
        "qayerda", "qaerda", "qayer", "qachon", "nega", "qani",
        "bu", "shu", "u", "bular", "ular", "haqida", "haqidagi", "xaqida", "haqda",
        "gapirib", "gapir", "ber", "bering", "ayt", "aytib", "aytchi", "aytgin", "ayting", "aytsang",
        "menga", "mening", "men", "sen", "siz", "zeno", "degani", "deb", "deyiladi", "hisoblanadi",
        "boladi", "bormi", "yoqmi", "ha", "va", "ham", "yoki", "uchun", "bilan", "bir",
        "tushuntir", "tushuntirib", "tushuntiring", "yozib", "izoh", "malumot", "malumoti",
        "ekan", "aslida", "bilasanmi", "bilasizmi", "aniqrok", "batafsil", "qisqacha", "iltimos"
    )

    private val suffixes = listOf(
        "larning", "larini", "lardan", "larga", "larda", "lari", "lar",
        "ning", "dagi", "dan", "ini", "ni", "ga", "ka", "qa", "da", "si"
    )

    private fun norm(s: String): String {
        var t = Norm.latin(s).lowercase(Locale.ROOT)
        t = t.replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'').replace('`', '\'').replace('´', '\'')
        t = t.replace("'", "")
        t = reJunk.replace(t, " ")
        return reSpaces.replace(t, " ").trim()
    }

    private fun stem(t: String): String {
        if (t.length < 6) return t
        for (suf in suffixes) {
            if (t.endsWith(suf) && t.length - suf.length >= 4) return t.substring(0, t.length - suf.length)
        }
        return t
    }

    private fun tokens(normalized: String): List<String> {
        val out = ArrayList<String>()
        for (w in normalized.split(' ')) {
            if (w.isEmpty() || w in stops) continue
            if (w.length < 2 && !w[0].isDigit()) continue
            out.add(stem(w))
        }
        return out
    }

    private fun key(t: String): String = if (t.length >= 4) t.substring(0, 4) else t

    // ---------------------------------------------------------------- moslik hisoblash

    private fun idf(t: String): Double {
        val n = entries.size.coerceAtLeast(1)
        val d = df[t] ?: return 0.5
        return ln(1.0 + n.toDouble() / d)
    }

    private fun lev1(a: String, b: String): Boolean {
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        if (i == a.length && i == b.length) return true
        return when {
            a.length == b.length -> a.substring(i + 1) == b.substring(i + 1)
            a.length > b.length -> a.substring(i + 1) == b.substring(i)
            else -> a.substring(i) == b.substring(i + 1)
        }
    }

    private fun tokMatch(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.length >= 5 && b.length >= 5) {
            if (lev1(a, b)) return 0.85
            if (a.startsWith(b) || b.startsWith(a)) return 0.85
        }
        return 0.0
    }

    private fun best(t: String, list: List<String>): Double {
        var m = 0.0
        for (x in list) {
            val s = tokMatch(t, x)
            if (s > m) m = s
            if (m >= 1.0) break
        }
        return m
    }

    /** `allow` shartiga mos yozuvlar ichidan eng yaxshisini topadi (topilmasa -1). */
    private fun findBest(nq: String, q: List<String>, allow: (Entry) -> Boolean): Int {
        exact[nq]?.forEach { if (allow(entries[it])) return it }
        if (q.isEmpty()) return -1

        val cand = HashSet<Int>()
        for (t in q) index[key(t)]?.forEach { if (allow(entries[it])) cand.add(it) }
        if (cand.isEmpty()) return -1

        val qw = q.map { idf(it) }
        val qSum = qw.sum()
        if (qSum <= 0.0) return -1
        var rarest = 0
        for (i in q.indices) if (qw[i] > qw[rarest]) rarest = i

        var bestScore = 0.0
        var bestEntry = -1
        for (ei in cand.sortedBy { it }) {
            val e = entries[ei]
            for (v in e.variants) {
                if (v.tokens.isEmpty()) continue
                var qHit = 0.0
                for (i in q.indices) qHit += qw[i] * best(q[i], v.tokens)
                val qCov = qHit / qSum

                var eSum = 0.0
                var eHit = 0.0
                for (t in v.tokens) {
                    val w = idf(t)
                    eSum += w
                    eHit += w * best(t, q)
                }
                val vCov = if (eSum > 0.0) eHit / eSum else 0.0

                val rarestHit = best(q[rarest], v.tokens) >= 0.85
                val score = 0.65 * qCov + 0.35 * vCov
                val ok = score >= 0.55 && (qCov >= 0.6 || (rarestHit && qCov >= 0.4))
                if (ok && score > bestScore) {
                    bestScore = score
                    bestEntry = ei
                }
            }
        }
        return bestEntry
    }

    // ---------------------------------------------------------------- mavzu va suhbat konteksti

    private fun hint(): String {
        val t = topics.filter { it.count > 0 }.take(2).map { "|${it.name}|" }
        return if (t.isEmpty()) "|Naruto|" else t.joinToString(" yoki ")
    }

    /** Xabarda qaysi mavzuning kaliti aytilgan (eng aniq/uzun kalit g‘olib). Topilmasa -1. */
    private fun detectTopic(q: List<String>): Int {
        if (q.isEmpty()) return -1
        var bestIdx = -1
        var bestLen = 0
        for ((i, t) in topics.withIndex()) {
            for (k in t.keys) {
                if (k.isEmpty()) continue
                if (k.all { kt -> best(kt, q) >= 0.85 }) {
                    val len = k.sumOf { it.length }
                    if (len > bestLen) {
                        bestLen = len
                        bestIdx = i
                    }
                }
            }
        }
        return bestIdx
    }

    private fun setActive(t: Int) {
        active = t
        remaining = CONTEXT_MESSAGES
        lastTs = System.currentTimeMillis()
    }

    private fun tick() {
        if (active < 0) return
        remaining--
        if (remaining < 0 || System.currentTimeMillis() - lastTs > CONTEXT_MAX_MS) active = -1
    }

    private fun topicList(): String {
        if (topics.isEmpty()) return "Hali mavzular yo‘q. Fayllarda |Mavzu nomi| qatorini yozing."
        val bySection = LinkedHashMap<String, MutableList<String>>()
        for (t in topics) bySection.getOrPut(t.section) { ArrayList() }.add(t.name)
        return bySection.entries.joinToString("\n") { "${it.key}: ${it.value.take(30).joinToString(", ")}" +
            (if (it.value.size > 30) " … (+${it.value.size - 30})" else "") }
    }

    /** Mavzu buyruqlari: |Naruto|, mavzular, mavzu, mavzu yo‘q. */
    private fun command(raw: String): String? {
        val t = raw.trim()
        if (t.startsWith("|")) {
            val name = t.trim('|', ' ').trim()
            if (name.isEmpty()) return null
            val q = tokens(norm(name))
            val idx = if (q.isEmpty()) -1 else topics.indexOfFirst { tp -> tp.keys.any { k -> k.isNotEmpty() && k.size == q.size && k.all { x -> best(x, q) >= 0.85 } } }
            if (idx >= 0) {
                setActive(idx)
                return "Mavzu: «${topics[idx].name}» (${topics[idx].section}). Savol bering."
            }
            val d = detectTopic(q)
            if (d >= 0) {
                setActive(d)
                return "Mavzu: «${topics[d].name}» (${topics[d].section}). Savol bering."
            }
            return "«$name» mavzusi topilmadi.\nMavjud mavzular:\n" + topicList()
        }
        val n = norm(t)
        return when (n) {
            "mavzular", "mavzular royxati", "mavzularim" -> "Mavjud mavzular:\n" + topicList()
            "mavzu" -> if (active >= 0 && active < topics.size) "Hozirgi mavzu: «${topics[active].name}»." else "Mavzu tanlanmagan."
            "mavzu yoq", "mavzuni tugat", "mavzuni yop", "mavzusiz", "mavzuni ochir" -> {
                active = -1
                "Mavzu o‘chirildi. Endi savollar hamma bilimlar ichidan qidiriladi."
            }
            else -> null
        }
    }

    /**
     * Mavzu ichidagi (va unga "Aloqa:" bilan bog'langan mavzulardagi) savollar ro'yxati — raqamlangan.
     * Foydalanuvchi shunchaki raqamni yozib tanlay oladi.
     */
    private fun suggestions(t: Int, max: Int = 10): String {
        val seen = HashSet<String>()
        val out = ArrayList<Int>()
        fun addFrom(tp: Int, limit: Int) {
            var n = 0
            for ((i, e) in entries.withIndex()) {
                if (n >= limit) break
                if (e.topic != tp || e.title.isEmpty()) continue
                if (!seen.add(e.title.lowercase(Locale.ROOT))) continue
                out.add(i)
                n++
            }
        }
        val links = topics[t].links
        var more = 0
        if (links.isEmpty()) {
            var total = 0
            val cnt = HashSet<String>()
            for (e in entries) if (e.topic == t && e.title.isNotEmpty() && cnt.add(e.title.lowercase(Locale.ROOT))) total++
            addFrom(t, max)
            more = total - out.size
        } else {
            val cap = 12
            addFrom(t, 5)
            val per = if (links.size <= 3) 2 else 1
            for (l in links) {
                if (out.size >= cap) break
                addFrom(l, min(per, cap - out.size))
            }
        }
        pendTopics = IntArray(0)
        if (out.isEmpty()) {
            pendEntries = IntArray(0)
            return ""
        }
        pendEntries = out.toIntArray()
        pendTs = System.currentTimeMillis()
        val sb = StringBuilder()
        for ((i, ei) in out.withIndex()) {
            if (i > 0) sb.append('\n')
            sb.append(i + 1).append(". ").append(entries[ei].title)
        }
        if (more > 0) sb.append("\n… yana $more ta savol bor")
        sb.append("\nRaqamini yozing (masalan: 1).")
        return sb.toString()
    }

    /** Foydalanuvchi faqat raqam yozsa (masalan "3") — oxirgi ro'yxatdagi shu raqamli savolga javob. */
    private fun pickByNumber(raw: String): String? {
        val m = Regex("^\\s*(?:savol\\s*)?#?(\\d{1,2})\\s*[.)\\-]?\\s*$", RegexOption.IGNORE_CASE).find(raw) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        if (System.currentTimeMillis() - pendTs > PENDING_MAX_MS) return null
        if (pendEntries.isNotEmpty()) {
            if (n < 1 || n > pendEntries.size) return null
            val ei = pendEntries[n - 1]
            if (ei < 0 || ei >= entries.size) return null
            val e = entries[ei]
            if (e.topic >= 0) setActive(e.topic)
            return e.answer
        }
        if (pendTopics.isNotEmpty()) {
            if (n < 1 || n > pendTopics.size) return null
            val t = pendTopics[n - 1]
            if (t < 0 || t >= topics.size) return null
            setActive(t)
            val sg = suggestions(t)
            return if (sg.isEmpty()) "Mavzu: «${topics[t].name}». Savol bering."
            else "Mavzu: «${topics[t].name}». Mana savollar:\n$sg"
        }
        return null
    }

    /** Qisqa xabardagi so‘z biror mavzu nomi/kalitiga o‘xshasa, shu mavzular ro‘yxati. */
    private fun relatedTopics(q: List<String>): List<Int> {
        if (q.isEmpty() || q.size > 4) return emptyList()
        val res = ArrayList<Int>()
        for ((i, t) in topics.withIndex()) {
            if (t.count <= 0) continue
            val hit = q.any { x ->
                x.length >= 4 && (t.nameTokens.any { tokMatch(it, x) >= 0.85 } ||
                    t.keys.any { k -> k.any { tokMatch(it, x) >= 0.85 } })
            }
            if (hit) res.add(i)
        }
        return res
    }

    private fun respond(question: String): String? {
        if (entries.isEmpty() && topics.isEmpty()) return null
        command(question)?.let { return it }
        pickByNumber(question)?.let { return it }

        val nq = norm(question)
        if (nq.isEmpty()) return null
        tick()

        val qAll = tokens(nq).distinct()
        val nameless = { t: Int ->
            val nameT = topics[t].nameTokens
            val r = qAll.filter { x -> nameT.none { tokMatch(it, x) >= 1.0 } }
            if (r.isEmpty()) qAll else r
        }

        // 1) savolda mavzu kaliti aytilgan — shu mavzuga o‘tamiz
        val mentioned = detectTopic(qAll)
        if (mentioned >= 0) {
            setActive(mentioned)
            val hit = findBest(nq, nameless(mentioned)) { it.topic == mentioned }
            if (hit >= 0) return entries[hit].answer
            val onlyKey = qAll.all { x -> topics[mentioned].keys.any { k -> best(x, k) >= 0.85 } }
            val sg = suggestions(mentioned)
            val head = if (onlyKey) "Mavzu: «${topics[mentioned].name}»."
            else "Bu haqda «${topics[mentioned].name}» mavzusida aniq ma’lumotim yo‘q."
            return if (sg.isEmpty()) "$head Savol bering."
            else "$head Mana shu mavzu bo‘yicha savollar (birini yozing):\n$sg"
        }

        // 2) faol mavzu bor — avval shu mavzu ichidan, keyin mavzusiz (umumiy) yozuvlardan
        if (active >= 0 && active < topics.size) {
            val a = active
            var hit = findBest(nq, nameless(a)) { it.topic == a }
            if (hit >= 0) {
                setActive(a)
                return entries[hit].answer
            }
            hit = findBest(nq, qAll) { it.topic < 0 }
            if (hit >= 0) return entries[hit].answer
            return null
        }

        // 3) mavzu yo‘q — hamma yozuvlar ichidan; topilsa o‘sha mavzu faollashadi
        val hit = findBest(nq, qAll) { true }
        if (hit >= 0) {
            val tp = entries[hit].topic
            if (tp >= 0) setActive(tp)
            return entries[hit].answer
        }
        val rel = relatedTopics(qAll)
        if (rel.size == 1) {
            setActive(rel[0])
            val sg = suggestions(rel[0])
            if (sg.isNotEmpty()) return "Savolingiz aniq emas. «${topics[rel[0]].name}» mavzusi bo‘yicha mana bu savollarni berishingiz mumkin:\n$sg"
        } else if (rel.size > 1) {
            val shown = rel.take(8)
            pendEntries = IntArray(0)
            pendTopics = shown.toIntArray()
            pendTs = System.currentTimeMillis()
            val names = shown.withIndex().joinToString("\n") { "${it.index + 1}. ${topics[it.value].name}" }
            return "Savolingiz aniq emas. Shu so‘zga yaqin mavzular bor. Raqamini yozing:\n$names"
        }
        return null
    }

    private const val SAMPLE = "# ZENO bilimlar fayli — namuna\n" +
        "# \"#\" bilan boshlangan qatorlar e’tiborga olinmaydi.\n" +
        "# Bo'lim: — ixtiyoriy (bo‘lmasa fayl nomi bo‘lim bo‘ladi).\n" +
        "# |Mavzu nomi| — yangi mavzu boshlanadi; nomi shu mavzuning asosiy kaliti.\n" +
        "# Kalit: — mavzuning qo‘shimcha kalitlari (vergul bilan).\n" +
        "# Aloqa: — bog‘liq mavzular (vergul bilan). Savol aniq bo‘lmasa, ularning savollari raqamlab ko‘rsatiladi.\n" +
        "# Har bir yozuv: Savol: ... va Javob: ... (bir nechta Savol: yozish mumkin).\n" +
        "# Yozuvlar orasiga bo‘sh qator qo‘ying.\n" +
        "\n" +
        "Bo'lim: Anime\n" +
        "\n" +
        "|One Piece|\n" +
        "Kalit: van pis, luffy\n" +
        "\n" +
        "Savol: One Piece nima?\n" +
        "Javob: One Piece — Eiichiro Oda yaratgan yapon mangasi va anime seriali.\n" +
        "\n" +
        "Savol: Luffy kim?\n" +
        "Javob: Monkey D. Luffy — One Piece qahramoni, Somon qalpoqlilar kapitani.\n" +
        "\n" +
        "Savol: Luffy qanaqa meva yegan?\n" +
        "Javob: Luffy Gomu Gomu no Mi — «rezina mevasi»ni yegan, shuning uchun tanasi rezinadek cho‘ziladi.\n" +
        "\n" +
        "|Somon qalpoqlilar|\n" +
        "Kalit: luffy komandasi, ekipaj\n" +
        "Aloqa: Zoro, Nami\n" +
        "\n" +
        "|Zoro|\n" +
        "Savol: Zoro kim?\n" +
        "Javob: Roronoa Zoro — Somon qalpoqlilarning qilichbozi.\n" +
        "\n" +
        "|Nami|\n" +
        "Savol: Nami kim?\n" +
        "Javob: Nami — Somon qalpoqlilarning navigatori.\n" +
        "\n" +
        "|Naruto|\n" +
        "Savol: Naruto kim?\n" +
        "Javob: Naruto Uzumaki — Konoha qishlog‘idan yosh ninja, Hokage bo‘lishni orzu qiladi.\n" +
        "\n" +
        "Bo'lim: Ona tili\n" +
        "\n" +
        "|Ona tili|\n" +
        "Savol: Ona tili nima?\n" +
        "Javob: Ona tili — inson bolaligidan o‘rganadigan va odatda eng yaxshi biladigan til.\n"
}
