package com.zeno.virtualfriend

/**
 * ZENO — suhbat bilimlari (salomlashish, maslahat, motivatsiya) va savol qidiruvi.
 * Maktab, o'yin, islom, umumiy bilim, til va texnologiya bo'limlari olib tashlangan:
 * bunday ma'lumotlarni foydalanuvchi o'zining .txt fayllari orqali qo'shadi (UserKb).
 */
object ZenoKnowledgeBase {
    enum class Category(val label: String) {
        SCHOOL("Matematika va maktab fanlari"),
        LANGUAGES("Ingliz tili va arab yozuvi"),
        TECHNOLOGY("Kompyuter, dasturlash va texnologiya"),
        GAMES("O'yinlar va qiziqarli ma'lumotlar"),
        ISLAM("Islom va kundalik ibodatlar"),
        CHAT("Suhbat, maslahat va motivatsiya"),
        GENERAL("Umumiy bilimlar va kundalik hayot")
    }

    data class Fact(
        val id: String,
        val category: Category,
        val question: String,
        val answer: String,
        val aliases: List<String> = emptyList(),
        val keywords: List<String> = emptyList()
    )

    data class Match(val fact: Fact, val score: Int)

    // Har bir Fact uchun savol, boshqa usulda aytilgan variantlar va kalit so'zlar saqlanadi.
    // Bitta faktga bir nechta savol variantini biriktirish takroriy ma'lumotlarni kamaytiradi.
    // Faqat suhbat uchun kerakli yozuvlar (salomlashish, maslahat, motivatsiya) qoldirildi.
    private val facts: List<Fact> = buildChatFacts()


    /**
     * Suhbat, maslahat va motivatsiya bo'limi: 70 mavzu × 50 savol uslubi × 2 shakl = 7 000 yozuv.
     * Har bir mavzu uchun mazmunli asosiy javob ishlatiladi; savol shakllari qidiruvni osonlashtiradi.
     */
    private data class ChatTopic(
        val question1: String,
        val answer: String,
        val question2: String,
        val keywords: List<String>
    )

    private fun buildChatFacts(): List<Fact> {
        val topics = listOf(
            ChatTopic("Motivatsiyam yo'q, nima qilay?", "Katta ishni kutib o'tirma: bugun atigi 5 daqiqa boshlagin. Maqsad — birdan mukammal qilish emas, odatni davom ettirish.", "hech narsa qilgim kelmayapti", listOf("motivatsiya", "odat", "boshlash")),
            ChatTopic("Maqsadni qanday belgilayman?", "Maqsadni aniq va o'lchab bo'ladigan qil. Masalan, 'ko'proq o'qiyman' o'rniga 'har kuni 10 daqiqa o'qiyman' deb belgilagin.", "maqsad qo'yish usuli", listOf("maqsad", "reja", "aniq")),
            ChatTopic("Xato qilsam nima bo'ladi?", "Xato — o'rganish jarayonining tabiiy qismi. Qaysi joyda adashganingni topib, keyingi urinishda bitta narsani yaxshilashga harakat qil.", "xato qilsam nima qilaman", listOf("xato", "o'rganish", "maslahat")),
            ChatTopic("Bugun maqsadimga ulgurmadim", "Bir kunlik tanaffus hammasi tugadi degani emas. Sababini ko'rib chiq va ertaga bajarish mumkin bo'lgan kichikroq qadamni tanla.", "rejani bajarmadim", listOf("maqsad", "reja", "davom etish")),
            ChatTopic("O'zimga ishonchim kam, nima qilay?", "O'zingga ishonch kichik va'dalarni bajarishdan o'sadi. Bugun bajara oladigan bitta ishni tanla va tugat.", "o'zimga ishonmayman", listOf("ishonch", "o'ziga baho", "jasorat")),
            ChatTopic("Xato qilishdan qo'rqaman", "Xato qilish o'rganishning bir qismi. Xatodan keyin nima o'rganganingni yozib, keyingi safar bitta narsani o'zgartir.", "xato qilish qo'rquvi", listOf("xato", "qo'rquv", "o'rganish")),
            ChatTopic("Boshqalar bilan o'zimni solishtiraman", "Har kimning sharoiti va tezligi boshqacha. Kechagi o'zing bilan bugungi o'zingni solishtirib, kichik o'sishni ham ko'rishga harakat qil.", "odamlar bilan solishtirish", listOf("solishtirish", "o'sish", "o'zini baholash")),
            ChatTopic("Diqqatim tez chalg'iydi", "Telefon bildirishnomalarini vaqtincha o'chir, bitta vazifani tanla va 10–15 daqiqalik qisqa vaqt bilan boshlagin.", "diqqatni jamlash", listOf("diqqat", "chalg'ish", "telefon")),
            ChatTopic("Vaqtimni qanday boshqaraman?", "Kun boshida eng muhim uchta ishni yoz. Ularni vaqt bo'laklariga joylashtir va dam olish uchun ham vaqt qoldir.", "vaqtni rejalash", listOf("vaqt", "reja", "ustuvorlik")),
            ChatTopic("Yangi odatni qanday shakllantiraman?", "Yangi odatni mavjud odatga bog'la: masalan, nonushtadan keyin 5 daqiqa ingliz tili. Avval kichik va muntazam qil.", "odatni shakllantirish", listOf("odat", "muntazamlik", "kichik qadam")),
            ChatTopic("Odatim buzilib qoldi", "Bir kun o'tkazib yuborish hammasi tugadi degani emas. Keyingi imkoniyatda qaytadan boshla va sababini aniqlab, rejani osonlashtir.", "odatni davom ettira olmadim", listOf("odat", "qaytish", "davom")),
            ChatTopic("Charchaganimda nima qilay?", "Charchoqni e'tiborsiz qoldirma. Suv ich, biroz dam ol, ovqatlanish va uyquni tekshir; muhim ishni kuchingga moslashtir.", "juda charchadim", listOf("charchoq", "dam", "uyqu")),
            ChatTopic("Kayfiyatim tushib ketdi", "Hozir o'zingdan hammasini hal qilishni talab qilma. Biroz yurish, suv ichish yoki ishonchli odam bilan gaplashish yordam berishi mumkin.", "kayfiyatim yo'q", listOf("kayfiyat", "dam", "suhbat")),
            ChatTopic("Asabiylashsam nima qilay?", "Javob berishdan oldin sekin nafas olib, bir oz tanaffus qil. Vaziyat tinchigach, nimaga asabiylashganingni so'z bilan ifodalashga urin.", "jahlim chiqyapti", listOf("asab", "tinchlanish", "nafas")),
            ChatTopic("Xafa bo'lsam kimga aytaman?", "Ishonadigan oila a'zosi, ustoz yoki do'stingga aytishing mumkin. Hammasini birdan tushuntirish shart emas; 'men xafaman, gaplashsak bo'ladimi?' deb boshlagin.", "dardimni kimga aytay", listOf("xafa", "ishonch", "gaplashish")),
            ChatTopic("Muammoni qanday hal qilaman?", "Muammoni bitta jumlada yoz, o'zing nazorat qila oladigan qismini ajrat va eng kichik keyingi qadamni tanla.", "muammoni hal qilish yo'li", listOf("muammo", "yechim", "qadam")),
            ChatTopic("Qaror qabul qilish qiyin", "Variantlarni, foyda va xavflarni yoz. Qaror shoshilinch bo'lmasa, biroz vaqt ber va ishonchli odam bilan maslahatlash.", "qaror qila olmayapman", listOf("qaror", "tanlov", "maslahat")),
            ChatTopic("Odamlar bilan gaplashishga uyalaman", "Oldindan bitta oddiy jumla tayyorla va kichik suhbatlardan mashq qil. Uyalish tabiiy; tajriba ortgani sari osonlashishi mumkin.", "gapirishga uyalaman", listOf("uyalish", "muloqot", "mashq")),
            ChatTopic("Notanish odamdan yordam so'rash", "Muloyim salom berib, aniq so'ra: 'Kechirasiz, menga ... bo'yicha yordam bera olasizmi?' Javob qanday bo'lishidan qat'i nazar, so'rashning o'zi ko'nikma.", "yordam so'rashni o'rganish", listOf("yordam", "muloqot", "savol")),
            ChatTopic("Do'st bilan kelishmovchilik bo'ldi", "Avval uning gapini bo'lmasdan tingla, keyin o'z his-tuyg'ungni ayblamasdan tushuntir. Muammoni birga hal qilishga urin.", "do'stim bilan urishib qoldim", listOf("do'st", "kelishmovchilik", "tinglash")),
            ChatTopic("Kechirimni qanday so'rayman?", "Nima qilganingni aniq tan ol, uzr so'ra va imkon bo'lsa zararni tuzat. 'Lekin sen ham...' deb aybni boshqa odamga yuklama.", "uzr so'rash", listOf("kechirim", "mas'uliyat", "munosabat")),
            ChatTopic("Birov meni ranjitdi", "His qilganingni tan ol va tinch paytda nima ranjitganini tushuntir. Agar bu takrorlansa, chegarangni aniq ayt va ishonchli kattadan yordam so'ra.", "kimdir meni ranjitdi", listOf("ranjish", "chegara", "suhbat")),
            ChatTopic("Yo'q deyishni qanday o'rganaman?", "Muloyim va aniq ayt: 'Rahmat, lekin bunga rozi bo'la olmayman.' Har bir iltimosga rozi bo'lish majburiy emas.", "rad etishga qiynalaman", listOf("yo'q deyish", "chegara", "hurmat")),
            ChatTopic("Meni tinglashmayapti", "Tinch vaqtda, qisqa qilib nima muhimligini ayt. 'Gapimni oxirigacha eshitsang, xursand bo'lardim' kabi jumladan foydalan.", "meni eshitishmaydi", listOf("tinglash", "muloqot", "his")),
            ChatTopic("Yolg'iz his qilyapman", "Yolg'izlik hissi og'ir bo'lishi mumkin. Ishonchli odamga xabar yozish, umumiy qiziqishli mashg'ulotga qo'shilish yoki yaqinlaring bilan vaqt o'tkazishdan boshlagin.", "o'zimni yolg'iz his qilyapman", listOf("yolg'izlik", "do'st", "aloqa")),
            ChatTopic("Yangi do'st orttirish", "Umumiy qiziqishdan suhbat boshlagin, savol ber va javobni tingla. Do'stlik asta-sekin shakllanadi; o'zingni majburlab ko'rsatishing shart emas.", "do'st topish", listOf("do'st", "suhbat", "qiziqish")),
            ChatTopic("Suhbatni qanday boshlayman?", "Oddiy vaziyatga oid savol ber: 'Bu darsni tushundingmi?' yoki 'Bu o'yinni o'ynaysanmi?' Samimiy va qisqa boshlash kifoya.", "gapni nimadan boshlash", listOf("suhbat", "savol", "muloqot")),
            ChatTopic("Kimdir meni masxara qilsa", "Tinch, qisqa javob ber va kerak bo'lsa vaziyatdan uzoqlash. Takroriy bezorilik bo'lsa, ishonchli kattaga yoki ustozga ayt.", "masxara qilishsa nima qilaman", listOf("masxara", "bezorilik", "yordam")),
            ChatTopic("Tanqidni qanday qabul qilaman?", "Tanqidning foydali qismini ajrat: aniq misol bormi, nimani yaxshilash mumkin? Haqoratni esa foydali fikr deb qabul qilish shart emas.", "tanqidga munosabat", listOf("tanqid", "o'sish", "fikr")),
            ChatTopic("Muvaffaqiyatsizlikdan keyin", "Biroz tinchlanib, nima ishlamaganini ko'rib chiq. Natijani o'z qadring bilan tenglashtirma; keyingi urinish uchun bitta o'zgarish tanla.", "yutqazdim nima qilay", listOf("muvaffaqiyatsizlik", "tajriba", "davom")),
            ChatTopic("Katta maqsadni kichraytirish", "Maqsadni haftalik, kunlik va hozir bajariladigan qadamga bo'l. Bugungi qadam juda kichik bo'lsa ham, yo'nalish muhim.", "katta maqsadni qanday boshlay", listOf("maqsad", "reja", "qadam")),
            ChatTopic("O'qishga qanday motivatsiya topaman?", "O'qishni kelajakdagi foydasi bilan bog'la, lekin faqat kayfiyatni kutma. 10 daqiqalik dars va kichik tanaffus bilan boshlagin.", "dars qilishga motivatsiya", listOf("o'qish", "dars", "motivatsiya")),
            ChatTopic("Imtihondan qo'rqyapman", "Mavzularni bo'lib, har kuni oz-ozdan takrorla va o'zingni savollar bilan sinab ko'r. Uyqu va tanaffus ham tayyorgarlikning bir qismi.", "imtihon oldidan qo'rquv", listOf("imtihon", "tayyorgarlik", "xavotir")),
            ChatTopic("Yodlaganim esimdan chiqadi", "Faqat qayta o'qish o'rniga, kitobni yopib o'zingga savol ber. Ma'lumotni bir necha kun oralatib takrorlash eslab qolishga yordam beradi.", "tez unutaman", listOf("xotira", "takrorlash", "o'qish")),
            ChatTopic("Ingliz tilini qanday o'rganaman?", "Har kuni 5–10 ta so'z, bitta sodda gap va qisqa tinglash bilan shug'ullan. O'rgangan so'zlaringni o'z gaplaringda ishlat.", "til o'rganishni boshlash", listOf("ingliz tili", "til", "so'z")),
            ChatTopic("Arab yozuvini o'rganish", "Avval harflarni shakli va tovushi bilan o'rgan, keyin harflarning so'z boshida, o'rtasida va oxirida yozilishini mashq qil.", "arab harflarini o'rganish", listOf("arab yozuvi", "harf", "yozish")),
            ChatTopic("Namozni muntazam o'qishga odatlanish", "Namoz vaqtlarini kundalik rejangga kirit va kerakli narsalarni oldindan tayyorla. O'rganayotgan bo'lsang, ishonchli manba yoki ustozdan bosqichma-bosqich o'rgan.", "namozni odat qilish", listOf("namoz", "ibodat", "muntazamlik")),
            ChatTopic("Ibodatda diqqatni jamlash", "Shoshilmaslikka harakat qil, o'qiyotgan so'zlaring ma'nosini o'rgan va chalg'ituvchi narsalarni kamaytir. Diqqat asta-sekin yaxshilanishi mumkin.", "ibodatda xayolim chalg'iydi", listOf("ibodat", "diqqat", "namoz")),
            ChatTopic("Kun tartibini tuzish", "Uyqu, o'qish, ibodat, harakat va dam olishga joy ajrat. Jadvalni haddan tashqari to'ldirma; kutilmagan ishlar uchun bo'sh vaqt qoldir.", "kun tartibi", listOf("jadval", "kun", "reja")),
            ChatTopic("Ertalab erta turish", "Uyqu vaqtini asta-sekin oldinga sur, kechqurun telefonni chetga qo'y va uyg'onish vaqtini barqaror tut. Yetarli uxlashni kamaytirma.", "erta turish usuli", listOf("ertalab", "uyqu", "odat")),
            ChatTopic("Telefonni kamroq ishlatish", "Keraksiz bildirishnomalarni o'chir, ilovalar uchun vaqt chegarasi belgilab, telefonni o'qish paytida ko'zdan uzoqroq qo'y.", "telefon ko'p chalg'itadi", listOf("telefon", "vaqt", "diqqat")),
            ChatTopic("Ijtimoiy tarmoqqa ko'p kiraman", "Qachon va nima uchun kirishingni kuzat. Ilovani ochishdan oldin maqsad belgilab, vaqt tugaganda chiqishga eslatma qo'y.", "ijtimoiy tarmoqqa qaram bo'lib qoldim", listOf("ijtimoiy tarmoq", "telefon", "odat")),
            ChatTopic("Sog'lom odatlar boshlash", "Birdan hammasini o'zgartirma. Uyqu, harakat, ovqatlanish yoki o'qishdan bittasini tanlab, kichik va barqaror qadam bilan boshlagin.", "foydali odat boshlash", listOf("sog'lom odat", "muntazamlik", "boshlash")),
            ChatTopic("Mashq qilishga motivatsiya", "O'zingga mos, xavfsiz mashqni tanla va texnikani to'g'ri bajarishga e'tibor ber. Dam olish ham rivojlanishning muhim qismi.", "sport qilishga erinaman", listOf("mashq", "sport", "motivatsiya")),
            ChatTopic("Natija sekin chiqyapti", "Ko'nikmalar vaqt bilan rivojlanadi. Natijani har kuni emas, bir necha hafta oralig'ida kuzat va o'zingdagi kichik yaxshilanishlarni qayd et.", "tez natija ko'rmayapman", listOf("natija", "sabr", "taraqqiyot")),
            ChatTopic("Boshqa odamlarning fikri meni bezovta qiladi", "Boshqalarning fikri muhim bo'lishi mumkin, lekin hammasi haqiqat degani emas. Ishonchli odamlarning foydali fikrini ol, qolganini saralashni o'rgan.", "odamlar nima deydi deb qo'rqaman", listOf("boshqalar fikri", "xavotir", "o'ziga ishonch")),
            ChatTopic("O'zimni qanday rag'batlantiraman?", "Bajargan kichik ishingni tan ol: kalendarga belgi qo'y yoki yoqimli tanaffus qil. Mukofot maqsadingga zarar bermaydigan bo'lsin.", "o'zimni mukofotlash", listOf("rag'bat", "mukofot", "odat")),
            ChatTopic("Kunlik natijalarni yozish", "Kechqurun uch narsani yoz: nima qildim, nimani o'rgandim, ertaga bitta muhim qadam nima. Bu o'sishni ko'rishga yordam beradi.", "kunlik hisobot yozish", listOf("kundalik", "natija", "maqsad")),
            ChatTopic("Minnatdorlikni qanday mashq qilaman?", "Har kuni qadrlaydigan ikki yoki uch narsani yoz. Bu muammolar yo'q degani emas; yaxshi jihatlarni ham ko'rishga yordam beradi.", "shukronalik mashqi", listOf("minnatdorlik", "shukr", "kayfiyat")),
            ChatTopic("Boshqalarga yordam berish", "Avval odamga qanday yordam kerakligini so'ra. Qo'lingdan keladiganini qil, lekin o'z imkoniyating va xavfsizligingni ham hisobga ol.", "yordam berish", listOf("yordam", "mehr", "hurmat")),
            ChatTopic("Sir saqlash haqida", "Birovning shaxsiy gapini ruxsatsiz tarqatma. Ammo kimdir xavf ostida bo'lsa, uni himoya qila oladigan ishonchli kattaga aytish muhim.", "sirni saqlash", listOf("sir", "ishonch", "xavfsizlik")),
            ChatTopic("Chegaralarimni belgilash", "Nimaga rozi va nimaga rozi emasligingni hurmat bilan, aniq ayt. Boshqalarning chegaralarini ham xuddi shunday hurmat qil.", "shaxsiy chegara", listOf("chegara", "hurmat", "rozilik")),
            ChatTopic("Birovning gapini noto'g'ri tushundim", "Taxmin qilish o'rniga aniqlashtir: 'To'g'ri tushundimmi, sen ... demoqchimisan?' Bu tushunmovchilikni kamaytiradi.", "gapni noto'g'ri tushunish", listOf("tushunmovchilik", "savol", "muloqot")),
            ChatTopic("Maslahat so'rashga uyalaman", "Maslahat so'rash ojizlik emas. Vaziyatni qisqacha tushuntirib, aynan qaysi qarorda qiynalayotganingni ayt.", "maslahat so'rash", listOf("maslahat", "uyalish", "yordam")),
            ChatTopic("Jahlim chiqqanda gapirib yuboraman", "Javobni kechiktir: suv ich, joyni o'zgartir yoki 10 gacha sanagin. Tinchigach, muammoni haqorat qilmasdan muhokama qil.", "jahlimni boshqara olmayman", listOf("jahl", "tinchlanish", "gap")),
            ChatTopic("Xavotirni kamaytirish", "Seni xavotirga solayotgan narsani yozib, nazorat qiladigan va qila olmaydigan qismlarga ajrat. Sekin nafas olish va ishonchli odam bilan gaplashish yordam berishi mumkin.", "ko'p xavotir olaman", listOf("xavotir", "stress", "nafas")),
            ChatTopic("Stress paytida nima qilay?", "Vazifalarni mayda qismlarga ajrat, qisqa tanaffus qil va uyquni asra. Stress uzoq davom etsa yoki kundalik hayotga xalaqit bersa, ishonchli kattadan yordam so'ra.", "stressni yengish", listOf("stress", "tanaffus", "yordam")),
            ChatTopic("Yig'lagim keladi", "His-tuyg'ularni his qilish tabiiy. O'zingga biroz vaqt ber, xavfsiz joyda tinchlan va kerak bo'lsa ishonchli odamga nima bo'layotganini ayt.", "yig'lagim kelyapti", listOf("his", "xafa", "yordam")),
            ChatTopic("Hech narsaga qiziqmay qoldim", "Bir necha kun davomida kichik, yengil mashg'ulotlardan boshlashga urin va yaqin inson bilan gaplash. Bu holat uzoq cho'zilsa, ishonchli kattadan yordam so'ra.", "hech narsa qiziq emas", listOf("qiziqish", "kayfiyat", "yordam")),
            ChatTopic("O'zimni qadrlash", "Qadring faqat baho, natija yoki boshqalarning fikriga bog'liq emas. O'zingdagi yaxshi sifatlarni va o'rgangan narsalaringni yozib ko'r.", "o'zimni qadrlamayman", listOf("qadr", "o'ziga munosabat", "ishonch")),
            ChatTopic("Yaxshi tinglovchi bo'lish", "Suhbatdoshning gapini bo'lma, tushunganingni qisqacha qaytar va maslahat berishdan oldin u maslahat xohlayaptimi, so'ra.", "odamlarni tinglash", listOf("tinglash", "suhbat", "hamdardlik")),
            ChatTopic("Vaqtida ish boshlash", "Boshlash uchun aniq signal tanla: masalan, choydan keyin dars. Kerakli narsalarni oldindan tayyorlab, birinchi qadamni juda oson qil.", "ishni kechiktirish", listOf("kechiktirish", "boshlash", "odat")),
            ChatTopic("Prokrastinatsiyani yengish", "Vazifaning faqat 5 daqiqasini bajarishga kelishib ol. Telefonni chetga qo'y va 'hammasini tugatish' emas, 'boshlash'ni maqsad qil.", "ishni doim keyinga qoldiraman", listOf("prokrastinatsiya", "kechiktirish", "diqqat")),
            ChatTopic("O'qish va dam olish muvozanati", "Oldindan qisqa o'qish bloklari va tanaffuslar belgilagin. Dam olishni dangasalik deb ko'rma; u diqqatni tiklashga yordam beradi.", "o'qishdan charchadim", listOf("o'qish", "dam", "muvozanat")),
            ChatTopic("Yangi ishni nimadan boshlay?", "Kerakli natijani aniqlab, eng kichik bajariladigan qadamni tanla. Birinchi urinishda hamma narsani mukammal qilish shart emas.", "yangi ish boshlash", listOf("boshlash", "reja", "qadam")),
            ChatTopic("Qobiliyatimni qanday rivojlantiraman?", "Bitta ko'nikmani tanla, uni muntazam mashq qil va natijani tekshir. Fikr-mulohaza olib, mashqni asta-sekin qiyinlashtir.", "qobiliyatni oshirish", listOf("ko'nikma", "mashq", "rivojlanish")),
            ChatTopic("O'rganganimni boshqalarga tushuntirish", "Mavzuni sodda so'zlar bilan tushuntirib ko'r, misol keltir va qayerda to'xtab qolganingni aniqlagin. Shu joyni qayta o'rgan.", "bilimni mustahkamlash", listOf("o'rganish", "tushuntirish", "takrorlash")),
            ChatTopic("Maqsadimni unutib qo'yaman", "Maqsadingni ko'rinadigan joyga yoz va har kuni ko'rib chiqadigan aniq vaqt belgilagin. Uni nima uchun xohlayotganingni ham yoz.", "maqsadni eslab turish", listOf("maqsad", "eslatma", "sabab")),
            ChatTopic("O'zimni tartibga solish", "Bir xil vaqtda bajariladigan sodda tartib tuz. Keraksiz qadamlarni kamaytir, kerakli narsalarni oldindan joyiga qo'y.", "intizomli bo'lish", listOf("intizom", "tartib", "odat")),
            ChatTopic("Boshqa odamga maslahat berish", "Avval uning gapini tingla va nima xohlayotganingni so'ra: tinglashmi yoki yechim topishmi. Uning o'rniga qaror qabul qilma.", "do'stimga qanday maslahat beraman", listOf("maslahat", "tinglash", "do'st")),
            ChatTopic("Nima gap?", "Tinchlik, o'zingda nima gap? Nimalar bo'lyapti?", "nima gaplar", listOf("salom", "gap", "tinchlik", "yangilik")),
            ChatTopic("Qalaysan?", "Yaxshiman, rahmat! O'zing qalaysan?", "qalesan", listOf("salom", "qalaysan", "ahvol")),
            ChatTopic("Nima qilyapsan?", "Hozir sen bilan suhbatlashyapman. O'zing nima bilan bandsan?", "nima qivossan", listOf("nima", "qilyapsan", "band")),
            ChatTopic("Zerikdim", "Unda biror qiziq mavzuda gaplashamizmi yoki senga o'yin, anime yoki texnologiya haqida qiziq narsa aytaymi?", "zerikib ketdim", listOf("zerikdim", "zerikish", "suhbat")),
            ChatTopic("Tushunmadim", "Qaysi joyi tushunarsiz bo'ldi? Oddiyroq qilib, bosqichma-bosqich tushuntirib beraman.", "tushunmadim qayta ayt", listOf("tushunmadim", "izoh", "qayta")),
            ChatTopic("Bu nima degani?", "Qaysi so'z yoki gapni nazarda tutyapsan? Yozib yubor, ma'nosini tushuntiraman.", "manosi nima", listOf("ma'no", "degani", "so'z")),
            ChatTopic("Fikring qanday?", "Menimcha, avval foydali va kamchilik tomonlarini ko'rib chiqish kerak. Qaysi vaziyat haqida so'rayapsan?", "sen nima deb o'ylaysan", listOf("fikr", "o'ylash", "maslahat")),
            ChatTopic("Rostdanmi?", "Ha, shunday bo'lishi mumkin. Lekin aniq bilish uchun vaziyatni biroz tushunib olaylik.", "seriozmi", listOf("rost", "haqiqat", "hayron")),
            ChatTopic("Rahmat aytish", "Arzimaydi! Yana nimadir kerak bo'lsa, bemalol yoz.", "katta rahmat", listOf("rahmat", "minnatdor")),
            ChatTopic("Kechirim so'rash", "Hechqisi yo'q. Muhimi, tushunib oldik va davom etamiz.", "uzr", listOf("uzr", "kechirim")),
            ChatTopic("Xayrlashish", "Mayli, ko'rishguncha! O'zingni ehtiyot qil.", "keyin gaplashamiz", listOf("xayr", "ko'rishguncha", "keyin")),
            ChatTopic("Hozir vaqtim yo'q", "Mayli, ishlaringni qilaver. Bo'shaganingda davom ettiramiz.", "keyinroq yozaman", listOf("vaqt", "band", "keyin")),
            ChatTopic("Bir narsani so'ramoqchiman", "So'rayver, qo'limdan kelganicha tushunarli qilib javob beraman.", "senga savolim bor", listOf("savol", "so'ramoq", "yordam")),
            ChatTopic("Menga yordam kerak", "Albatta, nima bo'ldi? Vaziyatni yoz, birgalikda yechim izlaymiz.", "yordam ber", listOf("yordam", "muammo", "kerak")),
            ChatTopic("Bu menga yoqmadi", "Tushundim. Aynan qaysi tomoni yoqmadi? Shuni bilsam, yaxshiroq tushunaman.", "yoqmadi", listOf("yoqmadi", "fikr", "tushunish")),
            ChatTopic("Menimcha", "Fikringni aytaver. Nima uchun shunday deb o'ylayotganingni ham aytsang, birga muhokama qilamiz.", "manimcha", listOf("fikr", "menimcha", "o'ylash")),
            ChatTopic("Nega unday?", "Bunga bir nechta sabab bo'lishi mumkin. Qaysi gap yoki vaziyatni nazarda tutayotganingni ayt.", "nimaga unaqa", listOf("nega", "sabab", "tushuntirish")),
            ChatTopic("Qanaqa qilib?", "Bosqichma-bosqich tushuntirib beraman. Qaysi ishni qanday qilishni bilmoqchisan?", "qanaqa qivolaman", listOf("qanday", "qanaqa", "usul")),
            ChatTopic("Mayli, tushundim", "Zo'r, demak tushunarli bo'ldi. Yana biror joyi noaniq bo'lsa, so'rashing mumkin.", "ha tushunarli", listOf("tushundim", "mayli", "xo'p")),
            ChatTopic("Ishonchim komil emas", "Shoshilmaylik. Bilganlarimizni va hali tekshirish kerak bo'lgan joylarni ajratib olaylik.", "aniq bilmayman", listOf("ishonch", "aniq", "shubha")),
            ChatTopic("Hazil qilyapman", "Ha, tushundim 😄 Davom et, hazilingni eshitaman.", "shunchaki hazil", listOf("hazil", "kulgi", "kulgili")),
            ChatTopic("Jiddiy gapiryapman", "Tushundim, jiddiy qabul qilaman. Nima bo'lganini ayt, diqqat bilan ko'rib chiqamiz.", "serioz aytyapman", listOf("jiddiy", "rost", "muhim")),
            ChatTopic("Gapimni tushundingmi?", "Ha, nima demoqchi ekaningni tushunishga harakat qilyapman. Noto'g'ri tushungan bo'lsam, tuzatib yubor.", "tushundingmi", listOf("tushunish", "gap", "aniqlash")),
            ChatTopic("Boshqa mavzuga o'tamiz", "Bo'ladi. Qaysi mavzu: o'yinlar, anime, texnologiya, ingliz tili yoki boshqa narsa?", "mavzuni o'zgartiraylik", listOf("mavzu", "o'zgartirish", "suhbat")),
            ChatTopic("Menga qiziq narsa ayt", "Qiziq fakt, o'yin, koinot, hayvonlar yoki texnologiya haqida aytishim mumkin. Qaysi biri yoqadi?", "qiziqarli narsa ayt", listOf("qiziq", "fakt", "ma'lumot")),
            ChatTopic("Birga o'ylab ko'raylik", "Bo'ladi. Vaziyatni yoz, variantlarni birma-bir ko'rib, qaysi biri ma'qul ekanini solishtiramiz.", "birgalashib ko'raylik", listOf("birga", "fikr", "yechim")),
            ChatTopic("Menga qisqa javob ber", "Xo'p, qisqa va aniq javob beraman. Kerak bo'lsa, keyin batafsil tushuntiraman.", "qisqaroq ayt", listOf("qisqa", "aniq", "javob")),
            ChatTopic("Batafsil tushuntir", "Mayli, avval asosiy fikrni aytaman, keyin misollar bilan bosqichma-bosqich tushuntiraman.", "to'liq tushuntirib ber", listOf("batafsil", "tushuntirish", "misol")),
            ChatTopic("Xato yozib yubordim", "Hechqisi yo'q, nima demoqchi bo'lganingni kontekstdan tushunishga harakat qilaman. Kerak bo'lsa, aniqlashtiraman.", "noto'g'ri yozdim", listOf("xato", "yozish", "tushunish")),
            ChatTopic("Gapimni davom ettiray", "Mayli, yozaver. Gaplaringni o'qib, keyin javob beraman.", "eshit", listOf("davom", "yoz", "gap"))
        )
        val prefixes = listOf(
            "Maslahat ber: ",
            "Qisqacha ayt: ",
            "Menga yordam ber: ",
            "Oddiy qilib tushuntir: ",
            "Qanday yo'l tutay: ",
            "Nimadan boshlay: ",
            "Menga tavsiya ber: ",
            "Buni qanday hal qilaman: ",
            "Bir maslahat kerak: ",
            "Yo'l ko'rsat: ",
            "Tushuntirib ber: ",
            "Eng muhim qadam nima: ",
            "Amalda nima qilay: ",
            "Bosqichma-bosqich ayt: ",
            "Menga ko'maklash: ",
            "Qanday yaxshilay: ",
            "Qanday o'zgartiraman: ",
            "Yaxshi yo'li qanday: ",
            "Nima qilishim mumkin: ",
            "Qanday uddalayman: ",
            "Yengilroq tushuntir: ",
            "Buni qanday o'rganaman: ",
            "Menga yo'l-yo'riq ber: ",
            "Qisqa tavsiya: ",
            "Men bilmoqchiman: ",
            "Shuni izohla: ",
            "Qanday davom etay: ",
            "Qanday boshlash kerak: ",
            "Qanday mashq qilay: ",
            "Nimani yodda tutay: ",
            "Menga ko'rsatma ber: ",
            "Bu vaziyatda nima qilay: ",
            "Foydali maslahat ayt: ",
            "Nima muhim: ",
            "Qanday qaror qilay: ",
            "Buni yengish yo'li: ",
            "Qanday odatlanaman: ",
            "O'zimga qanday yordam beray: ",
            "Qanday reja tuzay: ",
            "Eng sodda usul: ",
            "Qanday tinchlanaman: ",
            "Qanday gapirsam bo'ladi: ",
            "Buni qanday tushunay: ",
            "Yaxshi usul ayt: ",
            "Qanday yo'l topaman: ",
            "Menga tushunarli qilib ayt: ",
            "Qanday davom ettiraman: ",
            "Qanday o'rgansam bo'ladi: ",
            "Bir oz maslahat kerak: ",
            "Eng to'g'ri qadam nima: "
        )
        val result = ArrayList<Fact>(topics.size * 100)
        topics.forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                val base = topicIndex * 100 + styleIndex * 2 + 1
                val keywords = topic.keywords + listOf("suhbat", "maslahat", "motivatsiya")
                result.add(fact(
                    id = "chat_db_${base.toString().padStart(4, '0')}",
                    category = Category.CHAT,
                    question = prefix + topic.question1,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question2, topic.question1, topic.question2),
                    keywords = keywords
                ))
                result.add(fact(
                    id = "chat_db_${(base + 1).toString().padStart(4, '0')}",
                    category = Category.CHAT,
                    question = prefix + topic.question2,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question1, topic.question1, topic.question2),
                    keywords = keywords
                ))
            }
        }
        return result
    }



    private fun fact(
        id: String,
        category: Category,
        question: String,
        answer: String,
        aliases: List<String> = emptyList(),
        keywords: List<String> = emptyList()
    ) = Fact(id, category, question, answer, aliases, keywords)

    /** O'zbekcha harflar, apostrof va tinish belgilarini bir xil ko'rinishga keltiradi. */
    private val nonWordRe = Regex("[^\\p{L}\\p{N}+' ]")
    private val spacesRe = Regex("\\s+")

    /** Kundalik yozishdagi qisqartma va variantlar (Regex bir marta yaratiladi). */
    private val slang = mapOf(
        "lk" to "lekin", "blan" to "bilan", "manimcha" to "menimcha", "qalesan" to "qalaysan",
        "qivossan" to "qilyapsan", "deyyapman" to "deyapman", "bo'pti" to "bo'ldi"
    )
    private val slangRe = Regex("\\b(lk|blan|manimcha|qalesan|qivossan|deyyapman|bo'pti)\\b")

    fun normalize(text: String): String {
        return text.lowercase()
            .replace('’', '\'').replace('‘', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
            .replace('ё', 'е')
            // Kundalik yozishdagi keng tarqalgan qisqartma va variantlar.
            .replace(slangRe, { slang[it.value] ?: it.value })
            .replace(nonWordRe, " ")
            .replace(spacesRe, " ")
            .trim()
    }

    /** Savolda ma'no bermaydigan, tayyor prefikslarda ko'p uchraydigan so'zlar (yolg'on moslik bermasin). */
    private val genericWords = setOf(
        "qanday", "tushuntir", "ayt", "nima", "nimani", "qancha", "buni", "menga", "bir", "oz",
        "haqida", "degani", "mumkin", "kerak", "savol", "javob", "oddiy", "aniqroq", "mavzuni",
        "ma'nosini", "asoslarini", "qisqa", "ma'lumot", "muhim", "qaysi"
    )

    /** Har bir yozuv uchun normallashtirilgan matnlar bir marta hisoblanadi (qidiruv tez ishlashi uchun). */
    private class Prep(val cands: List<String>, val tokens: Set<String>)

    private val prepared: List<Prep> by lazy {
        val pool = HashMap<String, String>()
        facts.map { f ->
            val cands = (listOf(f.question) + f.aliases).map { normalize(it) }
            val all = normalize((listOf(f.question) + f.aliases + f.keywords).joinToString(" "))
            val ts = HashSet<String>()
            for (t in all.split(' ')) if (t.length >= 2) ts.add(pool.getOrPut(t) { t })
            Prep(cands, ts)
        }
    }

    /** Ilova ochilganda fon oqimida chaqiriladi: birinchi savolda kutib qolmaslik uchun. */
    fun warmUp() { prepared.size }

    private fun tokens(text: String): Set<String> = normalize(text)
        .split(' ').filter { it.length >= 2 }.toSet()

    /**
     * Savolga eng yaqin bilimni topadi.
     * threshold juda past bo'lsa noto'g'ri mosliklar ko'payishi mumkin.
     */
    fun search(question: String, category: Category? = null, threshold: Int = 6): Match? {
        val q = normalize(question)
        if (q.isBlank()) return null
        val qt = tokens(q).filter { it !in genericWords }.toSet()
        var best: Match? = null
        val prep = prepared

        for ((idx, f) in facts.withIndex()) {
            if (category != null && f.category != category) continue
            val p = prep[idx]
            var score = 0

            // To'liq savol yoki aliasga moslik eng yuqori ball oladi.
            if (p.cands.any { it == q }) score += 12
            else if (p.cands.any { c -> c.contains(q) || q.contains(c) }) score += 5

            val ft = p.tokens
            var overlap = 0
            for (t in qt) if (t in ft) overlap++
            score += overlap * 2

            // Kam uchraydigan uzunroq so'zlarga ko'proq og'irlik berish.
            for (token in qt) {
                if (token.length >= 5 && ft.any { it.startsWith(token) || token.startsWith(it) }) score += 1
            }

            if (score >= threshold && (best == null || score > best!!.score)) {
                best = Match(f, score)
            }
        }
        return best
    }

    fun answer(question: String, category: Category? = null): String? = search(question, category)?.fact?.answer

    fun allCategories(): List<Category> = Category.values().toList()
    fun count(): Int = facts.size
    fun count(category: Category): Int = facts.count { it.category == category }
    fun allFacts(): List<Fact> = facts
}
