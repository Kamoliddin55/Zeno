package com.zeno.virtualfriend

import java.math.BigInteger
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** Qo‘shimcha hisob-kitob funksiyalari (matn `Knowledge.n()` bilan moslashtirilgan holda keladi). */
object KbMath {

    private const val N = "(-?\\d+(?:[.,]\\d+)?)"

    private fun d(s: String): Double? = s.replace(',', '.').toDoubleOrNull()
    private fun f(x: Double): String = Calc.format(Math.round(x * 1_000_000.0) / 1_000_000.0)

    private val months = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr")
    private val weekdays = listOf("yakshanba", "dushanba", "seshanba", "chorshanba", "payshanba", "juma", "shanba")

    fun run(flat: String): String? {
        sqrt(flat)?.let { return it }
        power(flat)?.let { return it }
        factorial(flat)?.let { return it }
        gcdLcm(flat)?.let { return it }
        fib(flat)?.let { return it }
        roman(flat)?.let { return it }
        words(flat)?.let { return it }
        binary(flat)?.let { return it }
        leap(flat)?.let { return it }
        weekday(flat)?.let { return it }
        addDays(flat)?.let { return it }
        discount(flat)?.let { return it }
        change(flat)?.let { return it }
        stats(flat)?.let { return it }
        random(flat)?.let { return it }
        shapes(flat)?.let { return it }
        return null
    }

    // ---------------------------------------------------------------- ildiz va daraja
    private fun sqrt(flat: String): String? {
        val m = Regex("(?:kvadrat\\s+)?ildiz(?:i)?\\s*(?:dan)?\\s*$N|$N\\s*(?:ning|dan)\\s*(?:kvadrat\\s+)?ildiz").find(flat) ?: return null
        val v = d(m.groupValues[1].ifEmpty { m.groupValues[2] }) ?: return null
        if (v < 0) return "Manfiy sondan haqiqiy kvadrat ildiz olib bo‘lmaydi."
        return "√${f(v)} = ${f(Math.sqrt(v))}"
    }

    private fun power(flat: String): String? {
        var m = Regex("$N\\s*\\^\\s*$N").find(flat)
        var a: Double? = null
        var b: Double? = null
        if (m != null) { a = d(m.groupValues[1]); b = d(m.groupValues[2]) }
        if (a == null) {
            m = Regex("$N\\s*(?:ning)?\\s*$N\\s*(?:chi\\s*)?(?:daraja|darajasi|darajaga)").find(flat)
            if (m != null) { a = d(m.groupValues[1]); b = d(m.groupValues[2]) }
        }
        if (a == null || b == null) return null
        val r = Math.pow(a, b)
        if (r.isNaN() || r.isInfinite()) return null
        return "${f(a)}^${f(b)} = ${if (Math.abs(r) >= 1e15) String.format(Locale.US, "%.6e", r) else f(r)}"
    }

    private fun factorial(flat: String): String? {
        val m = Regex("faktorial\\w*\\s*(\\d{1,3})|(\\d{1,3})\\s*(?:ning)?\\s*faktorial|(\\d{1,3})!").find(flat) ?: return null
        val v = (m.groupValues[1] + m.groupValues[2] + m.groupValues[3]).toIntOrNull() ?: return null
        if (v > 170) return "Juda katta son (170 gacha hisoblayman)."
        var r = BigInteger.ONE
        for (i in 2..v) r = r.multiply(BigInteger.valueOf(i.toLong()))
        val s = r.toString()
        return "$v! = " + if (s.length > 40) "${s.take(12)}… (${s.length} xonali son)" else s
    }

    private fun gcd(a: Long, b: Long): Long = if (b == 0L) a else gcd(b, a % b)

    private fun gcdLcm(flat: String): String? {
        val m = Regex("(ekub|ekuk)\\w*\\D{0,12}(\\d+)\\D+(\\d+)").find(flat) ?: return null
        val a = m.groupValues[2].toLongOrNull() ?: return null
        val b = m.groupValues[3].toLongOrNull() ?: return null
        if (a == 0L || b == 0L) return null
        val g = gcd(a, b)
        return if (m.groupValues[1] == "ekub") "EKUB($a, $b) = $g" else "EKUK($a, $b) = ${a / g * b}"
    }

    private fun fib(flat: String): String? {
        val m = Regex("fibonac\\w*\\D{0,8}(\\d{1,4})").find(flat) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        if (n > 1000) return "1000 gacha hisoblayman."
        var a = BigInteger.ZERO
        var b = BigInteger.ONE
        for (i in 0 until n) { val t = a.add(b); a = b; b = t }
        val s = a.toString()
        return "Fibonachchi ketma-ketligining $n-hadi (0, 1, 1, 2, 3, 5…): " + if (s.length > 40) "${s.take(12)}… (${s.length} xonali)" else s
    }

    // ---------------------------------------------------------------- rim raqamlari
    private fun toRoman(v: Int): String {
        val nums = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val syms = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        var x = v
        val sb = StringBuilder()
        for (i in nums.indices) while (x >= nums[i]) { sb.append(syms[i]); x -= nums[i] }
        return sb.toString()
    }

    private fun fromRoman(s: String): Int? {
        val map = mapOf('I' to 1, 'V' to 5, 'X' to 10, 'L' to 50, 'C' to 100, 'D' to 500, 'M' to 1000)
        var total = 0
        for (i in s.indices) {
            val v = map[s[i]] ?: return null
            val nx = if (i + 1 < s.length) map[s[i + 1]] ?: return null else 0
            total += if (v < nx) -v else v
        }
        return if (toRoman(total) == s) total else null
    }

    private fun roman(flat: String): String? {
        if (!flat.contains("rim")) return null
        Regex("(\\d{1,4})").find(flat)?.let {
            val v = it.groupValues[1].toInt()
            if (v in 1..3999) return "$v = ${toRoman(v)} (rim raqamlarida)"
        }
        Regex("\\b([ivxlcdm]{1,12})\\b").find(flat)?.let {
            val v = fromRoman(it.groupValues[1].uppercase())
            if (v != null) return "${it.groupValues[1].uppercase()} = $v"
        }
        return null
    }

    // ---------------------------------------------------------------- son so‘z bilan (o‘zbekcha)
    private val ones = arrayOf("nol", "bir", "ikki", "uch", "to‘rt", "besh", "olti", "yetti", "sakkiz", "to‘qqiz")
    private val tens = arrayOf("", "o‘n", "yigirma", "o‘ttiz", "qirq", "ellik", "oltmish", "yetmish", "sakson", "to‘qson")

    private fun under1000(v: Int): String {
        val p = ArrayList<String>()
        val h = v / 100
        val t = (v % 100) / 10
        val o = v % 10
        if (h > 0) p.add((if (h > 1) ones[h] + " " else "") + "yuz")
        if (t > 0) p.add(tens[t])
        if (o > 0) p.add(ones[o])
        return p.joinToString(" ")
    }

    fun numWords(v: Long): String {
        if (v == 0L) return "nol"
        var x = v
        val parts = ArrayList<String>()
        val scales = listOf(1_000_000_000L to "milliard", 1_000_000L to "million", 1_000L to "ming")
        for ((s, name) in scales) {
            val c = (x / s).toInt()
            if (c > 0) {
                parts.add(under1000(c) + " " + name)
                x %= s
            }
        }
        if (x > 0) parts.add(under1000(x.toInt()))
        return parts.joinToString(" ")
    }

    private fun words(flat: String): String? {
        if (!(flat.contains("soz bilan") || flat.contains("harf bilan") || flat.contains("yozib ber") || flat.contains("sozlarda") || flat.contains("matn bilan"))) return null
        val v = Regex("(\\d{1,12})").find(flat)?.value?.toLongOrNull() ?: return null
        return "$v — ${numWords(v)}"
    }

    // ---------------------------------------------------------------- ikkilik/o‘nlik
    private fun binary(flat: String): String? {
        Regex("(\\d{1,15})\\s*(?:ni|ning)?\\s*ikkilik").find(flat)?.let {
            val v = it.groupValues[1].toLongOrNull() ?: return null
            return "$v (o‘nlik) = ${java.lang.Long.toBinaryString(v)} (ikkilik)"
        }
        Regex("ikkilik\\s*([01]{1,40})\\s*(?:ni|ning)?\\s*(?:onlik|o'nlik)?").find(flat)?.let {
            if (flat.contains("onlik") || flat.contains("nechaga")) {
                val v = it.groupValues[1].toLongOrNull(2) ?: return null
                return "${it.groupValues[1]} (ikkilik) = $v (o‘nlik)"
            }
        }
        Regex("(\\d{1,15})\\s*(?:ni|ning)?\\s*(?:sakkizlik|oktal)").find(flat)?.let {
            val v = it.groupValues[1].toLongOrNull() ?: return null
            return "$v (o‘nlik) = ${java.lang.Long.toOctalString(v)} (sakkizlik)"
        }
        Regex("(\\d{1,15})\\s*(?:ni|ning)?\\s*(?:on oltilik|geksa|hex)").find(flat)?.let {
            val v = it.groupValues[1].toLongOrNull() ?: return null
            return "$v (o‘nlik) = ${java.lang.Long.toHexString(v).uppercase()} (o‘n oltilik)"
        }
        return null
    }

    // ---------------------------------------------------------------- sanalar
    private fun leap(flat: String): String? {
        val m = Regex("(\\d{4})\\D{0,10}kabisa").find(flat) ?: Regex("kabisa\\D{0,12}(\\d{4})").find(flat) ?: return null
        val y = m.groupValues[1].toInt()
        val leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
        return if (leap) "$y — kabisa yili (366 kun) ✅" else "$y — kabisa yili emas (365 kun)."
    }

    private fun weekday(flat: String): String? {
        if (!(flat.contains("kaysi kun") || flat.contains("hafta kun") || flat.contains("kaysi hafta"))) return null
        val cal = Calendar.getInstance()
        Regex("(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})").find(flat)?.let {
            cal.clear(); cal.set(it.groupValues[3].toInt(), it.groupValues[2].toInt() - 1, it.groupValues[1].toInt())
            return "${it.value} — ${weekdays[cal.get(Calendar.DAY_OF_WEEK) - 1]}."
        }
        val ms = months.joinToString("|") { Knowledge.n(it) }
        Regex("(\\d{1,2})\\s*($ms)\\w*\\s*(\\d{4})?").find(flat)?.let {
            val mon = months.indexOfFirst { mm -> Knowledge.n(mm) == it.groupValues[2] }
            val y = it.groupValues[3].toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
            cal.clear(); cal.set(y, mon, it.groupValues[1].toInt())
            return "${it.groupValues[1]}-${months[mon]} $y — ${weekdays[cal.get(Calendar.DAY_OF_WEEK) - 1]}."
        }
        return null
    }

    private fun addDays(flat: String): String? {
        val m = Regex("(\\d{1,5})\\s*(kun|hafta|oy)\\s*(keyin|oldin)").find(flat) ?: return null
        val n = m.groupValues[1].toInt()
        val sign = if (m.groupValues[3] == "keyin") 1 else -1
        val cal = Calendar.getInstance()
        when (m.groupValues[2]) {
            "kun" -> cal.add(Calendar.DAY_OF_YEAR, sign * n)
            "hafta" -> cal.add(Calendar.DAY_OF_YEAR, sign * n * 7)
            else -> cal.add(Calendar.MONTH, sign * n)
        }
        val s = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(cal.time)
        return "${m.value} sana: $s (${weekdays[cal.get(Calendar.DAY_OF_WEEK) - 1]})."
    }

    // ---------------------------------------------------------------- savdo
    private fun discount(flat: String): String? {
        if (!flat.contains("chegirma")) return null
        val nums = Regex(N).findAll(flat).mapNotNull { d(it.value) }.toList()
        if (nums.size < 2) return null
        val price = nums[0]
        val pct = nums[1]
        if (pct !in 0.0..100.0) return null
        val off = price * pct / 100
        return "${f(price)} dan ${f(pct)}% chegirma: ${f(off)} tejaysiz, to‘lov = ${f(price - off)}."
    }

    private fun change(flat: String): String? {
        val m = Regex("$N\\s*(?:dan)\\s*$N\\s*(?:ga|gacha)\\s*necha\\s*foiz").find(flat) ?: return null
        val a = d(m.groupValues[1]) ?: return null
        val b = d(m.groupValues[2]) ?: return null
        if (a == 0.0) return null
        val p = (b - a) / Math.abs(a) * 100
        return "${f(a)} dan ${f(b)} gacha o‘zgarish: ${if (p >= 0) "+" else ""}${f(p)}% ${if (p >= 0) "(o‘sish)" else "(kamayish)"}."
    }

    private fun stats(flat: String): String? {
        val m = Regex("(ortacha|yigindi|eng katta|eng kichik|median)\\w*\\s*:?\\s*((?:-?\\d+(?:[.,]\\d+)?[\\s,;va]*){2,})").find(flat) ?: return null
        val xs = Regex(N).findAll(m.groupValues[2]).mapNotNull { d(it.value) }.toList()
        if (xs.size < 2) return null
        return when (m.groupValues[1]) {
            "ortacha" -> "O‘rtacha = ${f(xs.average())}"
            "yigindi" -> "Yig‘indi = ${f(xs.sum())}"
            "eng katta" -> "Eng kattasi = ${f(xs.max())}"
            "eng kichik" -> "Eng kichigi = ${f(xs.min())}"
            else -> {
                val s = xs.sorted()
                "Median = ${f(if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2)}"
            }
        }
    }

    private fun random(flat: String): String? {
        val m = Regex("tasodifiy\\s+son\\D{0,10}(\\d+)\\D+(\\d+)").find(flat) ?: return null
        val a = m.groupValues[1].toIntOrNull() ?: return null
        val b = m.groupValues[2].toIntOrNull() ?: return null
        if (b < a) return null
        return "Tasodifiy son ($a–$b): ${Random.nextInt(a, b + 1)} 🎲"
    }

    // ---------------------------------------------------------------- shakllar
    private fun shapes(flat: String): String? {
        val nums = Regex(N).findAll(flat).mapNotNull { d(it.value) }.toList()
        if (nums.isEmpty()) return null
        val a = nums[0]
        val wantsArea = flat.contains("yuz") && !flat.contains("yuzi nechta")
        val wantsVol = flat.contains("hajm")
        val wantsPer = flat.contains("perimetr")
        val wantsLen = flat.contains("uzunlik")
        val pi = Math.PI
        when {
            flat.contains("doira") && wantsArea -> return "Doira (r = ${f(a)}): yuzi = π·r² = ${f(pi * a * a)}"
            flat.contains("aylana") && wantsLen -> return "Aylana (r = ${f(a)}): uzunligi = 2π·r = ${f(2 * pi * a)}"
            flat.contains("shar") && wantsVol -> return "Shar (r = ${f(a)}): hajmi = (4/3)π·r³ = ${f(4.0 / 3 * pi * a * a * a)}"
            flat.contains("kub") && wantsVol -> return "Kub (a = ${f(a)}): hajmi = a³ = ${f(a * a * a)}"
            flat.contains("kvadrat") && wantsArea -> return "Kvadrat (a = ${f(a)}): yuzi = a² = ${f(a * a)}"
            flat.contains("kvadrat") && wantsPer -> return "Kvadrat (a = ${f(a)}): perimetri = 4a = ${f(4 * a)}"
        }
        if (nums.size >= 2) {
            val b = nums[1]
            when {
                flat.contains("tortburchak") && wantsArea -> return "To‘g‘ri to‘rtburchak (${f(a)} × ${f(b)}): yuzi = ${f(a * b)}"
                flat.contains("tortburchak") && wantsPer -> return "To‘g‘ri to‘rtburchak (${f(a)} × ${f(b)}): perimetri = ${f(2 * (a + b))}"
                flat.contains("uchburchak") && wantsArea -> return "Uchburchak (asos ${f(a)}, balandlik ${f(b)}): yuzi = ½·a·h = ${f(a * b / 2)}"
                flat.contains("silindr") && wantsVol -> return "Silindr (r = ${f(a)}, h = ${f(b)}): hajmi = π·r²·h = ${f(pi * a * a * b)}"
                flat.contains("konus") && wantsVol -> return "Konus (r = ${f(a)}, h = ${f(b)}): hajmi = ⅓·π·r²·h = ${f(pi * a * a * b / 3)}"
            }
        }
        if (nums.size >= 3 && flat.contains("uchburchak") && (wantsPer || wantsArea)) {
            val (x, y, z) = Triple(nums[0], nums[1], nums[2])
            if (x + y > z && x + z > y && y + z > x) {
                val p = (x + y + z) / 2
                val s = Math.sqrt(p * (p - x) * (p - y) * (p - z))
                return "Uchburchak (${f(x)}, ${f(y)}, ${f(z)}): perimetri = ${f(x + y + z)}, yuzi (Geron) = ${f(s)}"
            }
        }
        return null
    }
}
