package com.zeno.virtualfriend

import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

/**
 * Internetsiz hisob-kitob funksiyalari va qisqa suhbat javoblari.
 * Matn moslashtiriladi: apostrof olib tashlanadi, h→x, q→k — shunda "o'zbekiston", "uzbekiston",
 * "qancha"/"kancha" kabi turli yozilishlar bir xil taniladi.
 */
object Knowledge {

    fun n(s: String): String = s.lowercase()
        .replace("'", "").replace("ʻ", "").replace("ʼ", "").replace("‘", "").replace("’", "").replace("`", "")
        .replace('x', 'h').replace('q', 'k')

    private fun tokens(flat: String): List<String> =
        flat.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }

    private class Entry(val groups: List<List<String>>, val answer: String)

    /** Har bir guruh "a|b|c" ko‘rinishida; javob berilishi uchun HAMMA guruhdan kamida bittasi topilishi kerak. */
    private fun e(answer: String, vararg g: String): Entry =
        Entry(g.map { grp -> grp.split("|").map { n(it.trim()) }.filter { it.isNotEmpty() } }, answer)

    private fun hit(tk: List<String>, flat: String, key: String): Boolean = when {
        key.startsWith("=") -> tk.any { it == key.substring(1) }
        key.contains(' ') || key.contains('-') -> flat.contains(key)
        else -> tk.any { it.startsWith(key) }
    }

    private fun pickAnswer(a: String): String {
        val parts = a.split("###")
        return if (parts.size == 1) a else parts[Random.nextInt(parts.size)]
    }

    private fun fmt(d: Double): String = Calc.format(Math.round(d * 1_000_000.0) / 1_000_000.0)

    // ---------------------------------------------------------------- asosiy kirish
    fun features(lower: String): String? {
        val flat = n(lower)
        val tk = tokens(flat)
        if (tk.isEmpty()) return null

        crisis(flat)?.let { return it }
        percent(lower)?.let { return it }
        bmi(flat)?.let { return it }
        equation(lower)?.let { return it }
        prime(flat)?.let { return it }
        age(flat)?.let { return it }
        daysUntil(flat)?.let { return it }
        convert(flat)?.let { return it }
        KbMath.run(flat)?.let { return it }

        for (en in entries) {
            if (en.groups.all { grp -> grp.any { hit(tk, flat, it) } }) return pickAnswer(en.answer)
        }
        // Oxirgi zaxira: suhbat bilimlari (maslahat, motivatsiya).
        ZenoKnowledgeBase.answer(lower)?.let { return it }
        return null
    }

    // ---------------------------------------------------------------- xavfsizlik
    /** Og‘ir holat (o‘ziga zarar yetkazish) belgilari bo‘lsa — yordam so‘rashga undovchi javob. Boshqa tekshiruvlardan oldin chaqiriladi. */
    fun crisisCheck(lower: String): String? = crisis(n(lower))

    private val crisisKeys = listOf(
        "ozimni oldir", "ozimni oldirgim", "yashagim kelma", "olgim kel", "olmokchiman", "olib koymokchiman",
        "ozimga ziyon", "ozimni yokotgim", "yashashni xoxlamayman"
    ).map { n(it) }

    private fun crisis(flat: String): String? {
        if (crisisKeys.none { flat.contains(it) } || flat.contains("kulgi")) return null
        return "Buni yozganing juda muhim, va bunday og‘ir his-tuyg‘ular bilan yolg‘iz qolishing shart emas. " +
            "Iltimos, hozir yaqin odamingga (oila a’zosi yoki ishonchli do‘sting) aytib, yoningda bo‘lishini so‘ra. " +
            "Agar o‘zingga zarar yetkazish xavfi bor bo‘lsa, shoshilinch yordam raqamiga (112) qo‘ng‘iroq qil. " +
            "Men shu yerdaman — xohlasang, nima bo‘layotganini yozishing mumkin."
    }

    // ---------------------------------------------------------------- foiz
    private val num = "(\\d+(?:[.,]\\d+)?)"

    private fun d(s: String): Double? = s.replace(',', '.').toDoubleOrNull()

    private fun percent(lower: String): String? {
        Regex("$num\\s*(?:soni|ta)?\\s*$num\\s*(?:ning|dan)\\s*necha\\s*foiz").find(lower)?.let {
            val a = d(it.groupValues[1]) ?: return null
            val b = d(it.groupValues[2]) ?: return null
            if (b == 0.0) return null
            return "${fmt(a)} soni ${fmt(b)} ning ${fmt(a / b * 100)} foizini tashkil qiladi."
        }
        Regex("$num\\s*(?:ning|dan)\\s*$num\\s*(?:foiz|%)").find(lower)?.let {
            val a = d(it.groupValues[1]) ?: return null
            val p = d(it.groupValues[2]) ?: return null
            return "${fmt(a)} ning ${fmt(p)} foizi = ${fmt(a * p / 100)}"
        }
        Regex("$num\\s*%\\s*(?:of|dan|ning)?\\s*$num").find(lower)?.let {
            val p = d(it.groupValues[1]) ?: return null
            val a = d(it.groupValues[2]) ?: return null
            return "${fmt(a)} ning ${fmt(p)} foizi = ${fmt(a * p / 100)}"
        }
        return null
    }

    // ---------------------------------------------------------------- BMI
    private fun bmi(flat: String): String? {
        if (!(flat.contains("bmi") || flat.contains("tana massa"))) return null
        val nums = Regex("\\d+(?:[.,]\\d+)?").findAll(flat).mapNotNull { d(it.value) }.toList()
        if (nums.size < 2) return "Yozing: «bmi 70 175» (vazn kg, bo‘y sm)."
        val w = nums[0]
        var h = nums[1]
        if (h < 3) h *= 100
        if (w < 20 || w > 400 || h < 80 || h > 260) return "Raqamlar g‘alati ko‘rindi. Misol: «bmi 70 175» (vazn kg, bo‘y sm)."
        val v = w / ((h / 100) * (h / 100))
        val cat = when {
            v < 18.5 -> "me’yordan past"
            v < 25 -> "me’yor oralig‘ida"
            v < 30 -> "me’yordan yuqori"
            else -> "yuqori"
        }
        return "Tana massasi indeksi (BMI) ≈ ${String.format(Locale.US, "%.1f", v)} — $cat. " +
            "Bu faqat taxminiy ko‘rsatkich (mushak massasi, yosh va boshqalarni hisobga olmaydi); sog‘liq masalasida shifokor bilan maslahatlashing."
    }

    // ---------------------------------------------------------------- kvadrat tenglama
    private fun equation(lower: String): String? {
        val m = Regex("tenglama\\s+(-?\\d+(?:[.,]\\d+)?)\\s+(-?\\d+(?:[.,]\\d+)?)\\s+(-?\\d+(?:[.,]\\d+)?)").find(lower) ?: return null
        val a = d(m.groupValues[1]) ?: return null
        val b = d(m.groupValues[2]) ?: return null
        val c = d(m.groupValues[3]) ?: return null
        if (a == 0.0) {
            if (b == 0.0) return "Bu tenglama emas (a va b nol)."
            return "Chiziqli tenglama: x = ${fmt(-c / b)}"
        }
        val disc = b * b - 4 * a * c
        return when {
            disc < 0 -> "D = ${fmt(disc)} < 0, haqiqiy ildizlar yo‘q."
            disc == 0.0 -> "D = 0, bitta ildiz: x = ${fmt(-b / (2 * a))}"
            else -> {
                val s = Math.sqrt(disc)
                "D = ${fmt(disc)}; x₁ = ${fmt((-b + s) / (2 * a))}, x₂ = ${fmt((-b - s) / (2 * a))}"
            }
        }
    }

    // ---------------------------------------------------------------- tub son
    private fun prime(flat: String): String? {
        if (!(flat.contains("tub son") || flat.contains("tubmi"))) return null
        val v = Regex("\\d{1,12}").find(flat)?.value?.toLongOrNull() ?: return null
        if (v < 2) return "$v tub son emas (tub sonlar 2 dan boshlanadi)."
        var i = 2L
        while (i * i <= v) {
            if (v % i == 0L) return "$v tub son emas: u $i ga bo‘linadi (${v} = $i × ${v / i})."
            i++
        }
        return "$v — tub son ✅"
    }

    // ---------------------------------------------------------------- yosh
    private fun age(flat: String): String? {
        val m = Regex("(\\d{4}).{0,25}tugil").find(flat) ?: return null
        val y = m.groupValues[1].toInt()
        val now = Calendar.getInstance().get(Calendar.YEAR)
        if (y !in 1900..now) return null
        val a = now - y
        return "$y-yilda tug‘ilgan bo‘lsangiz, bu yil $a yoshga to‘lasiz (yoki to‘lgansiz — tug‘ilgan kuningizga qarab)."
    }

    // ---------------------------------------------------------------- sanagacha necha kun
    private val months = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    ).map { n(it) }

    private fun daysUntil(flat: String): String? {
        if (!(flat.contains(n("necha kun")) || flat.contains(n("qancha")) || flat.contains("kun kol"))) return null
        val m = Regex("(\\d{1,2})\\s*(${months.joinToString("|")})").find(flat) ?: return null
        val day = m.groupValues[1].toInt()
        val mon = months.indexOf(m.groupValues[2])
        if (mon < 0 || day !in 1..31) return null
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val target = (today.clone() as Calendar).apply {
            set(Calendar.MONTH, mon); set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.DAY_OF_MONTH, minOf(day, getActualMaximum(Calendar.DAY_OF_MONTH)))
        }
        if (target.before(today)) target.add(Calendar.YEAR, 1)
        val diff = Math.round((target.timeInMillis - today.timeInMillis) / 86_400_000.0)
        return if (diff == 0L) "Aynan bugun! 🎉" else "$day-${m.groupValues[2]}gacha taxminan $diff kun qoldi."
    }

    // ---------------------------------------------------------------- birliklarni o‘girish
    private class U(val dim: String, val f: Double, val name: String)

    private val units: Map<String, U> by lazy {
        val m = HashMap<String, U>()
        fun add(dim: String, f: Double, name: String, vararg aliases: String) {
            aliases.forEach { m[n(it)] = U(dim, f, name) }
        }
        add("L", 1000.0, "km", "km", "kilometr")
        add("L", 1.0, "m", "m", "metr")
        add("L", 0.01, "sm", "sm", "santimetr")
        add("L", 0.001, "mm", "mm", "millimetr")
        add("L", 1609.344, "mil", "mil")
        add("L", 0.3048, "fut", "fut")
        add("L", 0.0254, "dyuym", "dyuym", "inch")
        add("M", 1.0, "kg", "kg", "kilogramm")
        add("M", 0.001, "g", "g", "gramm")
        add("M", 1000.0, "tonna", "tonna")
        add("M", 0.45359237, "funt", "funt", "lb")
        add("M", 0.0283495, "untsiya", "untsiya")
        add("V", 1.0, "litr", "l", "litr")
        add("V", 0.001, "ml", "ml", "millilitr")
        add("V", 3.78541, "galon", "galon")
        add("T", 3600.0, "soat", "soat")
        add("T", 60.0, "daqiqa", "daqiqa", "minut")
        add("T", 1.0, "sekund", "sekund")
        add("T", 86400.0, "kun", "kun")
        add("T", 604800.0, "hafta", "hafta")
        add("TC", 1.0, "°C", "c", "selsiy")
        add("TF", 1.0, "°F", "f", "farengeyt")
        add("TK", 1.0, "K", "kelvin")
        m
    }

    private fun convert(flat: String): String? {
        val m = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*([a-z]+)\\s+(?:${n("necha")}|${n("qancha")}|${n("nechta")})\\s+([a-z]+)").find(flat) ?: return null
        val v = d(m.groupValues[1]) ?: return null
        val a = units[m.groupValues[2]] ?: return null
        val b = units[m.groupValues[3]] ?: return null
        if (a.dim.startsWith("T") && a.dim.length == 2 || b.dim.startsWith("T") && b.dim.length == 2) {
            if (!(a.dim.length == 2 && b.dim.length == 2)) return null
            val c = when (a.dim) { "TC" -> v; "TF" -> (v - 32) * 5 / 9; else -> v - 273.15 }
            val r = when (b.dim) { "TC" -> c; "TF" -> c * 9 / 5 + 32; else -> c + 273.15 }
            return "${fmt(v)} ${a.name} = ${fmt(r)} ${b.name}"
        }
        if (a.dim != b.dim) return null
        return "${fmt(v)} ${a.name} = ${fmt(v * a.f / b.f)} ${b.name}"
    }

    // ---------------------------------------------------------------- bilimlar bazasi
    private val entries: List<Entry> by lazy {
        listOf(
            // --- sog‘liq va turmush
            e("Kattalar uchun odatda 7–9 soat uyqu tavsiya etiladi. Bir xil vaqtda yotish va turish uyqu sifatini yaxshilaydi.", "uxla|uyqu", "qancha|necha|kerak|soat"),
            e("Odatiy tavsiya — kuniga taxminan 1,5–2 litr suyuqlik, lekin u iqlim, mashq va sog‘liqqa qarab o‘zgaradi. Kasallik bo‘lsa, shifokor maslahati muhim.", "suv", "ich", "qancha|necha|kerak|litr"),
            e("Jahon sog‘liqni saqlash tashkiloti kattalarga haftasiga kamida 150 daqiqa o‘rtacha faollik (tez yurish kabi) tavsiya qiladi. Kichikdan boshlang: kuniga 20–30 daqiqa yurish.", "mashq|sport|jismoniy", "qancha|necha|haftada|kerak"),
            e("Ko‘z charchasa 20-20-20 qoidasi yordam beradi: har 20 daqiqada 20 soniya davomida taxminan 6 metr uzoqlikka qarang. Ekran yorug‘ligini ham moslang.", "ko'z", "charcha|og'ri|dam|qizar"),
            e("Bosh og‘rig‘ida suv iching, dam oling, xonani shamollating va ekrandan tanaffus qiling. Og‘riq juda kuchli, to‘satdan boshlangan yoki uzoq davom etsa — shifokorga murojaat qiling.", "bosh", "og'ri|og'riyap|og'riyd"),
            e("Stress va xavotirda nafas mashqi yordam beradi: 4 soniya nafas oling, 4 soniya ushlang, 6 soniya sekin chiqaring — 5 marta takrorlang. Keyin xavotirni qog‘ozga yozib, nimani nazorat qila olishingizni ajrating.", "stress|xavotir|tashvish|asab|bezovta"),
            e("Uyqu qiyin bo‘lsa: yotishdan 1 soat oldin telefonni qo‘ying, xonani salqin va qorong‘i qiling, kechqurun kofe/choydan saqlaning, har kuni bir vaqtda yoting.", "uyqusiz|uxlay olmay|uxlolmay"),
            e("G‘azab kelganda bir necha chuqur nafas oling, 10 gacha sanang, imkon bo‘lsa joyingizni o‘zgartiring. Tinchlanib olgach gaplashish ancha foydali.", "g'azab|jahl|achchiq"),
            e("Yolg‘izlik his qilish — odamga xos holat. Bir do‘stingizga qisqa xabar yozing yoki qiziqish bo‘yicha guruhga qo‘shiling. Men ham shu yerdaman, xohlasangiz gaplashamiz 🙂", "yolg'iz"),
            e("Boshlash — eng qiyin qismi. 5 daqiqalik qoida: ishni faqat 5 daqiqaga boshlang — ko‘pincha davom etgingiz keladi.", "dangasa|boshlay olmay|hafsala|erinch"),
            e("Dars uchun «Pomodoro» usuli: 25 daqiqa diqqat bilan ishlang, 5 daqiqa dam oling; 4 ta sikldan keyin 15–30 daqiqa uzoqroq dam. Telefonni boshqa xonaga qo‘ying.", "dars|o'qish|imtihon|tayyorlan", "qanday|yaxshi|tez|maslahat"),
            e("Yodlash uchun: o‘qiganingizni o‘zingiz tushuntirib ko‘ring, oraliq takrorlash (1 kun, 3 kun, 1 hafta) qiling, kalit so‘zlar va misollar bilan bog‘lang.", "yodlash|yodlay|esda saqlash"),
            e("Vaqtni rejalash: kuning eng muhim 1–3 ishini oldindan yoz, eng murakkabini ertalab qil, 2 daqiqada bitadigan ishni darhol bajar, kun oxirida ertangi rejani yoz.", "vaqt", "rejala|tejash|boshqar|yetishmay|ulgura"),
            e("Odat shakllanishi odamga qarab farq qiladi: tadqiqotlarda o‘rtacha taxminan 2 oy (≈66 kun) topilgan. Kichik va har kuni takrorlanadigan qadamdan boshlang.", "odat", "qancha|necha|kun|shakllan|qanday"),
            e("Pul tejash uchun 50/30/20 qoidasi: daromadning 50% — zarur xarajatlar, 30% — xohishlar, 20% — jamg‘arma. Oylik boshlanishi bilan jamg‘armani avval chetga qo‘ying.", "pul", "tejash|yig'ish|tejam|byudjet|jamg'ar"),
            e("Yaxshi rezyume: 1 sahifa, aniq maqsad, oxirgi ish joylaringiz natijalar bilan (raqamlar bilan), ko‘nikmalar, bog‘lanish ma’lumotlari; imlo xatosiz bo‘lsin.", "rezyume|cv"),
            e("Til o‘rganish: kuniga 15–20 daqiqa, har kuni; 10 ta yangi so‘z va ularni gapda ishlating; tinglash va gapirishga ko‘proq vaqt ajrating.", "til", "o'rgan", "qanday|tez|yaxshi|maslahat"),
            e("Kitob o‘qish odatini shakllantirish: kuniga 10 sahifadan boshlang, qiziq mavzu tanlang, telefonsiz joy va vaqt belgilang.", "kitob", "o'qi|o'qish", "qanday|maslahat|nima"),

            // --- haqiqiy vaqtli ma’lumotlar (internetsiz mumkin emas)
            e("Valyuta kurslarini internetsiz bilolmayman — aniq kurs uchun bank ilovasi yoki Markaziy bank saytiga qarang.", "kurs", "dollar|valyuta|yevro|rubl|som"),
            e("Ob-havoni internetsiz bilolmayman — telefondagi ob-havo ilovasiga qarang.", "ob-havo|obhavo|ob havo|havo harorati|havo rayon"),

            // --- qiziqarli
            e("Katta yo‘l birinchi qadamdan boshlanadi. Bugun bitta kichik qadam qo‘y 🙂###Mukammallikni kutma — boshla, mukammallik yo‘lda keladi.###Yiqilish mag‘lubiyat emas; yiqilib turmaslik — mag‘lubiyat.###Bugun qilgan kichik ish — ertangi katta natijaning poydevori.###Har kuni 1% yaxshilansang, bir yilda o‘zingni tanimay qolasan.",
                "motivatsiya|ruhlan|ilhomlan|iqtibos|ruhimni ko'tar"),
            e("Mehnatning tagi — rohat.###Sabr tagi — sariq oltin.###Ona yurt — oltin beshik.###Ko‘p yashagan emas, ko‘p ko‘rgan biladi.###Birlashgan o‘zar, birlashmagan to‘zar.###Yaxshi so‘z — jon ozig‘i.",
                "maqol"),
            e("To‘g‘ri saqlansa, asal deyarli buzilmaydi.###Venerada bir kun (o‘z o‘qi atrofida to‘liq aylanish) uning bir yilidan uzoqroq davom etadi.###Ahtapotning uchta yuragi bor.###Yer yuzining taxminan 71 foizini suv egallaydi.###Mushuklar kunning ko‘p qismini — 12–16 soatni — uxlab o‘tkazadi.###«Algoritm» so‘zi buyuk bobokalonimiz al-Xorazmiy ismidan kelib chiqqan.###Banan botanik jihatdan rezavor mevalar turkumiga kiradi.",
                "fakt|qiziq narsa|qiziqarli|bilasanmi|bilasizmi"),

            // --- Zeno haqida
            e("Mening yoshim yo‘q — dasturman 🙂 Lekin sizni tinglashga doim tayyorman.", "yoshing|yoshingiz", "necha|nechchi|qancha"),
            e("Meni shu ilovani yaratgan inson yozgan. Men telefoningizdagi virtual do‘stman: maqsad, xotira, mashq natijalari va hisob-kitobda yordam beraman.", "seni kim|kim yaratgan|kim yozgan|kim tuzgan|yaratuvchi"),
            e("Rahmat, juda iliq so‘z 🙂 Men dastur bo‘lsam ham, sizga yordam berishdan xursandman.", "seni yaxshi ko'raman|seni sevaman|sevaman seni"),
            e("Sevimli rangim — yashil 😄 (ilovam ikonkasidagi nuqta ham shunday). Sizniki-chi?", "sevimli", "rang")
        )
    }
}
