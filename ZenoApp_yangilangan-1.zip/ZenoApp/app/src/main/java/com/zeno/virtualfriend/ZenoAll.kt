package com.zeno.virtualfriend

import android.Manifest
import android.app.AlarmManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.widget.ImageButton
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import android.widget.ImageView
import android.widget.PopupMenu
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.util.TypedValue
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import org.json.JSONArray
import org.json.JSONObject

// ======================== ZenoDb.kt ========================
data class Mem(val id: Long, val category: String, val text: String)
data class Goal(val id: Long, val title: String, val reminderTime: String? = null)
data class Workout(val day: String, val note: String, val amount: Int)

object Util {
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun todayDots(): String = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())
    fun hour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    fun midnight(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

class ZenoDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "zeno.db", null, 2) {

    companion object {
        @Volatile private var inst: ZenoDb? = null
        fun get(ctx: Context): ZenoDb = inst ?: synchronized(this) {
            inst ?: ZenoDb(ctx.applicationContext).also { inst = it }
        }
        private const val MAX_MEMORIES = 300
        private const val MAX_CHAT = 60
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, text TEXT, norm TEXT UNIQUE, ts INTEGER)")
        db.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, done INTEGER DEFAULT 0, ts INTEGER, reminder_time TEXT, last_reminder_day TEXT)")
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT, note TEXT, amount INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE style_days(day TEXT PRIMARY KEY, n INTEGER, sum REAL)")
        db.execSQL("CREATE TABLE notif_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, text TEXT)")
        db.execSQL("CREATE TABLE usage_alerts(day TEXT, pkg TEXT, threshold INTEGER, PRIMARY KEY(day, pkg, threshold))")
        db.execSQL("CREATE TABLE chat(id INTEGER PRIMARY KEY AUTOINCREMENT, who TEXT, text TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE goals ADD COLUMN reminder_time TEXT")
            db.execSQL("ALTER TABLE goals ADD COLUMN last_reminder_day TEXT")
        }
    }

    // ---------- Xotira ----------
    fun addMemory(category: String, text: String): Boolean {
        val clean = text.trim().take(160)
        if (clean.isEmpty()) return false
        val norm = clean.lowercase().replace(Regex("\\s+"), " ")
        val cv = ContentValues().apply {
            put("category", category); put("text", clean)
            put("norm", norm); put("ts", System.currentTimeMillis())
        }
        val id = writableDatabase.insertWithOnConflict("memories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        if (id != -1L) {
            // eski yozuvlarni siqish: faqat oxirgi MAX_MEMORIES ta qoladi
            writableDatabase.execSQL(
                "DELETE FROM memories WHERE id NOT IN (SELECT id FROM memories ORDER BY id DESC LIMIT $MAX_MEMORIES)"
            )
        }
        return id != -1L
    }

    fun memories(): List<Mem> = readableDatabase.rawQuery(
        "SELECT id, category, text FROM memories ORDER BY id DESC", null
    ).use { c ->
        val out = ArrayList<Mem>()
        while (c.moveToNext()) out.add(Mem(c.getLong(0), c.getString(1), c.getString(2)))
        out
    }

    fun deleteMemory(id: Long): Boolean =
        writableDatabase.delete("memories", "id=?", arrayOf(id.toString())) > 0

    /** Xotira statistikasi: turkum bo‘yicha soni va so‘nggi 7 kunda qo‘shilganlar (eng eskisidan bugungacha). */
    fun memoryStats(): Pair<List<Pair<String, Int>>, IntArray> {
        val cats = ArrayList<Pair<String, Int>>()
        readableDatabase.rawQuery(
            "SELECT category, COUNT(*) FROM memories GROUP BY category ORDER BY COUNT(*) DESC", null
        ).use { c ->
            while (c.moveToNext()) cats.add(Pair(c.getString(0) ?: "Boshqa", c.getInt(1)))
        }
        val days = IntArray(7)
        val dayMs = 24L * 3_600_000L
        val start = Util.midnight() - 6 * dayMs
        readableDatabase.rawQuery("SELECT ts FROM memories WHERE ts >= ?", arrayOf(start.toString())).use { c ->
            while (c.moveToNext()) {
                val idx = ((c.getLong(0) - start) / dayMs).toInt()
                if (idx in 0..6) days[idx]++
            }
        }
        return Pair(cats, days)
    }

    fun clearAll() {
        val d = writableDatabase
        listOf("memories", "goals", "workouts", "style_days", "chat").forEach { d.execSQL("DELETE FROM $it") }
    }

    // ---------- Maqsadlar ----------
    fun addGoal(title: String, reminderTime: String? = null): Long {
        val clean = title.trim().take(120)
        if (clean.isEmpty()) return -1L
        val existing = readableDatabase.rawQuery(
            "SELECT id FROM goals WHERE done=0 AND lower(title)=lower(?) LIMIT 1", arrayOf(clean)
        ).use { if (it.moveToFirst()) it.getLong(0) else null }
        if (existing != null) {
            if (reminderTime != null) {
                val cv = ContentValues().apply { put("reminder_time", reminderTime); putNull("last_reminder_day") }
                writableDatabase.update("goals", cv, "id=?", arrayOf(existing.toString()))
            }
            return existing
        }
        val cv = ContentValues().apply {
            put("title", clean); put("done", 0); put("ts", System.currentTimeMillis())
            if (reminderTime != null) put("reminder_time", reminderTime) else putNull("reminder_time")
            putNull("last_reminder_day")
        }
        return writableDatabase.insert("goals", null, cv)
    }

    fun openGoals(): List<Goal> = readableDatabase.rawQuery(
        "SELECT id, title, reminder_time FROM goals WHERE done=0 ORDER BY id", null
    ).use { c ->
        val out = ArrayList<Goal>()
        while (c.moveToNext()) out.add(Goal(c.getLong(0), c.getString(1), if (c.isNull(2)) null else c.getString(2)))
        out
    }

    fun dueGoals(nowHHmm: String): List<Goal> {
        val parts = nowHHmm.split(":")
        val total = (parts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (parts.getOrNull(1)?.toIntOrNull() ?: 0)
        val earliestTotal = (total - 45).coerceAtLeast(0)
        val earliest = String.format(Locale.US, "%02d:%02d", earliestTotal / 60, earliestTotal % 60)
        return readableDatabase.rawQuery(
        "SELECT id, title, reminder_time FROM goals WHERE done=0 AND reminder_time IS NOT NULL AND reminder_time<=? AND reminder_time>=? AND (last_reminder_day IS NULL OR last_reminder_day<>?) ORDER BY reminder_time",
        arrayOf(nowHHmm, earliest, Util.today())
    ).use { c ->
        val out = ArrayList<Goal>()
        while (c.moveToNext()) out.add(Goal(c.getLong(0), c.getString(1), c.getString(2)))
        out
    }
    }

    fun markGoalReminder(id: Long) {
        val cv = ContentValues().apply { put("last_reminder_day", Util.today()) }
        writableDatabase.update("goals", cv, "id=?", arrayOf(id.toString()))
    }

    fun allGoals(): List<Pair<Long, String>> = readableDatabase.rawQuery(
        "SELECT id, title FROM goals WHERE done=0 ORDER BY id DESC", null
    ).use { c ->
        val out = ArrayList<Pair<Long, String>>()
        while (c.moveToNext()) out.add(Pair(c.getLong(0), c.getString(1)))
        out
    }

    fun completeGoal(id: Long): String? {
        val title = readableDatabase.rawQuery(
            "SELECT title FROM goals WHERE id=? AND done=0", arrayOf(id.toString())
        ).use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        val cv = ContentValues().apply { put("done", 1) }
        writableDatabase.update("goals", cv, "id=?", arrayOf(id.toString()))
        return title
    }

    // ---------- Mashg'ulotlar ----------
    fun addWorkout(note: String, amount: Int) {
        val cv = ContentValues().apply {
            put("day", Util.today()); put("note", note); put("amount", amount)
            put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("workouts", null, cv)
    }

    fun lastWorkout(): Workout? = readableDatabase.rawQuery(
        "SELECT day, note, amount FROM workouts ORDER BY id DESC LIMIT 1", null
    ).use { if (it.moveToFirst()) Workout(it.getString(0), it.getString(1), it.getInt(2)) else null }

    fun recentWorkouts(limit: Int): List<Workout> = readableDatabase.rawQuery(
        "SELECT day, note, amount FROM workouts ORDER BY id DESC LIMIT $limit", null
    ).use { c ->
        val out = ArrayList<Workout>()
        while (c.moveToNext()) out.add(Workout(c.getString(0), c.getString(1), c.getInt(2)))
        out
    }

    fun workoutCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM workouts", null)
        .use { if (it.moveToFirst()) it.getInt(0) else 0 }

    // ---------- Muloqot uslubi statistikasi ----------
    fun addStyleSample(score: Double) {
        val day = Util.today()
        val row = readableDatabase.rawQuery("SELECT n, sum FROM style_days WHERE day=?", arrayOf(day))
            .use { if (it.moveToFirst()) Pair(it.getInt(0), it.getDouble(1)) else null }
        val cv = ContentValues().apply {
            put("day", day)
            put("n", (row?.first ?: 0) + 1)
            put("sum", (row?.second ?: 0.0) + score)
        }
        writableDatabase.insertWithOnConflict("style_days", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** (xabarlar soni, ball yig'indisi) — oxirgi `limit` kun, bugun ham kiradi */
    fun styleDays(limit: Int): List<Pair<Int, Double>> = readableDatabase.rawQuery(
        "SELECT n, sum FROM style_days ORDER BY day DESC LIMIT $limit", null
    ).use { c ->
        val out = ArrayList<Pair<Int, Double>>()
        while (c.moveToNext()) out.add(Pair(c.getInt(0), c.getDouble(1)))
        out
    }

    // ---------- Bildirishnomalar jurnali ----------
    fun logNotif(kind: String, text: String) {
        val cv = ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("kind", kind); put("text", text)
        }
        writableDatabase.insert("notif_log", null, cv)
    }

    /** Kunlik limitga "inactive" (suhbat taklifi) kirmaydi — u alohida hisoblanadi */
    fun notifCountToday(): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM notif_log WHERE ts>=? AND kind NOT IN ('inactive','test')", arrayOf(Util.midnight().toString())
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun recentNotifTexts(limit: Int): Set<String> = readableDatabase.rawQuery(
        "SELECT text FROM notif_log ORDER BY id DESC LIMIT $limit", null
    ).use { c ->
        val out = HashSet<String>()
        while (c.moveToNext()) out.add(c.getString(0))
        out
    }

    fun lastNotifTs(kind: String): Long = readableDatabase.rawQuery(
        "SELECT MAX(ts) FROM notif_log WHERE kind=?", arrayOf(kind)
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun prune() {
        val d = writableDatabase
        val weekAgo = System.currentTimeMillis() - 14L * 24 * 3600 * 1000
        d.execSQL("DELETE FROM notif_log WHERE ts < $weekAgo")
        d.execSQL("DELETE FROM usage_alerts WHERE day < ?", arrayOf(Util.today()))
        d.execSQL("DELETE FROM style_days WHERE day NOT IN (SELECT day FROM style_days ORDER BY day DESC LIMIT 30)")
    }

    // ---------- Ilova vaqti ogohlantirishlari ----------
    fun usageAlertSent(day: String, pkg: String, t: Int): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM usage_alerts WHERE day=? AND pkg=? AND threshold=?", arrayOf(day, pkg, t.toString())
    ).use { it.moveToFirst() }

    fun markUsageAlert(day: String, pkg: String, t: Int) {
        val cv = ContentValues().apply { put("day", day); put("pkg", pkg); put("threshold", t) }
        writableDatabase.insertWithOnConflict("usage_alerts", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    // ---------- Suhbat tarixi (oxirgi MAX_CHAT ta xabar) ----------
    fun addChat(who: String, text: String) {
        val cv = ContentValues().apply { put("who", who); put("text", text); put("ts", System.currentTimeMillis()) }
        writableDatabase.insert("chat", null, cv)
        writableDatabase.execSQL(
            "DELETE FROM chat WHERE id NOT IN (SELECT id FROM chat ORDER BY id DESC LIMIT $MAX_CHAT)"
        )
    }

    fun recentChat(): List<Pair<String, String>> = readableDatabase.rawQuery(
        "SELECT who, text FROM (SELECT id, who, text FROM chat ORDER BY id DESC LIMIT $MAX_CHAT) ORDER BY id ASC", null
    ).use { c ->
        val out = ArrayList<Pair<String, String>>()
        while (c.moveToNext()) out.add(Pair(c.getString(0), c.getString(1)))
        out
    }
}

// ======================== ZenoPrefs.kt ========================
data class TrackedApp(
    val pkg: String,
    val label: String,
    val enabled: Boolean,
    val thresholds: List<Int>
)

class ZenoPrefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zeno_prefs", Context.MODE_PRIVATE)

    var lastActive: Long
        get() {
            val v = sp.getLong("last_active", 0L)
            if (v != 0L) return v
            val now = System.currentTimeMillis()
            sp.edit().putLong("last_active", now).apply()
            return now
        }
        set(v) { sp.edit().putLong("last_active", v).apply() }

    var dailyCap: Int
        get() = sp.getInt("cap", 15)
        set(v) { sp.edit().putInt("cap", v).apply() }

    var quietStart: Int
        get() = sp.getInt("quiet_start", 23)
        set(v) { sp.edit().putInt("quiet_start", v).apply() }

    var quietEnd: Int
        get() = sp.getInt("quiet_end", 7)
        set(v) { sp.edit().putInt("quiet_end", v).apply() }

    var inactivityNudges: Boolean
        get() = sp.getBoolean("inactivity", true)
        set(v) { sp.edit().putBoolean("inactivity", v).apply() }

    var motivation: Boolean
        get() = sp.getBoolean("motivation", true)
        set(v) { sp.edit().putBoolean("motivation", v).apply() }

    var usageTracking: Boolean
        get() = sp.getBoolean("usage_tracking", true)
        set(v) { sp.edit().putBoolean("usage_tracking", v).apply() }

    var pausedUntil: Long
        get() = sp.getLong("paused_until", 0L)
        set(v) { sp.edit().putLong("paused_until", v).apply() }

    var lastInactivityNudge: Long
        get() = sp.getLong("last_inactivity_nudge", 0L)
        set(v) { sp.edit().putLong("last_inactivity_nudge", v).apply() }

    /** Doimiy fon xizmati (ishonchli eslatmalar uchun) */
    var keepAlive: Boolean
        get() = sp.getBoolean("keep_alive", true)
        set(v) { sp.edit().putBoolean("keep_alive", v).apply() }

    var lastTick: Long
        get() = sp.getLong("last_tick", 0L)
        set(v) { sp.edit().putLong("last_tick", v).apply() }

    /** Orqa fon rasmi xiraligi (0..90 %) */
    var bgDim: Int
        get() = sp.getInt("bg_dim", 40)
        set(v) { sp.edit().putInt("bg_dim", v).apply() }

    /** Orqa fonni xira qilish (blur) darajasi 0..6 */
    var bgBlur: Int
        get() = sp.getInt("bg_blur", 0)
        set(v) { sp.edit().putInt("bg_blur", v).apply() }

    /** Bilimlar fayllari papkasi (SAF uri) — bo‘sh bo‘lsa tanlanmagan */
    var kbTree: String
        get() = sp.getString("kb_tree", "") ?: ""
        set(v) { sp.edit().putString("kb_tree", v).apply() }

    var aiOn: Boolean
        get() = sp.getBoolean("ai_on", true)
        set(v) { sp.edit().putBoolean("ai_on", v).apply() }

    var aiKey: String
        get() = sp.getString("ai_key", "") ?: ""
        set(v) { sp.edit().putString("ai_key", v.trim()).apply() }

    /** "auto" | "neutral" | "serious" | "playful" */
    var styleMode: String
        get() = sp.getString("style_mode", "auto") ?: "auto"
        set(v) { sp.edit().putString("style_mode", v).apply() }

    fun tracked(): List<TrackedApp> {
        val s = sp.getString("tracked", null) ?: return presets()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val t = o.getJSONArray("t")
                TrackedApp(
                    o.getString("pkg"), o.getString("label"), o.getBoolean("on"),
                    (0 until t.length()).map { t.getInt(it) }
                )
            }
        } catch (e: Exception) {
            presets()
        }
    }

    fun saveTracked(list: List<TrackedApp>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject()
                    .put("pkg", it.pkg).put("label", it.label).put("on", it.enabled)
                    .put("t", JSONArray(it.thresholds))
            )
        }
        sp.edit().putString("tracked", a.toString()).apply()
    }

    private fun presets(): List<TrackedApp> {
        val d = listOf(30, 60, 90)
        return listOf(
            TrackedApp("com.mobile.legends", "Mobile Legends", false, d),
            TrackedApp("com.instagram.android", "Instagram", false, d),
            TrackedApp("com.google.android.youtube", "YouTube", false, d),
            TrackedApp("org.telegram.messenger", "Telegram", false, d),
            TrackedApp("com.mojang.minecraftpe", "Minecraft", false, d)
        )
    }
}

// ======================== ZenoBrain.kt ========================
enum class Tone { PLAYFUL, NEUTRAL, SERIOUS }

/** Tayyor jumlalar banki. pick() ketma-ket bir xil jumlani qaytarmaydi. */
object Msg {
    private val last = HashMap<String, Int>()

    fun pick(key: String, list: List<String>): String {
        if (list.size == 1) return list[0]
        var i = Random.nextInt(list.size)
        if (i == last[key]) i = (i + 1) % list.size
        last[key] = i
        return list[i]
    }

    val greet = mapOf(
        Tone.PLAYFUL to listOf("Qalesan, bro! 😄 Bugun nima gap?", "O‘o, salom! Kayfiyatlar zo‘rmi? 😎", "Salom-salom! Yangilik bormi? 😊"),
        Tone.NEUTRAL to listOf("Salom! Bugun qanday o‘tyapti?", "Salom, bro. Eshitaman — nima yangilik?", "Salom! Reja yoki mashg‘ulotlar haqida gaplashamizmi?"),
        Tone.SERIOUS to listOf("Salom. Eshitaman.", "Salom. Bugun nimadan boshlaymiz?")
    )
    val ack = mapOf(
        Tone.PLAYFUL to listOf("Hmm, qiziq-ku 😄 Yana aytchi.", "Tushundim, bro 😎 Davom et!", "Ha-ha, mayli! Keyin nima bo‘ldi?"),
        Tone.NEUTRAL to listOf("Tushundim. Davom ettir, eshitaman.", "Mayli, buni yodda tutaman. Yana nima bor?", "Ha, tushundim. Bu haqda ko‘proq aytib bera olasanmi?"),
        Tone.SERIOUS to listOf("Tushundim.", "Eshitdim. Davom ettir.")
    )
    val thanks = listOf("Arzimaydi, bro 🙂", "Doim tayyorman.", "Marhamat! Yana kerak bo‘lsam, yoz.")
    val support = listOf(
        "Ko‘rinishidan bugun og‘irroq kun bo‘lganga o‘xshaydi. Xohlasang, gaplashamiz; xohlamasang, shunchaki shu yerdaman.",
        "Bunaqa kunlar bo‘ladi. Biroz dam olib ko‘rsang-chi? Xohlasang, nima bo‘lganini aytib ber."
    )
    val jokes = listOf(
        "Dasturchi nega ko‘zoynak taqadi? Chunki C# ko‘rolmaydi 😄",
        "— Dadajon, nega telefon issiq bo‘ldi? — Chunki u «qizib» ketdi, bolam 😅",
        "Do‘stim aytdi: «Ertaga boshlayman». Bugun esa «Kecha boshlamagan edim» deb o‘tiribdi 😎",
        "Bir odam dangasalikdan charchabdi, lekin dam olishga ham dangasa bo‘libdi 😄"
    )
    val advice = listOf(
        "Hozir 10 daqiqa bitta kichik ishga ajrat: xona yig‘ishtir, bir sahifa o‘qi yoki 20 ta mashq qil. Boshlash eng qiyin qismi.",
        "Suv ich, derazani och, 5 daqiqa yur. Keyin nima qilishni o‘zing aniqroq his qilasan.",
        "Bugungi eng muhim bitta ishni yoz. Faqat bittasini. Uni bajarsang, kun behuda o‘tmagan bo‘ladi."
    )
    val noAnswer = listOf(
        "Bu savolga aniq javob topa olmadim. «mavzular» deb yozsang, qaysi mavzularni bilishimni ko‘rsataman. Yoki savolni boshqacharoq aytib ko‘r.",
        "Buni hozir ishonchli aytolmayman (internetsiz bilimim cheklangan). «mavzular» deb yozsang, nimalarni bilishimni ko‘rasan; AI kaliti qo‘shilsa, har qanday savolga javob beraman."
    )
    val helpCmds = setOf("yordam", "/yordam", "/help", "help", "/start", "menyu", "pomosh", "yordam ber")
    val memoryCmds = setOf("/xotira", "xotira", "xotiram", "eslaganlaring")
    val goalCmds = setOf("maqsadlarim", "maqsadlar", "rejalarim", "rejalar")
    val resultCmds = setOf("natijalarim", "natijalar", "mashqlarim", "mashqlar")
    val greetWords = setOf(
        "salom", "salam", "assalomu", "assalom", "qale", "qalesan", "hayrli",
        "hello", "hi", "hey", "privet", "zdravstvuyte"
    )
    val thanksWords = setOf("rahmat", "raxmat", "tashakkur", "minnatdorman", "thanks", "thank", "spasibo", "sagol")
    val byeWords = setOf("xayr", "hayr", "bay", "bye", "poka", "ko'rishguncha")
    val lowWords = setOf(
        "charchadim", "charchab", "xafaman", "hafaman", "xafa", "hafa", "yomon", "zerikdim",
        "toliqdim", "horib", "qiynalyapman", "qiyin", "tushkunman", "bezorman", "stress"
    )
    val bye = listOf("Xayr, bro! Kerak bo‘lsam, yoz 🙂", "Ko‘rishguncha! Omad.", "Xayr! Yaxshi dam ol.")
    val howAreYou = mapOf(
        Tone.PLAYFUL to listOf("Zo‘rman, bro! 😄 O‘zing qalaysan?", "Ishlar yaxshi 😎 Sendachi?"),
        Tone.NEUTRAL to listOf("Yaxshi, rahmat. O‘zingda nima yangilik?", "Hammasi joyida. Sen qalaysan?"),
        Tone.SERIOUS to listOf("Yaxshi. O‘zing-chi?", "Normal. Eshitaman.")
    )
    const val WHO = "Men Zenoman — telefondagi virtual do‘sting. Maqsadlar, mashq natijalari, xotira va hisob-kitobda yordam beraman. «yordam» deb yozsang, hammasini ko‘rsataman."

    const val HELP = "Men quyidagilarni tushunaman:\n" +
        "• maqsad: <matn> — maqsad qo‘shish; maqsad: Ingliz tili | 18:00 — vaqtli eslatma\n" +
        "• maqsadlarim — ochiq maqsadlar\n" +
        "• tayyor <raqam> — maqsadni bajarilgan deb belgilash\n" +
        "• mashq: 100 takror — natijani yozish\n" +
        "• natijalarim — oxirgi natijalar\n" +
        "• eslab qol: <matn> — xotiraga qo‘lda yozish\n" +
        "• /xotira — xotirani ko‘rish, /unut <raqam> — o‘chirish\n" +
        "• Soatni aytsang (masalan, har kuni 18:00 da ingliz tilini o‘rganaman), eslatma qo‘yaman\n" +
        "• hisobla 12*(3+4) — hisob-kitob\n" +
        "• /uslub avto|oddiy|jiddiy|quvnoq — muloqot uslubi\n" +
        "• mavzular — sizning bilimlar fayllaringizdagi mavzular ro‘yxati\n" +
        "• |Mavzu nomi| — mavzuni tanlash; hisob-kitob, maslahat va suhbat ham bor"

    // Fon bildirishnomalari uchun
    val inactiveShort = "Bro, bugun band bo‘lsang kerak 😅 Vaqting bo‘lsa, keyin gaplashamiz."
    val inactiveLong = "Bro, anchadan beri ko‘rinmaysan-ku 😅 Hammasi yaxshimi? Vaqting bo‘lsa, biroz suhbatlashamiz!"
    val motivNeutral = listOf(
        "Kichik qadam ham qadam. Bugun nimaga vaqt ajratasan?",
        "Dam olish ham rejaning bir qismi. Suv ichib, biroz cho‘zilib ol 🙂",
        "Hozir bir daqiqa to‘xtab, nafas olib ol — keyin yana davom etasan.",
        "Bugun kun qanday o‘tyapti? Xohlasang, yozib qo‘y, gaplashamiz.",
        "Telefondan bosh ko‘tarib, ko‘zlaringga dam berib qo‘y 👀",
        "Bugun boshlagan ishingga 10 daqiqa ajratsang ham yetadi."
    )
    val motivPlayful = listOf(
        "Bro, suv ichdingmi? 💧 Yo‘q bo‘lsa, hoziroq!",
        "Ey, qalaysan? 😄 Bugun nima qilib yuribsan?",
        "Kichik g‘alaba ham g‘alaba 😎 Bugun bittasini qo‘lga kiritamizmi?",
        "Biroz cho‘zilib ol, bro — yelkalar qotib qolmasin 😅",
        "Telefondan bosh ko‘tar-chi, atrofda nimalar bor 👀",
        "Ruhiyat qalay? Gaplashging kelsa, shu yerdaman 🙂"
    )
}

/** Kirill yozuvini lotinga o‘giradi (o‘zbekcha), shunda ikkala yozuvda ham tushunadi. */
object Norm {
    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m",
        'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "x", 'ц' to "s", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "'",
        'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o'", 'қ' to "q",
        'ғ' to "g'", 'ҳ' to "h"
    )

    fun latin(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            val low = ch.lowercaseChar()
            val m = cyr[low]
            if (m == null) sb.append(ch)
            else sb.append(if (ch != low) m.replaceFirstChar { it.uppercase() } else m)
        }
        return sb.toString()
    }
}

object Calc {
    fun eval(src: String): Double? = try {
        val s = src.replace(',', '.').replace('x', '*').replace('×', '*').replace('÷', '/').replace(" ", "")
        if (s.length > 200) null else P(s).parse().takeIf { it.isFinite() }
    } catch (e: Exception) {
        null
    } catch (e: StackOverflowError) {
        null // juda ko‘p qavs — ilova qulamasin
    }

    fun format(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString()
        else String.format(java.util.Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')

    private class P(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]; val r = factor()
                if (op == '/' && r == 0.0) throw ArithmeticException()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun factor(): Double {
            if (i < s.length && s[i] == '-') { i++; return -factor() }
            if (i < s.length && s[i] == '(') {
                i++; val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException()
                i++; return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException()
            return s.substring(st, i).toDouble()
        }
    }
}

/** Claude API orqali javob oladi (internet va API kaliti kerak). Faqat fon oqimida chaqiriladi. */
object Ai {
    const val MODEL = "claude-haiku-5-5"

    fun ask(key: String, extra: String, chat: List<Pair<String, String>>): String? {
        val system = "Sen Zeno — foydalanuvchining telefondagi samimiy virtual hamrohi. " +
            "Foydalanuvchi qaysi tilda yozsa, shu tilda (asosan o‘zbek, lotin yozuvida), uning oddiy va norasmiy yozish uslubiga mos, qisqa va tabiiy javob ber. " +
            "Hissiyotlarni faqat stiker bilan emas, matn ichida ham tabiiy ko‘rsat: gap boshida, o‘rtasida yoki oxirida vaziyatga mos emoji belgilaridan foydalan (masalan 😊 😄 🤔 🥹 ❤️ 😔 😂), lekin har bir gapga emoji tiqishtirma va bir xil belgini doim takrorlama. " +
            "Xursandchilikda quvnoqroq, hazilda yengil, jiddiy mavzuda vazmin, xafalik yoki dard aytilganda esa muloyim va hamdard bo‘l; qayg‘uli vaziyatga mos kelmaydigan kulgili emoji ishlatma. " +
            "Xafa bo‘lgan foydalanuvchini darhol maslahatga ko‘mib tashlama: avval tingla va hislarini tan ol, keyin maslahat kerakmi deb muloyim taklif qil. Uni gapirishga majburlama, hislarini kichraytirma va bilmaganingni o‘ylab topma. " +
            "Javob 1–4 jumladan oshmasin. Bilmasang, to‘g‘risini ayt. " + extra
        // Xabarlar navbatma-navbat bo‘lishi va foydalanuvchidan boshlanishi kerak
        val msgs = ArrayList<Pair<String, String>>()
        for ((who, text) in chat.takeLast(12)) {
            val role = if (who == "me") "user" else "assistant"
            if (msgs.isNotEmpty() && msgs.last().first == role) {
                msgs[msgs.size - 1] = Pair(role, msgs.last().second + "\n" + text)
            } else msgs.add(Pair(role, text))
        }
        while (msgs.isNotEmpty() && msgs.first().first != "user") msgs.removeAt(0)
        if (msgs.isEmpty() || msgs.last().first != "user") return null

        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }

        // Asosiy model topilmasa (404), zaxira modelni sinaymiz
        var last: String? = null
        for (m in listOf(MODEL, FALLBACK_MODEL)) {
            val r = request(key.trim(), m, system, arr)
            if (r != null && r.startsWith("__ERR__HTTP 404")) {
                last = r
                continue
            }
            return r
        }
        return last
    }

    private const val FALLBACK_MODEL = "claude-haiku-4-5"

    /** Javob matni; "__KEY__" — kalit noto‘g‘ri; "__ERR__..." — boshqa xato (sababi bilan). */
    private fun request(key: String, model: String, system: String, arr: JSONArray): String? {
        val body = JSONObject().put("model", model).put("max_tokens", 400).put("system", system).put("messages", arr)
        var con: java.net.HttpURLConnection? = null
        return try {
            con = java.net.URL("https://api.anthropic.com/v1/messages").openConnection() as java.net.HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 15000
            con.readTimeout = 30000
            con.doOutput = true
            con.setRequestProperty("content-type", "application/json")
            con.setRequestProperty("x-api-key", key)
            con.setRequestProperty("anthropic-version", "2023-06-01")
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            if (code == 401) return "__KEY__"
            if (code !in 200..299) {
                val errBody = try { con.errorStream?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null }
                val msg = try { JSONObject(errBody ?: "").getJSONObject("error").optString("message") } catch (e: Exception) { "" }
                Log.e("Ai", "HTTP $code $msg")
                return "__ERR__HTTP $code" + if (msg.isNotBlank()) ": ${msg.take(160)}" else ""
            }
            val resp = con.inputStream.bufferedReader().use { it.readText() }
            val content = JSONObject(resp).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val c = content.getJSONObject(i)
                if (c.optString("type") == "text") sb.append(c.optString("text"))
            }
            sb.toString().trim().ifEmpty { null }
        } catch (e: Exception) {
            Log.e("Ai", "so‘rov xatosi", e)
            "__ERR__" + when (e) {
                is java.net.UnknownHostException, is java.net.ConnectException,
                is java.net.SocketTimeoutException -> "internetga ulanib bo‘lmadi"
                is IllegalArgumentException -> "API kalitida ortiqcha belgi bor (qayta kiriting)"
                else -> e.javaClass.simpleName
            }
        } finally {
            con?.disconnect()
        }
    }
}

class ZenoBrain(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val db = ZenoDb.get(ctx)
    private val prefs = ZenoPrefs(ctx)

    companion object {
        /** Joriy suhbatdagi oxirgi 3 xabar balli — faqat shu javob uchun vaqtinchalik kayfiyat */
        private val session = ArrayDeque<Double>()
    }

    // ---------------- Uslub (xarakter) ----------------

    /** Uzoq muddatli uslub: oxirgi 5 kunning o‘rtachasi (kamida 3 kun, kuniga ≥2 xabar). */
    fun baseTone(): Tone {
        when (prefs.styleMode) {
            "serious" -> return Tone.SERIOUS
            "playful" -> return Tone.PLAYFUL
            "neutral" -> return Tone.NEUTRAL
        }
        val days = db.styleDays(5).filter { it.first >= 2 }
        if (days.size < 3) return Tone.NEUTRAL
        val avg = days.sumOf { it.second / it.first } / days.size
        return when {
            avg >= 0.35 -> Tone.PLAYFUL
            avg <= -0.2 -> Tone.SERIOUS
            else -> Tone.NEUTRAL
        }
    }

    /** Bir kunlik kayfiyat umumiy xarakterni o‘zgartirmaydi: faqat shu javobga ta’sir qiladi. */
    private fun effectiveTone(): Tone {
        val base = baseTone()
        if (prefs.styleMode != "auto" || session.size < 3) return base
        if (session.all { it <= -0.5 }) return Tone.SERIOUS
        if (session.all { it >= 1.0 }) return Tone.PLAYFUL
        return base
    }

    private val playfulRe = Regex("(😂|🤣|😄|😅|😁|😎|😜|\\)\\)|haha|xaxa|ahah|lol|hazil)")

    private fun styleScore(lower: String): Double {
        val words = lower.split(Regex("\\s+")).count { it.isNotBlank() }
        return when {
            playfulRe.containsMatchIn(lower) -> 1.0
            words <= 2 && !lower.contains('?') -> -0.5
            else -> 0.0
        }
    }

    // ---------------- Asosiy javob ----------------

    /** true bo‘lsa, javob tayyor qoidalardan topilmagan (AI'ga yuborish mumkin). */
    var lastWasFallback = false

    private fun fallbackReply(question: Boolean, tone: Tone, lower: String = ""): String {
        // Faol mavzu bo‘lsa va javob topilmasa — avval foydalanuvchining bazasidagi izohni tekshiramiz.
        if (question) UserKb.unsureReply(appCtx)?.let {
            lastWasFallback = false
            return it
        }
        lastWasFallback = true

        // Bilim yetishmaganda ham suhbatni uzib qo‘ymaslik: bilmaganni tan olish va tabiiy davom ettirish.
        if (question) return Msg.pick("unknownTalk", listOf(
            "Buni hozir aniq bilmayman, noto‘g‘ri ma’lumot berishni xohlamayman 😅 Lekin gapni tashlab ketmayman — biroz batafsilroq aytsang, birga tushunishga harakat qilamiz.",
            "Bu savolga ishonchli javobim yo‘q hozircha. Qaysi tomoni seni qiziqtiryapti? Shuni aniqlasak, bilganlarim bilan yordam beraman.",
            "Rostini aytsam, bunga aniq javob topolmadim. Xohlasang, boshqacha qilib tushuntir yoki ozgina kontekst ber — birga ko‘rib chiqamiz.",
            "Hozir bunga aniq javob bera olmayman, bro. Lekin boshqa tomondan gaplashishimiz mumkin — sen nimani nazarda tutganingni aytib ber-chi."
        ))

        val conversational = when {
            Regex("(zerik|nima qil|gaplash|suhbatlash)").containsMatchIn(lower) -> listOf(
                "Unda gaplashamiz 😄 Bugun nimalar bilan bandsan? Yoki xohlasang, men qiziq mavzu tashlayman.",
                "Bo‘ldi, suhbat qilamiz. O‘yinlar, texnologiya, hayot yoki shunchaki kulgili gaplar — qaysi biri kayfiyatingga mos?",
                "Mayli, jim qolib ketmaymiz 😅 Bugun xayolingda nima bor? Jiddiy mavzu bo‘lishi shart emas."
            )
            Regex("(bilmayman|bilmadim|farqi yo'q|farqi yoq|baribir)").containsMatchIn(lower) -> listOf(
                "Mayli, hozir aniq fikring bo‘lmasa ham bo‘ladi. Shoshilmaymiz — xohlasang, boshqa mavzudan boshlaymiz.",
                "Hechqisi yo‘q. Ba’zan nima deyishni bilmay qolamiz. Men bir mavzu taklif qilaymi yoki o‘zing xohlagan narsani aytasanmi?"
            )
            Regex("(ha endi|mayli|xo'p|hop|bo'pti|tushunarli|tushundim)").containsMatchIn(lower) -> listOf(
                "Bo‘ldi 🙂 Keyin nima qilamiz? Yana shu mavzuni davom ettiramizmi yoki boshqasiga o‘tamizmi?",
                "Xo‘p, tushundim. Aytgancha, xayolingda yana biror narsa bo‘lsa, bemalol yozaver."
            )
            lower.length < 12 -> listOf(
                "Ha, eshitaman 🙂 Yana ayt-chi.",
                "Mayli, davom et. Nima demoqchi eding?",
                "Tushundim, bro. Gapni davom ettiraver 😄"
            )
            else -> listOf(
                "Tushundim, bro. Buni biroz kengroq aytib ber-chi — sen nima deb o‘ylayapsan?",
                "Ha, fikringni tushunishga harakat qilyapman. Keyin nima bo‘ldi?",
                "Qiziq. Men hozircha hammasini bilmasam ham, sen bilan bemalol muhokama qilaman. Yana ayt-chi.",
                "Mayli, gaplashamiz 🙂 Bu haqda o‘zing qanday fikrdasan?"
            )
        }
        return Msg.pick("convo:$tone", conversational)
    }

    private val weekdays = listOf("yakshanba", "dushanba", "seshanba", "chorshanba", "payshanba", "juma", "shanba")

    private fun smallTalk(lower: String): String? {
        if (Regex("(soat nechi|soat necha|vaqt qancha|hozir soat|soat nechchi)").containsMatchIn(lower))
            return "Hozir soat " + SimpleDateFormat("HH:mm", Locale.US).format(Date()) + "."
        if (Regex("(bugun qaysi kun|bugun nechanchi|bugungi sana|sana qancha|bugun sana|qaysi kun)").containsMatchIn(lower)) {
            val d = weekdays[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1]
            return "Bugun $d, ${Util.todayDots()}."
        }
        if (Regex("(hazil|latifa|kuldir|kuldirchi)").containsMatchIn(lower)) return Msg.pick("joke", Msg.jokes)
        if (Regex("(tanga tashla|tanga)").containsMatchIn(lower))
            return if (Random.nextBoolean()) "Tanga: gerb 🪙" else "Tanga: raqam 🪙"
        if (Regex("(zar tashla|tasodifiy son)").containsMatchIn(lower)) return "Tushgan son: ${Random.nextInt(1, 7)} 🎲"
        if (Regex("(nima qilay|maslahat ber|maslahat bering)").containsMatchIn(lower)) return Msg.pick("advice", Msg.advice)
        Regex("^(-?\\d+(?:[.,]\\d+)?)\\s*(km|mil|kg|funt|lb|c|f)(?!\\p{L}).*(necha|qancha|=)").find(lower)?.let {
            val v = it.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
            val (r, u) = when (it.groupValues[2]) {
                "km" -> Pair(v * 0.621371, "mil")
                "mil" -> Pair(v * 1.609344, "km")
                "kg" -> Pair(v * 2.20462, "funt")
                "funt", "lb" -> Pair(v / 2.20462, "kg")
                "c" -> Pair(v * 9 / 5 + 32, "°F")
                else -> Pair((v - 32) * 5 / 9, "°C")
            }
            return "${Calc.format(v)} ${it.groupValues[2]} ≈ ${String.format(Locale.US, "%.2f", r)} $u"
        }
        return null
    }

    fun respond(raw: String): String {
        lastWasFallback = false
        val text = raw.trim()
        val lower = Norm.latin(text.lowercase())
            .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
        val ic = RegexOption.IGNORE_CASE
        val cmd = lower.trimEnd('.', '!', '?', ' ')
        // buyruq matnlarini (katta-kichik harf saqlangan holda) lotinga o‘giramiz
        val latinText = Norm.latin(text)
            .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')

        // --- buyruqlar ---
        if (cmd in Msg.helpCmds) return Msg.HELP
        if (cmd in Msg.memoryCmds) return memoryList()

        Regex("^/?unut\\s+(\\d+)").find(lower)?.let {
            val ok = it.groupValues[1].toLongOrNull()?.let { id -> db.deleteMemory(id) } ?: false
            return if (ok) "Xotiradan o‘chirdim." else "Bunday raqamli yozuv topilmadi. /xotira orqali tekshirib ko‘r."
        }

        Regex("^/uslub\\s+(\\S+)").find(lower)?.let {
            val mode = when (it.groupValues[1]) {
                "avto", "auto" -> "auto"
                "oddiy" -> "neutral"
                "jiddiy" -> "serious"
                "quvnoq" -> "playful"
                else -> null
            } ?: return "Uslublar: avto, oddiy, jiddiy, quvnoq."
            prefs.styleMode = mode
            return when (mode) {
                "auto" -> "Yaxshi, endi muloqot uslubingga asta-sekin moslashaman."
                "serious" -> "Mayli, jiddiyroq gaplashaman."
                "playful" -> "Bo‘ldi, bro! Endi hazilni ham qo‘shamiz 😄"
                else -> "Oddiy, o‘rtacha uslubga qaytdim."
            }
        }

        Regex("^(?:(?:hisoblab ber|hisobla|hisob|calc)(?!\\p{L})|=(?=\\s*[-\\d(.]))\\s*(.*)$").find(lower)?.let {
            val v = Calc.eval(it.groupValues[1]) ?: return "Buni hisoblay olmadim. Misol: hisobla 12*(3+4)"
            return "= ${Calc.format(v)}"
        }

        // Xabarning qaysi joyida bo‘lishidan qat’i nazar, vaqtni aniqlab olamiz.
        val timeMatch = Regex("(?:soat\\s*)?(\\d{1,2}):(\\d{2})\\s*(?:da)?", ic).find(latinText)
        val scheduledIntent = lower.contains("har kuni") || lower.contains("maqsad") || lower.contains("reja") ||
            lower.contains("qilaman") || lower.contains("o‘rganaman") || lower.contains("o'rganaman") || lower.contains("organaman") ||
            lower.contains("o'qiyman") || lower.contains("mashq")
        if (timeMatch != null && scheduledIntent && !Regex("^(maqsadim|maqsad|rejam|reja)\\b", ic).containsMatchIn(lower)) {
            val h = timeMatch.groupValues[1].toIntOrNull()
            val m = timeMatch.groupValues[2].toIntOrNull()
            if (h != null && h in 0..23 && m != null && m in 0..59) {
                var title = latinText.removeRange(timeMatch.range).trim()
                title = title.replace(Regex("\\bhar kuni\\b", ic), " ")
                    .replace(Regex("^(men|mening)\\s+", ic), "")
                    .trim().trim(' ', '.', '!', '?', ',')
                    .replace(Regex("\\s+(qilaman|o‘rganaman|o'rganaman|organaman|o'qiyman|o‘qiyman)$", ic), "")
                    .trim().trim(' ', '.', '!', '?', ',')
                if (title.isNotBlank()) {
                    val time = String.format(Locale.US, "%02d:%02d", h, m)
                    val id = db.addGoal(title, time)
                    db.addMemory("Maqsad", "Maqsad: $title; eslatma: $time")
                    return "Maqsad saqlandi (#$id): «$title». Har kuni $time atrofida eslataman. Bildirishnomalar ruxsati yoqilgan bo‘lsin."
                }
            }
        }

        Regex("^(maqsadim|maqsad|rejam|reja)(?:\\s*[:\\-]\\s*|\\s+)(.+)$", ic).find(latinText)?.let {
            val rawTitle = it.groupValues[2].trim()
            val parts = rawTitle.split(Regex("\\s*\\|\\s*"), limit = 2)
            val title = parts[0].trim()
            val reminder = if (parts.size == 2 && Regex("^\\d{1,2}:\\d{2}$").matches(parts[1].trim())) {
                val hm = parts[1].trim().split(":")
                val h = hm[0].toIntOrNull(); val m = hm[1].toIntOrNull()
                if (h != null && h in 0..23 && m != null && m in 0..59) String.format(Locale.US, "%02d:%02d", h, m) else null
            } else null
            val id = db.addGoal(title, reminder)
            if (reminder != null) db.addMemory("Maqsad", "Maqsad: $title; eslatma: $reminder")
            return if (reminder != null) "Maqsad saqlandi (#$id): «$title». Har kuni $reminder atrofida eslataman."
                else "Maqsad yozildi (#$id): «$title». Vaqtli eslatma uchun «maqsad: $title | 18:00» deb yoz."
        }

        if (cmd in Msg.goalCmds) {
            val g = db.openGoals()
            return if (g.isEmpty()) "Hozircha ochiq maqsad yo‘q. «maqsad: ...» deb yozsang, qo‘shaman."
            else g.joinToString("\n", "Ochiq maqsadlaring:\n") { "#${it.id} ${it.title}" + (it.reminderTime?.let { t -> " — eslatma $t" } ?: "") } +
                "\n\nBajarsang: tayyor <raqam>"
        }

        Regex("^(?:tayyor|bajarildi|bajardim|done)\\s+#?(\\d+)").find(lower)?.let {
            val t = it.groupValues[1].toLongOrNull()?.let { id -> db.completeGoal(id) }
            return if (t != null) "Zo‘r! «$t» bajarildi deb belgiladim 👏" else "Bunday ochiq maqsad topilmadi. «maqsadlarim» deb ko‘r."
        }

        if (Regex("^mashq(?!\\p{L})").containsMatchIn(lower)) {
            val m = Regex("^mashq[^\\d]*(\\d+)\\s*(.*)$", ic).find(latinText)
                ?: return "Natijani raqam bilan yoz, masalan: «mashq: 100 takror»."
            val amount = m.groupValues[1].toIntOrNull() ?: return "Raqam juda katta chiqdi, qayta yozib ko‘r."
            val note = m.groupValues[2].trim().ifEmpty { "takror" }
            val prev = db.lastWorkout()
            db.addWorkout(note, amount)
            db.addMemory("Mashg‘ulot", "${Util.todayDots()} — Mashg‘ulot: $amount $note")
            val cmp = if (prev != null && prev.note.equals(note, true)) {
                val d = amount - prev.amount
                " Oldingi natija (${prev.day}): ${prev.amount} " + when {
                    d > 0 -> "edi — bu safar $d ta ko‘p."
                    d < 0 -> "edi — bu safar ${-d} ta kam. Hechqisi yo‘q, davom etamiz."
                    else -> "edi — xuddi shuncha."
                }
            } else ""
            return "Yozib qo‘ydim: $amount $note.$cmp"
        }

        if (cmd in Msg.resultCmds) {
            val w = db.recentWorkouts(5)
            return if (w.isEmpty()) "Hali natija yozmagansan. «mashq: 100 takror» deb yozsang, saqlayman."
            else w.joinToString("\n", "Oxirgi natijalar:\n") { "${it.day}: ${it.amount} ${it.note}" }
        }

        if (Regex("^(?:mushuk(?:cha)?|zeno mushuk(?:cha)?)\\s+(?:kel|qayt|qayer|qani|ko['‘’]?rin|chiq)").containsMatchIn(lower)) {
            return if (CatCompanion.callCat(appCtx)) "Mushukchani chaqirdim, hozir keladi 🐱" else "Mushukcha shu yerning o‘zida 🐱"
        }

        Regex("^(?:eslab qol|yodda tut|yozib qo'y|yodla|esla|unutma)(?!\\p{L})\\s*[:\\-]?\\s*(.+)$", ic).find(latinText)?.let {
            val saved = db.addMemory("Muhim", it.groupValues[1])
            return if (saved) "Eslab qoldim. (/xotira orqali ko‘rib, /unut bilan o‘chira olasan.)" else "Buni allaqachon eslab qolgan ekanman."
        }

        // --- oddiy suhbat ---
        val score = styleScore(lower)
        db.addStyleSample(score)
        session.addLast(score)
        if (session.size > 3) session.removeFirst()
        val tone = effectiveTone()

        val words = lower.split(Regex("[^\\p{L}']+")).filter { it.isNotBlank() }

        // foydalanuvchining o‘z bilimlar fayllari (txt) — ichki bazadan oldin tekshiriladi
        UserKb.answer(appCtx, text)?.let { return it }

        // Qisqa salomlashish / "nima gap" kabi gaplar lug‘at yoki bilimlar bazasiga tushib ketmasin
        val translateIntent = Regex("(ingliz|rus|tarjima|degani|deyiladi|nima deb|so'zi)").containsMatchIn(lower)
        val social = words.size <= 3 && !translateIntent && (
            words.any { it in Msg.greetWords || it in Msg.byeWords || it in Msg.thanksWords } ||
                Regex("(qalaysan|yaxshimisan|ahvol|nima gap|nima yangilik|ishlar qalay)").containsMatchIn(lower)
            )

        // Og‘ir holat belgilari (xavfsizlik) har qanday hamdardlik javobidan oldin tekshiriladi.
        Knowledge.crisisCheck(lower)?.let { return it }

        // Hissiy holatni avval tanib, foydalanuvchini darhol fakt qidiruviga yubormaslik.
        val sadFeelings = Regex("(xafa|hafa|xafaman|hafaman|kayfiyatim yo'q|kayfiyatim yoq|ko'nglim\\s*(og'ri|xira)|yig'lagim|yomon bo'lyapti|yomon bo'lyapman|charchadim|siqildim|qiynalyapman|yolg'izman|yolg'iz his|hech kim meni tushunmay|meni tushunishmay|dardim|ichimdagini)")
        val dontWantToTalk = Regex("(gapirgim kelmay|aytgim kelmay|gaplashgim kelmay|hech kimga aytmay|bilmayman nima dey)")
        if (sadFeelings.containsMatchIn(lower)) {
            return when {
                dontWantToTalk.containsMatchIn(lower) -> Msg.pick("comfort:quiet", listOf(
                    "Mayli, majbur emassan. Hozir gapirishga tayyor bo‘lmasang ham bo‘ladi. Xohlasang, jimroq mavzuda gaplashamiz yoki shunchaki chalg‘iymiz. 🙂",
                    "Tushundim. Hamma narsani hoziroq aytishing shart emas. Men seni shoshirmayman — xohlasang, boshqa narsa haqida gaplashamiz."
                ))
                Regex("(hech kim meni tushunmay|meni tushunishmay|yolg'izman|yolg'iz his)").containsMatchIn(lower) -> Msg.pick("comfort:lonely", listOf(
                    "O‘zingni tushunishmayotgandek his qilish og‘ir bo‘lishi mumkin. Men vaziyatingni to‘liq bilmasligim mumkin, lekin seni tushunishga harakat qilaman. Nima bo‘lganini aytging keladimi?",
                    "Bu his bilan yolg‘iz qolish qiyin. Men tinglayman — seni shunday his qildirgan nima bo‘ldi? Xohlamasang, hozir maslahat ham bermayman, avval eshitaman."
                ))
                Regex("(charchadim|siqildim|qiynalyapman)").containsMatchIn(lower) -> Msg.pick("comfort:tired", listOf(
                    "Ancha toliqib qolganga o‘xshaysan. Hozir senga ko‘proq nima kerak: dardingni aytib olishmi, birga yechim izlashmi yoki biroz chalg‘ishmi?",
                    "Tushundim. Ba’zan hammasi ustma-ust keladi. Nima seni ko‘proq qiynayapti? Shoshilmay gaplashamiz."
                ))
                else -> Msg.pick("comfort:sad", listOf(
                    "Nima bo‘ldi? Biror narsa ko‘nglingni og‘ritdimi? Xohlasang, menga aytishing mumkin — shoshilmasdan gaplashamiz.",
                    "Afsus, hozir o‘zingni yaxshi his qilmayotganga o‘xshaysan. Men darrov maslahat berishga shoshilmayman. Nima bo‘lganini aytib bermoqchimisan?",
                    "Ha, eshitaman. Ichingdagini bemalol yozaver — seni hukm qilmayman. Hozir maslahat kerakmi yoki shunchaki tinglashimni xohlaysanmi?"
                ))
            }
        }

        if (!social) Knowledge.features(lower)?.let { return it }

        if (words.any { it in Msg.greetWords }) {
            val g = Msg.pick("greet$tone", Msg.greet.getValue(tone))
            val goals = db.openGoals()
            return if (goals.isNotEmpty() && Random.nextInt(100) < 40)
                "$g\nMaqsadlaringdan biri hali ochiq: «${goals.random().title}» — xohlasang, shuni gaplashamiz."
            else g
        }

        if (words.any { it in Msg.byeWords }) return Msg.pick("bye", Msg.bye)
        if (Regex("(qalaysan|yaxshimisan|ahvol|nima gap|nima yangilik|ishlar qalay)").containsMatchIn(lower))
            return Msg.pick("how$tone", Msg.howAreYou.getValue(tone))
        if (Regex("(isming|kimsan|nima qila olasan|nimalar qila olasan)").containsMatchIn(lower)) return Msg.WHO
        if (words.any { it in Msg.thanksWords })
            return Msg.pick("thanks", Msg.thanks)

        val low = Msg.lowWords
        if (words.any { it in low }) return Msg.pick("support", Msg.support)

        // Faqat uzoq muddat foydali bo‘lishi mumkin bo‘lgan odat/maqsadlarni avtomatik saqlash.
        val habitOrGoal = Regex("(har kuni|odatda|mening maqsadim|maqsadim|rejam|men .*\\b(qilaman|o‘qiyman|o'qiyman|o‘rganaman|o'rganaman|organaman)\\b)", ic)
        if (habitOrGoal.containsMatchIn(lower) && text.length in 8..150 && !lower.contains("?") && !lower.contains("nima")) {
            val saved = db.addMemory("Maqsad yoki odat", text)
            if (saved) {
                val base = Msg.pick("ack$tone", Msg.ack.getValue(tone))
                return "$base\n(Bu foydali ma’lumotni xotiraga saqladim — /xotira orqali ko‘rishing yoki o‘chirishing mumkin.)"
            }
        }

        val interest = Regex("(yoqtiraman|qiziqaman|o'ynayman|o'rganyapman|tomosha qilaman|yaxshi ko'raman|sevaman|o'qiyapman|tinglayman)")
        if (interest.containsMatchIn(lower) && text.length <= 120) {
            val saved = db.addMemory("Qiziqish", text)
            val base = Msg.pick("ack$tone", Msg.ack.getValue(tone))
            return if (saved) "$base\n(Buni xotiraga yozib qo‘ydim — /xotira.)" else base
        }

        smallTalk(lower)?.let { return it }

        // oldin aytgan gapiga bog‘liq bo‘lsa, shuni eslatamiz (faqat haqiqiy yozuvlar)
        val stop = setOf(
            "bugun", "qanday", "haqida", "yaxshi", "kerak", "mumkin", "lekin", "chunki", "hozir",
            "keyin", "bilan", "uchun", "menga", "senga", "qilib", "qilyapman", "qilyapsan",
            "bo'ldi", "bo'lsa", "nimani", "qayerda", "qachon", "yana", "juda"
        )
        val keys = words.filter { it.length >= 5 && it !in stop }
        if (keys.isNotEmpty()) {
            val rel = db.memories().firstOrNull { m ->
                m.category != "Mashg‘ulot" && m.text.lowercase()
                    .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
                    .let { t -> keys.any { k -> t.contains(k) } }
            }
            if (rel != null) return "Bu haqda oldin shuni yozib qo‘ygan ekanman: «${rel.text}». Hozir nima o‘zgardi?"
        }

        val qLike = text.contains('?') ||
            (UserKb.unsureReply(appCtx) != null &&
                Regex("(qancha|qanday|qanaqa|nima|kim|qaysi|nega|necha|qayer|qachon)").containsMatchIn(lower))
        return fallbackReply(qLike, tone, lower)
    }

    /** AI uchun kontekst: eslab qolingan narsalar va ochiq maqsadlar. */
    fun aiContext(): String {
        val mem = db.memories().filter { it.category != "Mashg‘ulot" }.take(10).joinToString("; ") { it.text }
        val goals = db.openGoals().take(5).joinToString("; ") { it.title }
        return "Foydalanuvchi haqida eslab qolinganlar: ${mem.ifEmpty { "yo‘q" }}. Ochiq maqsadlari: ${goals.ifEmpty { "yo‘q" }}."
    }

    private fun memoryList(): String {
        val m = db.memories()
        if (m.isEmpty()) return "Hozircha hech narsa eslab qolmadim."
        val shown = m.take(15).joinToString("\n") { "#${it.id} [${it.category}] ${it.text}" }
        val more = if (m.size > 15) "\n… yana ${m.size - 15} ta (Sozlamalarda hammasi ko‘rinadi)" else ""
        return "Xotiramda:\n$shown$more\n\nO‘chirish: /unut <raqam>"
    }
}

// ======================== UsageTracker.kt ========================
object UsageTracker {

    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        // Ba'zi qurilmalarda ruxsat berilgan bo'lsa ham MODE_DEFAULT qaytadi — shunda oddiy ruxsatni tekshiramiz
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            ctx.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    /**
     * Bugun (soat 00:00 dan hozirgacha) har bir ilovada o'tkazilgan daqiqalar.
     * Faqat `pkgs` ichidagi ilovalar hisoblanadi; boshqa ilovalar yoki ularning ichidagi ma'lumotlar o'qilmaydi.
     * Kun yangilanganda hisob o'z-o'zidan 0 dan boshlanadi, telefon qayta yonsa ham tizim statistikasi saqlanadi.
     */
    fun todayMinutes(ctx: Context, pkgs: Set<String>): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(Util.midnight(), end)
        val e = UsageEvents.Event()
        val fg = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val p = e.packageName
            if (p !in pkgs) continue
            when (e.eventType) {
                // 1 = MOVE_TO_FOREGROUND / ACTIVITY_RESUMED
                1 -> if (!fg.containsKey(p)) fg[p] = e.timeStamp
                // 2 = MOVE_TO_BACKGROUND / ACTIVITY_PAUSED
                2 -> fg.remove(p)?.let { total[p] = (total[p] ?: 0L) + (e.timeStamp - it) }
            }
        }
        // hozir ochiq turgan ilova
        fg.forEach { (p, s) -> total[p] = (total[p] ?: 0L) + (end - s) }
        return total.mapValues { it.value / 60000L }
    }
}

// ======================== NotifImages (bildirishnoma rasmlari) ========================
/** Har bir bildirishnoma turi uchun foydalanuvchi tanlagan rasm (bildirishnomaning o‘ng tomonida chiqadi). */
object NotifImages {
    const val REQ_BASE = 600
    const val ALL = "all"

    /** kalit (Notifier.send dagi kind) va ekranda ko‘rinadigan nomi */
    val KINDS: List<Pair<String, String>> = listOf(
        ALL to "Hammasi uchun umumiy rasm",
        "goal_scheduled" to "Maqsad eslatmasi (belgilangan vaqtda)",
        "goal" to "Maqsad haqida eslatma",
        "workout" to "Mashq eslatmasi",
        "usage" to "Ilova vaqti ogohlantirishi",
        "inactive" to "Faoliyatsizlik eslatmasi",
        "motivation" to "Motivatsion xabar",
        "test" to "Sinov bildirishnomasi"
    )

    private fun file(ctx: Context, kind: String) = java.io.File(ctx.filesDir, "notif_img_$kind.png")

    fun has(ctx: Context, kind: String): Boolean = file(ctx, kind).exists()

    /** Rasmni 256x256 kvadratga kesib, ilova ichki papkasiga saqlaydi. */
    fun save(ctx: Context, kind: String, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var s = 1
            while (bounds.outWidth / (s * 2) >= 256 && bounds.outHeight / (s * 2) >= 256) s *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = s }
            val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
            file(ctx, kind).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            Log.e("NotifImages", "saqlab bo‘lmadi", e)
            false
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    fun remove(ctx: Context, kind: String) {
        file(ctx, kind).delete()
    }

    /** Shu tur uchun rasm; yo‘q bo‘lsa — umumiy rasm; u ham yo‘q bo‘lsa null. */
    fun load(ctx: Context, kind: String): Bitmap? {
        for (k in listOf(kind, ALL)) {
            val f = file(ctx, k)
            if (f.exists()) {
                try {
                    BitmapFactory.decodeFile(f.path)?.let { return it }
                } catch (e: Exception) {
                    Log.e("NotifImages", "o‘qib bo‘lmadi", e)
                }
            }
        }
        return null
    }
}

// ======================== Notifier.kt ========================
object Notifier {
    private const val CH = "zeno_main"

    /** Bildirishnomani yuboradi va jurnalga yozadi. Bosilganda ilova shu matn bilan suhbatni ochadi. */
    fun send(ctx: Context, kind: String, text: String): Boolean {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return false

        if (Build.VERSION.SDK_INT >= 26) {
            val m = ctx.getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(CH) == null) {
                m.createNotificationChannel(
                    NotificationChannel(CH, "Zeno xabarlari", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }

        val open = Intent(ctx, MainActivity::class.java).apply {
            putExtra("zeno_open", text)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val id = (System.currentTimeMillis() % 100000).toInt()
        val pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // o'z ikonkangizga almashtiring
            .setContentTitle("Zeno")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
        // Foydalanuvchi tanlagan rasm bildirishnomaning o‘ng tomonida chiqadi
        NotifImages.load(ctx, kind)?.let { builder.setLargeIcon(it) }
        val n = builder.build()

        return try {
            nm.notify(id, n)
            ZenoDb.get(ctx).logNotif(kind, text)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

// ======================== ZenoWorker.kt ========================
/**
 * Har ~15 daqiqada (WorkManager minimumi) uyg'onadi va qoidalarni tekshiradi.
 * WorkManager telefon qayta yoqilgandan keyin ham ishni o'zi tiklaydi.
 * Android (ayniqsa MIUI) fon ishini kechiktirishi mumkin — aniq soniyaga kafolat yo'q.
 */
class ZenoWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        try {
            val p = ZenoPrefs(applicationContext)
            val now = System.currentTimeMillis()
            // bir nechta manba (xizmat, signal, WorkManager) bir vaqtda chaqirsa, qayta ishlamaymiz
            if (now - p.lastTick < 13L * 60_000L) return Result.success()
            p.lastTick = now
            tick(applicationContext, ZenoDb.get(applicationContext), p)
        } catch (e: Exception) {
            // fon ishi hech qachon ilovani qulatmasin, lekin xatoni Logcat'da ko'rish mumkin
            Log.e("ZenoWorker", "tick xatosi", e)
        }
        return Result.success()
    }

    private fun isQuiet(p: ZenoPrefs): Boolean {
        val h = Util.hour()
        return if (p.quietStart > p.quietEnd) h >= p.quietStart || h < p.quietEnd
        else h >= p.quietStart && h < p.quietEnd
    }

    private fun canSend(p: ZenoPrefs, db: ZenoDb, ignoreCap: Boolean): Boolean {
        if (System.currentTimeMillis() < p.pausedUntil) return false
        if (isQuiet(p)) return false
        return ignoreCap || db.notifCountToday() < p.dailyCap
    }

    private fun sentToday(db: ZenoDb, kind: String) = db.lastNotifTs(kind) >= Util.midnight()

    private fun fmt(min: Int): String = when {
        min < 60 -> "$min daqiqa"
        min % 60 == 0 -> "${min / 60} soat"
        min % 60 == 30 -> "${min / 60},5 soat"
        else -> "${min / 60} soat ${min % 60} daqiqa"
    }

    private fun usageText(label: String, t: Int): String {
        val base = "Siz «$label» ilovasida bugun ${fmt(t)} vaqt o‘tkazdingiz."
        return when {
            t >= 90 -> "$base Endi tanaffus qilish vaqti kelgandir 🙂"
            t >= 60 -> "$base Biroz dam olishingiz ma’qul."
            else -> base
        }
    }

    private fun tick(c: Context, db: ZenoDb, prefs: ZenoPrefs) {
        val hour = Util.hour()
        db.prune()

        // Foydalanuvchi belgilagan vaqtdagi maqsad eslatmalari.
        if (canSend(prefs, db, false)) {
            val nowTime = SimpleDateFormat("HH:mm", Locale.US).format(Date())
            val due = db.dueGoals(nowTime)
            if (due.isNotEmpty()) {
                val names = due.take(4).joinToString("; ") { it.title }
                val text = "Maqsad vaqting keldi: $names 🙂 Rejang bo‘yicha kichik qadamni boshlashing mumkin."
                if (Notifier.send(c, "goal_scheduled", text)) {
                    due.take(4).forEach { db.markGoalReminder(it.id) }
                    return
                }
            }
        }

        // 1) Tanlangan ilovalar bo'yicha kunlik vaqt ogohlantirishlari
        if (prefs.usageTracking && UsageTracker.hasAccess(c)) {
            val apps = prefs.tracked().filter { it.enabled }
            if (apps.isNotEmpty()) {
                val mins = UsageTracker.todayMinutes(c, apps.map { it.pkg }.toSet())
                val day = Util.today()
                for (a in apps) {
                    val m = mins[a.pkg] ?: 0L
                    val crossed = a.thresholds.filter { m >= it && !db.usageAlertSent(day, a.pkg, it) }
                    val top = crossed.maxOrNull() ?: continue
                    if (!canSend(prefs, db, false)) break
                    if (Notifier.send(c, "usage", usageText(a.label, top))) {
                        crossed.forEach { db.markUsageAlert(day, a.pkg, it) } // oradagi chegaralar takrorlanmasin
                    }
                }
            }
        }

        // Bir tikda boshqa turdagi eng ko'pi bilan bitta xabar (ketma-ket yog'ilib ketmasin)
        // 2) Maqsad va mashq eslatmalari (kuniga bir martadan, bosimsiz)
        if (canSend(prefs, db, false)) {
            if (hour in 18..20 && !sentToday(db, "goal")) {
                val g = db.openGoals().randomOrNull()
                if (g != null && Notifier.send(c, "goal", "Maqsadlaringdan biri: «${g.title}». Bosim yo‘q — vaqting bo‘lsa, kichik bir qadam qo‘y 🙂")) return
            }
            if (hour in 17..19 && !sentToday(db, "workout") && db.workoutCount() > 0 && db.lastWorkout()?.day != Util.today()) {
                if (Notifier.send(c, "workout", "Bugun hali mashq natijasini yozmading. Imkoning bo‘lsa, bajarib, menga ayt — majburlamayman 🙂")) return
            }
        }

        // 3) Foydalanuvchi ilovaga kirmasa: kamida 48 soatda bir marta, kunlik limitga kirmaydi
        if (prefs.inactivityNudges && canSend(prefs, db, true) && hour in 9..21) {
            val now = System.currentTimeMillis()
            val days = (now - prefs.lastActive) / 86_400_000L
            if (days >= 1 && now - prefs.lastInactivityNudge >= 48L * 3_600_000L) {
                val text = if (days >= 2) Msg.inactiveLong else Msg.inactiveShort
                if (Notifier.send(c, "inactive", text)) {
                    prefs.lastInactivityNudge = now
                    return
                }
            }
        }

        // 4) Aralash tizim: tasodifiy vaqtlarda qisqa motivatsion xabar
        if (prefs.motivation && canSend(prefs, db, false) && hour in 9..21) {
            val sinceLast = System.currentTimeMillis() - db.lastNotifTs("motivation")
            val chance = (prefs.dailyCap / 3.0) / 48.0 // taxminan limitning uchdan biri, kun bo'yi tarqalgan
            if (sinceLast >= 90L * 60_000L && Random.nextDouble() < chance) {
                val goals = db.openGoals()
                val text = if (goals.isNotEmpty() && Random.nextInt(100) < 40) {
                    "Maqsading — «${goals.random().title}». Bugun kichik bo‘lsa ham bir qadam qo‘ysak-chi?"
                } else {
                    val pool = if (ZenoBrain(c).baseTone() == Tone.PLAYFUL) Msg.motivPlayful else Msg.motivNeutral
                    val recent = db.recentNotifTexts(40)
                    (pool.filter { it !in recent }.ifEmpty { pool }).random()
                }
                Notifier.send(c, "motivation", text)
            }
        }
    }
}

// ======================== Keeper.kt (fon ishini tirik saqlash) ========================
/**
 * Fon ishi uch qatlam bilan himoyalanadi: WorkManager + AlarmManager (o‘zini qayta rejalaydi)
 * + doimiy xizmat (foreground service). Telefon qayta yonganda BootReceiver hammasini tiklaydi.
 */
object Keeper {
    private const val ALARM_CODE = 7001
    private const val EVERY = 15L * 60_000L

    fun ensure(ctx: Context) {
        val app = ctx.applicationContext
        try {
            WorkManager.getInstance(app).enqueueUniquePeriodicWork(
                "zeno_tick", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequest.Builder(ZenoWorker::class.java, 15, TimeUnit.MINUTES).build()
            )
        } catch (e: Exception) {
            Log.e("Keeper", "work xatosi", e)
        }
        scheduleAlarm(app)
        if (ZenoPrefs(app).keepAlive) startService(app)
    }

    fun scheduleAlarm(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, ALARM_CODE, Intent(ctx, AlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + EVERY, pi)
        } catch (e: Exception) {
            Log.e("Keeper", "alarm xatosi", e)
        }
    }

    fun runNow(ctx: Context) {
        try {
            // Handler, Alarm va WorkManager bir vaqtda chaqirsa ham 5 daqiqada bir martadan ko'p ishlamasin
            val sp = ctx.applicationContext.getSharedPreferences("zeno_keeper", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            if (now - sp.getLong("last_run_now", 0L) < 5 * 60 * 1000L) return
            sp.edit().putLong("last_run_now", now).apply()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork(
                "zeno_tick_once", ExistingWorkPolicy.KEEP, OneTimeWorkRequest.from(ZenoWorker::class.java)
            )
        } catch (e: Exception) {
            Log.e("Keeper", "runNow xatosi", e)
        }
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ZenoService::class.java))
        } catch (e: Exception) {
            Log.e("Keeper", "xizmatni boshlab bo‘lmadi", e)
        }
    }

    fun stopService(ctx: Context) {
        try {
            ctx.stopService(Intent(ctx, ZenoService::class.java))
        } catch (e: Exception) {
            Log.e("Keeper", "xizmatni to‘xtatib bo‘lmadi", e)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        Keeper.scheduleAlarm(ctx)
        Keeper.runNow(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        Keeper.ensure(ctx)
    }
}

class ZenoService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            Keeper.runNow(applicationContext)
            Keeper.scheduleAlarm(applicationContext)
            handler.postDelayed(this, 10L * 60_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "zeno_service"
        if (Build.VERSION.SDK_INT >= 26) {
            val m = getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(ch) == null) {
                m.createNotificationChannel(
                    NotificationChannel(ch, "Zeno fon rejimi", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Zeno ishlayapti")
            .setContentText("Eslatmalar uchun fonda kutyapman")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Log.e("ZenoService", "startForeground xatosi", e)
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(loop)
        handler.post(loop)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}

// ======================== Bg (orqa fon rasmi) ========================
object Bg {
    fun file(ctx: Context): java.io.File = java.io.File(ctx.filesDir, "bg.jpg")

    /** Galereyadan tanlangan rasmni kichraytirib, ilovaning ichki papkasiga saqlaydi. */
    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (bounds.outWidth / (s * 2) >= 1200 || bounds.outHeight / (s * 2) >= 1200) s *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Exception) {
            Log.e("Bg", "saqlab bo‘lmadi", e)
            false
        } catch (e: OutOfMemoryError) {
            false
        }
    }

    /** blur > 0 bo'lsa, rasm bir necha marta kichraytiriladi (ImageView uni yumshoq kattalashtiradi). */
    fun load(ctx: Context, blur: Int): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            var bmp = BitmapFactory.decodeFile(f.path) ?: return null
            var i = 0
            while (i < blur && bmp.width > 8 && bmp.height > 8) {
                bmp = Bitmap.createScaledBitmap(bmp, bmp.width / 2, bmp.height / 2, true)
                i++
            }
            bmp
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}

// ======================== MainActivity.kt ========================
class MainActivity : AppCompatActivity() {

    private lateinit var db: ZenoDb
    private lateinit var prefs: ZenoPrefs
    private lateinit var brain: ZenoBrain
    private lateinit var chatBox: LinearLayout
    private var bgActive = false
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var bgImage: ImageView
    private lateinit var menuBtn: ImageButton
    private lateinit var drawer: DrawerLayout
    private lateinit var titleView: TextView
    private lateinit var bgDimView: View
    private var defText = 0
    private var defInput = 0
    private var defHint = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = ZenoDb.get(this)
        prefs = ZenoPrefs(this)
        brain = ZenoBrain(this)

        chatBox = findViewById(R.id.chatBox)
        scroll = findViewById(R.id.chatScroll)
        // Pikselli mushukcha: yuradi, uxlaydi, ovqat yeydi; ilova chetidagi strelka ovqat idishini chiqaradi.
        val cat = CatCompanion.attach(this, findViewById<android.widget.FrameLayout>(R.id.mainFrame))
        // Mushukcha ba'zan ko'rinib turgan xabarlardan biri ustiga sakrab chiqadi
        cat.perchFinder = {
            val out = ArrayList<View>()
            val sl = IntArray(2)
            scroll.getLocationInWindow(sl)
            val minTop = sl[1] + (60 * resources.displayMetrics.density).toInt()
            val maxBottom = sl[1] + scroll.height
            for (i in 0 until chatBox.childCount) {
                val c = chatBox.getChildAt(i)
                if (c === catSpacer) continue
                if (!c.isShown || c.width <= 0 || c.height <= 0) continue
                val cl = IntArray(2)
                c.getLocationInWindow(cl)
                if (cl[1] >= minTop && cl[1] + c.height <= maxBottom) out.add(c)
            }
            out
        }
        // Mushukcha xabar ustiga o'tirsa, xabarlar orasida unga joy ochiladi (tushganda yana yig'iladi)
        cat.perchListener = { v -> updateCatSpacer(v, cat.roomPx) }
        // klaviatura ochilib, yozishmalar oynasi qisqarsa ham oxirgi xabar ko‘rinib tursin
        scroll.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top < oldBottom - oldTop) scroll.post { scroll.scrollTo(0, chatBox.bottom) }
        }
        input = findViewById(R.id.messageInput)
        // Yozayotganingizda uxlab yotgan mushukcha ko'zini yarim ochib, uyquchan qaraydi
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { cat.noteTyping() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        bgImage = findViewById(R.id.bgImage)
        menuBtn = findViewById(R.id.menuButton)
        titleView = findViewById(R.id.titleText)
        drawer = findViewById(R.id.drawerLayout)
        menuBtn.setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        findViewById<View>(R.id.drawerSettings).setOnClickListener {
            drawer.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<View>(R.id.drawerGoals).setOnClickListener { runCommand("maqsadlarim") }
        findViewById<View>(R.id.drawerMemory).setOnClickListener { runCommand("/xotira") }
        findViewById<View>(R.id.drawerHelp).setOnClickListener { runCommand("yordam") }
        bgDimView = findViewById(R.id.bgDim)
        defText = titleView.currentTextColor
        defInput = input.currentTextColor
        defHint = input.currentHintTextColor

        findViewById<Button>(R.id.sendButton).setOnClickListener { send() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }

        ensureWelcome()
        handleIntent(intent)
        render()
        applyBackground()

        Thread {
            try { ZenoKnowledgeBase.warmUp() } catch (e: Throwable) { Log.e("Zeno", "warmUp xatosi", e) }
            try { UserKb.reload(applicationContext) } catch (e: Throwable) { Log.e("Zeno", "UserKb xatosi", e) }
        }.start()
        askNotificationPermission()
        Keeper.ensure(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        render()
    }

    override fun onResume() {
        super.onResume()
        prefs.lastActive = System.currentTimeMillis()
        ensureWelcome()
        render()
        applyBackground()
        // boshqa ilovada fayl tahrirlangan bo‘lsa, qaytganda fonda yangilanadi
        Thread { UserKb.refresh(applicationContext) }.start()
    }

    /** Galereyadan tanlangan orqa fon bo'lsa, uni xiralik bilan ko'rsatadi; bo'lmasa oddiy ko'rinish. */
    private fun applyBackground() {
        val bmp = Bg.load(this, prefs.bgBlur)
        if (bmp != null) {
            bgImage.setImageBitmap(bmp)
            bgImage.visibility = View.VISIBLE
            bgDimView.setBackgroundColor(Color.argb(prefs.bgDim * 255 / 100, 0, 0, 0))
            bgDimView.visibility = View.VISIBLE
            bgActive = true
            titleView.setTextColor(Color.WHITE)
            menuBtn.setColorFilter(Color.WHITE)
            input.setTextColor(Color.WHITE)
            input.setHintTextColor(0xCCFFFFFF.toInt())
        } else {
            bgImage.visibility = View.GONE
            bgDimView.visibility = View.GONE
            bgActive = false
            titleView.setTextColor(defText)
            menuBtn.setColorFilter(defText)
            input.setTextColor(defInput)
            input.setHintTextColor(defHint)
        }
        render()
    }

    private fun ensureWelcome() {
        if (db.recentChat().isEmpty()) {
            db.addChat("zeno", "Salom! Men Zenoman — virtual do‘sting. Nima qila olishimni bilish uchun «yordam» deb yoz.")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, MENU_SETTINGS, 0, "Sozlamalar")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == MENU_SETTINGS) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /** Bildirishnomani bosib kirilganda, uning matni suhbatga Zeno xabari sifatida qo‘shiladi. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val t = i.getStringExtra("zeno_open") ?: return
        i.removeExtra("zeno_open")
        val last = db.recentChat().lastOrNull()
        if (last == null || last.second != t) db.addChat("zeno", t)
    }

    /** Yon paneldagi tugma: buyruqni yozilgandek yuboradi. */
    private fun runCommand(cmd: String) {
        drawer.closeDrawer(GravityCompat.START)
        input.setText(cmd)
        send()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::drawer.isInitialized && drawer.isDrawerOpen(GravityCompat.START)) drawer.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        db.addChat("me", t)
        val reply = try {
            brain.respond(t)
        } catch (e: Exception) {
            Log.e("Zeno", "respond xatosi", e)
            "Kechir, xatolik chiqdi. Qayta urinib ko‘rasanmi?"
        }
        val key = prefs.aiKey.trim()
        if (brain.lastWasFallback && prefs.aiOn && key.isNotBlank()) {
            // Tayyor qoidalar topa olmadi: AI'dan so‘raymiz
            val sendBtn = findViewById<Button>(R.id.sendButton)
            sendBtn.isEnabled = false
            input.hint = "Zeno o‘ylayapti…"
            val ctx = brain.aiContext()
            val history = db.recentChat()
            Thread {
                val ai = Ai.ask(key, ctx, history)
                runOnUiThread {
                    val text = when {
                        ai == "__KEY__" -> "API kaliti noto‘g‘ri ko‘rinadi. Sozlamalarda qayta kiriting.\n\n$reply"
                        ai != null && ai.startsWith("__ERR__") -> "AI ishlamadi (${ai.removePrefix("__ERR__")}).\n\n$reply"
                        ai != null -> ai
                        else -> reply
                    }
                    db.addChat("zeno", text)
                    sendBtn.isEnabled = true
                    input.hint = "Xabar yozing…"
                    if (!isFinishing) render()
                }
            }.start()
            return
        }
        db.addChat("zeno", reply)
        render()
    }

    /** Mushukcha o'tirgan xabar tepasidagi bo'sh joy (mushukcha sig'ishi uchun). */
    private var catSpacer: View? = null

    private fun updateCatSpacer(v: View?, room: Int) {
        var cur = catSpacer
        if (cur != null && cur.parent == null) {
            catSpacer = null
            cur = null
        }
        if (v == null || v.parent !== chatBox) {
            if (cur != null) {
                catSpacer = null
                animateSpacer(cur, cur.layoutParams?.height ?: 0, 0, true)
            }
            return
        }
        val idx = chatBox.indexOfChild(v)
        if (cur != null && chatBox.indexOfChild(cur) == idx - 1) return
        if (cur != null) {
            catSpacer = null
            animateSpacer(cur, cur.layoutParams?.height ?: 0, 0, true)
        }
        val sp = View(this)
        sp.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0)
        chatBox.addView(sp, chatBox.indexOfChild(v))
        catSpacer = sp
        animateSpacer(sp, 0, room, false)
    }

    private fun animateSpacer(sp: View, from: Int, to: Int, remove: Boolean) {
        var last = from
        val va = android.animation.ValueAnimator.ofInt(from, to)
        va.duration = 260L
        va.addUpdateListener { a ->
            val h = a.animatedValue as Int
            val lp = sp.layoutParams
            if (lp != null) {
                lp.height = h
                sp.layoutParams = lp
            }
            val d = h - last
            last = h
            // bo'sh joy ochilganda ko'rinib turgan xabar o'z joyida qolsin (yuqoridagilar yuqoriga suriladi)
            if (d > 0) scroll.post { scroll.scrollBy(0, d) }
        }
        va.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (remove) chatBox.removeView(sp)
            }
        })
        va.start()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun isNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Yozishmalarni bulutcha (pufak) ko‘rinishida chiqaradi: o‘ngda — sen, chapda — Zeno. */
    private fun render() {
        chatBox.removeAllViews()
        val maxW = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        for ((who, text) in db.recentChat()) chatBox.addView(bubble(text, who == "me", maxW))
        // fullScroll() EditText fokusini olib qo‘yib, klaviaturani yopib yuborardi
        scroll.post { scroll.scrollTo(0, chatBox.bottom) }
    }

    private fun bubble(text: String, mine: Boolean, maxW: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setLineSpacing(0f, 1.08f)
        tv.maxWidth = maxW
        tv.setPadding(dp(14), dp(9), dp(14), dp(10))

        val r = dp(18).toFloat()
        val s = dp(4).toFloat()
        val gd = GradientDrawable()
        gd.cornerRadii = if (mine) floatArrayOf(r, r, r, r, s, s, r, r) else floatArrayOf(r, r, r, r, r, r, s, s)
        when {
            mine -> {
                gd.setColor(0xFF3D7BF5.toInt())
                tv.setTextColor(Color.WHITE)
            }
            bgActive -> {
                gd.setColor(0x99000000.toInt())
                tv.setTextColor(Color.WHITE)
            }
            isNight() -> {
                gd.setColor(0xFF33353D.toInt())
                tv.setTextColor(0xFFF0F0F2.toInt())
            }
            else -> {
                gd.setColor(0xFFE6E8EF.toInt())
                tv.setTextColor(0xFF1B1C20.toInt())
            }
        }
        tv.background = gd

        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.topMargin = dp(4)
        lp.bottomMargin = dp(4)
        tv.layoutParams = lp
        return tv
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    /** Har ~15 daqiqada ZenoWorker ni ishga tushiradi (allaqachon rejalashtirilgan bo‘lsa, tegmaydi). */
    private fun scheduleWorker() {
        val req = PeriodicWorkRequest.Builder(ZenoWorker::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(applicationContext)
            .enqueueUniquePeriodicWork("zeno_tick", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    companion object {
        private const val MENU_SETTINGS = 1
    }
}

// ======================== BarChartView (oddiy grafik) ========================
/** Kutubxonasiz ustunli grafik: gorizontal (turkumlar) yoki vertikal (kunlar). */
class BarChartView(ctx: Context) : View(ctx) {
    var labels: List<String> = emptyList()
    var values: List<Int> = emptyList()
    var horizontal = true
    var barColor = 0xFF3D7BF5.toInt()
    var textColor = Color.BLACK
    var trackColor = 0x22808080

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private fun dpf(v: Float): Float = v * resources.displayMetrics.density

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = View.MeasureSpec.getSize(widthSpec)
        val h = if (horizontal) (dpf(30f) * labels.size + dpf(4f)).toInt() else dpf(150f).toInt()
        setMeasuredDimension(w, h.coerceAtLeast(dpf(40f).toInt()))
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (values.isEmpty()) return
        val maxV = (values.maxOrNull() ?: 1).coerceAtLeast(1)
        paint.style = Paint.Style.FILL
        paint.textSize = dpf(13f)
        if (horizontal) drawHorizontal(c, maxV) else drawVertical(c, maxV)
    }

    private fun fit(text: String, avail: Float): String {
        if (paint.measureText(text) <= avail) return text
        var s = text
        while (s.length > 1 && paint.measureText("$s…") > avail) s = s.dropLast(1)
        return "$s…"
    }

    private fun drawHorizontal(c: Canvas, maxV: Int) {
        val rowH = dpf(30f)
        val labelW = width * 0.36f
        val valW = dpf(30f)
        val x0 = labelW + dpf(6f)
        val x1 = width - valW
        val barH = dpf(12f)
        for (i in values.indices) {
            val cy = i * rowH + dpf(2f) + rowH / 2
            val ty = cy + paint.textSize * 0.35f

            paint.color = textColor
            paint.textAlign = Paint.Align.LEFT
            c.drawText(fit(labels.getOrElse(i) { "" }, labelW), 0f, ty, paint)

            rect.set(x0, cy - barH / 2, x1, cy + barH / 2)
            paint.color = trackColor
            c.drawRoundRect(rect, barH / 2, barH / 2, paint)

            if (values[i] > 0) {
                val fw = ((x1 - x0) * values[i] / maxV).coerceAtLeast(barH)
                rect.set(x0, cy - barH / 2, x0 + fw, cy + barH / 2)
                paint.color = barColor
                c.drawRoundRect(rect, barH / 2, barH / 2, paint)
            }

            paint.color = textColor
            paint.textAlign = Paint.Align.RIGHT
            c.drawText(values[i].toString(), width.toFloat(), ty, paint)
        }
    }

    private fun drawVertical(c: Canvas, maxV: Int) {
        val top = dpf(20f)
        val bottom = height - dpf(22f)
        val n = values.size
        val slot = width.toFloat() / n
        val barW = slot * 0.5f
        paint.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val cx = slot * i + slot / 2
            val h = if (values[i] > 0) (bottom - top) * values[i] / maxV else dpf(3f)
            rect.set(cx - barW / 2, bottom - h, cx + barW / 2, bottom)
            paint.color = if (values[i] > 0) barColor else trackColor
            c.drawRoundRect(rect, barW / 4, barW / 4, paint)

            paint.color = textColor
            if (values[i] > 0) c.drawText(values[i].toString(), cx, bottom - h - dpf(5f), paint)
            c.drawText(labels.getOrElse(i) { "" }, cx, height - dpf(5f), paint)
        }
    }
}

// ======================== SettingsActivity.kt ========================
/** Sozlamalar ekrani: butun interfeys kodda quriladi, shuning uchun qo‘shimcha XML kerak emas. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: ZenoPrefs
    private lateinit var db: ZenoDb
    private lateinit var root: LinearLayout
    private lateinit var section: LinearLayout
    private lateinit var usageStatus: TextView
    private lateinit var pauseStatus: TextView
    private lateinit var aiStatus: TextView
    private lateinit var kbStatus: TextView
    private lateinit var memSummary: TextView
    private lateinit var memWeekTitle: TextView
    private lateinit var memCatChart: BarChartView
    private lateinit var memWeekChart: BarChartView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Galereya/papka tanlash natijasi (eskirgan onActivityResult o'rniga). */
    private var pendingReq = 0
    private val resultLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val req = pendingReq
        pendingReq = 0
        if (req != 0) handleResult(req, res.resultCode, res.data)
    }

    private fun launchForResult(intent: Intent, req: Int) {
        pendingReq = req
        resultLauncher.launch(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pending_req", pendingReq)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingReq = savedInstanceState?.getInt("pending_req", 0) ?: 0
        title = "Sozlamalar"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = ZenoPrefs(this)
        db = ZenoDb.get(this)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(6), dp(14), dp(24))
        section = root

        val sv = ScrollView(this)
        sv.setBackgroundColor(if (isNight()) 0xFF17181C.toInt() else 0xFFF2F3F7.toInt())
        sv.addView(root)
        setContentView(sv)
        // Mushukcha sozlamalarda ham yuradi (menyudan "Uyiga qaytarish" bilan chatga qaytariladi)
        CatCompanion.attachToScreen(this, 16)

        build()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshMemoryCharts()
    }

    // ---------------- Ekran tuzilishi ----------------

    private fun build() {
        section = root
        header("Ko‘rinish")
        btn("Orqa fonga rasm tanlash (galereya)") { pickBg() }
        btn("Orqa fon rasmini olib tashlash") {
            Bg.file(this).delete()
            toast("Orqa fon olib tashlandi")
        }
        slider({ "Orqa fon xiraligi: $it%" }, 0, 90, prefs.bgDim) { prefs.bgDim = it }
        slider({ "Orqa fonni xira qilish (blur): $it" }, 0, 6, prefs.bgBlur) { prefs.bgBlur = it }

        header("Bildirishnomalar")
        toggle("Faoliyatsizlik eslatmalari", prefs.inactivityNudges) { prefs.inactivityNudges = it }
        toggle("Motivatsion xabarlar", prefs.motivation) { prefs.motivation = it }
        slider({ "Kunlik limit: $it ta xabar" }, 1, 30, prefs.dailyCap) { prefs.dailyCap = it }
        slider({ "Tinch soatlar boshlanishi: ${hh(it)}" }, 0, 23, prefs.quietStart) { prefs.quietStart = it }
        slider({ "Tinch soatlar tugashi: ${hh(it)}" }, 0, 23, prefs.quietEnd) { prefs.quietEnd = it }

        pauseStatus = TextView(this)
        pauseStatus.setPadding(0, dp(8), 0, 0)
        section.addView(pauseStatus)
        btn("1 soatga jim turish") { pause(1) }
        btn("8 soatga jim turish") { pause(8) }
        btn("Jim turishni bekor qilish") {
            prefs.pausedUntil = 0L
            refreshStatus()
        }
        toggle("Doimiy fon rejimi (ishonchliroq; doimiy belgi chiqadi)", prefs.keepAlive) { on ->
            prefs.keepAlive = on
            if (on) Keeper.startService(this) else Keeper.stopService(this)
        }
        btn("Batareya cheklovini o‘chirish") { requestBatteryExemption() }
        btn("Avtostartga ruxsat (Xiaomi, Huawei, Oppo…)") { openAutostart() }
        btn("Sinov bildirishnomasi yuborish") {
            val ok = Notifier.send(this, "test", "Bu sinov xabari. Hammasi ishlayapti 🙂")
            toast(if (ok) "Yuborildi" else "Yuborib bo‘lmadi — bildirishnoma ruxsatini tekshiring")
        }

        header("Bildirishnoma rasmlari (o‘ng tomonda)")
        val hint = TextView(this)
        hint.text = "Har bir bildirishnoma turi uchun o‘z rasmingizni tanlang. Tur uchun rasm yo‘q bo‘lsa, “Hammasi uchun” rasm ishlatiladi."
        hint.textSize = 13f
        section.addView(hint)
        notifThumbs.clear()
        NotifImages.KINDS.forEachIndexed { idx, (kind, label) -> notifImageRow(idx, kind, label) }
        btn("Sinab ko‘rish (test bildirishnomasi)") {
            val ok = Notifier.send(this, "test", "Rasm shunday ko‘rinadi 🙂")
            toast(if (ok) "Yuborildi" else "Yuborib bo‘lmadi — bildirishnoma ruxsatini tekshiring")
        }

        header("Ilova vaqti ogohlantirishlari")
        toggle("Ilova vaqtini kuzatish", prefs.usageTracking) { prefs.usageTracking = it }
        usageStatus = TextView(this)
        section.addView(usageStatus)
        btn("Foydalanish statistikasi ruxsatini ochish") {
            try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (e: Exception) {
                toast("Sozlamalarni ochib bo‘lmadi")
            }
        }
        val list = prefs.tracked().toMutableList()
        list.forEachIndexed { i, a ->
            toggle("${a.label} (${a.thresholds.joinToString("/")} daq)", a.enabled) { on ->
                list[i] = list[i].copy(enabled = on)
                prefs.saveTracked(list)
            }
        }

        btn("Boshqa ilova qo‘shish") { addAppDialog() }

        header("Muloqot uslubi")
        val modes = listOf(
            "auto" to "Avto (moslashadi)",
            "neutral" to "Oddiy",
            "serious" to "Jiddiy",
            "playful" to "Quvnoq"
        )
        val rg = RadioGroup(this)
        modes.forEachIndexed { i, m ->
            val rb = RadioButton(this)
            rb.id = 1000 + i
            rb.text = m.second
            rg.addView(rb)
        }
        val cur = modes.indexOfFirst { it.first == prefs.styleMode }.coerceAtLeast(0)
        rg.check(1000 + cur)
        rg.setOnCheckedChangeListener { _, checkedId ->
            val idx = checkedId - 1000
            if (idx in modes.indices) prefs.styleMode = modes[idx].first
        }
        section.addView(rg)

        header("Bilimlar fayllari")
        kbStatus = TextView(this)
        section.addView(kbStatus)
        btn("Bilimlar papkasini tanlash") { pickKbFolder() }
        btn("Bilimlarni yangilash") { reloadKb(true) }
        btn("Namuna fayl yaratish") {
            toast(UserKb.createSample(this))
            reloadKb(false)
        }
        btn("Tanlangan papkani olib tashlash") {
            prefs.kbTree = ""
            reloadKb(false)
        }
        val kbNote = TextView(this)
        kbNote.text = "Savol-javoblarni oddiy .txt faylga yozing (Savol: ... / Javob: ...). " +
            "Papka tanlanmasa, fayllar ilovaning o‘z papkasidan o‘qiladi:\n" + UserKb.appDir(this).absolutePath +
            "\nIchki papkalar ham o‘qiladi: Anime/One Piece.txt → bo‘lim «Anime», mavzu «One Piece»; " +
            "Anime/One Piece/baza.txt → xuddi shunday. O‘zgartirgach yangilash tugmasi shart emas — ZENO fayllarni savol kelganda o‘zi tekshiradi."
        kbNote.textSize = 12f
        section.addView(kbNote)
        reloadKb(false)

        header("Sun'iy intellekt (ixtiyoriy)")
        toggle("Qoidalar topa olmasa, AI javob bersin", prefs.aiOn) { prefs.aiOn = it }
        aiStatus = TextView(this)
        section.addView(aiStatus)
        btn("API kalitini kiritish") { aiKeyDialog() }
        val note = TextView(this)
        note.text = "Eslatma: AI yoqilganda faqat qoidalar javob bera olmagan xabarlar, oxirgi suhbat va xotiradagi qisqa ma’lumotlar Anthropic serveriga yuboriladi. Kalit faqat shu telefonda saqlanadi."
        note.textSize = 12f
        section.addView(note)

        header("Maqsadlar va eslatmalar")
        btn("Maqsadni qo‘lda saqlash") { addGoalDialog() }
        btn("Maqsadlarimni ko‘rish") { showGoals() }
        btn("Xotiraga ma’lumotni qo‘lda saqlash") { addMemoryDialog() }

        header("Xotira")
        memSummary = TextView(this)
        memSummary.textSize = 14f
        section.addView(memSummary)
        val wrapLp = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) } }
        memCatChart = BarChartView(this)
        section.addView(memCatChart, wrapLp())
        memWeekTitle = TextView(this)
        memWeekTitle.text = "So‘nggi 7 kunda qo‘shilganlar"
        memWeekTitle.textSize = 13f
        memWeekTitle.setPadding(0, dp(12), 0, 0)
        section.addView(memWeekTitle)
        memWeekChart = BarChartView(this)
        memWeekChart.horizontal = false
        section.addView(memWeekChart, wrapLp())
        refreshMemoryCharts()
        btn("Xotirani ko‘rish / o‘chirish") { showMemories() }
        btn("Hammasini o‘chirish") {
            AlertDialog.Builder(this)
                .setTitle("Hammasini o‘chirish?")
                .setMessage("Xotira, maqsadlar, mashq natijalari va suhbat tarixi o‘chadi.")
                .setPositiveButton("Ha") { _, _ ->
                    db.clearAll()
                    refreshMemoryCharts()
                    toast("O‘chirildi")
                }
                .setNegativeButton("Yo‘q", null)
                .show()
        }
    }

    // ---------------- Yordamchilar ----------------

    private val notifThumbs = HashMap<String, ImageView>()

    private fun notifImageRow(idx: Int, kind: String, label: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(4))

        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val ivBg = GradientDrawable()
        ivBg.setColor(if (isNight()) 0xFF3A3C45.toInt() else 0xFFE3E5EC.toInt())
        ivBg.cornerRadius = dp(10).toFloat()
        iv.background = ivBg
        row.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
        notifThumbs[kind] = iv

        val tv = TextView(this)
        tv.text = label
        tv.textSize = 14f
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.marginStart = dp(12)
        row.addView(tv, tlp)

        val pick = Button(this)
        pick.text = "Rasm"
        pick.setAllCaps(false)
        pick.setOnClickListener { pickNotifImage(idx) }
        row.addView(pick, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)))

        val del = Button(this)
        del.text = "✕"
        del.setAllCaps(false)
        del.setOnClickListener {
            NotifImages.remove(this, kind)
            refreshNotifThumbs()
            toast("Rasm olib tashlandi")
        }
        row.addView(del, LinearLayout.LayoutParams(dp(48), dp(44)))

        section.addView(row)
        refreshNotifThumbs()
    }

    private fun refreshNotifThumbs() {
        for ((kind, iv) in notifThumbs) {
            if (NotifImages.has(this, kind)) {
                iv.setImageBitmap(NotifImages.load(this, kind))
            } else {
                iv.setImageDrawable(null)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun pickNotifImage(idx: Int) {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            launchForResult(i, NotifImages.REQ_BASE + idx)
        } catch (e: Exception) {
            toast("Galereyani ochib bo‘lmadi")
        }
    }

    private fun pickBg() {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            launchForResult(i, 501)
        } catch (e: Exception) {
            toast("Galereyani ochib bo‘lmadi")
        }
    }

    private fun handleResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 502 && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) {
                val fl = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                try {
                    contentResolver.takePersistableUriPermission(u, if (fl != 0) fl else Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    try {
                        contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e2: Exception) {
                        Log.e("Zeno", "papka ruxsati saqlanmadi", e2)
                    }
                }
                prefs.kbTree = u.toString()
                toast("Papka tanlandi")
                reloadKb(true)
            }
        }
        val ni = requestCode - NotifImages.REQ_BASE
        if (ni in NotifImages.KINDS.indices && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) {
                val kind = NotifImages.KINDS[ni].first
                val ok = NotifImages.save(this, kind, u)
                refreshNotifThumbs()
                toast(if (ok) "Rasm saqlandi" else "Rasmni o‘qib bo‘lmadi")
            }
        }
        if (requestCode == 501 && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) toast(if (Bg.save(this, u)) "Rasm orqa fonga qo‘yildi" else "Rasmni o‘qib bo‘lmadi")
        }
    }

    private fun pickKbFolder() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                )
            }
            launchForResult(i, 502)
        } catch (e: Exception) {
            toast("Papka tanlashni ochib bo‘lmadi")
        }
    }

    /** Fayllarni fon oqimida qayta o‘qib, holatni ko‘rsatadi. showDialog = true bo‘lsa, xatolar ro‘yxati ham chiqadi. */
    private fun reloadKb(showDialog: Boolean) {
        Thread {
            val st = try {
                UserKb.reload(applicationContext)
            } catch (e: Throwable) {
                UserKb.status()
            }
            runOnUiThread {
                kbStatus.text = "Papka: " + (if (st.treeSet) "tanlangan" else "tanlanmagan (ilova papkasi)") +
                    "\nFayllar: ${st.files}   Mavzular: ${st.topics}   Yozuvlar: ${st.entries}   Noto‘g‘ri qatorlar: ${st.problems.size}"
                if (showDialog) {
                    val sb = StringBuilder()
                    sb.append("Ko‘rilgan papkalar: ${st.folders}\nFayllar (.txt): ${st.files}\nMavzular: ${st.topics}\nSavol-javoblar: ${st.entries}\n")
                    if (st.skipped.isNotEmpty()) {
                        sb.append("\n.txt bo‘lmagani uchun o‘qilmadi:\n")
                        st.skipped.take(6).forEach { sb.append("• $it\n") }
                        sb.append("(fayl nomi .txt bilan tugashi kerak)\n")
                    }
                    if (st.perFile.isNotEmpty()) {
                        sb.append("\nFayllar bo‘yicha:\n")
                        st.perFile.take(12).forEach { sb.append("• ${it.first}: ${it.second} ta\n") }
                        if (st.perFile.size > 12) sb.append("… va yana ${st.perFile.size - 12} ta fayl\n")
                        sb.append("\n")
                    }
                    if (st.problems.isEmpty()) sb.append("Noto‘g‘ri qatorlar yo‘q.")
                    else {
                        sb.append("E’tiborsiz qoldirilgan qatorlar:\n")
                        st.problems.take(8).forEach { sb.append("• ${it.file}" + (if (it.line > 0) ", ${it.line}-qator" else "") + ": ${it.msg}\n") }
                        if (st.problems.size > 8) sb.append("… va yana ${st.problems.size - 8} ta")
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Bilimlar yangilandi")
                        .setMessage(sb.toString())
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }.start()
    }

    private fun hh(h: Int): String = String.format(Locale.US, "%02d:00", h)

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    private fun isNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Har bir bo‘lim — alohida yumaloq kartochka. */
    private fun header(t: String) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(14), dp(16), dp(14))
        val bg = GradientDrawable()
        bg.setColor(if (isNight()) 0xFF25262C.toInt() else Color.WHITE)
        bg.cornerRadius = dp(16).toFloat()
        card.background = bg
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        root.addView(card, lp)

        val tv = TextView(this)
        tv.text = t
        tv.textSize = 15f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(if (isNight()) 0xFF8FB2FF.toInt() else 0xFF3D7BF5.toInt())
        tv.setPadding(0, 0, 0, dp(6))
        card.addView(tv)
        section = card
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val s = SwitchCompat(this)
        s.text = label
        s.textSize = 15f
        s.isChecked = checked
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        section.addView(s)
    }

    private fun btn(t: String, action: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.setAllCaps(false)
        b.textSize = 14f
        b.stateListAnimator = null
        b.setTextColor(if (isNight()) 0xFFBFD0FF.toInt() else 0xFF1F3FA8.toInt())
        val bg = GradientDrawable()
        bg.setColor(if (isNight()) 0xFF2F3A55.toInt() else 0xFFE7EDFD.toInt())
        bg.cornerRadius = dp(12).toFloat()
        b.background = RippleDrawable(ColorStateList.valueOf(0x22000000), bg, null)
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46))
        lp.topMargin = dp(8)
        section.addView(b, lp)
    }

    private fun slider(label: (Int) -> String, lo: Int, hi: Int, cur: Int, onSet: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = label(cur)
        tv.textSize = 14f
        tv.setPadding(0, dp(10), 0, 0)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                tv.text = label(v)
                if (fromUser) onSet(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        section.addView(tv)
        section.addView(sb)
    }

    private fun pause(hours: Int) {
        prefs.pausedUntil = System.currentTimeMillis() + hours * 3_600_000L
        refreshStatus()
    }

    private fun refreshStatus() {
        usageStatus.text = if (UsageTracker.hasAccess(this))
            "Ruxsat holati: berilgan ✅"
        else
            "Ruxsat holati: berilmagan ❌ (quyidagi tugma orqali Zeno’ni yoqing)"

        aiStatus.text = if (prefs.aiKey.isBlank()) "AI holati: kalit kiritilmagan ❌" else "AI holati: kalit saqlangan ✅"

        val p = prefs.pausedUntil
        pauseStatus.text = if (System.currentTimeMillis() < p)
            "Jim turish: ${SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(p))} gacha"
        else
            "Jim turish: o‘chiq"
    }

    /** Ro‘yxatda yo‘q ilovani paket nomi bilan qo‘shish (masalan: com.whatsapp). */
    private fun addAppDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val pkgIn = EditText(this)
        pkgIn.hint = "Paket nomi (masalan: com.whatsapp)"
        val nameIn = EditText(this)
        nameIn.hint = "Nomi (ixtiyoriy)"
        box.addView(pkgIn)
        box.addView(nameIn)
        AlertDialog.Builder(this)
            .setTitle("Ilova qo‘shish")
            .setView(box)
            .setPositiveButton("Qo‘shish") { _, _ ->
                val pkg = pkgIn.text.toString().trim()
                if (!Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$").matches(pkg)) {
                    toast("Paket nomi noto‘g‘ri")
                    return@setPositiveButton
                }
                val cur = prefs.tracked()
                if (cur.any { it.pkg == pkg }) {
                    toast("Bu ilova ro‘yxatda bor")
                    return@setPositiveButton
                }
                val label = nameIn.text.toString().trim().ifEmpty { pkg.substringAfterLast('.') }
                prefs.saveTracked(cur + TrackedApp(pkg, label, true, listOf(30, 60, 90)))
                root.removeAllViews()
                build()
                refreshStatus()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun aiKeyDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val et = EditText(this)
        et.hint = "sk-ant-… (bo‘sh qoldirsangiz, o‘chiriladi)"
        et.setSingleLine(true)
        box.addView(et)
        AlertDialog.Builder(this)
            .setTitle("Anthropic API kaliti")
            .setView(box)
            .setPositiveButton("Saqlash") { _, _ ->
                prefs.aiKey = et.text.toString().trim().replace("\n", "").replace(" ", "")
                refreshStatus()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Batareya cheklovi allaqachon o‘chirilgan ✅")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("Sozlamalarni ochib bo‘lmadi")
            }
        }
    }

    /** Ishlab chiqaruvchiga xos avtostart sahifasini ochadi; topilmasa, ilova sozlamalariga yuboradi. */
    private fun openAutostart() {
        val targets = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in targets) {
            try {
                startActivity(Intent().setComponent(ComponentName(pkg, cls)))
                return
            } catch (e: Exception) {
                // keyingisini sinaymiz
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            toast("Ilova sozlamalarida «Batareya» va «Avtostart»ni yoqing")
        } catch (e: Exception) {
            toast("Sozlamalarni ochib bo‘lmadi")
        }
    }

    private fun addGoalDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val titleInput = EditText(this).apply { hint = "Maqsad (masalan, ingliz tili)" }
        val timeInput = EditText(this).apply { hint = "Eslatma vaqti (ixtiyoriy, 18:00)" }
        box.addView(titleInput); box.addView(timeInput)
        AlertDialog.Builder(this).setTitle("Maqsadni saqlash").setView(box)
            .setPositiveButton("Saqlash") { _, _ ->
                val title = titleInput.text.toString().trim()
                val rawTime = timeInput.text.toString().trim()
                val time = if (rawTime.isEmpty()) null else rawTime.takeIf { Regex("^([01]?\\d|2[0-3]):[0-5]\\d$").matches(it) }
                if (title.isEmpty()) toast("Maqsad nomini yozing")
                else if (rawTime.isNotEmpty() && time == null) toast("Vaqtni 18:00 ko‘rinishida yozing")
                else {
                    val id = db.addGoal(title, time)
                    if (time != null) db.addMemory("Maqsad", "Maqsad: $title; eslatma: $time")
                    toast(if (time == null) "Maqsad saqlandi (#$id)" else "Maqsad saqlandi; $time da eslataman")
                }
            }.setNegativeButton("Bekor qilish", null).show()
    }

    private fun addMemoryDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val category = EditText(this).apply { hint = "Tur (Muhim, Qiziqish, Maqsad...)"; setText("Muhim") }
        val content = EditText(this).apply { hint = "Saqlanadigan ma’lumot"; minLines = 2 }
        box.addView(category); box.addView(content)
        AlertDialog.Builder(this).setTitle("Xotiraga saqlash").setView(box)
            .setPositiveButton("Saqlash") { _, _ ->
                val cat = category.text.toString().trim().ifEmpty { "Muhim" }
                val value = content.text.toString().trim()
                if (value.isEmpty()) toast("Saqlanadigan ma’lumotni yozing")
                else {
                    toast(if (db.addMemory(cat, value)) "Xotiraga saqlandi" else "Bu ma’lumot avval saqlangan")
                    refreshMemoryCharts()
                }
            }.setNegativeButton("Bekor qilish", null).show()
    }

    private fun showGoals() {
        val goals = db.allGoals()
        if (goals.isEmpty()) { toast("Hali maqsad yo‘q"); return }
        val items = goals.map { (id, title) -> "#$id $title" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Maqsadlar (bosing — bajarildi deb belgilash)")
            .setItems(items) { _, which ->
                val id = goals[which].first
                val title = db.completeGoal(id)
                toast(if (title != null) "«$title» bajarildi deb belgilandi" else "Bu maqsad allaqachon bajarilgan")
            }.setNegativeButton("Yopish", null).show()
    }

    /** Xotira grafiklarini bazadan qayta chizadi. */
    private fun refreshMemoryCharts() {
        if (!::memCatChart.isInitialized) return
        val (cats, days) = db.memoryStats()
        val total = cats.sumOf { it.second }
        val txt = if (isNight()) 0xFFE6E6EA.toInt() else 0xFF1B1C20.toInt()
        val accent = if (isNight()) 0xFF6C9BFF.toInt() else 0xFF3D7BF5.toInt()

        memSummary.text = if (total == 0) "Xotira hozircha bo‘sh." else "Jami: $total ta yozuv, ${cats.size} ta turkum"
        val vis = if (total == 0) View.GONE else View.VISIBLE
        memCatChart.visibility = vis
        memWeekTitle.visibility = vis
        memWeekChart.visibility = vis
        memWeekTitle.setTextColor(txt)

        val shown = cats.take(6)
        memCatChart.labels = shown.map { it.first }
        memCatChart.values = shown.map { it.second }
        memCatChart.textColor = txt
        memCatChart.barColor = accent

        val names = arrayOf("Yak", "Du", "Se", "Ch", "Pa", "Ju", "Sh")
        memWeekChart.labels = (0..6).map { i ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, i - 6)
            names[cal.get(Calendar.DAY_OF_WEEK) - 1]
        }
        memWeekChart.values = days.toList()
        memWeekChart.textColor = txt
        memWeekChart.barColor = accent

        memCatChart.requestLayout()
        memCatChart.invalidate()
        memWeekChart.invalidate()
    }

    /** Xotira ro‘yxati: har bir yozuvda ⋮ tugmasi, ichida "O‘chirish". */
    private fun showMemories() {
        val items = db.memories().toMutableList()
        if (items.isEmpty()) {
            toast("Xotira bo‘sh")
            return
        }
        val txt = if (isNight()) 0xFFE6E6EA.toInt() else 0xFF1B1C20.toInt()
        val sub = if (isNight()) 0xFF8FB2FF.toInt() else 0xFF3D7BF5.toInt()
        val list = ListView(this)
        var dialog: AlertDialog? = null

        val adapter = object : ArrayAdapter<Mem>(this, 0, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val mem = getItem(position)!!
                val row = LinearLayout(context)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(20), dp(8), dp(8), dp(8))

                val col = LinearLayout(context)
                col.orientation = LinearLayout.VERTICAL
                val cat = TextView(context)
                cat.text = "#${mem.id} · ${mem.category}"
                cat.textSize = 12f
                cat.setTextColor(sub)
                val body = TextView(context)
                body.text = mem.text
                body.textSize = 15f
                body.setTextColor(txt)
                col.addView(cat)
                col.addView(body)
                row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

                val more = ImageButton(context)
                more.setImageResource(R.drawable.ic_more_vert)
                more.setColorFilter(txt)
                val tv = TypedValue()
                theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                more.setBackgroundResource(tv.resourceId)
                more.contentDescription = "Amallar"
                more.setOnClickListener { v ->
                    val pm = PopupMenu(this@SettingsActivity, v)
                    pm.menu.add(0, 1, 0, "O‘chirish")
                    pm.setOnMenuItemClickListener {
                        confirmDelete(mem) {
                            remove(mem)
                            notifyDataSetChanged()
                            refreshMemoryCharts()
                            if (isEmpty) dialog?.dismiss()
                        }
                        true
                    }
                    pm.show()
                }
                row.addView(more, LinearLayout.LayoutParams(dp(44), dp(44)))
                return row
            }
        }
        list.adapter = adapter
        val dlg = AlertDialog.Builder(this)
            .setTitle("Xotira")
            .setView(list)
            .setNegativeButton("Yopish", null)
            .create()
        dialog = dlg
        dlg.show()
    }

    private fun confirmDelete(mem: Mem, onDone: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("O‘chirilsinmi?")
            .setMessage(mem.text)
            .setPositiveButton("Ha") { _, _ ->
                db.deleteMemory(mem.id)
                onDone()
            }
            .setNegativeButton("Yo‘q", null)
            .show()
    }
}
