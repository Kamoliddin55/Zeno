package com.zeno.virtualfriend

import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

/**
 * Internetsiz bilimlar bazasi va hisob-kitob funksiyalari.
 * Matn moslashtiriladi: apostrof olib tashlanadi, h→x, q→k — shunda "o'zbekiston", "uzbekiston",
 * "qancha"/"kancha" kabi turli yozilishlar bir xil taniladi.
 */
object Knowledge {

    fun n(s: String): String = s.lowercase()
        .replace("'", "").replace("ʻ", "").replace("ʼ", "").replace("‘", "").replace("’", "").replace("`", "")
        .replace('x', 'h').replace('q', 'k')

    private fun tokens(flat: String): List<String> =
        flat.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }

    private class Entry(val groups: List<List<String>>, val answer: String)

    /** Har bir guruh "a|b|c" ko‘rinishida; javob berilishi uchun HAMMA guruhdan kamida bittasi topilishi kerak. */
    private fun e(answer: String, vararg g: String): Entry =
        Entry(g.map { grp -> grp.split("|").map { n(it.trim()) }.filter { it.isNotEmpty() } }, answer)

    private fun hit(tk: List<String>, flat: String, key: String): Boolean = when {
        key.startsWith("=") -> tk.any { it == key.substring(1) }
        key.contains(' ') || key.contains('-') -> flat.contains(key)
        else -> tk.any { it.startsWith(key) }
    }

    private fun pickAnswer(a: String): String {
        val parts = a.split("###")
        return if (parts.size == 1) a else parts[Random.nextInt(parts.size)]
    }

    private fun fmt(d: Double): String = Calc.format(Math.round(d * 1_000_000.0) / 1_000_000.0)

    // ---------------------------------------------------------------- asosiy kirish
    fun features(lower: String): String? {
        val flat = n(lower)
        val tk = tokens(flat)
        if (tk.isEmpty()) return null

        crisis(flat)?.let { return it }
        percent(lower)?.let { return it }
        bmi(flat)?.let { return it }
        equation(lower)?.let { return it }
        prime(flat)?.let { return it }
        age(flat)?.let { return it }
        daysUntil(flat)?.let { return it }
        convert(flat)?.let { return it }
        KbMath.run(flat)?.let { return it }
        translate(flat)?.let { return it }
        capital(flat, tk)?.let { return it }
        KbWords.capital(flat, tk)?.let { return it }
        KbWords.element(flat, tk, true)?.let { return it }
        Kb.search(tk, flat)?.let { return it }

        for (en in entries) {
            if (en.groups.all { grp -> grp.any { hit(tk, flat, it) } }) return pickAnswer(en.answer)
        }
        KbWords.element(flat, tk, false)?.let { return it }
        // Oxirgi zaxira: kengaytirilgan ZENO bilimlar bazasi (o'yin, Islom, suhbat va boshqalar).
        ZenoKnowledgeBase.answer(lower)?.let { return it }
        return null
    }

    // ---------------------------------------------------------------- xavfsizlik
    private val crisisKeys = listOf(
        "ozimni oldir", "ozimni oldirgim", "yashagim kelma", "olgim kel", "olmokchiman", "olib koymokchiman",
        "ozimga ziyon", "ozimni yokotgim", "yashashni xoxlamayman"
    ).map { n(it) }

    private fun crisis(flat: String): String? {
        if (crisisKeys.none { flat.contains(it) } || flat.contains("kulgi")) return null
        return "Buni yozganing juda muhim, va bunday og‘ir his-tuyg‘ular bilan yolg‘iz qolishing shart emas. " +
            "Iltimos, hozir yaqin odamingga (oila a’zosi yoki ishonchli do‘sting) aytib, yoningda bo‘lishini so‘ra. " +
            "Agar o‘zingga zarar yetkazish xavfi bor bo‘lsa, shoshilinch yordam raqamiga (112) qo‘ng‘iroq qil. " +
            "Men shu yerdaman — xohlasang, nima bo‘layotganini yozishing mumkin."
    }

    // ---------------------------------------------------------------- foiz
    private val num = "(\\d+(?:[.,]\\d+)?)"

    private fun d(s: String): Double? = s.replace(',', '.').toDoubleOrNull()

    private fun percent(lower: String): String? {
        Regex("$num\\s*(?:soni|ta)?\\s*$num\\s*(?:ning|dan)\\s*necha\\s*foiz").find(lower)?.let {
            val a = d(it.groupValues[1]) ?: return null
            val b = d(it.groupValues[2]) ?: return null
            if (b == 0.0) return null
            return "${fmt(a)} soni ${fmt(b)} ning ${fmt(a / b * 100)} foizini tashkil qiladi."
        }
        Regex("$num\\s*(?:ning|dan)\\s*$num\\s*(?:foiz|%)").find(lower)?.let {
            val a = d(it.groupValues[1]) ?: return null
            val p = d(it.groupValues[2]) ?: return null
            return "${fmt(a)} ning ${fmt(p)} foizi = ${fmt(a * p / 100)}"
        }
        Regex("$num\\s*%\\s*(?:of|dan|ning)?\\s*$num").find(lower)?.let {
            val p = d(it.groupValues[1]) ?: return null
            val a = d(it.groupValues[2]) ?: return null
            return "${fmt(a)} ning ${fmt(p)} foizi = ${fmt(a * p / 100)}"
        }
        return null
    }

    // ---------------------------------------------------------------- BMI
    private fun bmi(flat: String): String? {
        if (!(flat.contains("bmi") || flat.contains("tana massa"))) return null
        val nums = Regex("\\d+(?:[.,]\\d+)?").findAll(flat).mapNotNull { d(it.value) }.toList()
        if (nums.size < 2) return "Yozing: «bmi 70 175» (vazn kg, bo‘y sm)."
        val w = nums[0]
        var h = nums[1]
        if (h < 3) h *= 100
        if (w < 20 || w > 400 || h < 80 || h > 260) return "Raqamlar g‘alati ko‘rindi. Misol: «bmi 70 175» (vazn kg, bo‘y sm)."
        val v = w / ((h / 100) * (h / 100))
        val cat = when {
            v < 18.5 -> "me’yordan past"
            v < 25 -> "me’yor oralig‘ida"
            v < 30 -> "me’yordan yuqori"
            else -> "yuqori"
        }
        return "Tana massasi indeksi (BMI) ≈ ${String.format(Locale.US, "%.1f", v)} — $cat. " +
            "Bu faqat taxminiy ko‘rsatkich (mushak massasi, yosh va boshqalarni hisobga olmaydi); sog‘liq masalasida shifokor bilan maslahatlashing."
    }

    // ---------------------------------------------------------------- kvadrat tenglama
    private fun equation(lower: String): String? {
        val m = Regex("tenglama\\s+(-?\\d+(?:[.,]\\d+)?)\\s+(-?\\d+(?:[.,]\\d+)?)\\s+(-?\\d+(?:[.,]\\d+)?)").find(lower) ?: return null
        val a = d(m.groupValues[1]) ?: return null
        val b = d(m.groupValues[2]) ?: return null
        val c = d(m.groupValues[3]) ?: return null
        if (a == 0.0) {
            if (b == 0.0) return "Bu tenglama emas (a va b nol)."
            return "Chiziqli tenglama: x = ${fmt(-c / b)}"
        }
        val disc = b * b - 4 * a * c
        return when {
            disc < 0 -> "D = ${fmt(disc)} < 0, haqiqiy ildizlar yo‘q."
            disc == 0.0 -> "D = 0, bitta ildiz: x = ${fmt(-b / (2 * a))}"
            else -> {
                val s = Math.sqrt(disc)
                "D = ${fmt(disc)}; x₁ = ${fmt((-b + s) / (2 * a))}, x₂ = ${fmt((-b - s) / (2 * a))}"
            }
        }
    }

    // ---------------------------------------------------------------- tub son
    private fun prime(flat: String): String? {
        if (!(flat.contains("tub son") || flat.contains("tubmi"))) return null
        val v = Regex("\\d{1,12}").find(flat)?.value?.toLongOrNull() ?: return null
        if (v < 2) return "$v tub son emas (tub sonlar 2 dan boshlanadi)."
        var i = 2L
        while (i * i <= v) {
            if (v % i == 0L) return "$v tub son emas: u $i ga bo‘linadi (${v} = $i × ${v / i})."
            i++
        }
        return "$v — tub son ✅"
    }

    // ---------------------------------------------------------------- yosh
    private fun age(flat: String): String? {
        val m = Regex("(\\d{4}).{0,25}tugil").find(flat) ?: return null
        val y = m.groupValues[1].toInt()
        val now = Calendar.getInstance().get(Calendar.YEAR)
        if (y !in 1900..now) return null
        val a = now - y
        return "$y-yilda tug‘ilgan bo‘lsangiz, bu yil $a yoshga to‘lasiz (yoki to‘lgansiz — tug‘ilgan kuningizga qarab)."
    }

    // ---------------------------------------------------------------- sanagacha necha kun
    private val months = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    ).map { n(it) }

    private fun daysUntil(flat: String): String? {
        if (!(flat.contains(n("necha kun")) || flat.contains(n("qancha")) || flat.contains("kun kol"))) return null
        val m = Regex("(\\d{1,2})\\s*(${months.joinToString("|")})").find(flat) ?: return null
        val day = m.groupValues[1].toInt()
        val mon = months.indexOf(m.groupValues[2])
        if (mon < 0 || day !in 1..31) return null
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val target = (today.clone() as Calendar).apply {
            set(Calendar.MONTH, mon); set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.DAY_OF_MONTH, minOf(day, getActualMaximum(Calendar.DAY_OF_MONTH)))
        }
        if (target.before(today)) target.add(Calendar.YEAR, 1)
        val diff = Math.round((target.timeInMillis - today.timeInMillis) / 86_400_000.0)
        return if (diff == 0L) "Aynan bugun! 🎉" else "$day-${m.groupValues[2]}gacha taxminan $diff kun qoldi."
    }

    // ---------------------------------------------------------------- birliklarni o‘girish
    private class U(val dim: String, val f: Double, val name: String)

    private val units: Map<String, U> by lazy {
        val m = HashMap<String, U>()
        fun add(dim: String, f: Double, name: String, vararg aliases: String) {
            aliases.forEach { m[n(it)] = U(dim, f, name) }
        }
        add("L", 1000.0, "km", "km", "kilometr")
        add("L", 1.0, "m", "m", "metr")
        add("L", 0.01, "sm", "sm", "santimetr")
        add("L", 0.001, "mm", "mm", "millimetr")
        add("L", 1609.344, "mil", "mil")
        add("L", 0.3048, "fut", "fut")
        add("L", 0.0254, "dyuym", "dyuym", "inch")
        add("M", 1.0, "kg", "kg", "kilogramm")
        add("M", 0.001, "g", "g", "gramm")
        add("M", 1000.0, "tonna", "tonna")
        add("M", 0.45359237, "funt", "funt", "lb")
        add("M", 0.0283495, "untsiya", "untsiya")
        add("V", 1.0, "litr", "l", "litr")
        add("V", 0.001, "ml", "ml", "millilitr")
        add("V", 3.78541, "galon", "galon")
        add("T", 3600.0, "soat", "soat")
        add("T", 60.0, "daqiqa", "daqiqa", "minut")
        add("T", 1.0, "sekund", "sekund")
        add("T", 86400.0, "kun", "kun")
        add("T", 604800.0, "hafta", "hafta")
        add("TC", 1.0, "°C", "c", "selsiy")
        add("TF", 1.0, "°F", "f", "farengeyt")
        add("TK", 1.0, "K", "kelvin")
        m
    }

    private fun convert(flat: String): String? {
        val m = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*([a-z]+)\\s+(?:${n("necha")}|${n("qancha")}|${n("nechta")})\\s+([a-z]+)").find(flat) ?: return null
        val v = d(m.groupValues[1]) ?: return null
        val a = units[m.groupValues[2]] ?: return null
        val b = units[m.groupValues[3]] ?: return null
        if (a.dim.startsWith("T") && a.dim.length == 2 || b.dim.startsWith("T") && b.dim.length == 2) {
            if (!(a.dim.length == 2 && b.dim.length == 2)) return null
            val c = when (a.dim) { "TC" -> v; "TF" -> (v - 32) * 5 / 9; else -> v - 273.15 }
            val r = when (b.dim) { "TC" -> c; "TF" -> c * 9 / 5 + 32; else -> c + 273.15 }
            return "${fmt(v)} ${a.name} = ${fmt(r)} ${b.name}"
        }
        if (a.dim != b.dim) return null
        return "${fmt(v)} ${a.name} = ${fmt(v * a.f / b.f)} ${b.name}"
    }

    // ---------------------------------------------------------------- lug‘at (o‘zbekcha ↔ inglizcha)
    private val dictRaw = "salom=hello;xayr=goodbye;rahmat=thank you;iltimos=please;ha=yes;yo'q=no;kechirasiz=sorry;" +
        "olma=apple;non=bread;suv=water;choy=tea;sut=milk;go'sht=meat;tuxum=egg;guruch=rice;shakar=sugar;tuz=salt;" +
        "kitob=book;qalam=pen;daftar=notebook;maktab=school;universitet=university;o'qituvchi=teacher;talaba=student;" +
        "do'st=friend;oila=family;ona=mother;ota=father;aka=older brother;uka=younger brother;opa=older sister;singil=younger sister;" +
        "bola=child;odam=person;uy=house;xona=room;eshik=door;deraza=window;stol=table;stul=chair;" +
        "shahar=city;qishloq=village;mamlakat=country;mashina=car;yo'l=road;velosiped=bicycle;samolyot=airplane;poyezd=train;" +
        "telefon=phone;kompyuter=computer;internet=internet;dastur=program;ish=work;pul=money;vaqt=time;" +
        "kun=day;tun=night;hafta=week;oy=month;yil=year;bugun=today;ertaga=tomorrow;kecha=yesterday;" +
        "ertalab=morning;kechqurun=evening;soat=hour;daqiqa=minute;" +
        "katta=big;kichik=small;yaxshi=good;yomon=bad;chiroyli=beautiful;tez=fast;sekin=slow;issiq=hot;sovuq=cold;" +
        "yangi=new;eski=old;uzun=long;qisqa=short;baland=tall;past=low;og'ir=heavy;yengil=light;oson=easy;qiyin=difficult;" +
        "qizil=red;ko'k=blue;yashil=green;sariq=yellow;qora=black;oq=white;" +
        "bir=one;ikki=two;uch=three;to'rt=four;besh=five;olti=six;yetti=seven;sakkiz=eight;to'qqiz=nine;o'n=ten;" +
        "men=I;sen=you;biz=we;sevgi=love;baxt=happiness;ilm=knowledge;til=language;savol=question;javob=answer;" +
        "yordam=help;qalaysiz=how are you;tushunmadim=i did not understand;yaxshimisiz=how are you;" +
        "yurak=heart;bosh=head;qo'l=hand;oyoq=leg;ko'z=eye;quloq=ear;og'iz=mouth;burun=nose;" +
        "quyosh=sun;oy sayyorasi=moon;yulduz=star;yomg'ir=rain;qor=snow;shamol=wind;daryo=river;tog'=mountain;dengiz=sea;daraxt=tree;gul=flower;" +
        "mushuk=cat;it=dog;ot=horse;qush=bird;baliq=fish;sigir=cow;qo'y=sheep;" +
        "dushanba=monday;seshanba=tuesday;chorshanba=wednesday;payshanba=thursday;juma=friday;shanba=saturday;yakshanba=sunday;" +
        "yanvar=january;fevral=february;mart=march;aprel=april;may=may;iyun=june;iyul=july;avgust=august;sentabr=september;oktabr=october;noyabr=november;dekabr=december"

    private val uzEn = HashMap<String, Pair<String, String>>()
    private val enUz = HashMap<String, Pair<String, String>>()

    init {
        (dictRaw + ";" + KbWords.dict2).split(";").forEach {
            val p = it.split("=")
            if (p.size == 2) {
                uzEn.putIfAbsent(n(p[0]), Pair(p[0], p[1]))
                enUz.putIfAbsent(n(p[1]), Pair(p[1], p[0]))
            }
        }
    }

    private val fillers = setOf("sozi", "suzi", "sozini", "iborasi", "gapni", "sozning", "ning", "tarjimasi", "tarjima", "kanday", "kanaka", "nima", "qanday")

    private fun translate(flat: String): String? {
        val trigs = listOf("inglizcha", "ingilizcha", "inglizchasi", "ozbekcha", "uzbekcha", "ozbekchasi", "nima degani", "degani nima").map { n(it) }
        if (!(flat.contains("tarjima") || trigs.any { flat.contains(it) })) return null
        var phrase: String? = null
        Regex("tarjima(?:si)?\\s*[:\\-]?\\s*(.+)$").find(flat)?.let { phrase = it.groupValues[1] }
        if (phrase == null) {
            Regex("^(.+?)\\s+(?:${trigs.joinToString("|")})").find(flat)
                ?.let { phrase = it.groupValues[1] }
        }
        var p = phrase?.trim() ?: return null
        p = p.trim('"', '«', '»', ' ', '?', '.', '!')
        val tk = tokens(p).filter { it !in fillers }
        if (tk.isEmpty()) return null
        val whole = tk.joinToString(" ")
        val cands = listOf(whole) + tk.reversed()
        for (c in cands) {
            uzEn[c]?.let { return "«${it.first}» inglizchada: ${it.second}" }
            enUz[c]?.let { return "«${it.first}» o‘zbekchada: ${it.second}" }
        }
        return null
    }

    // ---------------------------------------------------------------- poytaxtlar
    private class Cap(val name: String, val keys: List<String>, val city: String)

    private val caps: List<Cap> by lazy {
        fun c(name: String, keys: String, city: String) = Cap(name, keys.split("|").map { n(it) }, city)
        listOf(
            c("O‘zbekiston", "o'zbekiston|uzbekiston|uzbekistan", "Toshkent"),
            c("Qozog‘iston", "qozog'iston|qozogiston|kazakhstan|kazaxiston", "Ostona"),
            c("Qirg‘iziston", "qirg'iziston|qirgiziston|kirgiziston", "Bishkek"),
            c("Tojikiston", "tojikiston", "Dushanbe"),
            c("Turkmaniston", "turkmaniston", "Ashxobod"),
            c("Afg‘oniston", "afg'oniston|afgoniston", "Kobul"),
            c("Rossiya", "rossiya", "Moskva"),
            c("Turkiya", "turkiya", "Anqara"),
            c("AQSh", "=aqsh|=usa|amerika|qo'shma shtat", "Vashington"),
            c("Buyuk Britaniya", "britaniya|angliya", "London"),
            c("Fransiya", "fransiya", "Parij"),
            c("Germaniya", "germaniya", "Berlin"),
            c("Italiya", "italiya", "Rim"),
            c("Ispaniya", "ispaniya", "Madrid"),
            c("Yaponiya", "yaponiya", "Tokio"),
            c("Xitoy", "xitoy", "Pekin"),
            c("Hindiston", "hindiston", "Nyu-Deli"),
            c("Janubiy Koreya", "janubiy koreya|koreya", "Seul"),
            c("Misr", "misr", "Qohira"),
            c("Saudiya Arabistoni", "saudiya|saudiya arabiston", "Ar-Riyod"),
            c("BAA", "=baa|birlashgan arab", "Abu-Dabi"),
            c("Ukraina", "ukraina", "Kiyev"),
            c("Braziliya", "braziliya", "Brazilia"),
            c("Kanada", "kanada", "Ottava"),
            c("Avstraliya", "avstraliya", "Kanberra"),
            c("Eron", "=eron", "Tehron"),
            c("Ozarbayjon", "ozarbayjon|ozerbayjon", "Boku"),
            c("Gruziya", "gruziya", "Tbilisi"),
            c("Pokiston", "pokiston", "Islomobod"),
            c("Polsha", "polsha", "Varshava"),
            c("Belarus", "belarus|belorus", "Minsk"),
            c("Argentina", "argentina", "Buenos-Ayres"),
            c("Meksika", "meksika", "Mexiko")
        )
    }

    private fun capital(flat: String, tk: List<String>): String? {
        if (tk.none { it.startsWith("poytaxt") || it.startsWith("paytaxt") }) return null
        for (c in caps) {
            if (c.keys.any { hit(tk, flat, it) }) return "${c.name} poytaxti — ${c.city}."
        }
        return null
    }

    // ---------------------------------------------------------------- bilimlar bazasi
    private val entries: List<Entry> by lazy {
        listOf(
            // --- mavzular ro‘yxati
            e(
                "Men quyidagilar haqida gaplasha olaman:\n" +
                    "• O‘zbekiston: tarix, shaxslar (Temur, Navoiy, Ulug‘bek, Xorazmiy, Ibn Sino, Bobur), poytaxt, pul\n" +
                    "• Dunyo: davlatlar poytaxti, qit’alar, okeanlar, rekordlar\n" +
                    "• Fan: sayyoralar, yorug‘lik, suv, tana, DNK, formulalar (doira, uchburchak, Pifagor…)\n" +
                    "• Hisob: «200 ning 15 foizi», «bmi 70 175», «tenglama 1 -3 2», «17 tub sonmi», «5 km necha metr», «1 yanvargacha necha kun»\n" +
                    "• Tarjima: «tarjima: apple», «olma inglizcha»\n" +
                    "• Hayot: uyqu, suv ichish, mashq, stress, o‘qish, vaqt rejalash, pul tejash, rezyume\n" +
                    "• Texnika: dasturlash, Python, telefon batareyasi, parol\n" +
                    "• Qiziq: hazil, maqol, qiziq fakt, motivatsiya, plov retsepti",
                "=mavzular|=mavzu|=mavzularni|nimalar haqida|nima haqida gaplash|nimalarni bilasan|nimalarni bilasiz"
            ),

            // --- O‘zbekiston
            e("O‘zbekiston 1991-yil 1-sentabrda mustaqillikka erishgan. Mustaqillik kuni har yili 1-sentabrda nishonlanadi.",
                "mustaqillik|independence", "kuni|sana|qachon|yil|necha"),
            e("O‘zbekistonning milliy valyutasi — so‘m (UZS).", "o'zbekiston|uzbekiston|davlat", "pul birligi|valyuta|valyutasi|puli"),
            e("O‘zbekistonda 12 ta viloyat, Qoraqalpog‘iston Respublikasi va Toshkent shahri bor.", "o'zbekiston|uzbekiston", "viloyat"),
            e("O‘zbekiston aholisi taxminan 37 million kishi (so‘nggi yillardagi baho). Bu Markaziy Osiyodagi eng ko‘p aholili davlat.",
                "o'zbekiston|uzbekiston", "aholi|aholisi|necha odam|qancha odam"),
            e("O‘zbekistonning davlat tili — o‘zbek tili. Qoraqalpog‘istonda qoraqalpoq tili ham davlat tili hisoblanadi.",
                "davlat tili|rasmiy til"),
            e("Amir Temur (1336–1405) — Temuriylar davlati asoschisi, buyuk sarkarda va davlat arbobi. Poytaxti Samarqand bo‘lgan; Kesh (Shahrisabz) yaqinida tug‘ilgan.",
                "temur|tamerlan"),
            e("Alisher Navoiy (1441–1501) — buyuk o‘zbek shoiri va mutafakkiri, «Xamsa» muallifi. Hirotda yashab ijod qilgan, o‘zbek adabiy tilini yuksaltirgan.",
                "navoiy|navoi"),
            e("Mirzo Ulug‘bek (1394–1449) — temuriy hukmdor va buyuk astronom. Samarqandda rasadxona qurdirgan, «Ziji Ko‘ragoniy» yulduzlar jadvali uning nomi bilan mashhur.",
                "ulug'bek|ulugbek"),
            e("Al-Xorazmiy (taxminan 780–850) — buyuk matematik va astronom. Algebra fanining asoschisi hisoblanadi; «algoritm» so‘zi uning nomidan kelib chiqqan.",
                "xorazmiy|al-xorazmiy|al xorazmiy"),
            e("Abu Ali ibn Sino (980–1037) — buyuk tabib va olim, «Tib qonunlari» asari asrlar davomida Sharq va G‘arbda tibbiyot darsligi bo‘lgan.",
                "ibn sino|ibn sina|abu ali"),
            e("Zahiriddin Muhammad Bobur (1483–1530) — Andijonda tug‘ilgan shoir va sarkarda, Hindistonda Boburiylar sulolasiga asos solgan, «Boburnoma» muallifi.",
                "bobur"),
            e("Abu Rayhon Beruniy (973–1048) — Xorazmlik buyuk olim: astronomiya, geografiya, tarix va boshqa fanlar bo‘yicha asarlar yozgan.",
                "beruniy"),
            e("Samarqand, Buxoro va Xiva — Buyuk Ipak yo‘lidagi qadimiy shaharlar, ular o‘zining madrasa, minora va maqbaralari bilan mashhur (masalan, Samarqandda Registon maydoni). Ikki ming yildan ortiq tarixga ega.",
                "samarqand|buxoro|xiva|registon|ipak yo'li"),
            e("Orol dengizi bir paytlar dunyodagi eng katta ko‘llardan biri bo‘lgan, lekin o‘tgan asrning 60-yillaridan sug‘orish uchun suv olinishi sababli keskin qurib, ekologik ofatga aylandi.",
                "orol"),
            e("Navro‘z — bahor va yangi yil bayrami, 21-martda nishonlanadi. Unda sumalak, halim va boshqa milliy taomlar tayyorlanadi.",
                "navro'z|navruz|navroz"),
            e("Plov (4–5 kishiga): 1 kg guruch, 1 kg go‘sht, 1 kg sabzi, 2 ta piyoz, ~200 ml yog‘, zira, tuz.\n" +
                "1) Qozonda yog‘ni qizdirib, piyozni qizartiring.\n2) Go‘shtni soling va qovuring.\n3) Sabzini to‘g‘rab qo‘shing, 10–15 daqiqa qovuring.\n" +
                "4) Tuz, zira va suv quyib, zirvakni 30–40 daqiqa pishiring.\n5) Yuvilgan guruchni soling, suv guruchdan 1–2 barmoq baland bo‘lsin.\n" +
                "6) Suv shimilgach, olovni pasaytirib, qopqoq yopib 20–25 daqiqa damlang. Yoqimli ishtaha!",
                "plov|osh", "qanday|pishir|retsept|tayyorla"),

            // --- dunyo
            e("Yerda 7 ta qit’a bor: Osiyo, Afrika, Shimoliy Amerika, Janubiy Amerika, Antarktida, Yevropa va Avstraliya (Okeaniya).",
                "qita|qit'a|kitta", "nechta|qancha|necha"),
            e("Yerda 5 ta okean bor: Tinch, Atlantika, Hind, Shimoliy Muz va Janubiy okeanlar. Eng kattasi — Tinch okeani.",
                "okean", "nechta|qancha|necha|eng katta"),
            e("Dunyodagi eng baland tog‘ — Everest (Jomolungma), balandligi taxminan 8849 m.", "eng baland", "tog"),
            e("Eng uzun daryo — Nil (~6650 km) yoki Amazonka; o‘lchash usuliga qarab ikkalasi ham eng uzun deb aytiladi.", "eng uzun", "daryo"),
            e("Maydon bo‘yicha eng katta davlat — Rossiya. Aholisi bo‘yicha esa hozir Hindiston birinchi o‘rinda.", "eng katta", "davlat|mamlakat"),
            e("Dunyodagi eng kichik davlat — Vatikan.", "eng kichik", "davlat|mamlakat"),
            e("Okeanning eng chuqur joyi — Mariana cho‘kmasi (Tinch okeani), chuqurligi taxminan 11 km.", "eng chuqur", "okean|dengiz|joy"),
            e("Yerning yoshi taxminan 4,5 milliard yil, Koinotniki esa taxminan 13,8 milliard yil.", "yer|koinot|olam", "yoshi|necha yosh|qancha yosh"),
            e("Quyosh tizimida 8 ta sayyora bor: Merkuriy, Venera, Yer, Mars, Yupiter, Saturn, Uran va Neptun.", "sayyora", "nechta|qancha|necha|nomlari|qaysi"),
            e("Yerdan Quyoshgacha masofa taxminan 150 million km, Oygacha — taxminan 384 400 km.", "quyosh|oygacha|=oy", "masofa|uzoq|qancha|necha km"),
            e("Yorug‘lik tezligi vakuumda taxminan 300 000 km/s (aniqrog‘i 299 792 km/s).", "yorug'lik|yoruglik", "tezlig"),
            e("Tovush tezligi havoda taxminan 343 m/s (20 °C da), ya’ni ~1235 km/soat.", "tovush", "tezlig"),
            e("Suv normal bosimda 100 °C da qaynaydi va 0 °C da muzlaydi.", "suv", "qaynay|qaynash|muzla|muz bo"),
            e("Yer tortishish kuchi tufayli erkin tushish tezlanishi g ≈ 9,8 m/s². Oyda u taxminan 6 marta kichik.", "tortishish|gravitatsiya|og'irlik kuchi"),
            e("Fotosintez — o‘simliklar yorug‘lik energiyasi yordamida karbonat angidrid va suvdan glyukoza hosil qilib, kislorod ajratish jarayoni.", "fotosintez"),
            e("DNK — tirik organizmning irsiy ma’lumotini saqlovchi molekula (qo‘sh spiral). Genlar DNKning bo‘laklaridir.", "dnk|dna"),
            e("Hujayra — barcha tirik organizmlarning asosiy tuzilma birligi. Odam tanasi trillionlab hujayradan iborat.", "hujayra", "nima|nimadan"),
            e("Katta odamda 206 ta suyak bor. Tana vaznining taxminan yarmidan ko‘pi suvdan iborat.", "suyak|odam tanasi", "nechta|qancha|necha|nimadan"),
            e("Yurak kuniga taxminan 100 ming marta uradi. Dam olish holatida kattalarda odatda minutiga 60–100 urish normal hisoblanadi.", "yurak", "necha marta|qancha|uradi|urish"),
            e("Tana haroratining me’yori taxminan 36,1–37,2 °C oralig‘ida (o‘rtacha ~36,6 °C). Yuqori isitma uzoq davom etsa, shifokorga murojaat qiling.", "tana", "harorat"),
            e("Davriy jadvalda 118 ta kimyoviy element bor (Mendeleyev jadvali).", "element|davriy jadval|mendeleyev", "nechta|qancha|necha"),
            e("Atom — kimyoviy elementning eng kichik zarrasi; u yadro (proton va neytron) hamda uning atrofidagi elektronlardan iborat.", "=atom", "nima|nimadan"),
            e("Nyutonning 3 qonuni: 1) inersiya — kuch ta’sir etmasa, jism holatini saqlaydi; 2) F = m·a; 3) ta’sir kuchi aks ta’sir kuchiga teng va qarama-qarshi.", "nyuton", "qonun"),
            e("Om qonuni: I = U / R (tok kuchi = kuchlanish / qarshilik), shuningdek U = I·R.", "om qonuni|om qonun"),
            e("Pifagor teoremasi: to‘g‘ri burchakli uchburchakda a² + b² = c², bunda c — gipotenuza.", "pifagor"),
            e("π (pi) soni — aylana uzunligining diametriga nisbati, taxminan 3,14159.", "pi soni|=pi|pay soni"),
            e("Doira yuzi: S = π·r²; aylana uzunligi: L = 2·π·r (r — radius).", "doira|aylana", "yuz|uzunlik|formula|hisobla"),
            e("Uchburchak yuzi: S = ½ · asos · balandlik. Perimetri — uch tomon yig‘indisi.", "uchburchak", "yuz|perimetr|formula|hisobla"),
            e("To‘g‘ri to‘rtburchak: yuzi S = a·b, perimetri P = 2(a+b). Kvadrat: S = a², P = 4a.", "to'rtburchak|kvadrat", "yuz|perimetr|formula|hisobla"),
            e("Kvadrat tenglama ax² + bx + c = 0: D = b² − 4ac; D>0 bo‘lsa x = (−b ± √D) / 2a. Tez hisoblash uchun «tenglama 1 -3 2» deb yozing.", "kvadrat tenglama|diskriminant"),
            e("Tub son — faqat 1 ga va o‘ziga bo‘linadigan 1 dan katta natural son: 2, 3, 5, 7, 11… Tekshirish uchun «17 tub sonmi» deb yozing.", "tub son", "nima|nimaga"),
            e("Tezlik formulasi: v = S / t (masofa / vaqt). Shunga ko‘ra S = v·t va t = S / v.", "tezlik|yo'l formula", "formula|qanday hisob"),

            // --- sog‘liq va turmush
            e("Kattalar uchun odatda 7–9 soat uyqu tavsiya etiladi. Bir xil vaqtda yotish va turish uyqu sifatini yaxshilaydi.", "uxla|uyqu", "qancha|necha|kerak|soat"),
            e("Odatiy tavsiya — kuniga taxminan 1,5–2 litr suyuqlik, lekin u iqlim, mashq va sog‘liqqa qarab o‘zgaradi. Kasallik bo‘lsa, shifokor maslahati muhim.", "suv", "ich", "qancha|necha|kerak|litr"),
            e("Jahon sog‘liqni saqlash tashkiloti kattalarga haftasiga kamida 150 daqiqa o‘rtacha faollik (tez yurish kabi) tavsiya qiladi. Kichikdan boshlang: kuniga 20–30 daqiqa yurish.", "mashq|sport|jismoniy", "qancha|necha|haftada|kerak"),
            e("Ko‘z charchasa 20-20-20 qoidasi yordam beradi: har 20 daqiqada 20 soniya davomida taxminan 6 metr uzoqlikka qarang. Ekran yorug‘ligini ham moslang.", "ko'z", "charcha|og'ri|dam|qizar"),
            e("Bosh og‘rig‘ida suv iching, dam oling, xonani shamollating va ekrandan tanaffus qiling. Og‘riq juda kuchli, to‘satdan boshlangan yoki uzoq davom etsa — shifokorga murojaat qiling.", "bosh", "og'ri|og'riyap|og'riyd"),
            e("Stress va xavotirda nafas mashqi yordam beradi: 4 soniya nafas oling, 4 soniya ushlang, 6 soniya sekin chiqaring — 5 marta takrorlang. Keyin xavotirni qog‘ozga yozib, nimani nazorat qila olishingizni ajrating.", "stress|xavotir|tashvish|asab|bezovta"),
            e("Uyqu qiyin bo‘lsa: yotishdan 1 soat oldin telefonni qo‘ying, xonani salqin va qorong‘i qiling, kechqurun kofe/choydan saqlaning, har kuni bir vaqtda yoting.", "uyqusiz|uxlay olmay|uxlolmay"),
            e("G‘azab kelganda bir necha chuqur nafas oling, 10 gacha sanang, imkon bo‘lsa joyingizni o‘zgartiring. Tinchlanib olgach gaplashish ancha foydali.", "g'azab|jahl|achchiq"),
            e("Yolg‘izlik his qilish — odamga xos holat. Bir do‘stingizga qisqa xabar yozing yoki qiziqish bo‘yicha guruhga qo‘shiling. Men ham shu yerdaman, xohlasangiz gaplashamiz 🙂", "yolg'iz"),
            e("Boshlash — eng qiyin qismi. 5 daqiqalik qoida: ishni faqat 5 daqiqaga boshlang — ko‘pincha davom etgingiz keladi.", "dangasa|boshlay olmay|hafsala|erinch"),
            e("Dars uchun «Pomodoro» usuli: 25 daqiqa diqqat bilan ishlang, 5 daqiqa dam oling; 4 ta sikldan keyin 15–30 daqiqa uzoqroq dam. Telefonni boshqa xonaga qo‘ying.", "dars|o'qish|imtihon|tayyorlan", "qanday|yaxshi|tez|maslahat"),
            e("Yodlash uchun: o‘qiganingizni o‘zingiz tushuntirib ko‘ring, oraliq takrorlash (1 kun, 3 kun, 1 hafta) qiling, kalit so‘zlar va misollar bilan bog‘lang.", "yodlash|yodlay|esda saqlash"),
            e("Vaqtni rejalash: kuning eng muhim 1–3 ishini oldindan yoz, eng murakkabini ertalab qil, 2 daqiqada bitadigan ishni darhol bajar, kun oxirida ertangi rejani yoz.", "vaqt", "rejala|tejash|boshqar|yetishmay|ulgura"),
            e("Odat shakllanishi odamga qarab farq qiladi: tadqiqotlarda o‘rtacha taxminan 2 oy (≈66 kun) topilgan. Kichik va har kuni takrorlanadigan qadamdan boshlang.", "odat", "qancha|necha|kun|shakllan|qanday"),
            e("Pul tejash uchun 50/30/20 qoidasi: daromadning 50% — zarur xarajatlar, 30% — xohishlar, 20% — jamg‘arma. Oylik boshlanishi bilan jamg‘armani avval chetga qo‘ying.", "pul", "tejash|yig'ish|tejam|byudjet|jamg'ar"),
            e("Yaxshi rezyume: 1 sahifa, aniq maqsad, oxirgi ish joylaringiz natijalar bilan (raqamlar bilan), ko‘nikmalar, bog‘lanish ma’lumotlari; imlo xatosiz bo‘lsin.", "rezyume|cv"),
            e("Til o‘rganish: kuniga 15–20 daqiqa, har kuni; 10 ta yangi so‘z va ularni gapda ishlating; tinglash va gapirishga ko‘proq vaqt ajrating.", "til", "o'rgan", "qanday|tez|yaxshi|maslahat"),
            e("Kitob o‘qish odatini shakllantirish: kuniga 10 sahifadan boshlang, qiziq mavzu tanlang, telefonsiz joy va vaqt belgilang.", "kitob", "o'qi|o'qish", "qanday|maslahat|nima"),

            // --- texnika
            e("Dasturlashni boshlash uchun: 1) Python kabi sodda tilni tanlang, 2) kuniga 30–60 daqiqa mashq qiling, 3) kichik loyihalar (kalkulyator, vazifalar ro‘yxati) yozing, 4) xatolarni o‘zingiz qidirib tuzatishni o‘rganing.", "dasturlash|dasturchi", "nima|boshla|qanday|o'rgan"),
            e("Python — oddiy sintaksisli, o‘rganish oson, juda ko‘p sohada (veb, ma’lumotlar tahlili, sun’iy intellekt) ishlatiladigan dasturlash tili.", "python", "nima|haqida"),
            e("Kotlin — Android ilovalari uchun asosiy tillardan biri. Zeno ham aynan Kotlinda yozilgan.", "kotlin", "nima|haqida"),
            e("HTML — veb-sahifalarning tuzilishini (matn, rasm, havola) belgilovchi belgilash tili. CSS ko‘rinishni, JavaScript esa harakatni boshqaradi.", "=html", "nima|haqida"),
            e("Internet — dunyo bo‘ylab kompyuter va qurilmalarni bog‘lovchi global tarmoq.", "=internet", "nima"),
            e("Sun’iy intellekt (AI) — kompyuterlarning odamga xos vazifalarni (matnni tushunish, rasm tanish, qaror qabul qilish) bajarishi. Zenoga AI kalitini sozlamalardan qo‘shsangiz, yanada keng javob beradi.", "suniy intellekt|sun'iy intellekt|=ai|=ii", "nima|qanday"),
            e("Algoritm — masalani yechish uchun aniq va ketma-ket qadamlar to‘plami. So‘z al-Xorazmiy nomidan olingan.", "algoritm", "nima"),
            e("Batareyani tejash: ekran yorug‘ligini kamaytiring, keraksiz ilovalarning fon rejimini cheklang, lokatsiya va Bluetooth'ni kerak bo‘lmaganda o‘chiring, tejash rejimidan foydalaning. Eslatma: Zeno'ning eslatmalari ishlashi uchun uni cheklovdan chiqarib qo‘ying.", "batareya|zaryad", "tejash|tez bit|saqlash|uzoq|qanday"),
            e("Kuchli parol: kamida 12 belgi, so‘zlar aralashmasi (masalan, 4 ta tasodifiy so‘z), har saytga alohida parol; imkon bo‘lsa, parol menejeri va ikki bosqichli tasdiqlashdan foydalaning.", "parol", "kuchli|qanday|xavfsiz|yaxshi"),
            e("Telefon sekin ishlasa: qayta yoqing, keraksiz ilova va fayllarni o‘chiring, keshni tozalang, tizim va ilovalarni yangilang, xotira to‘la bo‘lmasin.", "telefon", "sekin|qotib|osilib|qotyap|tez bo"),

            // --- haqiqiy vaqtli ma’lumotlar (internetsiz mumkin emas)
            e("Valyuta kurslarini internetsiz bilolmayman — aniq kurs uchun bank ilovasi yoki Markaziy bank saytiga qarang.", "kurs", "dollar|valyuta|yevro|rubl|som"),
            e("Ob-havoni internetsiz bilolmayman — telefondagi ob-havo ilovasiga qarang.", "ob-havo|obhavo|ob havo|havo harorati|havo rayon"),

            // --- qiziqarli
            e("Katta yo‘l birinchi qadamdan boshlanadi. Bugun bitta kichik qadam qo‘y 🙂###Mukammallikni kutma — boshla, mukammallik yo‘lda keladi.###Yiqilish mag‘lubiyat emas; yiqilib turmaslik — mag‘lubiyat.###Bugun qilgan kichik ish — ertangi katta natijaning poydevori.###Har kuni 1% yaxshilansang, bir yilda o‘zingni tanimay qolasan.",
                "motivatsiya|ruhlan|ilhomlan|iqtibos|ruhimni ko'tar"),
            e("Mehnatning tagi — rohat.###Sabr tagi — sariq oltin.###Ona yurt — oltin beshik.###Ko‘p yashagan emas, ko‘p ko‘rgan biladi.###Birlashgan o‘zar, birlashmagan to‘zar.###Yaxshi so‘z — jon ozig‘i.",
                "maqol"),
            e("To‘g‘ri saqlansa, asal deyarli buzilmaydi.###Venerada bir kun (o‘z o‘qi atrofida to‘liq aylanish) uning bir yilidan uzoqroq davom etadi.###Ahtapotning uchta yuragi bor.###Yer yuzining taxminan 71 foizini suv egallaydi.###Mushuklar kunning ko‘p qismini — 12–16 soatni — uxlab o‘tkazadi.###«Algoritm» so‘zi buyuk bobokalonimiz al-Xorazmiy ismidan kelib chiqqan.###Banan botanik jihatdan rezavor mevalar turkumiga kiradi.",
                "fakt|qiziq narsa|qiziqarli|bilasanmi|bilasizmi"),

            // --- Zeno haqida
            e("Mening yoshim yo‘q — dasturman 🙂 Lekin sizni tinglashga doim tayyorman.", "yoshing|yoshingiz", "necha|nechchi|qancha"),
            e("Meni shu ilovani yaratgan inson yozgan. Men telefoningizdagi virtual do‘stman: maqsad, xotira, mashq natijalari va hisob-kitobda yordam beraman.", "seni kim|kim yaratgan|kim yozgan|kim tuzgan|yaratuvchi"),
            e("Rahmat, juda iliq so‘z 🙂 Men dastur bo‘lsam ham, sizga yordam berishdan xursandman.", "seni yaxshi ko'raman|seni sevaman|sevaman seni"),
            e("Sevimli rangim — yashil 😄 (ilovam ikonkasidagi nuqta ham shunday). Sizniki-chi?", "sevimli", "rang")
        )
    }
}
