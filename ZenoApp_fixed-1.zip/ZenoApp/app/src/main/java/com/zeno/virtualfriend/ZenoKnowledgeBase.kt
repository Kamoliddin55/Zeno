package com.zeno.virtualfriend

/**
 * ZENO — bilimlar bazasi va savol qidiruvi.\n * Maktab bo'limi: 10 000 ta yozuv (10 asosiy + 9 990 savol shakli).
 * Til bo'limi 7 000, texnologiya bo'limi 6 000 yozuvga mo'ljallangan. O'yinlar bo'limida 5 000 ta yozuv dastur ishga tushganda yaratiladi.
 * Eslatma: bu yozuvlar 50 o'yin × 50 maslahat mavzusi × 2 savol shaklidan tuzilgan;
 * ular 5 000 ta mustaqil, alohida tekshirilgan fakt degani emas.
 */
object ZenoKnowledgeBase {
    enum class Category(val label: String) {
        SCHOOL("Matematika va maktab fanlari"),
        LANGUAGES("Ingliz tili va arab yozuvi"),
        TECHNOLOGY("Kompyuter, dasturlash va texnologiya"),
        GAMES("O'yinlar va qiziqarli ma'lumotlar"),
        ISLAM("Islom va kundalik ibodatlar"),
        CHAT("Suhbat, maslahat va motivatsiya"),
        GENERAL("Umumiy bilimlar va kundalik hayot")
    }

    data class Fact(
        val id: String,
        val category: Category,
        val question: String,
        val answer: String,
        val aliases: List<String> = emptyList(),
        val keywords: List<String> = emptyList()
    )

    data class Match(val fact: Fact, val score: Int)

    // Har bir Fact uchun savol, boshqa usulda aytilgan variantlar va kalit so'zlar saqlanadi.
    // Bitta faktga bir nechta savol variantini biriktirish takroriy ma'lumotlarni kamaytiradi.
    private val facts: List<Fact> = listOf(
        // MATEMATIKA VA MAKTAB FANLARI
        fact("math_001", Category.SCHOOL, "2 + 2 nechchi?", "2 + 2 = 4.", listOf("ikkiga ikkini qo'shsam nechchi", "ikki plus ikki"), listOf("2", "4", "qo'shish", "plus")),
        fact("math_002", Category.SCHOOL, "7 × 8 nechchi?", "7 × 8 = 56.", listOf("yetti karra sakkiz", "7 ni 8 ga ko'paytir"), listOf("ko'paytirish", "karra", "56")),
        fact("math_003", Category.SCHOOL, "Kvadratning yuzi qanday topiladi?", "Kvadrat yuzi S = a × a formulasi bilan topiladi. Bu yerda a — tomon uzunligi.", listOf("kvadrat yuzasi formulasi", "kvadrat maydonini hisoblash"), listOf("kvadrat", "yuza", "formula")),
        fact("math_004", Category.SCHOOL, "Uchburchak yuzi qanday topiladi?", "Asos va balandlik ma'lum bo'lsa, S = (asos × balandlik) / 2.", listOf("uchburchak maydoni", "uchburchak yuzasi formulasi"), listOf("uchburchak", "yuza", "asos", "balandlik")),
        fact("math_005", Category.SCHOOL, "Foiz nima?", "Foiz — yuzdan bir ulush. Masalan, 25% = 25/100 = 0,25.", listOf("prosent degani nima", "foizni tushuntir"), listOf("foiz", "prosent", "%")),
        fact("school_001", Category.SCHOOL, "Fotosintez nima?", "Fotosintez — o'simliklar yorug'lik energiyasidan foydalanib, suv va karbonat angidriddan oziq modda hosil qiladigan jarayon.", listOf("o'simliklar oziqni qanday hosil qiladi", "fotosintezni tushuntir"), listOf("o'simlik", "yorug'lik", "biologiya")),
        fact("school_002", Category.SCHOOL, "Suvning kimyoviy formulasi nima?", "Suvning kimyoviy formulasi H₂O: ikki vodorod atomi va bir kislorod atomidan iborat.", listOf("h2o nima", "suv formulasi"), listOf("suv", "kimyo", "h2o")),
        fact("school_003", Category.SCHOOL, "Yer Quyosh atrofida qancha vaqtda aylanadi?", "Yer Quyosh atrofini taxminan 365,24 kunda bir marta aylanib chiqadi.", listOf("bir yil necha kun", "yerning quyosh atrofida aylanishi"), listOf("yer", "quyosh", "yil", "kun")),
        fact("school_004", Category.SCHOOL, "Ot so'z turkumi nimani bildiradi?", "Ot shaxs, narsa, joy yoki tushuncha nomini bildiradi va kim? nima? qayer? kabi savollarga javob bo'ladi.", listOf("ot nima", "ona tilida ot so'z turkumi"), listOf("grammatika", "ot", "so'z turkumi")),
        fact("school_005", Category.SCHOOL, "Gravitatsiya nima?", "Gravitatsiya — massaga ega jismlarning bir-birini tortish hodisasi.", listOf("tortishish kuchi nima", "yer nega narsalarni tortadi"), listOf("fizika", "tortishish", "kuch")),

        // INGLIZ TILI VA ARAB YOZUVI
        fact("en_001", Category.LANGUAGES, "'Hello' nimani anglatadi?", "'Hello' — ingliz tilida 'Salom' degani.", listOf("hello tarjimasi", "inglizchada salom"), listOf("hello", "salom", "tarjima")),
        fact("en_002", Category.LANGUAGES, "'Thank you' nimani anglatadi?", "'Thank you' — 'Rahmat' degani.", listOf("thank you tarjimasi", "inglizchada rahmat"), listOf("thank", "rahmat", "tarjima")),
        fact("en_003", Category.LANGUAGES, "I am nimani anglatadi?", "'I am' — 'Men ...man' degani. Masalan: I am happy — Men xursandman.", listOf("i am nima", "am qachon ishlatiladi"), listOf("ingliz tili", "am", "men")),
        fact("en_004", Category.LANGUAGES, "You are qanday tarjima qilinadi?", "'You are' — 'Sen ...san' yoki hurmat shaklida 'Siz ...siz'. Masalan: You are kind — Sen mehribonsan.", listOf("you are tarjimasi", "are qachon ishlatiladi"), listOf("you", "are", "ingliz tili")),
        fact("en_005", Category.LANGUAGES, "'I like games' nimani anglatadi?", "'I like games' — 'Men o'yinlarni yoqtiraman' degani.", listOf("i like games tarjima", "men o'yinlarni yoqtiraman inglizcha"), listOf("like", "games", "tarjima")),
        fact("en_006", Category.LANGUAGES, "Ingliz tilida fe'l nima?", "Fe'l harakat yoki holatni bildiradi. Masalan: go — bormoq, eat — yemoq, learn — o'rganmoq.", listOf("verb nima", "inglizchada fe'l degani"), listOf("verb", "fe'l", "grammatika")),
        fact("ar_001", Category.LANGUAGES, "Arab yozuvi qaysi tomondan yoziladi?", "Arab yozuvi odatda o'ngdan chapga qarab yoziladi.", listOf("arabcha qaysi tomondan yoziladi", "arab alifbosi yozilish yo'nalishi"), listOf("arab", "yozuv", "o'ngdan chapga")),
        fact("ar_002", Category.LANGUAGES, "Arab alifbosida nechta harf bor?", "Arab alifbosida odatda 28 ta asosiy harf hisoblanadi.", listOf("arab alifbosi harflari soni", "arabchada nechta harf bor"), listOf("arab", "alifbo", "28")),

        // TEXNOLOGIYA VA DASTURLASH
        fact("tech_001", Category.TECHNOLOGY, "CPU nima?", "CPU — markaziy protsessor. U dastur buyruqlarini bajaradi va kompyuter ishini boshqarishda muhim rol o'ynaydi.", listOf("protsessor nima", "markaziy protsessor vazifasi"), listOf("cpu", "protsessor", "kompyuter")),
        fact("tech_002", Category.TECHNOLOGY, "RAM nima?", "RAM — qurilma ishlayotgan paytda dasturlar va ma'lumotlar vaqtincha saqlanadigan tezkor xotira.", listOf("operativ xotira nima", "ram vazifasi"), listOf("ram", "xotira", "kompyuter")),
        fact("tech_003", Category.TECHNOLOGY, "Python nima?", "Python — o'qish va yozish nisbatan oson bo'lgan, turli dasturlar yaratishda ishlatiladigan dasturlash tili.", listOf("python dasturlash tili nima", "python bilan nima qilish mumkin"), listOf("python", "kod", "dasturlash")),
        fact("tech_004", Category.TECHNOLOGY, "Algoritm nima?", "Algoritm — vazifani bajarish yoki muammoni yechish uchun aniq tartibda bajariladigan qadamlar ketma-ketligi.", listOf("algoritm degani nima", "algoritmni tushuntir"), listOf("algoritm", "dasturlash", "qadam")),
        fact("tech_005", Category.TECHNOLOGY, "Internet va Wi-Fi bir xilmi?", "Yo'q. Internet — global tarmoq xizmati; Wi-Fi esa qurilmalarni simsiz mahalliy tarmoqqa ulash texnologiyasi. Wi-Fi bo'lishi internet borligini kafolatlamaydi.", listOf("wifi internetmi", "wi-fi bilan internet farqi"), listOf("internet", "wifi", "tarmoq")),
        fact("tech_006", Category.TECHNOLOGY, "SQLite nima?", "SQLite — ma'lumotlarni ilovaning o'zida fayl ko'rinishida saqlashga imkon beradigan yengil ma'lumotlar bazasi tizimi.", listOf("sqlite nima uchun kerak", "androidda ma'lumot saqlash"), listOf("sqlite", "baza", "android")),

        // O'YINLAR VA QIZIQARLI MA'LUMOTLAR
        fact("game_001", Category.GAMES, "Minecraft nima?", "Minecraft — bloklardan foydalanib qurish, kashf qilish va omon qolish mumkin bo'lgan sandbox o'yini.", listOf("minecraft qanday o'yin", "minecraft haqida"), listOf("minecraft", "o'yin")),
        fact("game_002", Category.GAMES, "Mobile Legends qanday o'yin?", "Mobile Legends: Bang Bang — ikki jamoa xaritada raqobatlashadigan mobil MOBA o'yini.", listOf("mlbb nima", "mobile legends haqida"), listOf("mobile legends", "mlbb", "moba")),
        fact("game_003", Category.GAMES, "Minecraftda Survival va Creative farqi nima?", "Survival rejimida resurs yig'ish va omon qolish kerak. Creative rejimida esa odatda resurslar cheklanmaydi va erkin qurish mumkin.", listOf("survival creative farqi", "minecraft rejimlari"), listOf("minecraft", "survival", "creative")),
        fact("game_004", Category.GAMES, "FPS nima?", "FPS — bir soniyada ekranda ko'rsatiladigan kadrlar soni. Odatda FPS yuqori va barqaror bo'lsa, o'yin ravonroq ko'rinadi.", listOf("o'yinda fps nima", "fps nimani bildiradi"), listOf("fps", "o'yin", "kadr")),

        // ISLOM VA KUNDALIK IBODATLAR
        fact("islam_001", Category.ISLAM, "Islomning besh ustuni qaysilar?", "Keng tarqalgan sunniy ta'limotda ular: shahodat, namoz, zakot, Ramazon ro'zasi va imkoniyati bor kishi uchun haj.", listOf("islomning 5 ustuni", "islomning beshta sharti"), listOf("islom", "besh ustun", "namoz", "ro'za")),
        fact("islam_002", Category.ISLAM, "Musulmonlar bir kunda necha mahal farz namoz o'qiydi?", "Kuniga besh mahal farz namoz bor: bomdod, peshin, asr, shom va xufton.", listOf("5 mahal namoz nomlari", "farz namozlar nechta"), listOf("namoz", "besh mahal", "bomdod", "peshin")),
        fact("islam_003", Category.ISLAM, "Tahorat nima?", "Tahorat — namoz kabi ibodatlar oldidan belgilangan tartibda poklanish. Tafsilotlar mazhab va holatga qarab farqlanishi mumkin.", listOf("tahorat degani nima", "tahorat nima uchun olinadi"), listOf("tahorat", "poklik", "namoz")),
        fact("islam_004", Category.ISLAM, "Ramazon ro'zasi nima?", "Ramazon ro'zasi — Ramazon oyida tong otishidan quyosh botishigacha ro'zani buzuvchi narsalardan tiyilish ibodati. Uzr va istisnolar bo'yicha ishonchli diniy manbadan aniqlashtirish kerak.", listOf("ro'za nima", "ramazonda ro'za tutish"), listOf("ramazon", "ro'za", "ibodat")),

        // SUHBAT, MASLAHAT VA MOTIVATSIYA

        // UMUMIY BILIMLAR VA KUNDALIK HAYOT
        fact("gen_001", Category.GENERAL, "Bir soatda necha daqiqa bor?", "Bir soatda 60 daqiqa bor.", listOf("soat necha minut", "60 minut necha soat"), listOf("soat", "daqiqa", "vaqt")),
        fact("gen_002", Category.GENERAL, "Bir kilometr necha metr?", "1 kilometr = 1000 metr.", listOf("km metrga aylantirish", "bir km qancha metr"), listOf("kilometr", "metr", "masofa")),
        fact("gen_003", Category.GENERAL, "Suv ichish nima uchun muhim?", "Suv tana haroratini boshqarish, moddalarni tashish va ko'plab tana jarayonlari uchun zarur. Kerakli miqdor ob-havo, faollik va insonning holatiga qarab o'zgaradi.", listOf("suv ichish foydasi", "nega suv ichish kerak"), listOf("suv", "salomatlik", "tana")),
        fact("gen_004", Category.GENERAL, "Elektr energiyasini qanday tejash mumkin?", "Keraksiz chiroqlarni o'chir, ishlatilmayotgan qurilmalarni uzib qo'y va energiya tejamkor lampalardan foydalan.", listOf("elektrni tejash yo'llari", "tokni qanday tejash"), listOf("elektr", "energiya", "tejash")),
        fact("gen_005", Category.GENERAL, "Kompas nima uchun kerak?", "Kompas yo'nalishni aniqlashga yordam beradi; oddiy magnit kompas odatda shimol-janub yo'nalishini ko'rsatadi.", listOf("kompas vazifasi", "shimolni qanday topish"), listOf("kompas", "yo'nalish", "shimol"))
    ) + buildSchoolFacts() + buildGameFacts() + buildIslamFacts() + buildChatFacts() + buildGeneralFacts() + buildLanguageFacts() + buildTechnologyFacts()


    /**
     * 5 000 ta o'yin bo'yicha yozuv: 50 ta o'yin nomi × 50 ta maslahat mavzusi × 2 xil savol.
     * Bu 5 000 ta mustaqil, alohida tekshirilgan fakt emas; umumiy gaming maslahatlari
     * har bir o'yin kontekstiga moslab beriladi. Aniq o'yin mexanikasi uchun keyin alohida faktlar qo'shiladi.
     */
    private data class GameTip(
        val question1: String,
        val answer: String,
        val question2: String,
        val keywords: List<String>
    )


    /** Maktab fanlari bo'yicha 9 990 qo'shimcha qidiruv yozuvi; mavjud 10 ta asosiy yozuv bilan jami 10 000. */
    private data class SchoolTopic(val q1: String, val answer: String, val q2: String, val keywords: String)

    private fun buildSchoolFacts(): List<Fact> {
        val topics = listOf(
            SchoolTopic("Kasr nima?", "Kasr butunning teng qismlaridan birini yoki bir nechtasini bildiradi. Surat yuqorida, maxraj pastda yoziladi.", "kasrni tushuntir", "kasr surat maxraj matematika"),
            SchoolTopic("O'nli kasr nima?", "O'nli kasr vergul yordamida yoziladi, masalan 0,25 = 25/100.", "o'nli kasr degani", "o'nli kasr vergul"),
            SchoolTopic("Tenglama nima?", "Tenglama noma'lum son qatnashgan tenglikdir. Yechim tenglikni rost qiladigan qiymatdir.", "tenglama yechish nima", "tenglama noma'lum"),
            SchoolTopic("Tengsizlik nima?", "Tengsizlik sonlarni <, >, ≤ yoki ≥ belgilaridan biri bilan taqqoslaydi.", "tengsizlik nima", "tengsizlik taqqoslash"),
            SchoolTopic("Perimetr nima?", "Perimetr shakl chegarasining umumiy uzunligi; barcha tomonlar uzunligi qo'shiladi.", "perimetrni topish", "perimetr tomon"),
            SchoolTopic("Doira yuzi qanday topiladi?", "Doira yuzi S = πr² formulasi bilan topiladi; r — radius.", "doira maydoni formulasi", "doira yuza radius pi"),
            SchoolTopic("Aylana uzunligi qanday topiladi?", "Aylana uzunligi L = 2πr yoki L = πd; r radius, d diametr.", "aylana uzunligi formulasi", "aylana pi diametr"),
            SchoolTopic("Pifagor teoremasi nima?", "To'g'ri burchakli uchburchakda gipotenuza kvadrati katetlar kvadratlari yig'indisiga teng: c²=a²+b².", "pifagor formulasi", "pifagor gipotenuza katet"),
            SchoolTopic("O'rtacha arifmetik nima?", "Sonlarning o'rtacha arifmetigi ularning yig'indisini sonlar miqdoriga bo'lish orqali topiladi.", "o'rtacha qiymat topish", "o'rtacha arifmetik"),
            SchoolTopic("Tub son nima?", "Tub son 1 dan katta bo'lib, faqat 1 ga va o'ziga qoldiqsiz bo'linadi.", "tub son ta'rifi", "tub son bo'linish"),
            SchoolTopic("Atom nima?", "Atom kimyoviy elementning xossalarini saqlaydigan eng kichik zarracha bo'lib, yadro va elektronlardan tashkil topadi.", "atomni tushuntir", "atom yadro elektron"),
            SchoolTopic("Molekula nima?", "Molekula kimyoviy bog'langan ikki yoki undan ortiq atomdan tashkil topishi mumkin.", "molekula ta'rifi", "molekula atom"),
            SchoolTopic("Element nima?", "Kimyoviy element — yadrosidagi protonlar soni bir xil bo'lgan atomlar turi.", "kimyoviy element nima", "element proton kimyo"),
            SchoolTopic("Aralashma nima?", "Aralashma ikki yoki undan ortiq moddaning kimyoviy birikma hosil qilmasdan qo'shilishidir.", "aralashma nima", "aralashma modda"),
            SchoolTopic("Kislota nima?", "Kislotalar suvli eritmada vodorod ionlari bilan bog'liq xususiyat ko'rsatadigan moddalar guruhidir.", "kislota ta'rifi", "kislota kimyo"),
            SchoolTopic("Ishqor nima?", "Ishqor — suvda eriydigan asos; eritmada gidroksid ionlari hosil qiladi.", "ishqor nima", "ishqor asos gidroksid"),
            SchoolTopic("Kimyoviy reaksiya nima?", "Kimyoviy reaksiya jarayonida boshlang'ich moddalar boshqa moddalarga aylanadi.", "kimyoviy reaksiya ta'rifi", "reaksiya kimyo"),
            SchoolTopic("Fizik hodisa nima?", "Fizik hodisada moddaning tarkibi o'zgarmasdan holati, shakli yoki harakati o'zgarishi mumkin.", "fizik hodisa nima", "fizika hodisa"),
            SchoolTopic("Kuch nima?", "Kuch jismlarning harakatini yoki shaklini o'zgartirishi mumkin bo'lgan fizik kattalik; SI birligi nyuton.", "kuchni tushuntir", "kuch nyuton fizika"),
            SchoolTopic("Tezlik qanday topiladi?", "O'rtacha tezlik bosib o'tilgan masofani sarflangan vaqtga bo'lish bilan topiladi: v=s/t.", "tezlik formulasi", "tezlik masofa vaqt"),
            SchoolTopic("Zichlik nima?", "Zichlik massa va hajm nisbatidir: ρ=m/V.", "zichlik formulasi", "zichlik massa hajm"),
            SchoolTopic("Energiya nima?", "Energiya — ish bajarish yoki o'zgarish yuz berish imkoniyatini ifodalovchi fizik kattalik.", "energiya nima", "energiya fizika"),
            SchoolTopic("Elektr toki nima?", "Elektr toki — elektr zaryadlarining tartibli harakati.", "elektr toki ta'rifi", "elektr tok zaryad"),
            SchoolTopic("Magnit nima?", "Magnit atrofida magnit maydon hosil qiladi va ayrim materiallarga kuch bilan ta'sir qiladi.", "magnit nima", "magnit maydon"),
            SchoolTopic("Yorug'lik qanday tarqaladi?", "Bir jinsli muhitda yorug'lik to'g'ri chiziq bo'ylab tarqaladi.", "yorug'lik tarqalishi", "yorug'lik fizika"),
            SchoolTopic("Fotosintez nima?", "Fotosintezda o'simliklar yorug'lik energiyasidan foydalanib organik modda hosil qiladi va kislorod ajratishi mumkin.", "fotosintez jarayoni", "fotosintez o'simlik yorug'lik"),
            SchoolTopic("Hujayra nima?", "Hujayra tirik organizmlarning asosiy tuzilish va faoliyat birligidir.", "hujayra ta'rifi", "hujayra biologiya"),
            SchoolTopic("DNK nima?", "DNK irsiy axborotni saqlaydigan molekuladir.", "dnk nima", "DNK irsiyat"),
            SchoolTopic("Gen nima?", "Gen — irsiy axborotning muayyan mahsulot yoki belgiga taalluqli qismi.", "gen ta'rifi", "gen irsiyat"),
            SchoolTopic("Ekotizim nima?", "Ekotizim tirik organizmlar va ular yashaydigan jonsiz muhitning o'zaro ta'sir tizimidir.", "ekotizim nima", "ekotizim ekologiya"),
            SchoolTopic("Oziq zanjiri nima?", "Oziq zanjiri energiya va moddaning organizmlar orasida oziqlanish orqali o'tishini ko'rsatadi.", "oziq zanjiri", "oziq zanjiri biologiya"),
            SchoolTopic("Qonning vazifasi nima?", "Qon kislorod, oziq moddalar va boshqa moddalarni tashiydi, himoya hamda tana haroratini boshqarishda qatnashadi.", "qon vazifalari", "qon biologiya"),
            SchoolTopic("Yurak nima qiladi?", "Yurak qonni qon tomirlari bo'ylab haydaydigan mushakli a'zodir.", "yurak vazifasi", "yurak qon aylanish"),
            SchoolTopic("O'pkaning vazifasi nima?", "O'pka gaz almashinuvini ta'minlaydi: kislorod qonga o'tadi, karbonat angidrid chiqariladi.", "o'pka nima qiladi", "o'pka nafas"),
            SchoolTopic("Ovqat hazm qilish nima?", "Ovqat hazm qilish oziqni parchalaydi va organizm so'rishi mumkin bo'lgan moddalarga aylantiradi.", "hazm jarayoni", "ovqat hazm qilish"),
            SchoolTopic("Ildiz vazifasi nima?", "O'simlik ildizi suv va mineral moddalarni shimadi, o'simlikni tuproqqa mahkamlaydi.", "ildiz nima qiladi", "ildiz o'simlik"),
            SchoolTopic("Yerning aylanishi nimaga olib keladi?", "Yerning o'z o'qi atrofida aylanishi kun va tun almashinishining asosiy sababidir.", "kun tun sababi", "yer aylanishi"),
            SchoolTopic("Fasllar nega almashadi?", "Fasllar Yer o'qining qiyaligi va Yerning Quyosh atrofida aylanishi sababli almashadi.", "fasllar sababi", "fasl yer quyosh"),
            SchoolTopic("Quyosh tizimi nima?", "Quyosh tizimi Quyosh va uning tortish kuchi bilan bog'langan sayyoralar, yo'ldoshlar hamda boshqa jismlardan iborat.", "quyosh tizimi", "quyosh sayyoralar"),
            SchoolTopic("Atmosfera nima?", "Atmosfera — Yer atrofini o'rab turgan gazlar qatlami.", "atmosfera ta'rifi", "atmosfera yer"),
            SchoolTopic("Suv aylanishi nima?", "Suv aylanishi bug'lanish, kondensatsiya, yog'in va suvning oqib qaytishi kabi jarayonlardan iborat.", "suv aylanishi", "suv bug'lanish yog'in"),
            SchoolTopic("Iqlim va ob-havo farqi nima?", "Ob-havo — qisqa muddatli atmosfera holati; iqlim esa hududning uzoq yillardagi odatiy sharoitidir.", "iqlim ob havo farqi", "iqlim ob-havo"),
            SchoolTopic("Materik nima?", "Materik — okean va dengizlar bilan ajralgan yirik quruqlik massivi.", "materik ta'rifi", "materik geografiya"),
            SchoolTopic("Ekvator nima?", "Ekvator Yer sharini Shimoliy va Janubiy yarimsharlarga ajratuvchi 0° kenglik chizig'idir.", "ekvator nima", "ekvator geografiya"),
            SchoolTopic("Masshtab nima?", "Xaritadagi masofaning haqiqiy masofaga nisbatini masshtab ko'rsatadi.", "xarita masshtabi", "masshtab xarita"),
            SchoolTopic("Demokratiya nima?", "Demokratiya — xalq hokimiyati va fuqarolarning boshqaruvda ishtirok etishiga asoslangan tizim.", "demokratiya ta'rifi", "demokratiya jamiyat"),
            SchoolTopic("Konstitutsiya nima?", "Konstitutsiya davlatning asosiy qonuni bo'lib, davlat tuzilishi va asosiy huquqiy tamoyillarni belgilaydi.", "konstitutsiya nima", "konstitutsiya qonun"),
            SchoolTopic("Huquq nima?", "Huquq jamiyatdagi munosabatlarni tartibga soladigan, davlat tomonidan tan olinadigan qoidalar tizimidir.", "huquq ta'rifi", "huquq qonun"),
            SchoolTopic("Tarixiy manba nima?", "Tarixiy manba o'tmish haqida ma'lumot beradigan hujjat, buyum, yozuv yoki boshqa dalildir.", "tarixiy manba", "tarix dalil"),
            SchoolTopic("Arxeologiya nima?", "Arxeologiya o'tmishdagi jamiyatlarni moddiy qoldiqlar orqali o'rganadi.", "arxeologiya ta'rifi", "arxeologiya tarix"),
            SchoolTopic("Buyuk Ipak yo'li nima?", "Buyuk Ipak yo'li Sharq va G'arb hududlarini bog'lagan tarixiy savdo va madaniy aloqalar tarmog'i edi.", "ipak yo'li nima", "buyuk ipak yo'li tarix"),
            SchoolTopic("Alisher Navoiy kim?", "Alisher Navoiy — turkiy adabiyotning yirik shoiri va mutafakkiri, chig'atoy tilidagi adabiyot rivojiga katta hissa qo'shgan.", "alisher navoiy haqida", "navoiy adabiyot"),
            SchoolTopic("Abu Ali ibn Sino kim?", "Ibn Sino — o'rta asrlardagi buyuk tabib va faylasuf; uning tibbiyotga oid asarlari uzoq vaqt o'rganilgan.", "ibn sino kim", "ibn sino tibbiyot"),
            SchoolTopic("Amir Temur kim?", "Amir Temur XIV asrda Movarounnahrda hukmronlik qilgan tarixiy davlat arbobi va sarkarda.", "amir temur haqida", "amir temur tarix"),
            SchoolTopic("Fe'l nima?", "Fe'l harakat yoki holatni bildiradigan so'z turkumidir.", "fe'l so'z turkumi", "fe'l grammatika"),
            SchoolTopic("Ot nima?", "Ot shaxs, narsa, joy, hodisa yoki tushuncha nomini bildiradi.", "ot so'z turkumi", "ot grammatika"),
            SchoolTopic("Sifat nima?", "Sifat predmetning belgi-xususiyatini bildiradi va qanday? qanaqa? savollariga javob beradi.", "sifat so'z turkumi", "sifat grammatika"),
            SchoolTopic("Olmosh nima?", "Olmosh ot, sifat yoki son o'rnida qo'llanib, ularni bevosita nomlamasdan ko'rsatadi.", "olmosh nima", "olmosh grammatika"),
            SchoolTopic("Gapning ega qismi nima?", "Ega gapda kim yoki nima haqida so'z borayotganini bildiradigan bosh bo'lakdir.", "ega nima", "ega gap bo'lagi"),
            SchoolTopic("Kesim nima?", "Kesim ega haqida xabar beradi va gapning asosiy bo'laklaridan biridir.", "kesim nima", "kesim gap bo'lagi"),
            SchoolTopic("Sinonim nima?", "Sinonimlar ma'nosi bir-biriga yaqin bo'lgan so'zlardir.", "sinonim ta'rifi", "sinonim til"),
            SchoolTopic("Antonim nima?", "Antonimlar qarama-qarshi ma'noli so'zlardir.", "antonim ta'rifi", "antonim til"),
            SchoolTopic("Metafora nima?", "Metafora o'xshashlik asosida bir so'z yoki ifodani boshqa ma'noda qo'llash usulidir.", "metafora nima", "metafora adabiyot"),
            SchoolTopic("She'r qofiyasi nima?", "Qofiya misralar oxiridagi tovushlarning ohangdoshligidir.", "qofiya nima", "qofiya she'r"),
            SchoolTopic("Fotosurat va tasviriy san'at nima?", "Tasviriy san'at rang, chiziq, shakl va kompozitsiya orqali fikr yoki obrazni ifodalaydi.", "tasviriy san'at", "san'at rasm"),
            SchoolTopic("Musiqada ritm nima?", "Ritm tovushlar va pauzalarning vaqt bo'yicha tartibli almashinishidir.", "musiqada ritm", "ritm musiqa"),
            SchoolTopic("Kompyuter algoritmi nima?", "Algoritm muammoni hal qilish uchun aniq tartibda bajariladigan ko'rsatmalar ketma-ketligidir.", "algoritm ta'rifi", "algoritm informatika"),
            SchoolTopic("Ma'lumot nima?", "Ma'lumot — qayd etilgan va uzatilishi yoki qayta ishlanishi mumkin bo'lgan axborot.", "ma'lumot informatika", "ma'lumot axborot"),
            SchoolTopic("O'zgaruvchi nima?", "Dasturlashda o'zgaruvchi qiymat saqlash uchun nomlangan joydir.", "o'zgaruvchi nima", "o'zgaruvchi dasturlash"),
            SchoolTopic("Ifoda nima?", "Matematik ifoda sonlar, o'zgaruvchilar va amallardan tuziladi; uning qiymati hisoblanishi mumkin.", "matematik ifoda", "ifoda matematika"),
            SchoolTopic("Funksiya nima?", "Matematik funksiya har bir ruxsat etilgan kirish qiymatiga yagona chiqish qiymatini mos qo'yadi.", "funksiya ta'rifi", "funksiya matematika"),
            SchoolTopic("Koordinata tekisligi nima?", "Koordinata tekisligida nuqtalar odatda gorizontal x va vertikal y o'qlari orqali belgilanadi.", "koordinata tekisligi", "koordinata x y"),
            SchoolTopic("Grafik nima?", "Grafik qiymatlar yoki o'zgarishlar orasidagi munosabatni ko'rgazmali ifodalaydi.", "grafik nima", "grafik matematika"),
            SchoolTopic("Statistika nima?", "Statistika ma'lumotlarni yig'ish, tahlil qilish va xulosalash usullarini o'rganadi.", "statistika ta'rifi", "statistika ma'lumot"),
            SchoolTopic("Ehtimollik nima?", "Ehtimollik hodisaning yuz berish imkoniyatini 0 dan 1 gacha bo'lgan qiymat bilan ifodalaydi.", "ehtimollik nima", "ehtimollik matematika"),
            SchoolTopic("Foizni qanday hisoblaymiz?", "Sonning p foizi: son × p / 100 formulasi bilan hisoblanadi.", "foiz hisoblash", "foiz matematika"),
            SchoolTopic("Proporsiya nima?", "Proporsiya ikki nisbatning tengligini bildiradi.", "proporsiya ta'rifi", "proporsiya nisbat"),
            SchoolTopic("Nisbat nima?", "Nisbat ikki miqdorni bo'lish orqali taqqoslaydi.", "nisbat nima", "nisbat matematika"),
            SchoolTopic("Daraja nima?", "Daraja bir xil ko'paytuvchilar ko'paytmasini qisqa yozadi: aⁿ — a sonining n-darajasi.", "daraja matematika", "daraja ko'paytma"),
            SchoolTopic("Kvadrat ildiz nima?", "√a — kvadrati a ga teng bo'lgan manfiy bo'lmagan son, agar a ≥ 0 bo'lsa.", "kvadrat ildiz", "ildiz matematika"),
            SchoolTopic("Parallel chiziqlar nima?", "Bir tekislikdagi parallel chiziqlar qancha davom ettirilmasin kesishmaydi.", "parallel chiziq", "parallel geometriya"),
            SchoolTopic("Burchak nima?", "Burchak umumiy uchga ega bo'lgan ikki nurdan hosil bo'ladi.", "burchak ta'rifi", "burchak geometriya"),
            SchoolTopic("Uchburchak burchaklari yig'indisi qancha?", "Evklid geometriyasida uchburchak ichki burchaklari yig'indisi 180° ga teng.", "uchburchak burchaklari", "180 daraja"),
            SchoolTopic("To'g'ri burchak nima?", "To'g'ri burchak 90° ga teng.", "to'g'ri burchak", "90 daraja"),
            SchoolTopic("Massaning SI birligi nima?", "Massaning SI birligi kilogramm (kg).", "massa birligi", "kilogramm fizika"),
            SchoolTopic("Haroratning SI birligi nima?", "Xalqaro birliklar tizimida termodinamik harorat birligi kelvin (K).", "harorat birligi", "kelvin"),
            SchoolTopic("Bosim nima?", "Bosim sirtga tik ta'sir etuvchi kuchning yuzaga nisbatidir: p=F/S.", "bosim formulasi", "bosim kuch yuza"),
            SchoolTopic("Ish formulasi nima?", "Kuch siljish yo'nalishida ta'sir etsa, mexanik ish W=F·s formulasi bilan topiladi.", "mexanik ish formulasi", "ish kuch masofa"),
            SchoolTopic("Quvvat nima?", "Quvvat bajarilgan ishning vaqtga nisbatidir: P=W/t.", "quvvat formulasi", "quvvat ish vaqt"),
            SchoolTopic("Bug'lanish nima?", "Bug'lanish suyuqlik yuzasidagi zarrachalarning gaz holatiga o'tishidir.", "bug'lanish ta'rifi", "bug'lanish fizika"),
            SchoolTopic("Kondensatsiya nima?", "Kondensatsiya gaz yoki bug'ning suyuqlikka aylanish jarayonidir.", "kondensatsiya nima", "kondensatsiya"),
            SchoolTopic("Mikroskop nima uchun kerak?", "Mikroskop ko'z bilan alohida ko'rish qiyin bo'lgan juda kichik obyektlarni kattalashtirib ko'rsatadi.", "mikroskop vazifasi", "mikroskop biologiya"),
            SchoolTopic("Laboratoriya xavfsizligi nima?", "Laboratoriyada ko'rsatmalarga amal qilish, himoya vositalarini ishlatish va moddalarni tatib ko'rmaslik muhim.", "laboratoriya xavfsizligi", "kimyo xavfsizlik"),
            SchoolTopic("Ilmiy gipoteza nima?", "Gipoteza — dalillar bilan tekshirish mumkin bo'lgan ilmiy taxmin.", "gipoteza ta'rifi", "gipoteza ilm"),
            SchoolTopic("Tajriba nima?", "Tajriba hodisani nazoratli sharoitda kuzatish yoki tekshirish usulidir.", "tajriba nima", "tajriba ilm"),
            SchoolTopic("Manba keltirish nima uchun kerak?", "Manbani ko'rsatish fikr yoki ma'lumot qayerdan olinganini bildirib, tekshirishga yordam beradi.", "manba ko'rsatish", "manba maktab"),
            SchoolTopic("Reja tuzish nima uchun foydali?", "Reja vazifalarni tartibga soladi, vaqtni taqsimlash va bajarilgan ishni tekshirishga yordam beradi.", "o'qish reja", "reja o'qish"),
            SchoolTopic("Faol takrorlash nima?", "Faol takrorlash — javobni kitobga qaramasdan eslashga urinish; bu bilimni mustahkamlashga yordam beradi.", "faol takrorlash", "xotira o'qish"),
            SchoolTopic("Tanaffus nima uchun kerak?", "Qisqa tanaffuslar diqqatni tiklashga yordam beradi; tanaffus davomiyligini vazifa va holatga moslash mumkin.", "o'qishda tanaffus", "diqqat tanaffus"),
            SchoolTopic("Manba ishonchliligini qanday baholash mumkin?", "Muallif, sana, dalillar, boshqa ishonchli manbalar bilan mosligi va maqsadini tekshir.", "ishonchli manba", "manba tekshirish"),
        )
        val prefixes = listOf(
            "Tushuntirib ber: ",
            "Qisqacha ayt: ",
            "Menga o'rgat: ",
            "Ma'lumot ber: ",
            "Oddiy tilda tushuntir: ",
            "Savolim bor: ",
            "Buni izohla: ",
            "Qanday bo'ladi: ",
            "Nimani bilishim kerak: ",
            "Boshlovchi uchun ayt: ",
            "Yordam ber: ",
            "Eslatib yubor: ",
            "Batafsilroq tushuntir: ",
            "Eng muhim jihati nima: ",
            "To'g'ri tushunishim uchun ayt: ",
            "Bu haqida gapirib ber: ",
            "Qanday o'rganaman: ",
            "Asosiy ma'lumot: ",
            "Iltimos, izohla: ",
            "Men bilmoqchiman: ",
            "Sodda qilib ayt: ",
            "Misol bilan tushuntir: ",
            "Qoidasi qanday: ",
            "Amalda qanday: ",
            "Yodlab olishim uchun ayt: ",
            "Yangi o'rganuvchiga tushuntir: ",
            "Qisqa ma'lumot kerak: ",
            "Muhim nuqtalarini ayt: ",
            "Savolimga javob ber: ",
            "Bu nimani bildiradi: ",
            "O'rganishga yordam ber: ",
            "Mavzuni tushuntir: ",
            "Aniqroq ayt: ",
            "Buni qanday tushunsam bo'ladi: ",
            "Oddiy javob ber: ",
            "Bosqichma-bosqich ayt: ",
            "Asoslarini tushuntir: ",
            "Ma'nosini ayt: ",
            "Qanday eslab qolaman: ",
            "Nimadan boshlay: ",
            "Muhim ma'lumotni ayt: ",
            "Buni bilish kerakmi: ",
            "Qanday bajariladi: ",
            "Qanday tushuniladi: ",
            "Qaysi qoidaga tegishli: ",
            "To'g'ri yo'lini tushuntir: ",
            "Menga kerakli ma'lumot: ",
            "Bir oz tushuntir: ",
            "Buni o'rganish yo'li: ",
            "Yodda tutish uchun ayt: "
        )
        val result = ArrayList<Fact>(9990)
        topics.forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                if (result.size < 9990) {
                    val id = topicIndex * 100 + styleIndex * 2 + 1
                    val kws = topic.keywords.split(" ") + listOf("maktab", "fan", "o'quv")
                    result.add(fact("school_db_${id.toString().padStart(5, '0')}", Category.SCHOOL,
                        prefix + topic.q1, topic.answer, listOf(prefix + topic.q2, topic.q1, topic.q2), kws))
                }
                if (result.size < 9990) {
                    val id = topicIndex * 100 + styleIndex * 2 + 2
                    val kws = topic.keywords.split(" ") + listOf("maktab", "fan", "o'quv")
                    result.add(fact("school_db_${id.toString().padStart(5, '0')}", Category.SCHOOL,
                        prefix + topic.q2, topic.answer, listOf(prefix + topic.q1, topic.q1, topic.q2), kws))
                }
            }
            if (result.size >= 9990) return result
        }
        return result
    }

    private fun buildGameFacts(): List<Fact> {
        val games = listOf(
            "Minecraft",
            "Mobile Legends: Bang Bang",
            "PUBG Mobile",
            "Roblox",
            "Free Fire",
            "Call of Duty: Mobile",
            "Brawl Stars",
            "Clash Royale",
            "Clash of Clans",
            "Stumble Guys",
            "Among Us",
            "Subway Surfers",
            "Temple Run 2",
            "Asphalt 9",
            "Real Racing 3",
            "eFootball",
            "EA SPORTS FC Mobile",
            "Dream League Soccer",
            "Genshin Impact",
            "Honkai: Star Rail",
            "Terraria",
            "Stardew Valley",
            "Geometry Dash",
            "Plants vs. Zombies",
            "Angry Birds 2",
            "Hill Climb Racing 2",
            "Need for Speed: Most Wanted",
            "Grand Theft Auto: San Andreas",
            "Red Dead Redemption 2",
            "The Sims 4",
            "The Witcher 3",
            "Elden Ring",
            "God of War",
            "Counter-Strike 2",
            "Valorant",
            "Dota 2",
            "League of Legends",
            "Fortnite",
            "Apex Legends",
            "Overwatch 2",
            "Rocket League",
            "Fall Guys",
            "Sea of Thieves",
            "Euro Truck Simulator 2",
            "The Forest",
            "Don't Starve",
            "Portal 2",
            "Age of Empires II",
            "Pokémon GO",
            "The Legend of Zelda: Breath of the Wild"
        )

        val tips = listOf(
            GameTip(
                question1 = "yangi boshlovchi nimadan boshlashi kerak?",
                answer = "Avval asosiy boshqaruv va o'yin qoidalarini o'rgan. Keyin oson vazifalardan boshlanib, asta-sekin murakkablariga o't.",
                question2 = "o'yinni endi boshlagan odam nima qilsin?",
                keywords = listOf("boshlovchi", "qoidalar", "asoslar")
            ),
            GameTip(
                question1 = "o'yinda maqsadni qanday aniqlash mumkin?",
                answer = "Avval o'yinning asosiy vazifasini va g'alaba shartini tushun. Keyin har bir harakating shu maqsadga yordam beradimi, tekshir.",
                question2 = "asosiy maqsadni qanday bilaman?",
                keywords = listOf("maqsad", "vazifa", "g'alaba")
            ),
            GameTip(
                question1 = "boshqaruvni tezroq o'rganish uchun nima qilish kerak?",
                answer = "Boshqaruv tugmalarini xavfsiz joyda sinab ko'r, sezgirlikni o'zingga qulay sozla va bir xil harakatlarni qisqa mashqlarda takrorla.",
                question2 = "tugmalarni qanday o'rganaman?",
                keywords = listOf("boshqaruv", "tugma", "sozlama")
            ),
            GameTip(
                question1 = "o'yin qotib qolsa nima qilish mumkin?",
                answer = "Grafika va effektlarni pasaytir, fondagi keraksiz ilovalarni yop, qurilmada bo'sh joy qoldir va qurilma qizib ketmaganini tekshir.",
                question2 = "lagni kamaytirish uchun nima qilay?",
                keywords = listOf("lag", "qotish", "fps", "unumdorlik")
            ),
            GameTip(
                question1 = "o'yin sekin ishlasa qanday sozlash kerak?",
                answer = "Avval grafikani bir pog'ona pasaytirib ko'r. Barqaror kadr tezligi juda yuqori, lekin tez-tez o'zgaradigan FPSdan ko'ra qulayroq bo'lishi mumkin.",
                question2 = "o'yinni ravon ishlatish yo'li qanday?",
                keywords = listOf("fps", "grafika", "ravon")
            ),
            GameTip(
                question1 = "yangi narsalarni qanday tezroq o'rganish mumkin?",
                answer = "Bir vaqtning o'zida bitta mexanikani o'rgan, kichik maqsad qo'y va mashqdan keyin nima yaxshi chiqqani hamda nimani yaxshilash kerakligini eslab qol.",
                question2 = "mahoratni oshirish usuli nima?",
                keywords = listOf("o'rganish", "mashq", "mahorat")
            ),
            GameTip(
                question1 = "yutqazgandan keyin nima qilish kerak?",
                answer = "Shoshilmay, mag'lubiyat sababini aniqlashga harakat qil. Bitta xatoni tanlab, keyingi o'yinda aynan shuni yaxshilashni maqsad qil.",
                question2 = "yutqazsam qanday yo'l tutay?",
                keywords = listOf("mag'lubiyat", "xato", "tahlil")
            ),
            GameTip(
                question1 = "jamoa bilan qanday yaxshi o'ynash mumkin?",
                answer = "Jamoa rejasiga amal qil, kerakli ma'lumotni qisqa yetkaz va sheriklarning vazifasini hurmat qil. Yolg'iz harakat har doim ham foydali emas.",
                question2 = "jamoaviy o'yinni qanday yaxshilayman?",
                keywords = listOf("jamoa", "hamkorlik", "aloqa")
            ),
            GameTip(
                question1 = "o'yinda resurslarni qanday tejash kerak?",
                answer = "Resursni ishlatishdan oldin uning keyinroq kerak bo'lish ehtimolini o'ylab ko'r. Muhim yangilashlar va vazifalar uchun zaxira qoldir.",
                question2 = "buyum va resurslarni qanday boshqaraman?",
                keywords = listOf("resurs", "buyum", "zaxira")
            ),
            GameTip(
                question1 = "o'yin ichidagi xaritadan qanday foydalanish kerak?",
                answer = "Xaritani muntazam tekshir, yo'nalish va xavfli joylarni eslab qol. Maqsadga borishdan oldin xavfsizroq yo'l bor-yo'qligini bahola.",
                question2 = "xaritani o'qishni qanday o'rganaman?",
                keywords = listOf("xarita", "yo'nalish", "joylashuv")
            ),
            GameTip(
                question1 = "qiyin vazifani qanday bajarish mumkin?",
                answer = "Vazifani kichik bosqichlarga bo'l. Har bir urinishda bitta usulni sinab ko'r va natijaga qarab strategiyani o'zgartir.",
                question2 = "qiyin leveldan qanday o'taman?",
                keywords = listOf("qiyin", "level", "bosqich")
            ),
            GameTip(
                question1 = "o'yindagi yangilanishlardan oldin nima qilish kerak?",
                answer = "Yangilanish tavsifini o'qib chiq, moslik va bo'sh xotirani tekshir, imkon bo'lsa muhim hisob ma'lumotlarini himoyalab qo'y.",
                question2 = "update kelganda nimalarga qaray?",
                keywords = listOf("yangilanish", "update", "xotira")
            ),
            GameTip(
                question1 = "hisobni qanday himoya qilish mumkin?",
                answer = "Kuchli va boshqa joyda ishlatilmaydigan parol qo'y, ikki bosqichli himoya bo'lsa yoq va tasdiqlash kodini hech kimga bermagin.",
                question2 = "akkauntni yo'qotmaslik uchun nima qilay?",
                keywords = listOf("akkaunt", "hisob", "parol", "xavfsizlik")
            ),
            GameTip(
                question1 = "bepul mukofot yoki sovg'alarda nimaga e'tibor berish kerak?",
                answer = "Faqat o'yinning rasmiy ichki menyusi yoki rasmiy sahifalaridan foydalan. Parol yoki tasdiqlash kodini so'raydigan shubhali havolalardan qoch.",
                question2 = "bepul sovg'a havolasi xavfsizligini qanday bilaman?",
                keywords = listOf("mukofot", "sovg'a", "havola", "firibgarlik")
            ),
            GameTip(
                question1 = "o'yin vaqtini qanday boshqarish mumkin?",
                answer = "Oldindan vaqt chegarasini belgilab, tanaffus qil. O'yin uyqu, o'qish, ibodat yoki kundalik vazifalarga xalaqit bermasligiga e'tibor ber.",
                question2 = "qancha vaqt o'ynashni qanday rejalayman?",
                keywords = listOf("vaqt", "tanaffus", "reja")
            ),
            GameTip(
                question1 = "o'yin ichidagi xaridni qilishdan oldin nima o'ylash kerak?",
                answer = "Xarid haqiqatan kerakmi va narxi budjetingga mosmi, tekshir. Shoshilinch takliflar sabab pul sarflama va ruxsatsiz to'lov qilma.",
                question2 = "skin yoki buyum sotib olaymi?",
                keywords = listOf("xarid", "skin", "pul", "budjet")
            ),
            GameTip(
                question1 = "o'yinda adolatli o'ynash nima degani?",
                answer = "Qoidalarni buzadigan cheat yoki noqonuniy dasturlardan foydalanma. Halol o'yin hisobni xavfsizroq saqlaydi va boshqalarga ham hurmat ko'rsatadi.",
                question2 = "cheat ishlatish kerakmi?",
                keywords = listOf("cheat", "adolat", "qoidalar")
            ),
            GameTip(
                question1 = "o'yin ichidagi suhbatda qanday muomala qilish kerak?",
                answer = "Haqorat qilmasdan, aniq va qisqa gapir. Boshqalar bezovta qilsa, mute yoki report vositalaridan foydalan.",
                question2 = "toxik o'yinchilarga qanday javob beray?",
                keywords = listOf("suhbat", "haqorat", "mute", "report")
            ),
            GameTip(
                question1 = "o'yinda do'stlar bilan kelishib olish uchun nima qilish kerak?",
                answer = "O'yin boshlanishidan oldin oddiy reja tuz, vazifalarni bo'lish va reja o'zgarsa bir-biringga xabar ber.",
                question2 = "do'stlar bilan strategiyani qanday tuzamiz?",
                keywords = listOf("do'st", "strategiya", "reja")
            ),
            GameTip(
                question1 = "mashq natijasini qanday o'lchash mumkin?",
                answer = "Bitta yoki ikkita ko'rsatkichni kuzat: masalan, vazifani bajarish vaqti, xatolar soni yoki g'alaba sharti. Natijani oldingi urinish bilan solishtir.",
                question2 = "o'sayotganimni qanday bilaman?",
                keywords = listOf("natija", "ko'rsatkich", "taraqqiyot")
            ),
            GameTip(
                question1 = "o'yin ovozini qanday sozlash kerak?",
                answer = "Muhim ovozlarni eshitadigan darajani tanla, lekin quloqchin ovozini juda baland qilma. Kerak bo'lsa musiqa va effektlar ovozini alohida sozla.",
                question2 = "ovoz sozlamalari qanday bo'lishi kerak?",
                keywords = listOf("ovoz", "audio", "quloqchin")
            ),
            GameTip(
                question1 = "internet yomon bo'lsa nima qilish kerak?",
                answer = "Wi-Fi yoki mobil tarmoq signalini tekshir, yuklab olayotgan boshqa ilovalarni to'xtat va server holatini ko'r. Aloqa barqaror bo'lmasa, raqobatli o'yinni keyinroq boshlash ma'qul.",
                question2 = "ping baland bo'lsa nima qilaman?",
                keywords = listOf("internet", "ping", "tarmoq")
            ),
            GameTip(
                question1 = "o'yin hisobini boshqa qurilmada ochishdan oldin nima qilish kerak?",
                answer = "Hisob rasmiy usul bilan bog'langanini tekshir, faqat o'zing ishonadigan qurilmada kir va ish tugagach hisobdan chiqishni unutma.",
                question2 = "boshqa telefonda akkauntga kirish xavfsizmi?",
                keywords = listOf("qurilma", "kirish", "hisob")
            ),
            GameTip(
                question1 = "o'yinni o'rnatishdan oldin nimalarni tekshirish kerak?",
                answer = "Qurilma talablari, ilova hajmi, bo'sh xotira va operatsion tizim mosligini tekshir. Ilovani rasmiy do'kondan olish xavfsizroq.",
                question2 = "telefonim o'yinni ko'taradimi?",
                keywords = listOf("o'rnatish", "talablar", "xotira")
            ),
            GameTip(
                question1 = "saqlangan progress yo'qolmasligi uchun nima qilish kerak?",
                answer = "O'yin rasmiy bulutli saqlash yoki hisobga bog'lash imkonini bersa, uni sozla. O'yinni o'chirishdan oldin progress qanday saqlanishini tekshir.",
                question2 = "progressni qanday saqlab qolaman?",
                keywords = listOf("progress", "saqlash", "bulut")
            ),
            GameTip(
                question1 = "o'yin boshida xato qilmaslik uchun nima qilish kerak?",
                answer = "Qo'llanma va ko'rsatmalarni o'tkazib yuborma. Dastlabki bosqichlar odatda asosiy mexanikani tushuntiradi.",
                question2 = "tutorialni o'tkazib yuborsam bo'ladimi?",
                keywords = listOf("tutorial", "qo'llanma", "boshlanish")
            ),
            GameTip(
                question1 = "o'yindagi vazifalar orasidan qaysisini birinchi bajarish kerak?",
                answer = "Vaqti cheklangan yoki rivojlanishga ko'proq yordam beradigan vazifani ustun qo'y. Mukofot va talablarni solishtirib, keyin tanla.",
                question2 = "qaysi questni birinchi qilay?",
                keywords = listOf("vazifa", "quest", "ustuvorlik")
            ),
            GameTip(
                question1 = "inventar yoki buyumlar tartibini qanday saqlash mumkin?",
                answer = "Keraksiz buyumlarni ajrat, tez-tez ishlatadigan narsalarni qulay joyga qo'y va muhim buyumlarni tasodifan sarflab yubormaslik uchun tavsifini o'qib chiq.",
                question2 = "inventarni qanday tartiblayman?",
                keywords = listOf("inventar", "buyum", "tartib")
            ),
            GameTip(
                question1 = "o'yinda kuchayish yoki rivojlanish uchun nima qilish kerak?",
                answer = "Rivojlanish tizimi nimani oshirishini tekshir va resursni eng ko'p foyda beradigan yo'nalishga sarfla. Har bir yangilash bir xil darajada foydali emas.",
                question2 = "qanday qilib tezroq rivojlanaman?",
                keywords = listOf("rivojlanish", "upgrade", "kuchayish")
            ),
            GameTip(
                question1 = "o'yinda himoyalanishni qanday yaxshilash mumkin?",
                answer = "Xavfni oldindan kuzat, xavfsiz joy va chekinish yo'lini eslab qol. Hujum qilishdan tashqari, zararni kamaytirish ham muhim.",
                question2 = "himoyani yaxshilash usuli nima?",
                keywords = listOf("himoya", "xavf", "chekinish")
            ),
            GameTip(
                question1 = "hujum yoki harakatni qachon boshlash kerak?",
                answer = "Shoshilishdan oldin vaziyatni, resurslarni va raqibning holatini bahola. Qulay imkoniyat bo'lganda harakat qil, reja ishlamasa orqaga qayt.",
                question2 = "qachon hujum qilish ma'qul?",
                keywords = listOf("hujum", "vaqt", "vaziyat")
            ),
            GameTip(
                question1 = "o'yinda xarakter yoki qahramon tanlashda nimaga qarash kerak?",
                answer = "Qahramonning vazifasi, qobiliyatlari va o'yin uslubingga mosligini ko'r. Faqat mashhurligiga qarab tanlash shart emas.",
                question2 = "qaysi personajni tanlay?",
                keywords = listOf("qahramon", "personaj", "tanlash")
            ),
            GameTip(
                question1 = "turli strategiyalarni qanday sinab ko'rish kerak?",
                answer = "Bir urinishda juda ko'p narsani o'zgartirma. Bitta strategiyani sinab, natijani bahola va keyingi urinishda zarur o'zgarishni kirit.",
                question2 = "strategiya topishning yo'li qanday?",
                keywords = listOf("strategiya", "sinov", "usul")
            ),
            GameTip(
                question1 = "o'yinda yangilik yoki sirni qanday topish mumkin?",
                answer = "Atrofni sinchiklab o'rgan, belgilar va dialoglarga e'tibor ber, lekin shubhali mod yoki zararli fayllarni o'rnatma.",
                question2 = "yashirin narsalarni qanday izlayman?",
                keywords = listOf("sir", "yashirin", "kashfiyot")
            ),
            GameTip(
                question1 = "o'yin modlarini o'rnatishda nimaga e'tibor berish kerak?",
                answer = "Modning manbasi, versiya mosligi va foydalanuvchi izohlarini tekshir. Muhim fayllarni zaxiralamasdan noma'lum modlarni o'rnatma.",
                question2 = "mod xavfsizligini qanday tekshiraman?",
                keywords = listOf("mod", "versiya", "fayl")
            ),
            GameTip(
                question1 = "o'yinda xotira yetmayotgan bo'lsa nima qilish kerak?",
                answer = "Keraksiz yuklamalar va ishlatilmayotgan ilovalarni olib tashla, o'yin ichidagi qo'shimcha fayllarni tekshir. O'yin ma'lumotlarini o'chirishdan oldin progress saqlanganini aniqlab ol.",
                question2 = "o'yin joy egallasa nima qilay?",
                keywords = listOf("xotira", "joy", "fayl")
            ),
            GameTip(
                question1 = "batareya tez tugasa nima qilish mumkin?",
                answer = "Ekran yorqinligini pasaytir, yuqori grafika va ortiqcha effektlarni kamaytir, qurilmani haddan tashqari qizdirmaslikka harakat qil.",
                question2 = "batareyani tejab o'ynash yo'li qanday?",
                keywords = listOf("batareya", "quvvat", "qizish")
            ),
            GameTip(
                question1 = "telefon o'yin paytida qizisa nima qilish kerak?",
                answer = "Tanaffus qil, telefonni quyoshdan uzoq tut, zaryad olayotganda og'ir o'yin o'ynashni chekla va qizishni kuchaytiradigan g'ilofni vaqtincha yech.",
                question2 = "qizib ketganda nima qilaman?",
                keywords = listOf("qizish", "harorat", "telefon")
            ),
            GameTip(
                question1 = "o'yin yangilanishidan keyin muammo chiqsa nima qilish kerak?",
                answer = "O'yinni qayta ishga tushir, qurilmada joy borligini tekshir va rasmiy xatolik xabarlarini ko'r. Noma'lum saytlardan tuzatish fayllarini yuklab olma.",
                question2 = "update dan keyin o'yin ochilmasa nima qilay?",
                keywords = listOf("xatolik", "update", "ochilmaydi")
            ),
            GameTip(
                question1 = "o'yinda musobaqaga tayyorlanish uchun nima qilish kerak?",
                answer = "Qoidalarni o'rgan, kerakli boshqaruvni mashq qil va o'yin oldidan qurilma hamda internetni tekshir. Yetarli dam olish ham diqqatga yordam beradi.",
                question2 = "turnirga qanday tayyorlanaman?",
                keywords = listOf("musobaqa", "turnir", "tayyorgarlik")
            ),
            GameTip(
                question1 = "reytingni ko'tarishda nimalar muhim?",
                answer = "Barqaror o'ynash, xatolarni tahlil qilish va jamoa bilan kelishish ko'pincha faqat ko'p o'yin o'ynashdan foydaliroq.",
                question2 = "rankni oshirish uchun nima qilay?",
                keywords = listOf("reyting", "rank", "mahorat")
            ),
            GameTip(
                question1 = "o'yinda ketma-ket yutqazsam qanday tanaffus qilay?",
                answer = "Bir necha mag'lubiyatdan keyin qisqa tanaffus qil. Jahling chiqqan paytda davom etish qarorlarni yomonlashtirishi mumkin.",
                question2 = "tilt bo'lsam nima qilaman?",
                keywords = listOf("tilt", "asab", "tanaffus")
            ),
            GameTip(
                question1 = "o'yin ichidagi xarid yoki sovg'ani do'stga berish xavfsizmi?",
                answer = "Faqat o'yinning rasmiy sovg'a funksiyasidan foydalan. Hisob paroli yoki tasdiqlash kodini do'stingga ham yuborish xavfli.",
                question2 = "do'stimga item yuborish mumkinmi?",
                keywords = listOf("sovg'a", "do'st", "item")
            ),
            GameTip(
                question1 = "o'yinda shaxsiy ma'lumotni qanday himoya qilaman?",
                answer = "Haqiqiy manzil, telefon raqami, parol va shaxsiy hujjatlarni chatda yuborma. Profil maxfiylik sozlamalarini tekshir.",
                question2 = "o'yin chatida nimalarni yozmaslik kerak?",
                keywords = listOf("maxfiylik", "shaxsiy ma'lumot", "chat")
            ),
            GameTip(
                question1 = "o'yinda boshqa odam aldasa nima qilish kerak?",
                answer = "Dalil bo'lsa o'yinning rasmiy report vositasidan foydalan. Javoban qoidani buzma va shaxsiy ma'lumotlarini izlashga urinma.",
                question2 = "cheaterga nima qilaman?",
                keywords = listOf("aldash", "report", "cheater")
            ),
            GameTip(
                question1 = "o'yin haqida ishonchli ma'lumotni qayerdan topish mumkin?",
                answer = "Rasmiy qo'llanma, ishlab chiquvchi e'lonlari va ishonchli hamjamiyat manbalarini solishtir. Eski ma'lumot yangilanishdan keyin eskirgan bo'lishi mumkin.",
                question2 = "o'yin ma'lumotini qayerdan tekshiraman?",
                keywords = listOf("manba", "rasmiy", "ma'lumot")
            ),
            GameTip(
                question1 = "o'yin ichidagi atamalarni qanday o'rganaman?",
                answer = "Atamani uchratgan joyingni yozib ol, o'yin kontekstida ma'nosini tekshir va bitta misol bilan eslab qol.",
                question2 = "gaming terminlarini qanday tushunaman?",
                keywords = listOf("atama", "termin", "lug'at")
            ),
            GameTip(
                question1 = "o'yinda ko'p vaqt sarflamasdan rivojlansa bo'ladimi?",
                answer = "Qisqa, maqsadli mashqlar qil va kunlik vazifalardan foydalansang, vaqtingni samarali ishlatishing mumkin. Biroq har bir o'yinning rivojlanish tizimi boshqacha.",
                question2 = "kam vaqt bilan qanday rivojlanaman?",
                keywords = listOf("kam vaqt", "samarali", "mashq")
            ),
            GameTip(
                question1 = "o'yin davomida diqqatni qanday saqlash mumkin?",
                answer = "Chalg'ituvchi bildirishnomalarni o'chir, kerak bo'lsa qisqa tanaffus qil va bir vaqtning o'zida bitta maqsadga e'tibor ber.",
                question2 = "diqqatni yo'qotmaslik uchun nima qilay?",
                keywords = listOf("diqqat", "bildirishnoma", "fokus")
            ),
            GameTip(
                question1 = "o'yinda o'z uslubimni qanday topaman?",
                answer = "Bir nechta yondashuvni sinab ko'r, qaysi biri senga qulay va natijali ekanini kuzat. Boshqalarning uslubini aynan ko'chirish shart emas.",
                question2 = "o'zimga mos uslubni qanday topaman?",
                keywords = listOf("uslub", "o'yin usuli", "moslik")
            )
        )

        val result = ArrayList<Fact>(5000)
        games.forEachIndexed { gameIndex, game ->
            tips.forEachIndexed { tipIndex, tip ->
                val base = gameIndex * 100 + tipIndex * 2 + 1
                val gameKeywords = listOf(game.lowercase(), "o'yin", "gaming") + tip.keywords

                result.add(
                    fact(
                        id = "game_db_${base.toString().padStart(4, '0')}",
                        category = Category.GAMES,
                        question = "$game o'yinida ${tip.question1}",
                        answer = tip.answer,
                        aliases = listOf("$game: ${tip.question2}"),
                        keywords = gameKeywords
                    )
                )
                result.add(
                    fact(
                        id = "game_db_${(base + 1).toString().padStart(4, '0')}",
                        category = Category.GAMES,
                        question = "$game o'yinida ${tip.question2}",
                        answer = tip.answer,
                        aliases = listOf("$game: ${tip.question1}"),
                        keywords = gameKeywords
                    )
                )
            }
        }
        return result
    }



    /**
     * Islom bo'limidagi 5 000 ta qidiruv yozuvi: 50 mavzu × 50 savol uslubi × 2 shakl.
     * Bu 5 000 ta mustaqil diniy hukm degani emas. Asosiy mazmunlar mavzular bo'yicha beriladi;
     * savol variantlari esa foydalanuvchi turlicha yozganda topishga yordam beradi.
     */
    private data class IslamTopic(
        val question1: String,
        val answer: String,
        val question2: String,
        val keywords: List<String>
    )

    private fun buildIslamFacts(): List<Fact> {
        val topics = listOf(
            IslamTopic("Fotiha surasi qanday o'qiladi?", "Fotiha surasi (arabcha): بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ. Talaffuzni ishonchli qori tilovatidan o'rgan.", "namoz uchun Fotiha surasi matni", listOf("fotiha", "namoz", "sura", "arabcha")),
            IslamTopic("Ixlos surasi matni qanday?", "Ixlos surasi: قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ. O'qilishini audio tilovat bilan tekshirib yodlash foydali.", "Qul huvallohu ahad surasi", listOf("ixlos", "qul huvallohu ahad", "sura")),
            IslamTopic("Falaq surasi matni qanday?", "Falaq surasi: قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ. Arabcha matnni to'g'ri talaffuz bilan o'rganish uchun ustoz yoki ishonchli qori tilovatiga ergash.", "Qul a'uzu birabbil falaq surasi", listOf("falaq", "qul a'uzu", "sura")),
            IslamTopic("Nos surasi matni qanday?", "Nos surasi: قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ. Talaffuzni audio tilovat bilan tekshir.", "Qul a'uzu birabbin nas surasi", listOf("nos", "nas", "qul a'uzu birabbin nas", "sura")),
            IslamTopic("Kavsar surasi matni qanday?", "Kavsar surasi: إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ۝ فَصَلِّ لِرَبِّكَ وَانْحَرْ ۝ إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ. Yodlayotganda oyatlarni bo'lib takrorla va talaffuzni tekshirtir.", "Inna a'toynakal kavsar surasi", listOf("kavsar", "inna a'toynaka", "sura")),
            IslamTopic("Asr surasi matni qanday?", "Asr surasi: وَالْعَصْرِ ۝ إِنَّ الْإِنسَانَ لَفِي خُسْرٍ ۝ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ. To'g'ri o'qishni ishonchli tilovatdan o'rgan.", "Val asr surasi", listOf("asr", "val asr", "sura")),
            IslamTopic("Kofirun surasi matni qanday?", "Kofirun surasi: قُلْ يَا أَيُّهَا الْكَافِرُونَ ۝ لَا أَعْبُدُ مَا تَعْبُدُونَ ۝ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ۝ وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ ۝ وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ۝ لَكُمْ دِينُكُمْ وَلِيَ دِينِ. Yodlashda oyatlarni ketma-ket takrorla.", "Qul ya ayyuhal kafirun surasi", listOf("kofirun", "qul ya ayyuhal", "sura")),
            IslamTopic("Namozda qaysi qisqa suralarni o'qishni yodlash mumkin?", "Namozda Fotiha surasidan keyin yod bilgan qisqa suralardan o'qish o'rgatiladi. Boshlash uchun Ixlos, Kavsar, Asr, Falaq va Nos suralarini o'rganish mumkin. Namozdagi tartib va mazhabga oid tafsilotlarni mahalliy ishonchli imomdan tekshir.", "namoz uchun qisqa suralar qaysilar", listOf("namoz", "qisqa suralar", "yodlash")),
            IslamTopic("Namozning besh mahal nomlari qaysilar?", "Besh mahal farz namoz: bomdod, peshin, asr, shom va xufton.", "kunlik namoz nomlari", listOf("besh mahal", "bomdod", "peshin", "asr", "shom", "xufton")),
            IslamTopic("Tahoratning ma'nosi nima?", "Tahorat — ibodat oldidan belgilangan tartibda poklanish. Amaliy tartibni ishonchli ustoz yoki mahalliy diniy manbadan o'rgan; ayrim tafsilotlar mazhabga ko'ra farq qilishi mumkin.", "tahorat nima degani", listOf("tahorat", "poklanish", "namoz")),
            IslamTopic("Namozdan oldin nima qilish kerak?", "Namozdan oldin namoz vaqti kirganini, badan-kiyim-joy pokligini, tahoratni va qiblani tekshirish o'rgatiladi. Batafsil qoidalarni ishonchli diniy ustozdan o'rgan.", "namozga tayyorgarlik", listOf("namoz", "tahorat", "qibla", "vaqt")),
            IslamTopic("Qibla nima?", "Qibla — musulmonlar namozda yuzlanadigan Ka'ba tomoni. Joylashuvingga mos ishonchli qibla kompasidan yoki mahalliy masjiddan tekshir.", "namozda qaysi tomonga qaraladi", listOf("qibla", "ka'ba", "namoz")),
            IslamTopic("Azon nima?", "Azon — namoz vaqti kirganini bildiruvchi chaqiriq. Uning lafzlari va talaffuzini masjid muazzini yoki ishonchli audio orqali o'rganish mumkin.", "azonning ma'nosi", listOf("azon", "namoz vaqti")),
            IslamTopic("Iqomat nima?", "Iqomat — farz namozi boshlanishidan oldin aytiladigan chaqiriq. Uning amaliy tafsilotlari mahalliy imomdan o'rganilishi mumkin.", "namoz boshlanishidagi iqomat", listOf("iqomat", "farz namoz")),
            IslamTopic("Ruku nima?", "Ruku — namozdagi egilish holati. To'g'ri holat va zikrlarni namoz o'rgatuvchi ishonchli manbadan ko'rib o'rgan.", "namozda ruku degani", listOf("ruku", "namoz")),
            IslamTopic("Sajda nima?", "Sajda — namozdagi Allohga ibodat holatlaridan biri. Uning to'g'ri bajarilishini ishonchli namoz qo'llanmasi yoki ustozdan o'rgan.", "namozdagi sajda", listOf("sajda", "namoz")),
            IslamTopic("Qiyom nima?", "Qiyom — namozda tik turish holati. Qaysi namozda qayerda turish va qiroat qilish tartibini ishonchli ustozdan o'rgan.", "namozda tik turish", listOf("qiyom", "tik turish", "namoz")),
            IslamTopic("Takbir nima?", "Takbir — Allohu akbar deyish. Namoz boshlanishidagi takbirning o'rni va harakatlarini to'g'ri namoz qo'llanmasidan o'rgan.", "Allohu akbar nimani anglatadi", listOf("takbir", "allohu akbar", "namoz")),
            IslamTopic("Tasbeh nima?", "Tasbeh so'zi Allohni pok deb ulug'lash zikriga ham ishlatiladi; kundalik zikrlar turli shaklda bo'lishi mumkin. Aniq ibodat tartibi uchun ishonchli manbaga murojaat qil.", "tasbeh aytish nima", listOf("tasbeh", "zikr")),
            IslamTopic("Duo nima?", "Duo — Allohdan so'rash va Unga murojaat qilish. Duoni o'z tilingda ham qilishing mumkin; maxsus rivoyat qilingan duolarning matnini ishonchli manbadan tekshir.", "duo qilish ma'nosi", listOf("duo", "ibodat")),
            IslamTopic("Zikr nima?", "Zikr — Allohni eslash va ulug'lash. Zikr matnlarini to'g'ri o'rganish uchun ishonchli diniy manbalardan foydalan.", "Allohni zikr qilish", listOf("zikr", "Allohni eslash")),
            IslamTopic("Ramazon ro'zasi qachon tutiladi?", "Ramazon ro'zasi tong otishidan quyosh botishigacha tutiladi. Ro'za vaqtlari hudud va sanaga qarab o'zgaradi; mahalliy taqvimni tekshir.", "ro'za vaqti qanday", listOf("ramazon", "ro'za", "saharlik", "iftor")),
            IslamTopic("Saharlik nima?", "Saharlik — ro'za tutuvchi kishi tong otishidan oldin yeydigan ovqat. Aniq tugash vaqtini hududingdagi ishonchli namoz taqvimidan tekshir.", "saharlik vaqti", listOf("saharlik", "ro'za")),
            IslamTopic("Iftor nima?", "Iftor — quyosh botib, shom vaqti kirganda ro'zani ochish. Vaqtni mahalliy ishonchli taqvimdan tekshirish kerak.", "ro'zani qachon ochish", listOf("iftor", "shom", "ro'za")),
            IslamTopic("Zakot nima?", "Zakot — shartlari va miqdori belgilangan moliyaviy ibodat. Kimga farz bo'lishi va hisoblash usulini ishonchli olim yoki zakot bo'yicha mutaxassisdan aniqlashtir.", "zakotning ma'nosi", listOf("zakot", "moliyaviy ibodat")),
            IslamTopic("Haj nima?", "Haj — imkoniyati va shartlari mavjud musulmon uchun Makka bilan bog'liq belgilangan ibodat. Safar va marosim tafsilotlarini ishonchli haj qo'llanmasidan o'rgan.", "haj ibodati nima", listOf("haj", "makkа", "ibodat")),
            IslamTopic("Shahodat kalimasi nima haqida?", "Shahodat Islom e'tiqodining asosini ifodalaydi: Allohdan o'zga iloh yo'qligiga va Muhammad ﷺ Allohning elchisi ekaniga guvohlik berish. Arabcha lafz va talaffuzni ustozdan o'rganish foydali.", "shahodat ma'nosi", listOf("shahodat", "e'tiqod", "kalima")),
            IslamTopic("Juma namozi nima?", "Juma namozi juma kuni peshin vaqti bilan bog'liq jamoat ibodatidir. Kimga vojibligi va uzrlar kabi tafsilotlar mazhab hamda holatga qarab tushuntiriladi; mahalliy imomdan so'ra.", "juma namozi haqida", listOf("juma", "namoz", "masjid")),
            IslamTopic("Masjidda odob qanday bo'ladi?", "Masjidga hurmat bilan kirish, boshqalarga xalaqit bermaslik, poklikni saqlash va telefon ovozini pasaytirish yaxshi odoblardandir.", "masjid odoblari", listOf("masjid", "odob", "poklik")),
            IslamTopic("Qur'onni qanday yodlash mumkin?", "Kichik qismlarni tanla, ishonchli qori tilovatini tingla, talaffuzni tekshirtir va har kuni oldingi yodlaganingni takrorla. Shoshilmasdan to'g'ri o'qishga e'tibor ber.", "sura yodlash usuli", listOf("Qur'on", "yodlash", "sura")),
            IslamTopic("Qur'on o'qishni qanday o'rganaman?", "Arab harflari va harakatlardan boshlash, ustoz bilan talaffuzni tekshirtirish va ishonchli audio tilovatni tinglash foydali. O'zbekcha transliteratsiya arabcha talaffuzni to'liq bera olmaydi.", "Qur'on o'qishni o'rganish", listOf("Qur'on", "arabcha", "talaffuz")),
            IslamTopic("Bismilloh nimani anglatadi?", "Bismillahir rohmanir rohiym iborasi 'Mehribon va rahmli Alloh nomi bilan' ma'nosini bildiradi. Arabcha talaffuzni to'g'ri o'rganishga e'tibor ber.", "bismilloh tarjimasi", listOf("bismilloh", "tarjima")),
            IslamTopic("Alhamdulillah nimani anglatadi?", "Alhamdulillah — 'Hamd va shukr Allohgadir' degan ma'noda ishlatiladi.", "alhamdulillah tarjimasi", listOf("alhamdulillah", "shukr")),
            IslamTopic("Subhanalloh nimani anglatadi?", "Subhanalloh — Alloh barcha nuqsonlardan pok ekanini ulug'lab aytiladigan zikr.", "subhanalloh ma'nosi", listOf("subhanalloh", "zikr")),
            IslamTopic("Astaghfirulloh nimani anglatadi?", "Astaghfirulloh — Allohdan mag'firat, ya'ni kechirim so'rash iborasi.", "astag'firulloh tarjimasi", listOf("astag'firulloh", "istig'for", "kechirim")),
            IslamTopic("Salovat nima?", "Salovat — Payg'ambar Muhammad ﷺ ga duo va salom aytish. Salovatlarning matnini ishonchli manbadan o'rganish mumkin.", "Payg'ambarga salovat aytish", listOf("salovat", "Muhammad")),
            IslamTopic("Islomda poklik nima uchun muhim?", "Poklik ibodatlarda muhim o'rin tutadi. Tahorat, g'usl va najosatdan poklanishning aniq qoidalarini ishonchli fiqh manbasidan o'rgan.", "poklik va ibodat", listOf("poklik", "tahorat", "g'usl")),
            IslamTopic("G'usl nima?", "G'usl — belgilangan holatlarda butun badanni yuvish orqali poklanish. Qachon farz bo'lishi va to'g'ri tartibini ishonchli diniy ustozdan aniqlashtir.", "g'usl olish", listOf("g'usl", "poklanish")),
            IslamTopic("Jamoat namozi nima?", "Jamoat namozi bir necha kishining imomga ergashib namoz o'qishidir. Saf va imomga ergashish qoidalarini masjidda o'rganish mumkin.", "jamoat bilan namoz", listOf("jamoat", "imom", "namoz")),
            IslamTopic("Imom kim?", "Imom jamoat namozida oldinda turib, namozni boshqaradigan kishidir. Imomga ergashish qoidalari namoz qo'llanmalarida tushuntiriladi.", "namozdagi imom", listOf("imom", "jamoat")),
            IslamTopic("Farz nima?", "Farz — diniy ta'limotda bajarilishi qat'iy talab qilingan amal. Muayyan amalning hukmini ishonchli olimdan aniqlashtir.", "farz degani nima", listOf("farz", "hukm")),
            IslamTopic("Sunnat nima?", "Sunnat — Payg'ambar Muhammad ﷺ ning so'zlari, amallari va ma'qullashlari bilan bog'liq yo'l. Fiqhdagi hukm tafsilotlarini ishonchli manbadan o'rgan.", "sunnat ma'nosi", listOf("sunnat", "hadis")),
            IslamTopic("Halol va harom nima?", "Halol — ruxsat etilgan, harom — taqiqlangan narsani bildiradi. Muayyan vaziyatdagi hukm uchun ishonchli olimga murojaat qilish kerak.", "halol harom farqi", listOf("halol", "harom")),
            IslamTopic("Sabr nima?", "Sabr — qiyinchilikda o'zini tutish, to'g'ri ishda davom etish va shoshqaloqlikdan tiyilish. Islom ta'limotida sabr muhim fazilat hisoblanadi.", "islomda sabr", listOf("sabr", "fazilat")),
            IslamTopic("Shukr nima?", "Shukr — berilgan ne'matlarni tan olish va minnatdor bo'lish. Shukr so'z, qalb va yaxshi amallar bilan ifodalanishi mumkin.", "shukr qilish ma'nosi", listOf("shukr", "ne'mat")),
            IslamTopic("Ota-onaga hurmat haqida Islom nima deydi?", "Islom ta'limotida ota-onaga yaxshilik qilish va hurmat ko'rsatish muhim. Bu hurmat zararli yoki adolatsiz ishga ko'r-ko'rona rozi bo'lish degani emas.", "ota-onaga yaxshilik", listOf("ota-ona", "hurmat", "odob")),
            IslamTopic("Yolg'on haqida Islomda qanday qaraladi?", "Rostgo'ylik muhim axloqiy fazilat sanaladi, yolg'on esa qoralangan. Murakkab holatlarda ishonchli diniy ustozdan maslahat ol.", "rostgo'ylik va yolg'on", listOf("yolg'on", "rostgo'ylik")),
            IslamTopic("Birovning haqqi nima?", "Birovning haqqi — boshqa insonning moli, obro'si yoki huquqiga tegishli masalalar. Bunday haqni buzmaslik va zarar yetgan bo'lsa uni tuzatishga intilish muhim.", "banda haqqi nima", listOf("birovning haqqi", "banda haqqi", "haq")),
            IslamTopic("Islomda ilm o'rganishning ahamiyati nima?", "Foydali ilm o'rganish muhim qadriyat hisoblanadi. Diniy bilimni ishonchli ustoz va tekshirilgan manbalardan, boshqa fanlarni esa sifatli ta'lim orqali o'rganish mumkin.", "ilmning fazilati", listOf("ilm", "o'rganish")),
            IslamTopic("Diniy savolga javobni qayerdan tekshirish kerak?", "Qur'on, ishonchli hadis va tan olingan fiqh manbalariga tayangan olim yoki mahalliy imomdan tekshir. Internetdagi har bir postni diniy hukm deb qabul qilma.", "islomiy ma'lumotni tekshirish", listOf("manba", "imom", "diniy savol")),
            IslamTopic("Namozni endi o'rganayotgan odam nimadan boshlasin?", "Avval tahoratni, namoz vaqtlarini, namozning asosiy harakatlarini va Fotiha surasini o'rgan. Keyin qisqa suralarni bosqichma-bosqich yodla va o'qishingni ishonchli ustozga tekshirtir.", "namoz o'qishni boshlash", listOf("namozni o'rganish", "fotiha", "tahorat")),
            IslamTopic("Namozdagi talaffuzni qanday yaxshilash mumkin?", "Oyatni kichik bo'laklarga ajratib, ishonchli qori tilovatini tingla va arab tilini biladigan ustozdan talaffuzni tekshirtir. Transliteratsiya yordamchi bo'lishi mumkin, lekin arabcha tovushlarni to'liq ifodalamaydi.", "namoz qiroatini to'g'rilash", listOf("talaffuz", "qiroat", "arabcha")),
            IslamTopic("Namoz vaqti qanday aniqlanadi?", "Namoz vaqtlari quyosh holatiga va hududga bog'liq. O'z hududing uchun ishonchli masjid yoki diniy idora taqvimidan foydalan.", "namoz vaqtini bilish", listOf("namoz vaqti", "taqvim", "bomdod", "shom"))
        )

        // Har bir mavzu uchun 50 xil so'rov iborasi va ikki savol shakli yaratiladi.
        val prefixes = listOf(
            "Tushuntirib ber: ", "Qisqacha ayt: ", "Menga o'rgat: ", "Ma'lumot ber: ",
            "Oddiy tilda tushuntir: ", "Savolim bor: ", "Buni izohla: ", "Qanday bo'ladi: ",
            "Nimani bilishim kerak: ", "Boshlovchi uchun ayt: ", "Yordam ber: ", "Eslatib yubor: ",
            "Batafsilroq tushuntir: ", "Eng muhim jihati nima: ", "To'g'ri tushunishim uchun ayt: ",
            "Bu haqida gapirib ber: ", "Qanday o'rganaman: ", "Asosiy ma'lumot: ", "Iltimos, izohla: ",
            "Men bilmoqchiman: ", "Sodda qilib ayt: ", "Misol bilan tushuntir: ", "Qoidasi qanday: ",
            "Amalda qanday: ", "Yodlab olishim uchun ayt: ", "Yangi o'rganuvchiga tushuntir: ",
            "Qisqa ma'lumot kerak: ", "Muhim nuqtalarini ayt: ", "Savolimga javob ber: ", "Bu nimani bildiradi: ",
            "O'rganishga yordam ber: ", "Mavzuni tushuntir: ", "Aniqroq ayt: ", "Buni qanday tushunsam bo'ladi: ",
            "Oddiy javob ber: ", "Bosqichma-bosqich ayt: ", "Asoslarini tushuntir: ", "Ma'nosini ayt: ",
            "Qanday eslab qolaman: ", "Nimadan boshlay: ", "Muhim ma'lumotni ayt: ", "Buni bilish kerakmi: ",
            "Qanday bajariladi: ", "Qanday talaffuz qilinadi: ", "Qaysi qoidaga tegishli: ", "To'g'ri yo'lini tushuntir: ",
            "Menga kerakli ma'lumot: ", "Bir oz tushuntir: ", "Buni o'rganish yo'li: ", "Yodda tutish uchun ayt: "
        )
        val result = ArrayList<Fact>(5000)
        topics.take(50).forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                val base = topicIndex * 100 + styleIndex * 2 + 1
                val keywords = topic.keywords + listOf("islom", "ibodat", "namoz")
                result.add(fact(
                    id = "islam_db_${base.toString().padStart(4, '0')}",
                    category = Category.ISLAM,
                    question = prefix + topic.question1,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question2, topic.question1, topic.question2),
                    keywords = keywords
                ))
                result.add(fact(
                    id = "islam_db_${(base + 1).toString().padStart(4, '0')}",
                    category = Category.ISLAM,
                    question = prefix + topic.question2,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question1, topic.question1, topic.question2),
                    keywords = keywords
                ))
            }
        }
        return result
    }


    /**
     * Suhbat, maslahat va motivatsiya bo'limi: 70 mavzu × 50 savol uslubi × 2 shakl = 7 000 yozuv.
     * Har bir mavzu uchun mazmunli asosiy javob ishlatiladi; savol shakllari qidiruvni osonlashtiradi.
     */
    private data class ChatTopic(
        val question1: String,
        val answer: String,
        val question2: String,
        val keywords: List<String>
    )

    private fun buildChatFacts(): List<Fact> {
        val topics = listOf(
            ChatTopic("Motivatsiyam yo'q, nima qilay?", "Katta ishni kutib o'tirma: bugun atigi 5 daqiqa boshlagin. Maqsad — birdan mukammal qilish emas, odatni davom ettirish.", "hech narsa qilgim kelmayapti", listOf("motivatsiya", "odat", "boshlash")),
            ChatTopic("Maqsadni qanday belgilayman?", "Maqsadni aniq va o'lchab bo'ladigan qil. Masalan, 'ko'proq o'qiyman' o'rniga 'har kuni 10 daqiqa o'qiyman' deb belgilagin.", "maqsad qo'yish usuli", listOf("maqsad", "reja", "aniq")),
            ChatTopic("Xato qilsam nima bo'ladi?", "Xato — o'rganish jarayonining tabiiy qismi. Qaysi joyda adashganingni topib, keyingi urinishda bitta narsani yaxshilashga harakat qil.", "xato qilsam nima qilaman", listOf("xato", "o'rganish", "maslahat")),
            ChatTopic("Bugun maqsadimga ulgurmadim", "Bir kunlik tanaffus hammasi tugadi degani emas. Sababini ko'rib chiq va ertaga bajarish mumkin bo'lgan kichikroq qadamni tanla.", "rejani bajarmadim", listOf("maqsad", "reja", "davom etish")),
            ChatTopic("O'zimga ishonchim kam, nima qilay?", "O'zingga ishonch kichik va'dalarni bajarishdan o'sadi. Bugun bajara oladigan bitta ishni tanla va tugat.", "o'zimga ishonmayman", listOf("ishonch", "o'ziga baho", "jasorat")),
            ChatTopic("Xato qilishdan qo'rqaman", "Xato qilish o'rganishning bir qismi. Xatodan keyin nima o'rganganingni yozib, keyingi safar bitta narsani o'zgartir.", "xato qilish qo'rquvi", listOf("xato", "qo'rquv", "o'rganish")),
            ChatTopic("Boshqalar bilan o'zimni solishtiraman", "Har kimning sharoiti va tezligi boshqacha. Kechagi o'zing bilan bugungi o'zingni solishtirib, kichik o'sishni ham ko'rishga harakat qil.", "odamlar bilan solishtirish", listOf("solishtirish", "o'sish", "o'zini baholash")),
            ChatTopic("Diqqatim tez chalg'iydi", "Telefon bildirishnomalarini vaqtincha o'chir, bitta vazifani tanla va 10–15 daqiqalik qisqa vaqt bilan boshlagin.", "diqqatni jamlash", listOf("diqqat", "chalg'ish", "telefon")),
            ChatTopic("Vaqtimni qanday boshqaraman?", "Kun boshida eng muhim uchta ishni yoz. Ularni vaqt bo'laklariga joylashtir va dam olish uchun ham vaqt qoldir.", "vaqtni rejalash", listOf("vaqt", "reja", "ustuvorlik")),
            ChatTopic("Yangi odatni qanday shakllantiraman?", "Yangi odatni mavjud odatga bog'la: masalan, nonushtadan keyin 5 daqiqa ingliz tili. Avval kichik va muntazam qil.", "odatni shakllantirish", listOf("odat", "muntazamlik", "kichik qadam")),
            ChatTopic("Odatim buzilib qoldi", "Bir kun o'tkazib yuborish hammasi tugadi degani emas. Keyingi imkoniyatda qaytadan boshla va sababini aniqlab, rejani osonlashtir.", "odatni davom ettira olmadim", listOf("odat", "qaytish", "davom")),
            ChatTopic("Charchaganimda nima qilay?", "Charchoqni e'tiborsiz qoldirma. Suv ich, biroz dam ol, ovqatlanish va uyquni tekshir; muhim ishni kuchingga moslashtir.", "juda charchadim", listOf("charchoq", "dam", "uyqu")),
            ChatTopic("Kayfiyatim tushib ketdi", "Hozir o'zingdan hammasini hal qilishni talab qilma. Biroz yurish, suv ichish yoki ishonchli odam bilan gaplashish yordam berishi mumkin.", "kayfiyatim yo'q", listOf("kayfiyat", "dam", "suhbat")),
            ChatTopic("Asabiylashsam nima qilay?", "Javob berishdan oldin sekin nafas olib, bir oz tanaffus qil. Vaziyat tinchigach, nimaga asabiylashganingni so'z bilan ifodalashga urin.", "jahlim chiqyapti", listOf("asab", "tinchlanish", "nafas")),
            ChatTopic("Xafa bo'lsam kimga aytaman?", "Ishonadigan oila a'zosi, ustoz yoki do'stingga aytishing mumkin. Hammasini birdan tushuntirish shart emas; 'men xafaman, gaplashsak bo'ladimi?' deb boshlagin.", "dardimni kimga aytay", listOf("xafa", "ishonch", "gaplashish")),
            ChatTopic("Muammoni qanday hal qilaman?", "Muammoni bitta jumlada yoz, o'zing nazorat qila oladigan qismini ajrat va eng kichik keyingi qadamni tanla.", "muammoni hal qilish yo'li", listOf("muammo", "yechim", "qadam")),
            ChatTopic("Qaror qabul qilish qiyin", "Variantlarni, foyda va xavflarni yoz. Qaror shoshilinch bo'lmasa, biroz vaqt ber va ishonchli odam bilan maslahatlash.", "qaror qila olmayapman", listOf("qaror", "tanlov", "maslahat")),
            ChatTopic("Odamlar bilan gaplashishga uyalaman", "Oldindan bitta oddiy jumla tayyorla va kichik suhbatlardan mashq qil. Uyalish tabiiy; tajriba ortgani sari osonlashishi mumkin.", "gapirishga uyalaman", listOf("uyalish", "muloqot", "mashq")),
            ChatTopic("Notanish odamdan yordam so'rash", "Muloyim salom berib, aniq so'ra: 'Kechirasiz, menga ... bo'yicha yordam bera olasizmi?' Javob qanday bo'lishidan qat'i nazar, so'rashning o'zi ko'nikma.", "yordam so'rashni o'rganish", listOf("yordam", "muloqot", "savol")),
            ChatTopic("Do'st bilan kelishmovchilik bo'ldi", "Avval uning gapini bo'lmasdan tingla, keyin o'z his-tuyg'ungni ayblamasdan tushuntir. Muammoni birga hal qilishga urin.", "do'stim bilan urishib qoldim", listOf("do'st", "kelishmovchilik", "tinglash")),
            ChatTopic("Kechirimni qanday so'rayman?", "Nima qilganingni aniq tan ol, uzr so'ra va imkon bo'lsa zararni tuzat. 'Lekin sen ham...' deb aybni boshqa odamga yuklama.", "uzr so'rash", listOf("kechirim", "mas'uliyat", "munosabat")),
            ChatTopic("Birov meni ranjitdi", "His qilganingni tan ol va tinch paytda nima ranjitganini tushuntir. Agar bu takrorlansa, chegarangni aniq ayt va ishonchli kattadan yordam so'ra.", "kimdir meni ranjitdi", listOf("ranjish", "chegara", "suhbat")),
            ChatTopic("Yo'q deyishni qanday o'rganaman?", "Muloyim va aniq ayt: 'Rahmat, lekin bunga rozi bo'la olmayman.' Har bir iltimosga rozi bo'lish majburiy emas.", "rad etishga qiynalaman", listOf("yo'q deyish", "chegara", "hurmat")),
            ChatTopic("Meni tinglashmayapti", "Tinch vaqtda, qisqa qilib nima muhimligini ayt. 'Gapimni oxirigacha eshitsang, xursand bo'lardim' kabi jumladan foydalan.", "meni eshitishmaydi", listOf("tinglash", "muloqot", "his")),
            ChatTopic("Yolg'iz his qilyapman", "Yolg'izlik hissi og'ir bo'lishi mumkin. Ishonchli odamga xabar yozish, umumiy qiziqishli mashg'ulotga qo'shilish yoki yaqinlaring bilan vaqt o'tkazishdan boshlagin.", "o'zimni yolg'iz his qilyapman", listOf("yolg'izlik", "do'st", "aloqa")),
            ChatTopic("Yangi do'st orttirish", "Umumiy qiziqishdan suhbat boshlagin, savol ber va javobni tingla. Do'stlik asta-sekin shakllanadi; o'zingni majburlab ko'rsatishing shart emas.", "do'st topish", listOf("do'st", "suhbat", "qiziqish")),
            ChatTopic("Suhbatni qanday boshlayman?", "Oddiy vaziyatga oid savol ber: 'Bu darsni tushundingmi?' yoki 'Bu o'yinni o'ynaysanmi?' Samimiy va qisqa boshlash kifoya.", "gapni nimadan boshlash", listOf("suhbat", "savol", "muloqot")),
            ChatTopic("Kimdir meni masxara qilsa", "Tinch, qisqa javob ber va kerak bo'lsa vaziyatdan uzoqlash. Takroriy bezorilik bo'lsa, ishonchli kattaga yoki ustozga ayt.", "masxara qilishsa nima qilaman", listOf("masxara", "bezorilik", "yordam")),
            ChatTopic("Tanqidni qanday qabul qilaman?", "Tanqidning foydali qismini ajrat: aniq misol bormi, nimani yaxshilash mumkin? Haqoratni esa foydali fikr deb qabul qilish shart emas.", "tanqidga munosabat", listOf("tanqid", "o'sish", "fikr")),
            ChatTopic("Muvaffaqiyatsizlikdan keyin", "Biroz tinchlanib, nima ishlamaganini ko'rib chiq. Natijani o'z qadring bilan tenglashtirma; keyingi urinish uchun bitta o'zgarish tanla.", "yutqazdim nima qilay", listOf("muvaffaqiyatsizlik", "tajriba", "davom")),
            ChatTopic("Katta maqsadni kichraytirish", "Maqsadni haftalik, kunlik va hozir bajariladigan qadamga bo'l. Bugungi qadam juda kichik bo'lsa ham, yo'nalish muhim.", "katta maqsadni qanday boshlay", listOf("maqsad", "reja", "qadam")),
            ChatTopic("O'qishga qanday motivatsiya topaman?", "O'qishni kelajakdagi foydasi bilan bog'la, lekin faqat kayfiyatni kutma. 10 daqiqalik dars va kichik tanaffus bilan boshlagin.", "dars qilishga motivatsiya", listOf("o'qish", "dars", "motivatsiya")),
            ChatTopic("Imtihondan qo'rqyapman", "Mavzularni bo'lib, har kuni oz-ozdan takrorla va o'zingni savollar bilan sinab ko'r. Uyqu va tanaffus ham tayyorgarlikning bir qismi.", "imtihon oldidan qo'rquv", listOf("imtihon", "tayyorgarlik", "xavotir")),
            ChatTopic("Yodlaganim esimdan chiqadi", "Faqat qayta o'qish o'rniga, kitobni yopib o'zingga savol ber. Ma'lumotni bir necha kun oralatib takrorlash eslab qolishga yordam beradi.", "tez unutaman", listOf("xotira", "takrorlash", "o'qish")),
            ChatTopic("Ingliz tilini qanday o'rganaman?", "Har kuni 5–10 ta so'z, bitta sodda gap va qisqa tinglash bilan shug'ullan. O'rgangan so'zlaringni o'z gaplaringda ishlat.", "til o'rganishni boshlash", listOf("ingliz tili", "til", "so'z")),
            ChatTopic("Arab yozuvini o'rganish", "Avval harflarni shakli va tovushi bilan o'rgan, keyin harflarning so'z boshida, o'rtasida va oxirida yozilishini mashq qil.", "arab harflarini o'rganish", listOf("arab yozuvi", "harf", "yozish")),
            ChatTopic("Namozni muntazam o'qishga odatlanish", "Namoz vaqtlarini kundalik rejangga kirit va kerakli narsalarni oldindan tayyorla. O'rganayotgan bo'lsang, ishonchli manba yoki ustozdan bosqichma-bosqich o'rgan.", "namozni odat qilish", listOf("namoz", "ibodat", "muntazamlik")),
            ChatTopic("Ibodatda diqqatni jamlash", "Shoshilmaslikka harakat qil, o'qiyotgan so'zlaring ma'nosini o'rgan va chalg'ituvchi narsalarni kamaytir. Diqqat asta-sekin yaxshilanishi mumkin.", "ibodatda xayolim chalg'iydi", listOf("ibodat", "diqqat", "namoz")),
            ChatTopic("Kun tartibini tuzish", "Uyqu, o'qish, ibodat, harakat va dam olishga joy ajrat. Jadvalni haddan tashqari to'ldirma; kutilmagan ishlar uchun bo'sh vaqt qoldir.", "kun tartibi", listOf("jadval", "kun", "reja")),
            ChatTopic("Ertalab erta turish", "Uyqu vaqtini asta-sekin oldinga sur, kechqurun telefonni chetga qo'y va uyg'onish vaqtini barqaror tut. Yetarli uxlashni kamaytirma.", "erta turish usuli", listOf("ertalab", "uyqu", "odat")),
            ChatTopic("Telefonni kamroq ishlatish", "Keraksiz bildirishnomalarni o'chir, ilovalar uchun vaqt chegarasi belgilab, telefonni o'qish paytida ko'zdan uzoqroq qo'y.", "telefon ko'p chalg'itadi", listOf("telefon", "vaqt", "diqqat")),
            ChatTopic("Ijtimoiy tarmoqqa ko'p kiraman", "Qachon va nima uchun kirishingni kuzat. Ilovani ochishdan oldin maqsad belgilab, vaqt tugaganda chiqishga eslatma qo'y.", "ijtimoiy tarmoqqa qaram bo'lib qoldim", listOf("ijtimoiy tarmoq", "telefon", "odat")),
            ChatTopic("Sog'lom odatlar boshlash", "Birdan hammasini o'zgartirma. Uyqu, harakat, ovqatlanish yoki o'qishdan bittasini tanlab, kichik va barqaror qadam bilan boshlagin.", "foydali odat boshlash", listOf("sog'lom odat", "muntazamlik", "boshlash")),
            ChatTopic("Mashq qilishga motivatsiya", "O'zingga mos, xavfsiz mashqni tanla va texnikani to'g'ri bajarishga e'tibor ber. Dam olish ham rivojlanishning muhim qismi.", "sport qilishga erinaman", listOf("mashq", "sport", "motivatsiya")),
            ChatTopic("Natija sekin chiqyapti", "Ko'nikmalar vaqt bilan rivojlanadi. Natijani har kuni emas, bir necha hafta oralig'ida kuzat va o'zingdagi kichik yaxshilanishlarni qayd et.", "tez natija ko'rmayapman", listOf("natija", "sabr", "taraqqiyot")),
            ChatTopic("Boshqa odamlarning fikri meni bezovta qiladi", "Boshqalarning fikri muhim bo'lishi mumkin, lekin hammasi haqiqat degani emas. Ishonchli odamlarning foydali fikrini ol, qolganini saralashni o'rgan.", "odamlar nima deydi deb qo'rqaman", listOf("boshqalar fikri", "xavotir", "o'ziga ishonch")),
            ChatTopic("O'zimni qanday rag'batlantiraman?", "Bajargan kichik ishingni tan ol: kalendarga belgi qo'y yoki yoqimli tanaffus qil. Mukofot maqsadingga zarar bermaydigan bo'lsin.", "o'zimni mukofotlash", listOf("rag'bat", "mukofot", "odat")),
            ChatTopic("Kunlik natijalarni yozish", "Kechqurun uch narsani yoz: nima qildim, nimani o'rgandim, ertaga bitta muhim qadam nima. Bu o'sishni ko'rishga yordam beradi.", "kunlik hisobot yozish", listOf("kundalik", "natija", "maqsad")),
            ChatTopic("Minnatdorlikni qanday mashq qilaman?", "Har kuni qadrlaydigan ikki yoki uch narsani yoz. Bu muammolar yo'q degani emas; yaxshi jihatlarni ham ko'rishga yordam beradi.", "shukronalik mashqi", listOf("minnatdorlik", "shukr", "kayfiyat")),
            ChatTopic("Boshqalarga yordam berish", "Avval odamga qanday yordam kerakligini so'ra. Qo'lingdan keladiganini qil, lekin o'z imkoniyating va xavfsizligingni ham hisobga ol.", "yordam berish", listOf("yordam", "mehr", "hurmat")),
            ChatTopic("Sir saqlash haqida", "Birovning shaxsiy gapini ruxsatsiz tarqatma. Ammo kimdir xavf ostida bo'lsa, uni himoya qila oladigan ishonchli kattaga aytish muhim.", "sirni saqlash", listOf("sir", "ishonch", "xavfsizlik")),
            ChatTopic("Chegaralarimni belgilash", "Nimaga rozi va nimaga rozi emasligingni hurmat bilan, aniq ayt. Boshqalarning chegaralarini ham xuddi shunday hurmat qil.", "shaxsiy chegara", listOf("chegara", "hurmat", "rozilik")),
            ChatTopic("Birovning gapini noto'g'ri tushundim", "Taxmin qilish o'rniga aniqlashtir: 'To'g'ri tushundimmi, sen ... demoqchimisan?' Bu tushunmovchilikni kamaytiradi.", "gapni noto'g'ri tushunish", listOf("tushunmovchilik", "savol", "muloqot")),
            ChatTopic("Maslahat so'rashga uyalaman", "Maslahat so'rash ojizlik emas. Vaziyatni qisqacha tushuntirib, aynan qaysi qarorda qiynalayotganingni ayt.", "maslahat so'rash", listOf("maslahat", "uyalish", "yordam")),
            ChatTopic("Jahlim chiqqanda gapirib yuboraman", "Javobni kechiktir: suv ich, joyni o'zgartir yoki 10 gacha sanagin. Tinchigach, muammoni haqorat qilmasdan muhokama qil.", "jahlimni boshqara olmayman", listOf("jahl", "tinchlanish", "gap")),
            ChatTopic("Xavotirni kamaytirish", "Seni xavotirga solayotgan narsani yozib, nazorat qiladigan va qila olmaydigan qismlarga ajrat. Sekin nafas olish va ishonchli odam bilan gaplashish yordam berishi mumkin.", "ko'p xavotir olaman", listOf("xavotir", "stress", "nafas")),
            ChatTopic("Stress paytida nima qilay?", "Vazifalarni mayda qismlarga ajrat, qisqa tanaffus qil va uyquni asra. Stress uzoq davom etsa yoki kundalik hayotga xalaqit bersa, ishonchli kattadan yordam so'ra.", "stressni yengish", listOf("stress", "tanaffus", "yordam")),
            ChatTopic("Yig'lagim keladi", "His-tuyg'ularni his qilish tabiiy. O'zingga biroz vaqt ber, xavfsiz joyda tinchlan va kerak bo'lsa ishonchli odamga nima bo'layotganini ayt.", "yig'lagim kelyapti", listOf("his", "xafa", "yordam")),
            ChatTopic("Hech narsaga qiziqmay qoldim", "Bir necha kun davomida kichik, yengil mashg'ulotlardan boshlashga urin va yaqin inson bilan gaplash. Bu holat uzoq cho'zilsa, ishonchli kattadan yordam so'ra.", "hech narsa qiziq emas", listOf("qiziqish", "kayfiyat", "yordam")),
            ChatTopic("O'zimni qadrlash", "Qadring faqat baho, natija yoki boshqalarning fikriga bog'liq emas. O'zingdagi yaxshi sifatlarni va o'rgangan narsalaringni yozib ko'r.", "o'zimni qadrlamayman", listOf("qadr", "o'ziga munosabat", "ishonch")),
            ChatTopic("Yaxshi tinglovchi bo'lish", "Suhbatdoshning gapini bo'lma, tushunganingni qisqacha qaytar va maslahat berishdan oldin u maslahat xohlayaptimi, so'ra.", "odamlarni tinglash", listOf("tinglash", "suhbat", "hamdardlik")),
            ChatTopic("Vaqtida ish boshlash", "Boshlash uchun aniq signal tanla: masalan, choydan keyin dars. Kerakli narsalarni oldindan tayyorlab, birinchi qadamni juda oson qil.", "ishni kechiktirish", listOf("kechiktirish", "boshlash", "odat")),
            ChatTopic("Prokrastinatsiyani yengish", "Vazifaning faqat 5 daqiqasini bajarishga kelishib ol. Telefonni chetga qo'y va 'hammasini tugatish' emas, 'boshlash'ni maqsad qil.", "ishni doim keyinga qoldiraman", listOf("prokrastinatsiya", "kechiktirish", "diqqat")),
            ChatTopic("O'qish va dam olish muvozanati", "Oldindan qisqa o'qish bloklari va tanaffuslar belgilagin. Dam olishni dangasalik deb ko'rma; u diqqatni tiklashga yordam beradi.", "o'qishdan charchadim", listOf("o'qish", "dam", "muvozanat")),
            ChatTopic("Yangi ishni nimadan boshlay?", "Kerakli natijani aniqlab, eng kichik bajariladigan qadamni tanla. Birinchi urinishda hamma narsani mukammal qilish shart emas.", "yangi ish boshlash", listOf("boshlash", "reja", "qadam")),
            ChatTopic("Qobiliyatimni qanday rivojlantiraman?", "Bitta ko'nikmani tanla, uni muntazam mashq qil va natijani tekshir. Fikr-mulohaza olib, mashqni asta-sekin qiyinlashtir.", "qobiliyatni oshirish", listOf("ko'nikma", "mashq", "rivojlanish")),
            ChatTopic("O'rganganimni boshqalarga tushuntirish", "Mavzuni sodda so'zlar bilan tushuntirib ko'r, misol keltir va qayerda to'xtab qolganingni aniqlagin. Shu joyni qayta o'rgan.", "bilimni mustahkamlash", listOf("o'rganish", "tushuntirish", "takrorlash")),
            ChatTopic("Maqsadimni unutib qo'yaman", "Maqsadingni ko'rinadigan joyga yoz va har kuni ko'rib chiqadigan aniq vaqt belgilagin. Uni nima uchun xohlayotganingni ham yoz.", "maqsadni eslab turish", listOf("maqsad", "eslatma", "sabab")),
            ChatTopic("O'zimni tartibga solish", "Bir xil vaqtda bajariladigan sodda tartib tuz. Keraksiz qadamlarni kamaytir, kerakli narsalarni oldindan joyiga qo'y.", "intizomli bo'lish", listOf("intizom", "tartib", "odat")),
            ChatTopic("Boshqa odamga maslahat berish", "Avval uning gapini tingla va nima xohlayotganini so'ra: tinglashmi yoki yechim topishmi. Uning o'rniga qaror qabul qilma.", "do'stimga qanday maslahat beraman", listOf("maslahat", "tinglash", "do'st"))
        )
        val prefixes = listOf(
            "Maslahat ber: ",
            "Qisqacha ayt: ",
            "Menga yordam ber: ",
            "Oddiy qilib tushuntir: ",
            "Qanday yo'l tutay: ",
            "Nimadan boshlay: ",
            "Menga tavsiya ber: ",
            "Buni qanday hal qilaman: ",
            "Bir maslahat kerak: ",
            "Yo'l ko'rsat: ",
            "Tushuntirib ber: ",
            "Eng muhim qadam nima: ",
            "Amalda nima qilay: ",
            "Bosqichma-bosqich ayt: ",
            "Menga ko'maklash: ",
            "Qanday yaxshilay: ",
            "Qanday o'zgartiraman: ",
            "Yaxshi yo'li qanday: ",
            "Nima qilishim mumkin: ",
            "Qanday uddalayman: ",
            "Yengilroq tushuntir: ",
            "Buni qanday o'rganaman: ",
            "Menga yo'l-yo'riq ber: ",
            "Qisqa tavsiya: ",
            "Men bilmoqchiman: ",
            "Shuni izohla: ",
            "Qanday davom etay: ",
            "Qanday boshlash kerak: ",
            "Qanday mashq qilay: ",
            "Nimani yodda tutay: ",
            "Menga ko'rsatma ber: ",
            "Bu vaziyatda nima qilay: ",
            "Foydali maslahat ayt: ",
            "Nima muhim: ",
            "Qanday qaror qilay: ",
            "Buni yengish yo'li: ",
            "Qanday odatlanaman: ",
            "O'zimga qanday yordam beray: ",
            "Qanday reja tuzay: ",
            "Eng sodda usul: ",
            "Qanday tinchlanaman: ",
            "Qanday gapirsam bo'ladi: ",
            "Buni qanday tushunay: ",
            "Yaxshi usul ayt: ",
            "Qanday yo'l topaman: ",
            "Menga tushunarli qilib ayt: ",
            "Qanday davom ettiraman: ",
            "Qanday o'rgansam bo'ladi: ",
            "Bir oz maslahat kerak: ",
            "Eng to'g'ri qadam nima: "
        )
        val result = ArrayList<Fact>(7000)
        topics.take(70).forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                val base = topicIndex * 100 + styleIndex * 2 + 1
                val keywords = topic.keywords + listOf("suhbat", "maslahat", "motivatsiya")
                result.add(fact(
                    id = "chat_db_${base.toString().padStart(4, '0')}",
                    category = Category.CHAT,
                    question = prefix + topic.question1,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question2, topic.question1, topic.question2),
                    keywords = keywords
                ))
                result.add(fact(
                    id = "chat_db_${(base + 1).toString().padStart(4, '0')}",
                    category = Category.CHAT,
                    question = prefix + topic.question2,
                    answer = topic.answer,
                    aliases = listOf(prefix + topic.question1, topic.question1, topic.question2),
                    keywords = keywords
                ))
            }
        }
        return result
    }



    /** Umumiy bilim va kundalik hayot: mavjud 5 ta asosiy yozuv bilan jami 10 000 ta yozuv. */
    private data class GeneralTopic(val q1: String, val answer: String, val q2: String, val keywords: List<String>)

    private fun buildGeneralFacts(): List<Fact> {
        val topics = listOf(
            GeneralTopic("Vaqtni qanday rejalashtiraman?", "Kun boshida eng muhim ishlarni yoz, har biriga taxminiy vaqt ajrat va tanaffus uchun ham joy qoldir.", "kun tartibini tuzish", listOf("vaqt", "reja", "kun")),
            GeneralTopic("Pulni tejashni nimadan boshlayman?", "Xarajatlarni yozib bor, zarur va ixtiyoriy xarajatlarni ajrat, xarid oldidan rostdan kerakmi deb o'ylab ko'r.", "pul tejash usuli", listOf("pul", "tejash", "xarajat")),
            GeneralTopic("Byudjet nima?", "Byudjet — ma'lum davr uchun kutilayotgan daromad va xarajatlar rejasi.", "daromad va xarajat rejasi", listOf("byudjet", "pul", "reja")),
            GeneralTopic("Chek nima uchun kerak?", "Chek xarid va to'lov haqidagi ma'lumotni tasdiqlaydi; kerak bo'lsa uni kafolat yoki qaytarish uchun saqlash mumkin.", "xarid chekini saqlash sababi", listOf("chek", "xarid", "to'lov")),
            GeneralTopic("Parolni qanday xavfsiz saqlayman?", "Har bir muhim hisob uchun alohida, uzun parol ishlat va uni boshqalarga yuborma. Imkon bo'lsa ikki bosqichli himoyani yoq.", "hisob parolini himoyalash", listOf("parol", "xavfsizlik", "hisob")),
            GeneralTopic("Ikki bosqichli himoya nima?", "Bu kirishda paroldan tashqari ikkinchi tasdiq ham so'raladigan himoya usuli.", "2FA nimani anglatadi", listOf("2fa", "himoya", "akkaunt")),
            GeneralTopic("Fishing nima?", "Fishing — odamni aldab parol yoki shaxsiy ma'lumotini oldirishga urinish. Shubhali havola va xabarlarga ehtiyot bo'l.", "internetdagi fishing", listOf("fishing", "firibgarlik", "internet")),
            GeneralTopic("Shubhali havola kelsa nima qilaman?", "Havolani ochishga shoshilma, yuboruvchini boshqa yo'l bilan tekshir va parol yoki tasdiqlash kodini hech kimga bermagin.", "noma'lum link xavfsizmi", listOf("havola", "link", "xavfsizlik")),
            GeneralTopic("Zaxira nusxa nima?", "Zaxira nusxa — muhim fayllarning alohida saqlangan ko'chirmasi; qurilma yo'qolsa yoki buzilsa, ma'lumotni tiklashga yordam beradi.", "backup nima degani", listOf("backup", "zaxira", "fayl")),
            GeneralTopic("Fayl va papka farqi nima?", "Fayl ma'lumotni saqlaydi, papka esa fayllar va boshqa papkalarni tartibli joylashtirish uchun ishlatiladi.", "papka bilan fayl farqi", listOf("fayl", "papka", "kompyuter")),
            GeneralTopic("PDF nima?", "PDF — hujjat ko'rinishini turli qurilmalarda bir xil saqlashga mo'ljallangan fayl formati.", "pdf fayli nima", listOf("pdf", "hujjat", "fayl")),
            GeneralTopic("QR-kod nima?", "QR-kod kamera orqali o'qiladigan ikki o'lchamli kod bo'lib, havola yoki boshqa ma'lumotni saqlashi mumkin.", "qr kod vazifasi", listOf("qr", "kod", "kamera")),
            GeneralTopic("GPS nima?", "GPS sun'iy yo'ldosh signallari yordamida joylashuvni aniqlashga yordam beradigan navigatsiya tizimidir.", "gps qanday ishlaydi", listOf("gps", "joylashuv", "xarita")),
            GeneralTopic("Xaritadan qanday foydalanaman?", "Manzilni qidir, yo'nalishni tanla va yo'l belgilariga e'tibor ber. Navigatsiya ko'rsatmasi yo'l qoidalaridan ustun emas.", "xaritada yo'l topish", listOf("xarita", "yo'nalish", "manzil")),
            GeneralTopic("Kompas qaysi tomonni ko'rsatadi?", "Oddiy magnit kompas magnit shimol yo'nalishini ko'rsatadi; u geografik shimol bilan aynan bir nuqta emas.", "kompas qanday yo'nalish beradi", listOf("kompas", "shimol", "yo'nalish")),
            GeneralTopic("Metr va kilometr munosabati qanday?", "1 kilometrda 1000 metr bor.", "bir km necha metr", listOf("kilometr", "metr", "masofa")),
            GeneralTopic("Kilogramm va gramm munosabati qanday?", "1 kilogrammda 1000 gramm bor.", "bir kg necha gramm", listOf("kilogramm", "gramm", "og'irlik")),
            GeneralTopic("Litr nima o'lchaydi?", "Litr suyuqlik kabi moddalarning hajmini o'lchashda ishlatiladi.", "litr nimani o'lchaydi", listOf("litr", "hajm", "o'lchov")),
            GeneralTopic("Bir sutka necha soat?", "Bir sutka 24 soatdan iborat.", "24 soat nima", listOf("sutka", "soat", "vaqt")),
            GeneralTopic("Kabisa yili nima?", "Kabisa yilida odatda 366 kun bo'ladi va fevral 29 kun davom etadi. Gregorian taqvimida kabisa qoidalari maxsus hisoblanadi.", "fevral qachon 29 kun", listOf("kabisa", "fevral", "taqvim")),
            GeneralTopic("Fasl nima?", "Yilning odatda bahor, yoz, kuz va qish deb ataladigan to'rt davridan biri fasl deyiladi.", "yil fasllari", listOf("fasl", "bahor", "yoz", "kuz", "qish")),
            GeneralTopic("Ob-havo va iqlim farqi nima?", "Ob-havo — ma'lum joydagi qisqa muddatli atmosfera holati; iqlim esa uzoq yillar davomida kuzatiladigan odatiy sharoitlar.", "iqlim ob havodan farqi", listOf("ob-havo", "iqlim", "atmosfera")),
            GeneralTopic("Bulut qanday hosil bo'ladi?", "Havodagi suv bug'i sovib, mayda suv tomchilari yoki muz kristallariga aylanganda bulut hosil bo'ladi.", "bulut paydo bo'lishi", listOf("bulut", "suv bug'i", "tabiat")),
            GeneralTopic("Yomg'ir qanday yog'adi?", "Bulutdagi suv tomchilari kattalashib, havo ularni ushlab turolmay qolganda yerga yog'in bo'lib tushadi.", "yomg'ir hosil bo'lishi", listOf("yomg'ir", "bulut", "suv")),
            GeneralTopic("Kamalak qanday paydo bo'ladi?", "Quyosh nuri yomg'ir tomchilarida sinib va ranglarga ajralib qaytganda kamalak ko'rinishi mumkin.", "kamalak sababi", listOf("kamalak", "quyosh", "yomg'ir")),
            GeneralTopic("Shamol nima?", "Shamol — havoning bir joydan boshqa joyga harakatlanishi; bunga atmosfera bosimidagi farqlar sabab bo'ladi.", "shamol qanday hosil bo'ladi", listOf("shamol", "havo", "bosim")),
            GeneralTopic("Suvning muzlash harorati qancha?", "Oddiy atmosfera bosimida toza suv taxminan 0 °C da muzlaydi.", "suv necha gradusda muzlaydi", listOf("suv", "muz", "harorat")),
            GeneralTopic("Suv qaynash harorati qancha?", "Dengiz sathidagi odatiy atmosfera bosimida toza suv taxminan 100 °C da qaynaydi; balandlik va bosim bu qiymatni o'zgartiradi.", "suv necha gradusda qaynaydi", listOf("suv", "qaynash", "harorat")),
            GeneralTopic("Quyosh nima?", "Quyosh — Yerga yorug'lik va issiqlik beradigan yulduz.", "quyosh yulduzmi", listOf("quyosh", "yulduz", "koinot")),
            GeneralTopic("Yerning tabiiy yo'ldoshi nima?", "Oy — Yerning tabiiy yo'ldoshi.", "yer yo'ldoshi", listOf("oy", "yer", "koinot")),
            GeneralTopic("Quyosh tizimida nechta sayyora bor?", "Hozirgi astronomik tasnif bo'yicha Quyosh tizimida 8 ta sayyora bor.", "sayyoralar soni", listOf("sayyora", "quyosh tizimi", "8")),
            GeneralTopic("Yer nima uchun tun va kunduzga ega?", "Yer o'z o'qi atrofida aylangani uchun uning turli qismlari navbat bilan Quyoshga qaraydi yoki undan teskari tomonda qoladi.", "tun kunduz sababi", listOf("yer", "aylanish", "tun", "kunduz")),
            GeneralTopic("Oy nega shaklini o'zgartirgandek ko'rinadi?", "Oy Quyosh nuri bilan yoritilgan qismining Yerdan ko'rinadigan ulushi o'zgargani uchun turli fazalarda ko'rinadi.", "oy fazalari sababi", listOf("oy", "faza", "quyosh")),
            GeneralTopic("O'simlikka nimalar kerak?", "Ko'pchilik o'simliklar o'sishi uchun yorug'lik, suv, havo, mos harorat va tuproqdan olinadigan mineral moddalarga muhtoj.", "o'simlik o'sishi uchun sharoit", listOf("o'simlik", "suv", "yorug'lik")),
            GeneralTopic("Daraxtlar nima uchun foydali?", "Daraxtlar yashash joyi yaratadi, karbonat angidridni yutishda qatnashadi, soya beradi va tuproqni eroziyadan himoyalashga yordam beradi.", "daraxtlarning foydasi", listOf("daraxt", "tabiat", "havo")),
            GeneralTopic("Chiqindini saralash nima uchun kerak?", "Chiqindini turiga qarab ajratish qayta ishlashni osonlashtiradi va poligonga ketadigan chiqindi miqdorini kamaytirishi mumkin.", "axlatni ajratish foydasi", listOf("chiqindi", "qayta ishlash", "tabiat")),
            GeneralTopic("Qayta ishlash nima?", "Qayta ishlash — ishlatilgan materiallarni qayta ishlab, yangi mahsulot yoki xomashyo olish jarayoni.", "recycling nima", listOf("qayta ishlash", "material", "ekologiya")),
            GeneralTopic("Elektrni qanday tejash mumkin?", "Keraksiz chiroqlarni o'chir, energiya tejamkor lampalardan foydalan va qurilmalarni yo'riqnoma bo'yicha ishlat.", "tokni tejash", listOf("elektr", "energiya", "tejash")),
            GeneralTopic("Suvni qanday tejash mumkin?", "Jo'mrakni bekorga oqizib qo'yma, sizib chiqayotgan joylarni tuzat va suvdan foydalanishda ehtiyojga mos miqdorni tanla.", "suvni tejash yo'llari", listOf("suv", "tejash", "jo'mrak")),
            GeneralTopic("Ovqatni xavfsiz saqlash uchun nima qilish kerak?", "Xom va tayyor ovqatni ajrat, tez buziladigan mahsulotlarni sovutkichda saqla va saqlash muddatiga amal qil.", "ovqatni to'g'ri saqlash", listOf("ovqat", "sovutkich", "xavfsizlik")),
            GeneralTopic("Qo'lni qachon yuvish kerak?", "Hojatxonadan keyin, ovqat tayyorlash va yeyishdan oldin, tashqaridan kelganda va qo'l iflos bo'lganda sovun bilan yuvish foydali.", "qo'l yuvish vaqtlari", listOf("qo'l", "gigiyena", "sovun")),
            GeneralTopic("Tishlarni parvarish qilish qanday?", "Tishlarni kuniga ikki marta ftorli pasta bilan tozalash va tish shifokori tavsiyalariga amal qilish og'iz salomatligiga yordam beradi.", "tish tozalash qoidasi", listOf("tish", "gigiyena", "pasta")),
            GeneralTopic("Uyqu nima uchun muhim?", "Uyqu diqqat, xotira, kayfiyat va tananing tiklanishi uchun muhim. Yoshga mos uyqu tartibini saqlashga harakat qil.", "uyqu foydasi", listOf("uyqu", "dam", "salomatlik")),
            GeneralTopic("Jismoniy faollik nima uchun kerak?", "Muntazam, yosh va imkoniyatga mos harakat yurak, mushaklar, suyaklar va umumiy kayfiyatni qo'llab-quvvatlaydi.", "mashq qilish foydasi", listOf("jismoniy faollik", "mashq", "salomatlik")),
            GeneralTopic("Tanaffusni qanday foydali o'tkazaman?", "Ko'z va tanani dam oldir, biroz turib yur, suv ich va keyin vazifaga qayt.", "o'qish orasida tanaffus", listOf("tanaffus", "dam", "o'qish")),
            GeneralTopic("Ko'z charchashini kamaytirish uchun nima qilaman?", "Ekrandan muntazam tanaffus qil, xonani mos yorit va matnni qulay kattalikda tut. Doimiy noqulaylik bo'lsa, mutaxassisga murojaat qil.", "ekranda ko'z charchashi", listOf("ko'z", "ekran", "tanaffus")),
            GeneralTopic("Birinchi yordam nima?", "Birinchi yordam — mutaxassislar yetib kelguncha jarohatlangan yoki to'satdan betob bo'lgan kishiga xavfsiz tarzda ko'rsatiladigan dastlabki yordam.", "birinchi yordam ta'rifi", listOf("birinchi yordam", "xavfsizlik", "salomatlik")),
            GeneralTopic("Favqulodda vaziyatda nima qilish kerak?", "Avvalo o'zing va atrofdagilar xavfsizligini ta'minla, mahalliy favqulodda xizmatga xabar ber va rasmiy ko'rsatmalarga amal qil.", "favqulodda holatdagi harakat", listOf("favqulodda", "xavfsizlik", "yordam")),
            GeneralTopic("Yo'lni qanday xavfsiz kesib o'taman?", "Belgilangan piyodalar o'tish joyidan foydalan, svetofor signalini kut, ikki tomonni tekshir va telefon bilan chalg'ima.", "yo'lni kesib o'tish qoidasi", listOf("yo'l", "piyoda", "svetofor")),
            GeneralTopic("Svetofor ranglari nimani bildiradi?", "Odatda qizil — to'xta, yashil — harakatlanishga ruxsat, sariq — signal almashayotganidan ogohlantirish. Mahalliy yo'l qoidalariga amal qil.", "svetofor ranglari ma'nosi", listOf("svetofor", "qizil", "yashil")),
            GeneralTopic("Jamoat transportida odob qanday?", "Navbatga rioya qil, tushayotganlarga yo'l ber, baland ovozda xalaqit qilma va zarur bo'lsa o'rningni muhtoj kishiga taklif et.", "transportdagi odob", listOf("transport", "odob", "navbat")),
            GeneralTopic("Navbat kutish odobi nima?", "Navbatdagi tartibni saqla, boshqalarning oldiga o'tib ketma va tushunmovchilik bo'lsa muloyim gaplash.", "navbatda o'zini tutish", listOf("navbat", "odob", "hurmat")),
            GeneralTopic("Samarali o'qish uchun nima qilaman?", "Maqsadni aniqlab, mavzuni kichik qismlarga bo'l, o'qiganingni o'z so'zing bilan tushuntir va keyin eslab ko'r.", "darsni yaxshi o'rganish", listOf("o'qish", "dars", "xotira")),
            GeneralTopic("Eslab qolishni qanday yaxshilayman?", "Ma'lumotni bir necha kunda oraliq bilan takrorla, o'zingni savollar bilan tekshir va misollar bilan bog'la.", "xotirani yaxshilash", listOf("xotira", "takrorlash", "o'rganish")),
            GeneralTopic("Konspekt nima?", "Konspekt — mavzuning asosiy fikrlari, atamalari va misollarini qisqa, tartibli yozib olish.", "konspekt ta'rifi", listOf("konspekt", "dars", "yozuv")),
            GeneralTopic("Lug'atdan qanday foydalanaman?", "So'zni qidirib, ma'nosini va misolini o'qi; yangi so'zni o'z gapingda ishlatib, keyin takrorla.", "lug'at bilan so'z o'rganish", listOf("lug'at", "so'z", "til")),
            GeneralTopic("Muloqotda faol tinglash nima?", "Suhbatdoshning gapini bo'lmasdan tingla, tushunmagan joyingni so'ra va uning fikrini to'g'ri tushunganingni tekshir.", "faol tinglash usuli", listOf("muloqot", "tinglash", "suhbat")),
            GeneralTopic("Muloyim rad javobi qanday beriladi?", "Qisqa va hurmat bilan ayt: 'Rahmat, lekin hozir bunga imkonim yo'q'. Kerak bo'lsa sababni qisqacha tushuntir.", "yo'q deyishni o'rganish", listOf("rad etish", "muloqot", "hurmat")),
            GeneralTopic("Kechirim so'rashda nima muhim?", "Xatoni aniq tan ol, samimiy uzr so'ra va imkon bo'lsa uni tuzatish uchun nima qilishingni ayt.", "uzr so'rash odobi", listOf("kechirim", "uzr", "mas'uliyat")),
            GeneralTopic("Ishonchli ma'lumotni qanday tekshiraman?", "Manbaning kimligini, sanasini va dalillarini tekshir; boshqa ishonchli manbalar bilan solishtir va shoshilib ulashma.", "ma'lumot haqiqatligini tekshirish", listOf("manba", "tekshirish", "dalil")),
            GeneralTopic("Mish-mishni qanday baholayman?", "Tasdiqlovchi dalil va ishonchli manba bo'lmasa, mish-mishni haqiqat deb qabul qilma yoki tarqatma.", "mish-mish tarqatmaslik", listOf("mish-mish", "dalil", "manba")),
            GeneralTopic("Mualliflik huquqi nima?", "Mualliflik huquqi ijodiy asar muallifining qonun bilan himoyalanadigan huquqlarini belgilaydi; foydalanishda ruxsat va litsenziyani tekshir.", "copyright nima", listOf("mualliflik", "huquq", "litsenziya")),
            GeneralTopic("Ochiq litsenziya nima?", "Ochiq litsenziya muallif belgilagan shartlar asosida asardan foydalanish, tarqatish yoki o'zgartirishga ruxsat berishi mumkin.", "open license ta'rifi", listOf("litsenziya", "ochiq", "mualliflik")),
            GeneralTopic("Til o'rganishda muntazamlik nima uchun kerak?", "Har kuni oz bo'lsa ham shug'ullanish eslab qolish va odat shakllantirishga yordam beradi. Qisqa takrorlashlarni rejalashtir.", "tilni muntazam o'rganish", listOf("til", "muntazamlik", "takrorlash")),
            GeneralTopic("Telefon xotirasini qanday bo'shataman?", "Keraksiz yuklab olingan fayllarni tekshir, foydalanmaydigan ilovalarni o'chir va muhim ma'lumotni zaxiralagandan keyin tozalashni bajar.", "telefon joyini bo'shatish", listOf("telefon", "xotira", "fayl")),
            GeneralTopic("Ilova keshini o'chirish nima qiladi?", "Kesh vaqtinchalik fayllarni saqlaydi. Uni tozalash joy bo'shatishi mumkin, ammo ayrim ma'lumotlar qayta yuklanadi; 'ma'lumotlarni tozalash' bilan farqiga e'tibor ber.", "cache tozalash", listOf("kesh", "cache", "telefon")),
            GeneralTopic("Wi-Fi va mobil internet farqi nima?", "Wi-Fi qurilmani simsiz mahalliy tarmoqqa ulaydi; mobil internet esa operator tarmog'i orqali internetga chiqadi.", "wifi bilan mobil internet farqi", listOf("wifi", "mobil internet", "tarmoq")),
            GeneralTopic("Bluetooth nima uchun kerak?", "Bluetooth yaqin masofadagi qurilmalar o'rtasida simsiz aloqa, masalan quloqchin yoki klaviatura ulash uchun ishlatiladi.", "bluetooth vazifasi", listOf("bluetooth", "simsiz", "qurilma")),
            GeneralTopic("Ilovani yangilash nima uchun kerak?", "Yangilanishlar xatolarni tuzatishi, xavfsizlikni yaxshilashi va yangi imkoniyatlar qo'shishi mumkin. O'rnatishdan oldin bo'sh joyni tekshir.", "app yangilash foydasi", listOf("ilova", "yangilash", "xavfsizlik")),
            GeneralTopic("Operatsion tizim nima?", "Operatsion tizim qurilma resurslarini boshqaradi va ilovalarning ishlashiga imkon beradi. Android va Windows bunga misol.", "operatsion sistema ta'rifi", listOf("operatsion tizim", "android", "windows")),
            GeneralTopic("Sun'iy intellekt nima?", "Sun'iy intellekt — kompyuter tizimlarining matnni tushunish, naqshlarni aniqlash yoki tavsiya berish kabi vazifalarni bajarish usullari sohasi.", "ai nima degani", listOf("sun'iy intellekt", "ai", "texnologiya")),
            GeneralTopic("AI javobini tekshirish kerakmi?", "Ha. Sun'iy intellekt ba'zan xato yoki eskirgan ma'lumot berishi mumkin; muhim masalalarda ishonchli manbadan tekshir.", "suniy intellektga to'liq ishonsa bo'ladimi", listOf("ai", "xato", "tekshirish")),
            GeneralTopic("Ma'lumotlar bazasi nima?", "Ma'lumotlar bazasi — ma'lumotlarni tartibli saqlash, qidirish va yangilash uchun tashkil qilingan to'plam.", "database nima", listOf("baza", "ma'lumot", "qidiruv")),
            GeneralTopic("Algoritm nima?", "Algoritm — vazifani bajarish uchun aniq tartibda bajariladigan qadamlar ketma-ketligi.", "algoritm ta'rifi", listOf("algoritm", "qadam", "mantiq")),
            GeneralTopic("Elektr toki bilan ishlashda nima muhim?", "Nam qo'l bilan elektr jihozlariga tegma, shikastlangan simlardan foydalanma va nosozlikda kattalar yoki malakali mutaxassisdan yordam so'ra.", "elektr xavfsizligi", listOf("elektr", "xavfsizlik", "sim")),
            GeneralTopic("Yong'inni ko'rsam nima qilaman?", "Xavfsiz joyga chiq, boshqalarni ogohlantir va mahalliy favqulodda xizmatga xabar ber. Xavfli joyga qaytib kirmagin.", "yong'in paytida harakat", listOf("yong'in", "xavfsizlik", "favqulodda")),
            GeneralTopic("Uyda tozalikni qanday saqlayman?", "Kichik kundalik tartib tuz: buyumlarni joyiga qo'y, yuzalarni tozala va chiqindini vaqtida olib chiq.", "uy yig'ishtirish rejasi", listOf("tozalik", "uy", "tartib")),
            GeneralTopic("Kiyim yorlig'ini nima uchun o'qish kerak?", "Kiyim yorlig'idagi belgilar yuvish, quritish va dazmollash usulini ko'rsatadi; ularga amal qilish kiyimni asrashga yordam beradi.", "kiyim yuvish belgisi", listOf("kiyim", "yuvish", "yorliq")),
            GeneralTopic("Mahsulot yaroqlilik muddatini nega tekshirish kerak?", "Muddat mahsulotni qachongacha ishlatish yoki iste'mol qilish bo'yicha muhim ko'rsatma beradi; saqlash shartlariga ham amal qil.", "yaroqlilik muddatini tekshirish", listOf("muddat", "mahsulot", "xavfsizlik")),
            GeneralTopic("Xarid ro'yxati nima uchun foydali?", "Xarid ro'yxati kerakli narsalarni unutmaslikka va rejasiz ortiqcha xaridlarni kamaytirishga yordam beradi.", "do'konga ro'yxat tuzish", listOf("xarid", "ro'yxat", "reja")),
            GeneralTopic("Kafolat nima?", "Kafolat — mahsulot yoki xizmat bo'yicha ma'lum shartlar doirasida ta'mirlash, almashtirish yoki boshqa yechimni nazarda tutishi mumkin bo'lgan majburiyat.", "mahsulot kafolati", listOf("kafolat", "xarid", "ta'mirlash")),
            GeneralTopic("Shartnomani imzolashdan oldin nima qilaman?", "Shartlarni to'liq o'qi, tushunmagan joyingni so'ra va nusxasini saqla. Muhim huquqiy masalada mutaxassisdan maslahat ol.", "shartnomani tekshirish", listOf("shartnoma", "huquq", "hujjat")),
            GeneralTopic("Rasmiy hujjatni qanday saqlash kerak?", "Hujjatni xavfsiz joyda saqla, kerak bo'lsa nusxasini alohida saqlab qo'y va shaxsiy ma'lumotlarni begonalarga yuborma.", "hujjatlarni saqlash", listOf("hujjat", "nusxa", "maxfiylik")),
            GeneralTopic("Shaxsiy ma'lumot nima?", "Shaxsiy ma'lumot odamni aniqlashga yordam beradigan ma'lumotdir, masalan to'liq ism, manzil yoki hisob ma'lumotlari. Uni faqat zarur va ishonchli joyda ulash.", "personal data ta'rifi", listOf("shaxsiy", "ma'lumot", "maxfiylik")),
            GeneralTopic("Internetda hurmat bilan yozish qanday?", "Aniq va muloyim yoz, haqoratdan qoch, boshqalarning shaxsiy ma'lumotini ruxsatsiz tarqatma va yuborishdan oldin xabarni qayta o'qi.", "internet odobi", listOf("internet", "odob", "muloqot")),
            GeneralTopic("Raqamli iz nima?", "Raqamli iz — internetda qoldiradigan post, izoh, qidiruv yoki boshqa faoliyat izlari. Joylayotgan narsang keyin ham ko'rinishi mumkinligini hisobga ol.", "digital footprint nima", listOf("raqamli iz", "internet", "maxfiylik")),
            GeneralTopic("Soxta profilni qanday payqash mumkin?", "Profil tarixini, g'ayrioddiy va'dalarni va shoshilinch pul yoki kod so'rashni tekshir. Shubha bo'lsa, shaxsni boshqa ishonchli yo'l bilan tasdiqla.", "fake profil belgilari", listOf("soxta profil", "firibgarlik", "hisob")),
            GeneralTopic("Onlayn xaridda nimaga qarayman?", "Sotuvchi obro'sini, mahsulot tavsifini, qaytarish shartlarini va xavfsiz to'lov usulini tekshir; shubhali oldindan to'lovlardan ehtiyot bo'l.", "internetdan xarid qilish", listOf("onlayn xarid", "sotuvchi", "to'lov")),
            GeneralTopic("Qayta aloqa nima?", "Qayta aloqa — ish yoki xatti-harakat haqida beriladigan fikr. Foydali qayta aloqa aniq, hurmatli va yaxshilash mumkin bo'lgan jihatni ko'rsatadi.", "feedback ta'rifi", listOf("qayta aloqa", "fikr", "rivojlanish")),
            GeneralTopic("Maqsadga erishishni qanday kuzataman?", "Maqsadni kichik bosqichlarga ajrat, bajarilgan ishni belgilab bor va rejangni haftada bir marta ko'rib chiq.", "natijani kuzatish", listOf("maqsad", "kuzatish", "reja")),
            GeneralTopic("Ustuvorlik nima?", "Ustuvorlik — qaysi ish muhimroq yoki shoshilinchroq ekanini belgilash. Avval muhim vazifalarga vaqt ajrat.", "prioritet nimani anglatadi", listOf("ustuvorlik", "vazifa", "vaqt")),
            GeneralTopic("Qiyin vazifani qanday boshlayman?", "Vazifani eng kichik bajariladigan qadamga bo'l va faqat shu qadamni boshlashga e'tibor ber.", "ishni boshlash qiyin", listOf("vazifa", "boshlash", "qadam")),
            GeneralTopic("Dam olish va ish muvozanati nima?", "Ish, o'qish, uyqu va dam olish uchun real vaqt ajrat. Doimiy charchoqni odatiy hol deb qabul qilma.", "muvozanatli kun tartibi", listOf("dam", "ish", "muvozanat")),
            GeneralTopic("Jamoada ishlash uchun nima muhim?", "Maqsadni kelishib ol, vazifalarni aniq taqsimla, bir-biringni tingla va muammolarni vaqtida muhokama qil.", "jamoaviy ish", listOf("jamoa", "hamkorlik", "vazifa")),
            GeneralTopic("Muammoni bosqichma-bosqich hal qilish qanday?", "Muammoni aniqlab yoz, sabablarni ajrat, bir nechta yechim o'ylab top, mosini tanla va natijani tekshir.", "muammo yechish qadamlari", listOf("muammo", "yechim", "qadam")),
            GeneralTopic("Statistika nima?", "Statistika ma'lumotlarni yig'ish, tartiblash, tahlil qilish va ulardan xulosa chiqarish usullarini o'rganadi.", "statistika ta'rifi", listOf("statistika", "ma'lumot", "tahlil")),
            GeneralTopic("O'rtacha qiymat nima?", "Arifmetik o'rtacha qiymat sonlarni qo'shib, ularning soniga bo'lish orqali topiladi.", "arifmetik o'rtacha qanday topiladi", listOf("o'rtacha", "matematika", "hisob")),
            GeneralTopic("Foiz nima?", "Foiz — yuzdan bir ulush. Masalan, 25 foiz = 25/100 = 0,25.", "prosent ta'rifi", listOf("foiz", "prosent", "ulush")),
            GeneralTopic("Chegirma qanday hisoblanadi?", "Chegirma summasi = boshlang'ich narx × chegirma foizi / 100. Yakuniy narx uchun chegirmani boshlang'ich narxdan ayir.", "foizli chegirma hisoblash", listOf("chegirma", "foiz", "narx")),
            GeneralTopic("Harorat va issiqlik farqi nima?", "Harorat jismning qanchalik issiq yoki sovuqligini ifodalaydi; issiqlik esa harorat farqi tufayli uzatiladigan energiyadir.", "issiqlik bilan harorat farqi", listOf("harorat", "issiqlik", "fizika")),
            GeneralTopic("Tovush qanday tarqaladi?", "Tovush tebranishlardan hosil bo'ladi va havo, suv yoki qattiq jism kabi muhit orqali tarqaladi; vakuumda odatiy tovush tarqalmaydi.", "tovush tarqalishi", listOf("tovush", "tebranish", "fizika")),
            GeneralTopic("Magnit nima qiladi?", "Magnit ayrim materiallarga, masalan temirga, kuch bilan ta'sir qiladi va magnit maydon hosil qiladi.", "magnit vazifasi", listOf("magnit", "temir", "maydon")),
            GeneralTopic("Atom nima?", "Atom kimyoviy elementning xususiyatlarini saqlaydigan eng kichik zarrachalaridan biri bo'lib, yadro va elektronlardan tashkil topadi.", "atom ta'rifi", listOf("atom", "kimyo", "zarrachalar")),
            GeneralTopic("Molekula nima?", "Molekula ikki yoki undan ortiq atomning kimyoviy bog'lanishi orqali hosil bo'lishi mumkin bo'lgan zarracha.", "molekula ta'rifi", listOf("molekula", "atom", "kimyo")),
            GeneralTopic("Kislorod nima uchun kerak?", "Kislorod ko'p organizmlarda hujayralarning energiya olish jarayonida muhim rol o'ynaydi.", "kislorodning vazifasi", listOf("kislorod", "nafas", "biologiya")),
            GeneralTopic("Fotosintez nima?", "Fotosintezda o'simliklar yorug'lik energiyasidan foydalanib, suv va karbonat angidriddan organik moddalar hosil qiladi.", "o'simlik oziqni qanday hosil qiladi", listOf("fotosintez", "o'simlik", "yorug'lik")),
            GeneralTopic("Oziq zanjiri nima?", "Oziq zanjiri ekotizimda energiya va oziq moddalarning organizmlar orasida o'tishini ko'rsatadi.", "oziq zanjiri ta'rifi", listOf("oziq zanjiri", "ekotizim", "tabiat")),
            GeneralTopic("Ekotizim nima?", "Ekotizim — tirik organizmlar va ular yashaydigan jonsiz muhitning o'zaro ta'sir qiladigan tizimi.", "ekotizim ta'rifi", listOf("ekotizim", "tabiat", "organizmlar")),
            GeneralTopic("Bakteriyalar nima?", "Bakteriyalar odatda bir hujayrali mikroorganizmlardir; ayrimlari foydali, ayrimlari esa kasallik keltirib chiqarishi mumkin.", "bakteriya nima", listOf("bakteriya", "mikroorganizm", "biologiya")),
            GeneralTopic("Virus va bakteriya bir xilmi?", "Yo'q. Bakteriyalar hujayrali organizmlar, viruslar esa ko'payish uchun mezbon hujayraga muhtoj bo'lgan zarrachalardir.", "virus bakteriyadan farqi", listOf("virus", "bakteriya", "farq")),
            GeneralTopic("Suyaklar nima uchun kerak?", "Suyaklar tanaga tayanch beradi, muhim a'zolarni himoya qiladi va mushaklar bilan birga harakatda qatnashadi.", "suyak vazifasi", listOf("suyak", "tana", "biologiya")),
            GeneralTopic("Yurakning vazifasi nima?", "Yurak qonni qon tomirlari bo'ylab haydaydi va to'qimalarga kislorod hamda moddalar yetkazilishiga yordam beradi.", "yurak nima qiladi", listOf("yurak", "qon", "tana")),
            GeneralTopic("O'pkaning vazifasi nima?", "O'pka nafas olishda kislorodning qonga o'tishi va karbonat angidridning tashqariga chiqarilishida qatnashadi.", "o'pka nima qiladi", listOf("o'pka", "nafas", "kislorod")),
            GeneralTopic("Ovqat hazm qilish nima?", "Ovqat hazm qilish tizimi ovqatni parchalaydi, oziq moddalarni so'rishga va qoldiqlarni chiqarishga yordam beradi.", "hazm qilish ta'rifi", listOf("hazm", "ovqat", "tana")),
            GeneralTopic("Muvozanatli ovqatlanish nima?", "Turli oziq guruhlaridan yetarli miqdorda iste'mol qilish, meva-sabzavot, oqsil va don mahsulotlarini muvozanatlash foydali.", "sog'lom ovqatlanish asoslari", listOf("ovqatlanish", "muvozanat", "salomatlik")),
            GeneralTopic("Suvsizlanish nima?", "Suvsizlanish tanada suyuqlik yetishmasligi holatidir. Chanqoq, og'iz qurishi yoki holsizlik bo'lishi mumkin; og'ir holatda tibbiy yordam kerak.", "suvsizlanish belgilari", listOf("suvsizlanish", "suv", "salomatlik")),
            GeneralTopic("Stressni kamaytirish uchun nima qilish mumkin?", "Tinch nafas olish, qisqa tanaffus, yengil harakat va ishonchli odam bilan gaplashish yordam berishi mumkin. Uzoq davom etsa, yordam so'ra.", "stressni yengillashtirish", listOf("stress", "tanaffus", "salomatlik")),
            GeneralTopic("Hissiyotlarni nomlash nima uchun foydali?", "Hissiyotni nomlash vaziyatni tushunishga va unga mos javob tanlashga yordam beradi; masalan, 'jahlim chiqdi' yoki 'xavotirdaman' deb aytish.", "hislarni tushunish", listOf("hissiyot", "kayfiyat", "tushunish")),
            GeneralTopic("Shaxsiy chegara nima?", "Shaxsiy chegara — odam o'ziga qanday munosabat va xatti-harakat maqbul ekanini belgilaydigan qoida. Uni hurmat bilan tushuntirish mumkin.", "shaxsiy chegaralar", listOf("chegara", "hurmat", "muloqot")),
            GeneralTopic("Rozilik nima?", "Rozilik — biror ishga erkin, tushungan holda va bosimsiz rozi bo'lish. Odam istalgan payt fikrini o'zgartirishi mumkin.", "rozilik ta'rifi", listOf("rozilik", "hurmat", "xavfsizlik")),
            GeneralTopic("Vaqtida kelish nima uchun muhim?", "Vaqtida kelish boshqalarning vaqtini hurmat qilishga va kelishilgan ishlarni tartibli bajarishga yordam beradi.", "punktuallik foydasi", listOf("vaqt", "hurmat", "mas'uliyat")),
            GeneralTopic("Mas'uliyat nima?", "Mas'uliyat — o'z vazifasi va qarorlarining oqibatini tushunish hamda imkon qadar bajarishga tayyor bo'lish.", "mas'uliyat ta'rifi", listOf("mas'uliyat", "vazifa", "qaror")),
            GeneralTopic("Qiziqish va qobiliyat farqi nima?", "Qiziqish — nimaga moyilliging yoki yoqtirishing; qobiliyat esa muayyan ishni bajarishga yordam beradigan ko'nikma yoki salohiyat.", "qiziqish qobiliyatdan farqi", listOf("qiziqish", "qobiliyat", "ko'nikma")),
            GeneralTopic("Ko'nikma qanday rivojlanadi?", "Ko'nikma maqsadli mashq, xatolarni tahlil qilish va muntazam qayta urinish orqali rivojlanadi.", "yangi ko'nikma hosil qilish", listOf("ko'nikma", "mashq", "rivojlanish")),
            GeneralTopic("Kreativ fikrlash nima?", "Kreativ fikrlash muammoga turli tomondan qarash va yangi g'oyalar ishlab chiqish qobiliyatidir.", "ijodiy fikrlash ta'rifi", listOf("kreativ", "ijod", "g'oya")),
            GeneralTopic("Tanqidiy fikrlash nima?", "Tanqidiy fikrlash da'vo va dalillarni tekshirish, taxminlarni ajratish va asosli xulosa chiqarishni anglatadi.", "kritik fikrlash ta'rifi", listOf("tanqidiy", "dalil", "xulosa")),
            GeneralTopic("Maqsadni o'lchab bo'ladigan qilish nima?", "Maqsadga aniq natija va muddat qo'sh. Masalan, 'ko'proq o'qiyman' o'rniga 'bugun 10 bet o'qiyman' deb yoz.", "aniq maqsad qo'yish", listOf("maqsad", "o'lchash", "muddat")),
            GeneralTopic("Odatni qanday saqlab qolaman?", "Odatni kichik qil, uni bir vaqtda bajarishga harakat qil va bajarilgan kunlarni belgilab bor. Bir kun o'tkazib yuborsang, qaytadan boshlagin.", "odatni davom ettirish", listOf("odat", "muntazamlik", "reja")),
            GeneralTopic("Yordam so'rash zaiflikmi?", "Yo'q. Vaziyatni yolg'iz hal qilish qiyin bo'lsa, ishonchli odamdan yordam so'rash oqilona va mas'uliyatli qadam bo'lishi mumkin.", "yordam so'rash haqida", listOf("yordam", "ishonch", "maslahat")),
            GeneralTopic("Shukronalik odati nima?", "Har kuni minnatdor bo'lgan bir yoki ikki narsani eslash ijobiy jihatlarni payqashga yordam berishi mumkin.", "shukronalikni mashq qilish", listOf("shukronalik", "odat", "kayfiyat")),
            GeneralTopic("Jamoat joyida axlat tashlash nega noto'g'ri?", "Axlatni belgilangan joyga tashlash atrof-muhitni toza saqlaydi va boshqalarga hurmatni ko'rsatadi.", "jamoat joyida tozalik", listOf("axlat", "tozalik", "odob")),
            GeneralTopic("Madaniy meros nima?", "Madaniy meros — avlodlardan qolgan tarixiy obidalar, urf-odatlar, san'at, til va boshqa qadriyatlar majmuasi.", "madaniy meros ta'rifi", listOf("madaniyat", "tarix", "meros")),
            GeneralTopic("Muzey nima uchun kerak?", "Muzey tarixiy buyumlar, san'at asarlari yoki ilmiy namunalarni saqlash, o'rganish va jamoatchilikka ko'rsatish uchun xizmat qiladi.", "muzey vazifasi", listOf("muzey", "tarix", "madaniyat")),
            GeneralTopic("Kutubxonadan qanday foydalanaman?", "Kerakli mavzuni katalogdan qidir, kitobni olish qoidalarini bilib ol va qaytarish muddatiga amal qil.", "kutubxona bilan ishlash", listOf("kutubxona", "kitob", "o'qish")),
            GeneralTopic("Manzilni aniq yozish nima uchun muhim?", "Aniq manzil yetkazib berish, uchrashuv yoki favqulodda yordamda kerakli joyni topishni osonlashtiradi.", "manzilni to'g'ri ko'rsatish", listOf("manzil", "joy", "aloqa")),
            GeneralTopic("Valyuta kursi nima?", "Valyuta kursi bir mamlakat pul birligining boshqa pul birligiga nisbatan qiymatini bildiradi va vaqt o'tishi bilan o'zgarishi mumkin.", "valyuta kursi ta'rifi", listOf("valyuta", "kurs", "pul")),
            GeneralTopic("Inflyatsiya nima?", "Inflyatsiya — iqtisodiyotda tovar va xizmatlarning umumiy narx darajasi vaqt o'tishi bilan oshishi jarayoni.", "inflyatsiya ta'rifi", listOf("inflyatsiya", "narx", "iqtisod")),
            GeneralTopic("Bank kartasi PIN-kodini kimga aytish mumkin?", "PIN-kodni hech kimga aytma va kartaga yozib qo'yma. Bank xodimi ham PIN-kodingni so'ramasligi kerak.", "karta pin kodini himoyalash", listOf("bank", "karta", "pin", "xavfsizlik")),
            GeneralTopic("Pul o'tkazmasini tekshirish nima uchun kerak?", "Pul yuborishdan oldin oluvchi ma'lumotlari va summani qayta tekshir; tasdiqdan keyin kvitansiyani saqla.", "pul o'tkazishdan oldin", listOf("pul", "o'tkazma", "to'lov")),
            GeneralTopic("Mahsulot narxlarini qanday solishtiraman?", "Bir xil hajm yoki miqdor uchun narxni solishtir, sifat, yetkazish va kafolat shartlarini ham hisobga ol.", "narxlarni solishtirish", listOf("narx", "xarid", "taqqoslash")),
            GeneralTopic("Qadoqdagi o'lchov birligi nima uchun muhim?", "Narxlarni adolatli solishtirish uchun mahsulotning og'irligi, hajmi yoki dona sonini tekshir.", "mahsulot miqdorini solishtirish", listOf("qadoq", "miqdor", "narx")),
            GeneralTopic("Mahalliy urf-odatlarga hurmat qanday ko'rsatiladi?", "Boshqa odamlarning odatlari haqida muloyim so'ra, kamsitishdan qoch va vaziyatga mos hurmatli muomala qil.", "urf odatga hurmat", listOf("urf-odat", "madaniyat", "hurmat")),
            GeneralTopic("Til va lahja farqi nima?", "Til kengroq aloqa tizimi; lahja esa tilning ma'lum hudud yoki jamoaga xos talaffuz va so'zlashuv xususiyatlariga ega ko'rinishi.", "lahja ta'rifi", listOf("til", "lahja", "so'zlashuv")),
            GeneralTopic("Tarixiy manba nima?", "Tarixiy manba o'tmish haqida ma'lumot beradigan hujjat, buyum, yozuv yoki guvohlik bo'lishi mumkin.", "tarixiy manba ta'rifi", listOf("tarix", "manba", "hujjat")),
            GeneralTopic("Vaqt mintaqasi nima?", "Vaqt mintaqasi Yer yuzidagi hududlar uchun mahalliy vaqtni belgilashda ishlatiladigan geografik va ma'muriy tizimdir.", "time zone nima", listOf("vaqt", "mintaqa", "geografiya")),
            GeneralTopic("Koordinata nima?", "Koordinatalar nuqtaning joylashuvini belgilashga yordam beradi; geografiyada kenglik va uzunlik ishlatiladi.", "geografik koordinata", listOf("koordinata", "kenglik", "uzunlik")),
            GeneralTopic("Materik nima?", "Materik — Yer yuzidagi juda katta quruqlik massivi. Materiklarni ajratish usuli geografik an'anaga qarab farq qilishi mumkin.", "materik ta'rifi", listOf("materik", "geografiya", "quruqlik")),
            GeneralTopic("Okean nima?", "Okean — Yer yuzasining katta qismini egallagan sho'r suv havzasi.", "okean ta'rifi", listOf("okean", "suv", "geografiya")),
            GeneralTopic("Daryo nima?", "Daryo — o'zani bo'ylab oqadigan tabiiy suv oqimi.", "daryo ta'rifi", listOf("daryo", "suv", "geografiya")),
            GeneralTopic("Cho'l nima?", "Cho'l — yog'ingarchilik kam bo'lgan va o'simliklar siyrak o'sadigan tabiiy hudud.", "cho'l ta'rifi", listOf("cho'l", "iqlim", "tabiat")),
            GeneralTopic("Tog' nima?", "Tog' — atrofdagi hududdan balandroq ko'tarilgan tabiiy relyef shakli.", "tog' ta'rifi", listOf("tog'", "relyef", "geografiya")),
            GeneralTopic("Zilzila nima?", "Zilzila — Yer po'stida to'plangan energiya ajralishi natijasida yer yuzasining silkinishi.", "zilzila ta'rifi", listOf("zilzila", "yer", "tabiiy hodisa")),
            GeneralTopic("Vulqon nima?", "Vulqon — Yer ichkarisidagi magma, gaz va boshqa materiallar yuzaga chiqishi mumkin bo'lgan geologik tuzilma.", "vulqon ta'rifi", listOf("vulqon", "magma", "geologiya")),
            GeneralTopic("Qazilma boylik nima?", "Qazilma boylik — Yer qa'ridan olinadigan foydali tabiiy resurs, masalan ayrim rudalar, ko'mir yoki tabiiy gaz.", "foydali qazilma ta'rifi", listOf("qazilma", "resurs", "yer")),
            GeneralTopic("Qayta tiklanuvchi energiya nima?", "Quyosh, shamol va oqayotgan suvdan olinadigan energiya manbalari tabiiy ravishda qayta tiklanishi mumkin.", "qayta tiklanuvchi energiya", listOf("energiya", "quyosh", "shamol")),
            GeneralTopic("Quyosh paneli nima qiladi?", "Quyosh paneli yorug'lik energiyasining bir qismini elektr energiyasiga aylantiradi.", "quyosh paneli vazifasi", listOf("quyosh paneli", "elektr", "energiya")),
            GeneralTopic("Batareyani qanday asrash mumkin?", "Qurilmani haddan tashqari issiqda qoldirma, mos zaryadlovchidan foydalan va ishlab chiqaruvchi tavsiyalariga amal qil.", "telefon batareyasini asrash", listOf("batareya", "zaryad", "telefon")),
            GeneralTopic("Elektron chiqindi nima?", "Elektron chiqindi — ishlatilmay qolgan telefon, kompyuter va boshqa elektron qurilmalar. Ularni imkon bo'lsa maxsus yig'ish joyiga topshir.", "eski elektronika qayerga topshiriladi", listOf("elektron chiqindi", "qurilma", "qayta ishlash")),
            GeneralTopic("Ochiq manbali dastur nima?", "Ochiq manbali dastur kodini litsenziya shartlariga ko'ra ko'rish, o'zgartirish yoki tarqatish mumkin.", "open source nima", listOf("ochiq kod", "dastur", "litsenziya")),
            GeneralTopic("Brauzer nima?", "Brauzer veb-sahifalarni ochish va internetdagi ma'lumotlarni ko'rish uchun ishlatiladigan dastur.", "internet brauzeri ta'rifi", listOf("brauzer", "veb", "internet")),
            GeneralTopic("Qidiruv tizimi nima?", "Qidiruv tizimi so'rovga mos veb-sahifalar yoki boshqa ma'lumotlarni topishga yordam beradi.", "search engine nima", listOf("qidiruv", "internet", "ma'lumot")),
            GeneralTopic("Elektron pochta nima?", "Elektron pochta internet orqali xabar va fayllarni yuborish hamda qabul qilish xizmatidir.", "email ta'rifi", listOf("email", "pochta", "xabar")),
            GeneralTopic("Spam nima?", "Spam — ko'pincha ommaviy yoki istalmagan xabarlar. Shubhali ilovalar va havolalarni ochmaslik ma'qul.", "spam xabar nima", listOf("spam", "xabar", "internet")),
            GeneralTopic("Ilovaga ruxsat berishda nimani tekshiraman?", "Ilova so'rayotgan ruxsat uning vazifasiga mosmi, tekshir. Keraksiz kamera, mikrofon yoki joylashuv ruxsatlarini bermaslik mumkin.", "app permissions xavfsizligi", listOf("ruxsat", "ilova", "maxfiylik")),
            GeneralTopic("Oflayn ilova nima?", "Oflayn ilova asosiy vazifalarining kamida bir qismini internet ulanmasdan bajarishi mumkin.", "offline app nima", listOf("oflayn", "internet", "ilova")),
            GeneralTopic("Server nima?", "Server boshqa qurilmalar yoki dasturlarga ma'lumot va xizmat taqdim etadigan kompyuter yoki dasturiy tizimdir.", "server ta'rifi", listOf("server", "tarmoq", "xizmat")),
            GeneralTopic("Bulutli saqlash nima?", "Bulutli saqlash fayllarni internet orqali masofadagi serverlarda saqlash va turli qurilmalardan ochish imkonini beradi.", "cloud storage nima", listOf("bulut", "fayl", "internet")),
            GeneralTopic("LAN nima?", "LAN — uy, maktab yoki ofis kabi cheklangan hududdagi qurilmalarni bog'laydigan mahalliy tarmoq.", "lan tarmog'i ta'rifi", listOf("lan", "mahalliy tarmoq", "kompyuter")),
            GeneralTopic("Router nima qiladi?", "Router turli tarmoqlar orasida ma'lumot paketlarini yo'naltiradi; uyda ko'pincha qurilmalarni mahalliy tarmoqqa va internetga ulaydi.", "router vazifasi", listOf("router", "wifi", "tarmoq")),
            GeneralTopic("Dasturiy xato nima?", "Dasturiy xato — dastur kutilganidek ishlamasligiga olib keladigan kod yoki loyihadagi muammo.", "bug nima", listOf("bug", "kod", "dastur")),
            GeneralTopic("Yangilanishdan oldin nima qilish foydali?", "Muhim fayllarni zaxiralash, yetarli bo'sh joy va batareya borligini tekshirish foydali.", "update oldidan tayyorgarlik", listOf("yangilash", "zaxira", "telefon")),
            GeneralTopic("Raqamli fayl nomini qanday tanlayman?", "Fayl nomini qisqa va mazmunli qil, sana yoki versiya kerak bo'lsa qo'sh, chalkash belgilarni ishlatmaslikka harakat qil.", "fayl nomlash qoidasi", listOf("fayl", "nom", "tartib")),
            GeneralTopic("Versiya raqami nima?", "Versiya raqami dastur yoki faylning qaysi nashri ekanini ajratishga yordam beradi.", "version raqami", listOf("versiya", "dastur", "yangilash")),
            GeneralTopic("Ilova hajmi nimaga bog'liq?", "Ilova hajmiga kod, rasmlar, audio, kutubxonalar, til fayllari va ichiga qo'shilgan ma'lumotlar ta'sir qiladi.", "apk hajmi nima bilan oshadi", listOf("ilova", "hajm", "apk")),
            GeneralTopic("Siqilgan ZIP fayl nima?", "ZIP bir nechta faylni bitta arxivga jamlaydi va ayrim ma'lumotlarni siqib, uzatish yoki saqlashni qulaylashtiradi.", "zip arxiv ta'rifi", listOf("zip", "arxiv", "fayl")),
            GeneralTopic("Faylni ochishdan oldin nimaga e'tibor beraman?", "Faylni ishonchli manbadan ol, turi va nomini tekshir, shubhali dasturlarni o'rnatma va muhim fayllarni zaxirala.", "noma'lum fayl xavfsizligi", listOf("fayl", "xavfsizlik", "virus")),
            GeneralTopic("Kompyuter virusi nima?", "Kompyuter virusi zararli kod bo'lib, boshqa fayl yoki tizimlarga tarqalishi mumkin. Dasturlarni ishonchli manbalardan ol.", "virus nima", listOf("virus", "kompyuter", "xavfsizlik")),
            GeneralTopic("Antivirus nima?", "Antivirus zararli dasturlarni aniqlash, bloklash yoki olib tashlashga yordam beradigan xavfsizlik dasturidir.", "antivirus vazifasi", listOf("antivirus", "zararli dastur", "himoya")),
            GeneralTopic("Ekran yorqinligini qanday tanlayman?", "Yorqinlikni atrofdagi yorug'likka mosla; qorong'i xonada juda yorqin ekran ko'zni noqulay qilishi mumkin.", "telefon yorqinligi", listOf("ekran", "yorqinlik", "telefon")),
            GeneralTopic("Telefon qizib ketsa nima qilaman?", "Og'ir ilovani to'xtat, qurilmani quyoshdan ol va sovishini kut. Sovitish uchun muzlatkichga qo'yma; tez-tez qizisa servisga ko'rsat.", "telefon qizib ketishi", listOf("telefon", "qizish", "batareya")),
            GeneralTopic("Qurilma qotib qolsa nima qilaman?", "Biroz kut, keraksiz ilovalarni yoping va qayta ishga tushirishni ko'rib chiq. Muhim ma'lumotni saqlash odatini yo'lga qo'y.", "telefon qotishi", listOf("qotish", "telefon", "ilova")),
            GeneralTopic("Ilova javob bermasa nima qilaman?", "Ilovani yopib qayta och, qurilmani qayta ishga tushir va yangilanish borligini tekshir. Muammo davom etsa, xato xabarini yozib ol.", "app ishlamay qolsa", listOf("ilova", "xato", "qayta ochish")),
            GeneralTopic("Texnik yordamga qanday ma'lumot beraman?", "Qurilma modeli, ilova versiyasi, xato matni va muammo qachon yuz berishini ayt; parol yoki maxfiy kodlarni yuborma.", "supportga muammoni tushuntirish", listOf("texnik yordam", "xato", "qurilma")),
            GeneralTopic("Kundalik xarajatni qayd qilish foydalimi?", "Xarajatlarni yozish pul qayerga ketayotganini ko'rishga va keyingi reja tuzishga yordam beradi.", "xarajatlarni hisoblash", listOf("xarajat", "pul", "hisob")),
            GeneralTopic("Maqsadlar ro'yxati qanday bo'lishi kerak?", "Ro'yxatni qisqa tut, muhimlarini yuqoriga qo'y va har bir maqsad uchun keyingi aniq qadamni yoz.", "maqsadlar ro'yxati", listOf("maqsad", "ro'yxat", "reja")),
            GeneralTopic("Kun yakunini qanday tahlil qilaman?", "Bugun nimalar bajarilganini, nimasi qiyin bo'lganini va ertaga qilinadigan bitta muhim ishni yozib chiq.", "kunni tahlil qilish", listOf("kun", "tahlil", "reja")),
            GeneralTopic("Kichik yutuqlarni qayd qilish nega foydali?", "Kichik yutuqlarni yozish taraqqiyotni ko'rishga va odatni davom ettirishga yordam berishi mumkin.", "yutuqlarni yozib borish", listOf("yutuq", "odat", "taraqqiyot")),
            GeneralTopic("O'rganilgan narsani boshqaga tushuntirish foydalimi?", "Ha, o'z so'zing bilan tushuntirish mavzuni qanchalik tushunganingni ko'rsatadi va bo'sh joylarni topishga yordam beradi.", "o'rgangan narsani tushuntirish", listOf("o'rganish", "tushuntirish", "xotira")),
            GeneralTopic("Savolni aniq berish qanday?", "Nimani bilmoqchi ekaningni qisqa yoz, kerakli kontekstni qo'sh va qanday javob kerakligini ayt.", "aniq savol tuzish", listOf("savol", "muloqot", "aniqlik")),
            GeneralTopic("Javobni tushunmasam nima qilaman?", "Tushunmagan joyni aniq ko'rsatib, sodda tilda yoki misol bilan qayta tushuntirishni so'ra.", "tushunmagan narsani so'rash", listOf("tushunish", "savol", "misol")),
            GeneralTopic("Turli fikrlar bilan qanday muomala qilaman?", "Avval dalillarni tingla, odamni fikridan ajrat va kelishmagan joyingni hurmat bilan tushuntir.", "fikrlar farqiga munosabat", listOf("fikr", "hurmat", "munozara")),
            GeneralTopic("Bahsda dalil nima uchun kerak?", "Dalil fikrni tekshirishga yordam beradi; faqat ovozni balandlatish yoki odamni haqorat qilish masalani hal qilmaydi.", "bahsda dalil ishlatish", listOf("dalil", "bahs", "fikr")),
            GeneralTopic("Qarorni qayta ko'rib chiqish mumkinmi?", "Yangi dalil yoki sharoit paydo bo'lsa, qarorni qayta baholash oqilona. Muhimi, sababni tushunib, oqibatini hisobga olish.", "qarorni o'zgartirish", listOf("qaror", "dalil", "o'zgarish")),
            GeneralTopic("O'zgarishga moslashish nima?", "Moslashish — yangi sharoitni tushunib, kerakli reja yoki odatlarni o'zgartira olish.", "moslashuv ta'rifi", listOf("moslashish", "o'zgarish", "reja")),
            GeneralTopic("Sabr nima?", "Sabr — qiyin vaziyatda o'ylab ish tutish, shoshqaloqlikni kamaytirish va maqsad yo'lida izchil qolishga intilish.", "sabr ta'rifi", listOf("sabr", "xulq", "maqsad")),
            GeneralTopic("Minnatdorchilikni qanday bildirish mumkin?", "Yordam uchun aniq rahmat ayt, qanday foyda berganini aytish ham minnatdorchilikni samimiy qiladi.", "rahmat aytish odobi", listOf("rahmat", "minnatdorchilik", "odob")),
            GeneralTopic("Va'daga vafo nima?", "Va'da berishdan oldin imkoningni bahola; bajara olmasang, imkon qadar erta xabar ber va vaziyatni tushuntir.", "va'dani bajarish", listOf("va'da", "mas'uliyat", "ishonch")),
            GeneralTopic("Sir saqlashda nima muhim?", "Boshqa odamning shaxsiy gapini ruxsatsiz tarqatma, lekin kimdir xavf ostida bo'lsa, ishonchli kattadan yordam so'rash muhim bo'lishi mumkin.", "sir va maxfiylik", listOf("sir", "ishonch", "maxfiylik")),
            GeneralTopic("Do'stlikda hurmat qanday ko'rinadi?", "Bir-birini tinglash, chegaralarni hurmat qilish, rostgo'y bo'lish va kelishmovchilikni tinch muhokama qilish do'stlikni mustahkamlaydi.", "do'stlik odobi", listOf("do'stlik", "hurmat", "ishonch")),
            GeneralTopic("Boshqalarning vaqtini hurmat qilish qanday?", "Uchrashuvga kelishilgan vaqtda bor, kechiksang oldindan xabar ber va suhbatda odamning vaqtini hisobga ol.", "vaqtni hurmat qilish", listOf("vaqt", "hurmat", "uchrashuv")),
            GeneralTopic("Shaxsiy narsani qarzga olish odobi qanday?", "Avval ruxsat so'ra, kelishilgan vaqtda qaytar va buyumga ehtiyotkorlik bilan munosabatda bo'l.", "birovning buyumini olish", listOf("ruxsat", "buyum", "hurmat")),
            GeneralTopic("Jamoat joyida telefon ishlatish odobi qanday?", "Baland ovozda gaplashma, boshqalarning suratini ruxsatsiz olma va xavfsizlik talab qiladigan vaziyatda ekranga chalg'ima.", "telefon odobi", listOf("telefon", "jamoat", "odob")),
            GeneralTopic("Sayohatga chiqishdan oldin nima tayyorlayman?", "Manzil, transport va vaqtni tekshir, kerakli hujjatlarni tayyorla, ob-havoni ko'r va yaqinlaringga rejangni bildir.", "sayohatga tayyorgarlik", listOf("sayohat", "hujjat", "reja")),
            GeneralTopic("Yo'qolgan buyumni topsam nima qilaman?", "Buyumni egasiga qaytarishga harakat qil yoki mas'ul xodimga topshir; ichidagi shaxsiy ma'lumotni tarqatma.", "topilgan buyum bilan nima qilish", listOf("buyum", "egasi", "halollik")),
            GeneralTopic("Ko'ngilli yordam nima?", "Ko'ngilli yordam — odam yoki jamoaga o'z xohishi bilan vaqt va kuch ajratib yordam berish.", "volontyorlik ta'rifi", listOf("ko'ngilli", "yordam", "jamoa")),
            GeneralTopic("Xayriya qilishda nimaga e'tibor beraman?", "Tashkilot yoki yordam so'rayotgan shaxsning ishonchliligini tekshir va o'z imkoningga mos yordamni tanla.", "xayriyani xavfsiz qilish", listOf("xayriya", "ishonch", "yordam")),
            GeneralTopic("Tabiiy resurs nima?", "Tabiiy resurs — inson foydalanishi mumkin bo'lgan suv, tuproq, o'rmon, quyosh yoki foydali qazilma kabi tabiat boyligi.", "tabiiy resurs ta'rifi", listOf("resurs", "tabiat", "boylik")),
            GeneralTopic("Biologik xilma-xillik nima?", "Biologik xilma-xillik tirik organizmlar, ularning genetik farqlari va yashash ekotizimlarining rang-barangligini bildiradi.", "biodiversity ta'rifi", listOf("biologik xilma-xillik", "tabiat", "ekotizim")),
            GeneralTopic("Ifloslanish nima?", "Ifloslanish — havo, suv yoki tuproqqa zararli modda yoki ortiqcha chiqindilar tushib, muhit sifatini yomonlashtirishi.", "atrof muhit ifloslanishi", listOf("ifloslanish", "havo", "suv")),
            GeneralTopic("Havo sifati nima uchun muhim?", "Toza havo nafas olish va umumiy salomatlik uchun muhim; tutun ko'p joylarda imkon bo'lsa ifloslanish manbasidan uzoqroq tur.", "havo sifatining ahamiyati", listOf("havo", "salomatlik", "ifloslanish")),
            GeneralTopic("Suv aylanishi nima?", "Suv aylanishida suv bug'lanadi, kondensatsiyalanadi, yog'in bo'lib tushadi va yer usti yoki yer osti orqali harakatlanadi.", "suv aylanishi bosqichlari", listOf("suv", "bug'lanish", "tabiat")),
            GeneralTopic("Yerning ichki tuzilishi qanday?", "Yerning asosiy qatlamlari po'st, mantiya va yadrodan iborat; ularning tarkibi va xususiyatlari bir-biridan farq qiladi.", "yer qatlamlari", listOf("yer", "po'st", "mantiya", "yadro")),
            GeneralTopic("Oy Yer atrofida aylanadimi?", "Ha, Oy Yer atrofida aylanadi; shu bilan birga, Yer va Oy umumiy massa markazi atrofida harakatlanadi.", "oy yer atrofida harakatlanishi", listOf("oy", "yer", "orbita")),
            GeneralTopic("Yulduz va sayyora farqi nima?", "Yulduz o'z ichida energiya ishlab, yorug'lik chiqaradi; sayyora esa yulduz atrofida aylanadi va odatda o'zidan yulduz kabi yorug'lik chiqarmaydi.", "sayyora yulduzdan farqi", listOf("yulduz", "sayyora", "koinot")),
            GeneralTopic("Galaktika nima?", "Galaktika — gravitatsiya bilan bog'langan yulduzlar, gaz, chang va boshqa moddalar tizimi.", "galaktika ta'rifi", listOf("galaktika", "yulduz", "koinot")),
            GeneralTopic("Kosmosda vaznsizlik nimani anglatadi?", "Orbita atrofida erkin tushish holatida jismlar va odamlar tayanch kuchini juda kam sezadi; shu sabab vaznsizlikka o'xshash holat yuz beradi.", "kosmosda vaznsizlik", listOf("kosmos", "orbita", "gravitatsiya")),
            GeneralTopic("Mantiqiy xulosa nima?", "Mantiqiy xulosa berilgan dalillar yoki shartlardan izchil fikrlash orqali kelib chiqadigan natijadir.", "xulosa chiqarish", listOf("mantiq", "dalil", "xulosa")),
            GeneralTopic("Taxmin va fakt farqi nima?", "Fakt dalil bilan tekshirilishi mumkin bo'lgan ma'lumot; taxmin esa hali yetarlicha tasdiqlanmagan fikr bo'lishi mumkin.", "fakt bilan taxmin farqi", listOf("fakt", "taxmin", "dalil")),
            GeneralTopic("Manba sanasi nima uchun muhim?", "Ayrim ma'lumotlar tez o'zgaradi; sanani tekshirish ma'lumot hali dolzarbmi, tushunishga yordam beradi.", "ma'lumot sanasini tekshirish", listOf("sana", "manba", "dolzarblik")),
            GeneralTopic("Bir nechta manbani solishtirish nima beradi?", "Mustaqil va ishonchli manbalarni solishtirish xatolarni payqash va bir tomonlama ma'lumotga berilib ketmaslikka yordam beradi.", "manbalarni taqqoslash", listOf("manba", "tekshirish", "dalil")),
            GeneralTopic("Ommaviy axborot savodxonligi nima?", "Bu xabarlarni tanqidiy baholash, manbani tekshirish va fakt bilan fikrni farqlash ko'nikmalaridir.", "media savodxonlik ta'rifi", listOf("media", "axborot", "savodxonlik")),
            GeneralTopic("Reklama va tavsiya farqi nima?", "Reklama mahsulot yoki xizmatni targ'ib qiladi; tavsiya esa tajriba yoki ehtiyoj asosida berilishi mumkin. Har ikkisida manfaatlar bo'lishi mumkinligini hisobga ol.", "reklamani ajratish", listOf("reklama", "tavsiya", "manfaat")),
            GeneralTopic("So'rovnoma natijasini qanday tushunaman?", "Savollar kimlarga berilgani, tanlanma hajmi va usuli natijaga ta'sir qiladi; kichik yoki bir tomonlama so'rov hammani ifodalamasligi mumkin.", "so'rovnoma natijasi", listOf("so'rovnoma", "statistika", "tanlanma")),
            GeneralTopic("Diagramma nima uchun ishlatiladi?", "Diagramma ma'lumotlarni ko'rgazmali ko'rsatadi; o'qlar, birliklar va miqyosni tekshirish to'g'ri talqin qilishga yordam beradi.", "diagramma o'qish", listOf("diagramma", "ma'lumot", "grafik")),
            GeneralTopic("Foizli o'zgarish nima?", "Foizli o'zgarish = (yangi qiymat − eski qiymat) / eski qiymat × 100%; eski qiymat nol bo'lsa, bu formula ishlamaydi.", "foizli o'zgarishni hisoblash", listOf("foiz", "o'zgarish", "hisob")),
            GeneralTopic("Masofa va tezlik munosabati qanday?", "Bir xil tezlikda masofa = tezlik × vaqt. Birliklarni bir xil tizimga keltirish kerak.", "masofani hisoblash", listOf("masofa", "tezlik", "vaqt")),
            GeneralTopic("Zichlik nima?", "Zichlik massa bilan hajm nisbatidir: zichlik = massa / hajm.", "zichlik formulasi", listOf("zichlik", "massa", "hajm")),
            GeneralTopic("Bosim nima?", "Bosim — sirtga tik ta'sir qiladigan kuchning shu sirt maydoniga nisbatidir.", "bosim ta'rifi", listOf("bosim", "kuch", "fizika")),
            GeneralTopic("Ish va energiya nima?", "Fizikada ish kuch ta'sirida siljish bilan bog'liq; energiya esa ish bajarish qobiliyatini ifodalovchi kattalikdir.", "fizikada ish energiya", listOf("ish", "energiya", "fizika")),
            GeneralTopic("Yorug'lik tezligi nima uchun muhim?", "Vakuumdagi yorug'lik tezligi taxminan sekundiga 300 ming kilometr bo'lib, fizikaning asosiy doimiylaridan biridir.", "yorug'lik tezligi", listOf("yorug'lik", "tezlik", "fizika")),
            GeneralTopic("Ranglar qanday ko'rinadi?", "Jismdan qaytgan yoki o'tgan yorug'likning turli to'lqin uzunliklari ko'zga turlicha ta'sir qilgani uchun ranglarni ko'ramiz.", "rang ko'rish sababi", listOf("rang", "yorug'lik", "ko'z")),
            GeneralTopic("Ko'zoynak nima uchun ishlatiladi?", "Ko'zoynak ko'rishni tuzatish yoki ko'zni ayrim tashqi ta'sirlardan himoyalash uchun ishlatiladi; mos turini mutaxassis tavsiyasi bilan tanlash mumkin.", "ko'zoynak vazifasi", listOf("ko'zoynak", "ko'rish", "himoya")),
            GeneralTopic("Eshitish vositasining ovozini qanday tanlayman?", "Ovozni qulay darajada tut, uzoq vaqt baland ovozda tinglashdan saqlan va quloqda noqulaylik bo'lsa tanaffus qil.", "quloqchin ovoz xavfsizligi", listOf("quloqchin", "ovoz", "eshitish")),
            GeneralTopic("Qayta foydalanish nima?", "Qayta foydalanish buyumni tashlab yuborish o'rniga uni yana ishlatishdir; bu chiqindini kamaytirishi mumkin.", "re-use ta'rifi", listOf("qayta foydalanish", "chiqindi", "buyum")),
            GeneralTopic("Ta'mirlash va almashtirishni qanday tanlayman?", "Narx, xavfsizlik, ehtiyot qism mavjudligi va buyumning qolgan xizmat muddatini solishtirib qaror qil.", "ta'mirlash yoki yangisini olish", listOf("ta'mirlash", "almashtirish", "xarajat")),
            GeneralTopic("Uy jihozidan foydalanish yo'riqnomasi nima uchun kerak?", "Yo'riqnoma qurilmani to'g'ri va xavfsiz ishlatish, parvarish qilish va muammolarni kamaytirishga yordam beradi.", "qo'llanmani o'qish", listOf("yo'riqnoma", "jihoz", "xavfsizlik")),
            GeneralTopic("Oziq-ovqat tarkibidagi yorliqni qanday o'qiyman?", "Tarkib ro'yxati va oziq qiymati jadvalini ko'r, porsiya hajmi hamda allergenlar haqidagi ma'lumotga e'tibor ber.", "mahsulot yorlig'ini o'qish", listOf("yorliq", "tarkib", "oziq")),
            GeneralTopic("Allergiya nima?", "Allergiya — immun tizimining odatda zararsiz moddalarga haddan tashqari javob berishi. Jiddiy alomatlar bo'lsa, tez tibbiy yordam kerak.", "allergiya ta'rifi", listOf("allergiya", "immunitet", "salomatlik")),
            GeneralTopic("Emlash nima uchun qilinadi?", "Emlash immun tizimini ayrim infeksiyalarga qarshi tayyorlashga yordam beradi. Shaxsiy emlash rejasini tibbiyot mutaxassisi bilan aniqlashtir.", "vaksina vazifasi", listOf("emlash", "vaksina", "salomatlik")),
            GeneralTopic("Yuqumli kasallik qanday tarqalishi mumkin?", "Ayrim infeksiyalar havo tomchilari, bevosita aloqa, ifloslangan suv yoki oziq-ovqat orqali tarqalishi mumkin; yo'li kasallikka bog'liq.", "infeksiya tarqalishi", listOf("infeksiya", "kasallik", "gigiyena")),
            GeneralTopic("Dam olish kunini qanday rejalashtiraman?", "Dam olish, uy ishlari va yoqtirgan mashg'ulotlar uchun vaqt ajrat, lekin rejani ortiqcha to'ldirib yuborma.", "dam olish kunini o'tkazish", listOf("dam", "reja", "mashg'ulot")),
            GeneralTopic("Yangi joyga borganda qanday tayyorlanaman?", "Manzilni oldindan tekshir, yo'l va qaytish variantini rejalashtir, zarur aloqa ma'lumotlarini saqla.", "yangi joyga borish", listOf("manzil", "yo'l", "tayyorgarlik")),
            GeneralTopic("Mahalliy vaqtni qanday aniqlayman?", "Qurilma sozlamalaridagi vaqt mintaqasini tekshir yoki ishonchli soat xizmatidan foydalan; sayohatda vaqt farqini hisobga ol.", "mahalliy vaqtni tekshirish", listOf("vaqt", "mintaqa", "soat")),
            GeneralTopic("Taqvim nima uchun kerak?", "Taqvim kunlar, haftalar va oylarni tartiblaydi hamda uchrashuv va vazifalarni rejalashga yordam beradi.", "taqvim vazifasi", listOf("taqvim", "sana", "reja")),
            GeneralTopic("Eslatma qo'yish nima uchun foydali?", "Eslatma muhim vazifa yoki uchrashuvni unutmaslikka yordam beradi. Juda ko'p eslatma o'rniga eng zarurlarini tanla.", "reminder foydasi", listOf("eslatma", "vazifa", "vaqt")),
            GeneralTopic("Ro'yxat bilan ishlashning foydasi nima?", "Ro'yxat murakkab ishni mayda qadamlarga ajratadi, bajarilganlarini kuzatish va qolganini ko'rishni osonlashtiradi.", "to do list foydasi", listOf("ro'yxat", "vazifa", "tartib")),
            GeneralTopic("Qarzdorlikni yozib borish nima uchun kerak?", "Qarz summasi, muddati va kelishuvni yozib borish chalkashlikni kamaytiradi. Shartlarni tushunmasdan qarz olma yoki berma.", "qarzni qayd qilish", listOf("qarz", "pul", "kelishuv")),
            GeneralTopic("Vaqtni behuda ketkazayotganimni qanday bilaman?", "Kun davomida vaqt qayerga ketganini qisqacha qayd et; keyin chalg'ituvchilarni aniqlab, bitta o'zgarish sinab ko'r.", "vaqt sarfini kuzatish", listOf("vaqt", "chalg'ish", "odat")),
            GeneralTopic("Raqamli bildirishnomalarni qanday boshqaraman?", "Faqat zarur ilovalarning bildirishnomalarini qoldir, diqqat talab qiladigan paytda bezovta qilmaslik rejimini yoq.", "bildirishnomalarni kamaytirish", listOf("bildirishnoma", "telefon", "diqqat")),
            GeneralTopic("Telefonni dars vaqtida qanday ishlataman?", "Telefonni faqat darsga kerak bo'lganda ishlat, chalg'ituvchi ilovalarni vaqtincha chekla va tanaffusni oldindan belgilab qo'y.", "dars payti telefon", listOf("telefon", "dars", "diqqat")),
            GeneralTopic("Axborot ortiqchaligi nima?", "Axborot ortiqchaligi bir vaqtda juda ko'p ma'lumot olish tufayli muhimini ajratishni qiyinlashtirishi mumkin.", "information overload nima", listOf("axborot", "diqqat", "ma'lumot")),
            GeneralTopic("Kichik tanaffuslar nima uchun kerak?", "Qisqa tanaffus diqqatni tiklashga yordam berishi mumkin. Tanaffusdan keyin keyingi vazifani aniq belgilash foydali.", "qisqa tanaffus foydasi", listOf("tanaffus", "diqqat", "dam")),
            GeneralTopic("Ish joyini tartibli tutish foydalimi?", "Kerakli buyumlarni bir joyda saqlash, ortiqcha narsalarni yig'ishtirish va yorug'likni moslash vazifaga kirishishni osonlashtiradi.", "ish joyini tartiblash", listOf("ish joyi", "tartib", "diqqat")),
            GeneralTopic("Uyqu jadvalini qanday barqaror qilaman?", "Imkon qadar bir xil vaqtda uxlash va uyg'onish, kechki payt tinch muhit yaratish yordam berishi mumkin.", "uyqu jadvali", listOf("uyqu", "jadval", "odat")),
            GeneralTopic("Yurishning foydasi nima?", "Yosh va imkoniyatga mos muntazam yurish kundalik faollikni oshiradi va umumiy salomatlikni qo'llab-quvvatlaydi.", "piyoda yurish foydasi", listOf("yurish", "faollik", "salomatlik")),
            GeneralTopic("Suv ichishni qanday eslab qolaman?", "Suvni kun davomida ko'rinadigan joyda tut va chanqoq hamda faolligingga qarab ich; ehtiyoj odamdan odamga farq qiladi.", "suv ichishni eslab qolish", listOf("suv", "odat", "salomatlik")),
            GeneralTopic("Ovqat tayyorlashdan oldin nima qilaman?", "Qo'llarni yuv, ish yuzasini tozala, xom mahsulotni tayyor ovqatdan ajrat va retseptni oldindan o'qib chiq.", "ovqat tayyorlash gigiyenasi", listOf("ovqat", "gigiyena", "oshxona")),
            GeneralTopic("Oshxona pichog'idan xavfsiz foydalanish qanday?", "Pichoqni barqaror taxtada ishlat, barmoqlarni tig'dan uzoq tut va pichoqni yuvayotganda ehtiyot bo'l. Yosh bo'lsang, zarur paytda kattadan yordam ol.", "oshxona xavfsizligi", listOf("pichoq", "oshxona", "xavfsizlik")),
            GeneralTopic("Issiq idishni qanday ushlash kerak?", "Issiq idish uchun quruq issiqqa chidamli tutqichdan foydalan va uni xavfsiz, tekis joyga qo'y.", "issiq idish xavfsizligi", listOf("issiq", "idish", "xavfsizlik")),
            GeneralTopic("Uy hayvoniga qanday mas'uliyat bilan qarayman?", "Hayvonga mos ovqat, toza suv, xavfsiz joy va zarur veterinariya parvarishini ta'minlash kerak.", "uy hayvonini parvarish qilish", listOf("hayvon", "parvarish", "mas'uliyat")),
            GeneralTopic("Ko'cha hayvoniga yordam berishda nima muhim?", "Hayvonga ehtiyotkorlik bilan yondash, qo'rqitma va xavf bo'lsa tegishga urinma; zarur bo'lsa mahalliy hayvonlarni himoya qilish xizmatiga murojaat qil.", "ko'cha hayvoniga yordam", listOf("hayvon", "xavfsizlik", "yordam")),
            GeneralTopic("O'simlikni sug'orishda nimaga qarayman?", "Tuproq namligini va o'simlik turini hisobga ol; hamma o'simlikka bir xil miqdorda suv kerak emas.", "gulni sug'orish", listOf("o'simlik", "suv", "parvarish")),
            GeneralTopic("Xonani shamollatish nima uchun kerak?", "Xonani mos sharoitda shamollatish ichki havoni yangilashga yordam beradi; tashqi havo iflos bo'lsa, vaqt va usulni hisobga ol.", "xonani shamollatish", listOf("havo", "xona", "shamollatish")),
            GeneralTopic("Mavsumiy kiyimni qanday tanlayman?", "Ob-havo, faoliyat va joy sharoitiga mos kiyim tanla; sovuqda qatlamlab kiyinish haroratni boshqarishga yordam beradi.", "ob havoga mos kiyim", listOf("kiyim", "ob-havo", "harorat")),
            GeneralTopic("Yomg'irli kunda yo'lda nima muhim?", "Ko'rinish va yo'l sirpanchiqligini hisobga ol, shoshilma va transport vositalaridan xavfsiz masofani saqla.", "yomg'irda yo'l xavfsizligi", listOf("yomg'ir", "yo'l", "xavfsizlik")),
            GeneralTopic("Quyoshdan himoyalanish nima uchun kerak?", "Uzoq vaqt kuchli quyoshda bo'lsang, soya, mos kiyim va tavsiya etilgan quyoshdan himoya vositalaridan foydalan.", "quyoshdan himoyalanish", listOf("quyosh", "teri", "himoya")),
            GeneralTopic("Qorong'ida ko'rinishni qanday oshiraman?", "Piyoda yurganda yoritilgan yo'lni tanla va haydovchilar ko'rishi uchun yorug' yoki qaytaruvchi elementlardan foydalan.", "qorong'ida piyoda xavfsizligi", listOf("qorong'i", "piyoda", "yo'l")),
            GeneralTopic("Velosipedda xavfsizlik uchun nima kerak?", "Velosipedni soz holatda tut, yo'l qoidalariga amal qil, ko'rinadigan bo'l va hududingdagi himoya vositalari talablarini bil.", "velosiped xavfsizligi", listOf("velosiped", "yo'l", "xavfsizlik")),
            GeneralTopic("Sport qoidalari nima uchun kerak?", "Qoidalar o'yinni adolatli va xavfsiz o'tkazishga, ishtirokchilar vazifalarini tushunishga yordam beradi.", "sport qoidalari foydasi", listOf("sport", "qoida", "adolat")),
            GeneralTopic("Jamoaviy o'yinda hamkorlik qanday?", "Vazifalarni kelishib ol, jamoadoshlaringni tingla va natijadan qat'i nazar hurmatni saqla.", "jamoaviy o'yin", listOf("jamoa", "o'yin", "hamkorlik")),
            GeneralTopic("Mag'lubiyatdan nima o'rganish mumkin?", "Natijani xolis ko'rib chiq, nimalar ishlaganini va nimani o'zgartirish mumkinligini aniqlab, keyingi urinish uchun bitta maqsad tanla.", "mag'lubiyatdan saboq", listOf("mag'lubiyat", "tajriba", "o'rganish")),
            GeneralTopic("G'alabada kamtarlik nima uchun muhim?", "Yutuqni qadrlash bilan birga raqib va jamoadoshlarni hurmat qilish yaxshi munosabatni saqlaydi.", "g'alabada odob", listOf("g'alaba", "kamtarlik", "hurmat")),
            GeneralTopic("Mashg'ulot natijasini qanday qayd qilaman?", "Sana, bajarilgan mashq va o'zingni qanday his qilganingni qisqa yozib bor; natijani vaqt o'tishi bilan solishtir.", "mashq natijasini yozish", listOf("mashq", "qayd", "taraqqiyot")),
            GeneralTopic("Yangi ishni o'rganishda xato qilish normalmi?", "Ha, xato o'rganish jarayonining tabiiy qismi. Xatoni tahlil qilib, keyingi safar nimani o'zgartirishni belgilash foydali.", "xato qilishdan o'rganish", listOf("xato", "o'rganish", "tajriba")),
            GeneralTopic("Rejani qayta tuzish qachon kerak?", "Sharoit, vaqt yoki ustuvorlik o'zgarsa, rejangni qayta ko'rib chiq. Reja foydali bo'lishi uchun real bo'lishi kerak.", "rejani yangilash", listOf("reja", "o'zgarish", "vaqt")),
            GeneralTopic("Vazifani bo'lib bajarish foydalimi?", "Katta vazifani kichik bosqichlarga bo'lish boshlashni osonlashtiradi va taraqqiyotni ko'rishga yordam beradi.", "katta ishni qismlarga ajratish", listOf("vazifa", "bosqich", "reja")),
            GeneralTopic("O'z vaqtida dam olish nima uchun muhim?", "Dam olish diqqat va quvvatni tiklashga yordam beradi; tanaffusni dangasalik deb emas, rejadagi zarur qism deb ko'r.", "dam olishning ahamiyati", listOf("dam", "quvvat", "diqqat")),
            GeneralTopic("Yangi bilimni amalda qo'llash nima beradi?", "Bilimni amalda sinash uni chuqurroq tushunishga va qaysi joyini yana o'rganish kerakligini aniqlashga yordam beradi.", "nazariyani amaliyotga qo'llash", listOf("bilim", "amaliyot", "o'rganish")),
            GeneralTopic("Kundalik yozuv nima uchun kerak?", "Qisqa kundalik fikr, vazifa va voqealarni eslab qolishga, vaqt o'tishi bilan o'zgarishni ko'rishga yordam berishi mumkin.", "kundalik yuritish foydasi", listOf("kundalik", "xotira", "yozuv")),
            GeneralTopic("Hujjatni suratga olayotganda nimaga qarayman?", "Matn to'liq ko'rinsin, yorug'lik yetarli bo'lsin va shaxsiy ma'lumotlar faqat zarur bo'lsa ulashilsin.", "hujjatni aniq suratga olish", listOf("hujjat", "surat", "maxfiylik")),
            GeneralTopic("Telefon kamerasini qanday tozalayman?", "Kamerani yumshoq, toza mikrofiber mato bilan ehtiyotkorlik bilan art; qattiq yoki abraziv material ishlatma.", "kamera linzasini tozalash", listOf("kamera", "tozalash", "telefon")),
            GeneralTopic("Eshitish vositasini qanday saqlayman?", "Qurilmani namlik va kuchli issiqdan asra, simini keskin tortma va saqlash uchun mos g'ilofdan foydalan.", "quloqchinni asrash", listOf("quloqchin", "saqlash", "qurilma")),
            GeneralTopic("Zaryadlovchini tanlashda nima muhim?", "Qurilmaga mos, sifatli va ishonchli ishlab chiqaruvchining zaryadlovchisidan foydalan; shikastlangan simni ishlatma.", "telefon zaryadlovchi tanlash", listOf("zaryadlovchi", "telefon", "xavfsizlik")),
            GeneralTopic("Kuchli parol qanday bo'ladi?", "Uzun, taxmin qilish qiyin va boshqa hisoblarda takrorlanmaydigan parol tanla; parol menejeri yordam berishi mumkin.", "mustahkam parol yaratish", listOf("parol", "hisob", "xavfsizlik")),
            GeneralTopic("Tasdiqlash kodi nima uchun maxfiy?", "Tasdiqlash kodi hisobga kirishni tasdiqlashi mumkin. Uni so'ragan odamga, hatto o'zini xizmat xodimi desa ham, bermagin.", "sms kodni himoyalash", listOf("kod", "sms", "hisob")),
            GeneralTopic("Hisobdan chiqish qachon kerak?", "Umumiy yoki begona qurilmadan foydalangandan keyin hisobdan chiq va parolni saqlab qolish taklifini qabul qilma.", "akkauntdan xavfsiz chiqish", listOf("hisob", "parol", "xavfsizlik")),
            GeneralTopic("Umumiy Wi-Fi ishlatishda nima muhim?", "Ishonchsiz tarmoqda maxfiy ma'lumot kiritishdan saqlan, sayt manzilini tekshir va qurilma ulashish sozlamalarini ehtiyotkor boshqar.", "public wifi xavfsizligi", listOf("wifi", "tarmoq", "maxfiylik")),
            GeneralTopic("Ma'lumotni bulutga yuklashda nima tekshiriladi?", "Xizmatning maxfiylik sozlamalarini, hisob xavfsizligini va qaysi fayllar ulashilganini tekshir.", "cloudga fayl joylash", listOf("bulut", "fayl", "maxfiylik")),
            GeneralTopic("Faylni boshqalar bilan ulashishda nima muhim?", "To'g'ri fayl va ruxsat darajasini tanla, havolani kim ko'ra olishini tekshir va keraksiz shaxsiy ma'lumotni olib tashla.", "fayl ulashish xavfsizligi", listOf("fayl", "ulashish", "ruxsat")),
            GeneralTopic("Katta faylni yuborishning yo'li qanday?", "Fayl hajmi chegarasini tekshir, kerak bo'lsa ishonchli bulut xizmati yoki arxivdan foydalan va oluvchiga kirish ruxsatini ber.", "katta fayl yuborish", listOf("fayl", "hajm", "yuborish")),
            GeneralTopic("Matnni tahrirlashdan oldin nima qilaman?", "Asl nusxani saqla, keyin imlo, mazmun, tartib va kerakli ohangni tekshir.", "matnni tekshirish", listOf("matn", "tahrir", "imlo")),
            GeneralTopic("Rasm manbasini ko'rsatish nima uchun kerak?", "Manbani ko'rsatish muallif mehnatini tan olish va boshqalarga asl materialni topishga yordam beradi; litsenziya shartlarini ham tekshir.", "rasmga manba berish", listOf("rasm", "manba", "mualliflik")),
            GeneralTopic("Audio fayl formati nima?", "Audio format ovoz ma'lumotining qanday saqlanishini belgilaydi; ayrim formatlar siqilgan, boshqalari esa kamroq yo'qotish bilan saqlashi mumkin.", "audio format ta'rifi", listOf("audio", "format", "fayl")),
            GeneralTopic("Video sifati nimaga bog'liq?", "Video sifati aniqlik, kadr tezligi, siqish darajasi, yorug'lik va manba sifatiga bog'liq.", "video sifati omillari", listOf("video", "sifat", "fps")),
            GeneralTopic("Rasm o'lchami nima?", "Rasm o'lchami ko'pincha piksel kengligi va balandligi bilan ifodalanadi; kattaroq o'lcham har doim ham yaxshi sifat degani emas.", "rasm rezolyutsiyasi", listOf("rasm", "piksel", "o'lcham")),
            GeneralTopic("Piksel nima?", "Piksel raqamli tasvirni tashkil etadigan eng kichik rangli nuqtalardan biridir.", "pixel ta'rifi", listOf("piksel", "rasm", "ekran")),
            GeneralTopic("Internet tezligi qanday o'lchanadi?", "Internet tezligi odatda bit/soniya birliklari bilan ifodalanadi; yuklab olish va yuborish tezligi farq qilishi mumkin.", "internet tezligi birligi", listOf("internet", "tezlik", "bit")),
            GeneralTopic("MB va GB farqi nima?", "GB megabaytdan kattaroq birlik. Amaliy hisoblashda 1 GB ko'pincha 1000 MB deb olinadi, ayrim tizimlarda 1024 MB ishlatiladi.", "megabayt gigabayt farqi", listOf("mb", "gb", "xotira")),
            GeneralTopic("Xotira to'lib qolmasligi uchun nima qilaman?", "Keraksiz fayllarni va foydalanilmaydigan ilovalarni vaqti-vaqti bilan tekshir, muhim ma'lumotlarni zaxirala.", "xotirani boshqarish", listOf("xotira", "fayl", "telefon")),
            GeneralTopic("Kompyuterni to'g'ri o'chirish nima uchun kerak?", "Tizim menyusidan o'chirish ochiq fayllarni saqlash va dasturlarning ishini to'g'ri yakunlashga yordam beradi.", "kompyuterni xavfsiz o'chirish", listOf("kompyuter", "o'chirish", "fayl")),
            GeneralTopic("Dastur o'rnatishda nimaga qarayman?", "Dastur manbasini, qurilma bilan mosligini, so'ralgan ruxsatlarni va foydalanuvchi shartlarini tekshir.", "ilova o'rnatish xavfsizligi", listOf("dastur", "o'rnatish", "xavfsizlik")),
            GeneralTopic("Ilova yangilanishi ishlamay qolsa nima qilaman?", "Internet va bo'sh joyni tekshir, qurilmani qayta ishga tushir va rasmiy do'kondagi ko'rsatmalarga amal qil.", "ilova yangilanmayapti", listOf("yangilash", "internet", "xotira")),
            GeneralTopic("Raqamli ko'nikmalar nima?", "Raqamli ko'nikmalar qurilma va onlayn xizmatlardan xavfsiz, samarali va mas'uliyatli foydalanish qobiliyatlaridir.", "digital skills ta'rifi", listOf("raqamli", "ko'nikma", "texnologiya")),
            GeneralTopic("Texnologiyadan tanaffus qilish foydalimi?", "Ekrandan tanaffus qilish boshqa faoliyatga vaqt ajratish va diqqatni tiklashga yordam berishi mumkin.", "ekrandan dam olish", listOf("ekran", "tanaffus", "diqqat")),
            GeneralTopic("Shaxsiy maqsad va odat farqi nima?", "Maqsad erishmoqchi bo'lgan natija; odat esa muntazam takrorlanadigan xatti-harakatdir.", "maqsad odatdan farqi", listOf("maqsad", "odat", "natija")),
            GeneralTopic("O'zgarishni qanday baholayman?", "Boshlang'ich holatni yozib qo'y, bir xil mezonlardan foydalan va natijani yetarli vaqt oralig'ida solishtir.", "taraqqiyotni baholash", listOf("o'zgarish", "natija", "mezon")),
            GeneralTopic("Yangi mavzuni o'rganish rejasini qanday tuzaman?", "Mavzuni kichik qismlarga ajrat, har biriga vaqt belgilab, o'rganish va takrorlashni navbatlashtir.", "o'rganish rejasini tuzish", listOf("mavzu", "reja", "takrorlash")),
            GeneralTopic("Kunlik vazifalar sonini qanday tanlayman?", "Vaqting va quvvatingga mos miqdorni tanla, eng muhim ishlarni ajrat va kutilmagan vaziyat uchun zaxira qoldir.", "kunlik reja hajmi", listOf("vazifa", "vaqt", "reja")),
            GeneralTopic("O'zimga mos maqsadni qanday tanlayman?", "Maqsad sen uchun muhim, real va aniq bo'lsin; kerak bo'lsa uni kichik bosqichlarga bo'l.", "mos maqsad tanlash", listOf("maqsad", "qiziqish", "reja")),
            GeneralTopic("Boshqalardan maslahat olganda nima qilish kerak?", "Maslahatni tingla, manba va vaziyatga mosligini bahola, so'ng qarorni o'zingning sharoiting va ishonchli dalillarga tayangan holda qil.", "maslahatni baholash", listOf("maslahat", "qaror", "dalil")),
            GeneralTopic("Qiyin vaziyatda kimga murojaat qilaman?", "Vaziyatga qarab ishonchli oila a'zosi, ustoz yoki tegishli mutaxassisdan yordam so'ra; xavf bo'lsa favqulodda xizmatga murojaat qil.", "qiyin paytda yordam so'rash", listOf("yordam", "ishonch", "xavfsizlik")),
            GeneralTopic("Shoshilinch xulosa chiqarish nega xavfli?", "Ma'lumot to'liq bo'lmasa, xulosa noto'g'ri chiqishi mumkin. Avval dalillarni tekshir va kerak bo'lsa qo'shimcha ma'lumot ol.", "shoshma xulosa", listOf("xulosa", "dalil", "tekshirish")),
            GeneralTopic("Maqsadga erishishda moslashuvchanlik nima?", "Asosiy maqsadni saqlab, unga boradigan usulni sharoitga qarab o'zgartirish mumkin.", "moslashuvchan reja", listOf("maqsad", "reja", "moslashish")),
            GeneralTopic("Kundalik hayotda tartib nima beradi?", "Oddiy tartib buyumlarni topish, vazifalarni eslash va vaqtni rejalashni osonlashtirishi mumkin.", "kundalik tartib foydasi", listOf("tartib", "vaqt", "odat")),
            GeneralTopic("O'z vaqtida savol berish nega muhim?", "Tushunmagan joyni erta so'rash xatoni kamaytiradi va keyingi ishni to'g'ri bajarishga yordam beradi.", "savol berish foydasi", listOf("savol", "o'rganish", "aniqlik")),
            GeneralTopic("Boshqa odamning fikrini qayta aytish nima beradi?", "Suhbatdosh fikrini o'z so'zing bilan qisqacha qaytarish uni to'g'ri tushunganingni tekshirishga yordam beradi.", "fikrni qayta ifodalash", listOf("suhbat", "tinglash", "tushunish")),
            GeneralTopic("Kichik yordam ham foydalimi?", "Imkoningga mos kichik yordam ham boshqa odamning ishini yengillashtirishi mumkin; avval qanday yordam kerakligini so'ra.", "kichik yordamning ahamiyati", listOf("yordam", "hamkorlik", "mehr")),
            GeneralTopic("Jamoat mulkiga qanday munosabatda bo'lish kerak?", "Umumiy buyum va joylardan ehtiyotkor foydalan, ifloslantirma va buzilgan narsani mas'ul kishiga bildir.", "jamoat mulkini asrash", listOf("jamoat", "mulk", "mas'uliyat")),
            GeneralTopic("Qoidalarga rioya qilish nima uchun kerak?", "Qoidalar ko'pincha xavfsizlik, adolat va tartibni saqlash uchun tuziladi; tushunarsiz qoidani ishonchli manbadan aniqlashtir.", "qoidalarning vazifasi", listOf("qoida", "xavfsizlik", "tartib")),
            GeneralTopic("Kutilmagan xarajatga tayyorlanish nima?", "Imkon bo'lsa, kichik zaxira mablag'ini rejalashtirish kutilmagan zarur xarajatlarni boshqarishga yordam beradi.", "favqulodda xarajatga tayyorgarlik", listOf("xarajat", "zaxira", "byudjet")),
            GeneralTopic("Sotib olishdan oldin ehtiyojni tekshirish nima beradi?", "Buyum nima uchun kerakligini va undan qanchalik tez-tez foydalanishingni o'ylash shoshma xaridni kamaytirishi mumkin.", "xariddan oldin o'ylash", listOf("xarid", "ehtiyoj", "pul")),
            GeneralTopic("Tovar sifati qanday baholanadi?", "Tavsif, material, kafolat, mustaqil sharhlar va sotuvchining qaytarish shartlarini solishtir.", "mahsulot sifatini tekshirish", listOf("sifat", "mahsulot", "kafolat")),
            GeneralTopic("Sharhlarni o'qishda nimaga e'tibor beraman?", "Bir nechta batafsil sharhni ko'r, juda umumiy yoki bir xil matnlarni ehtiyotkor bahola va kamchiliklarni ham o'qi.", "internet sharhlarini baholash", listOf("sharh", "mahsulot", "ishonch")),
            GeneralTopic("Narx va qiymat bir xilmi?", "Narx to'lanadigan pul miqdori; qiymat esa mahsulotning foydasi, sifati va ehtiyojga mosligini ham o'z ichiga oladi.", "narx bilan qiymat farqi", listOf("narx", "qiymat", "xarid")),
            GeneralTopic("O'lchov birliklarini almashtirishda nima muhim?", "Boshlang'ich va kerakli birlik orasidagi nisbatni aniqlab, hisobni shu nisbat asosida bajar.", "birliklarni aylantirish", listOf("o'lchov", "birlik", "hisob")),
            GeneralTopic("Aniq va taxminiy qiymat farqi nima?", "Aniq qiymat belgilangan aniqlikda beriladi; taxminiy qiymat esa yaqin natija bo'lib, o'lchov yoki hisobdagi noaniqlikni aks ettiradi.", "taxminiy qiymat ta'rifi", listOf("aniqlik", "taxmin", "o'lchov")),
            GeneralTopic("Xatolikni qayta tekshirish qanday?", "Hisobni boshqa usulda tekshir, birliklarni ko'rib chiq va natija mantiqan to'g'rimi deb bahola.", "hisobni tekshirish", listOf("xato", "hisob", "tekshirish")),
            GeneralTopic("Muammoning sababini topish nima uchun kerak?", "Sababni aniqlash bir xil muammoning qayta takrorlanishini kamaytirishga va mos yechim tanlashga yordam beradi.", "muammo sababini topish", listOf("sabab", "muammo", "yechim")),
            GeneralTopic("Sinab ko'rish va tekshirish farqi nima?", "Sinab ko'rish usul yoki g'oyani amalda qo'llash; tekshirish esa natijaning talabga mosligini baholashdir.", "test va tekshiruv farqi", listOf("sinov", "tekshirish", "natija")),
            GeneralTopic("Xavfsiz tajriba qanday bo'ladi?", "Tajribani oldindan rejalashtir, xavflarni bahola, kerakli himoya choralarini ko'r va xavfli moddalar yoki jihozlarda kattalar nazoratidan foydalan.", "tajriba xavfsizligi", listOf("tajriba", "xavfsizlik", "reja")),
            GeneralTopic("Ilmiy usul nima?", "Ilmiy usul savol qo'yish, kuzatish, taxmin tuzish, tekshirish, natijani tahlil qilish va xulosa chiqarishni o'z ichiga oladi.", "ilmiy usul bosqichlari", listOf("ilm", "kuzatish", "tajriba")),
            GeneralTopic("Kuzatish va tajriba farqi nima?", "Kuzatishda hodisa kuzatiladi va qayd etiladi; tajribada esa shartlarning bir qismi nazoratli ravishda o'zgartirilib, natija tekshiriladi.", "kuzatish tajriba farqi", listOf("kuzatish", "tajriba", "ilm")),
            GeneralTopic("Dalil va fikr farqi nima?", "Dalil tekshiriladigan ma'lumot yoki kuzatuvga tayanadi; fikr esa shaxsiy baho yoki qarash bo'lishi mumkin.", "dalil fikrdan farqi", listOf("dalil", "fikr", "manba")),
            GeneralTopic("Savodxonlik nima?", "Savodxonlik matnni o'qish, tushunish va yozish, shuningdek ma'lumotdan maqsadga muvofiq foydalanish ko'nikmalarini o'z ichiga oladi.", "savodxonlik ta'rifi", listOf("savodxonlik", "o'qish", "yozish")),
            GeneralTopic("Moliyaviy savodxonlik nima?", "Moliyaviy savodxonlik daromad, xarajat, jamg'arma, qarz va xavflar haqida tushunib qaror qabul qilish ko'nikmasidir.", "moliyaviy savodxonlik ta'rifi", listOf("moliya", "pul", "savodxonlik")),
            GeneralTopic("Vaqt qiymati nima?", "Vaqt cheklangan resurs; bir ishga vaqt ajratish boshqa ishga ajratiladigan vaqtni kamaytirishi mumkin.", "vaqtni qadrlash", listOf("vaqt", "resurs", "tanlov")),
            GeneralTopic("Tanlovning oqibati nima?", "Har bir tanlov foyda va xarajatlarga ega bo'lishi mumkin; qaror oldidan qisqa va uzoq muddatli oqibatlarni ko'rib chiq.", "qaror oqibatlarini baholash", listOf("tanlov", "qaror", "oqibat")),
            GeneralTopic("Kundalik odobning ahamiyati nima?", "Salomlashish, rahmat aytish, navbatni saqlash va boshqalarni tinglash o'zaro hurmatni mustahkamlaydi.", "odob qoidalari", listOf("odob", "hurmat", "muloqot")),
            GeneralTopic("Salomlashish odobi qanday?", "Vaziyatga mos salom ber, suhbatdoshning javobini tingla va uning shaxsiy makonini hurmat qil.", "salomlashish qoidasi", listOf("salom", "odob", "muloqot")),
            GeneralTopic("Minnatdorchilik va maqtov farqi nima?", "Minnatdorchilik yordam yoki yaxshilik uchun rahmat bildirish; maqtov esa kimningdir sifati yoki ishini ijobiy baholashdir.", "rahmat va maqtov farqi", listOf("rahmat", "maqtov", "muloqot")),
            GeneralTopic("O'z fikrimni aniq ifodalash qanday?", "Asosiy fikrni birinchi ayt, keyin qisqa sabab yoki misol keltir va kerak bo'lsa suhbatdoshdan tushunganini so'ra.", "fikrni aniq aytish", listOf("fikr", "muloqot", "aniqlik")),
            GeneralTopic("Nizoni tinch hal qilish qanday?", "Ovoz ohangini tinch saqla, muammoni aniq ayt, ikki tomonning ehtiyojini tingla va kelishilgan yechim izla.", "nizoni hal qilish", listOf("nizo", "suhbat", "yechim")),
            GeneralTopic("Boshqaga yordam berishdan oldin nima so'rash kerak?", "'Qanday yordam kerak?' deb so'ra; ba'zan odamga maslahatdan ko'ra tinglash yoki amaliy yordam kerak bo'ladi.", "yordam turini aniqlash", listOf("yordam", "savol", "tinglash")),
            GeneralTopic("O'zingni boshqalar bilan solishtirishga qanday qaraysan?", "Boshqalarning sharoiti farq qiladi. O'z rivojlanishingni oldingi holating va o'zing belgilagan mezonlar bilan baholash foydaliroq.", "o'zini solishtirish", listOf("solishtirish", "rivojlanish", "maqsad")),
            GeneralTopic("Muvaffaqiyat nima?", "Muvaffaqiyatning ta'rifi odam va maqsadga qarab farq qiladi; o'zing uchun muhim natijalarni aniqlash yordam beradi.", "muvaffaqiyat ta'rifi", listOf("muvaffaqiyat", "maqsad", "natija")),
            GeneralTopic("Sog'lom odatni qanday boshlayman?", "Bitta kichik va aniq odat tanla, uni mavjud kun tartibiga bog'la va bajarishni kuzatib bor.", "foydali odat boshlash", listOf("odat", "salomatlik", "reja")),
            GeneralTopic("O'zgarishni kichik qadamdan boshlash nega foydali?", "Kichik qadamni bajarish osonroq bo'ladi va keyingi bosqichga o'tish uchun tajriba beradi.", "kichik qadamlar usuli", listOf("qadam", "odat", "maqsad")),
            GeneralTopic("Ishni tugatgach nima qilish foydali?", "Natijani tekshir, kerakli fayllarni saqla, keyingi qadamni yoz va bajarilgan ishni belgilab qo'y.", "vazifadan keyin tekshiruv", listOf("tekshirish", "saqlash", "reja")),
            GeneralTopic("Tartibli fayl papkalari nima beradi?", "Fayllarni mavzu yoki loyiha bo'yicha papkalarga ajratish ularni keyin tez topishga yordam beradi.", "fayllarni tartiblash", listOf("papka", "fayl", "tartib")),
            GeneralTopic("Eski fayllarni o'chirishdan oldin nima qilaman?", "Fayl kerak emasligiga ishonch hosil qil, muhim nusxasi borligini tekshir va savatchani bo'shatishdan oldin yana ko'rib chiq.", "faylni xavfsiz o'chirish", listOf("fayl", "o'chirish", "zaxira")),
            GeneralTopic("Ilova ma'lumotini zaxiralash nima uchun kerak?", "Zaxira nusxa qurilma buzilishi yoki almashtirilishida muhim ma'lumotni tiklash imkonini beradi.", "ilova ma'lumotini saqlash", listOf("zaxira", "ilova", "ma'lumot")),
            GeneralTopic("Foydalanuvchi fikri dasturga qanday yordam beradi?", "Aniq xato tavsifi va takrorlash qadamlari ishlab chiquvchiga muammoni topish va tuzatishga yordam beradi.", "dasturga xato haqida xabar", listOf("fikr", "xato", "dastur")),
            GeneralTopic("Dastur ishlashini qanday tekshiraman?", "Asosiy vazifalarni sinab ko'r, kutilgan natija bilan amaldagi natijani solishtir va xato chiqqan qadamlarni qayd et.", "dastur test qilish", listOf("test", "dastur", "natija")),
            GeneralTopic("Oddiy prototip nima?", "Prototip g'oya yoki dastur qanday ishlashini erta ko'rsatadigan sodda namuna bo'lib, kamchiliklarni tez aniqlashga yordam beradi.", "prototip ta'rifi", listOf("prototip", "loyiha", "dastur")),
            GeneralTopic("Foydalanuvchi interfeysi nima?", "Foydalanuvchi interfeysi odamning ilova yoki qurilma bilan o'zaro ishlaydigan tugma, matn, menyu va boshqa elementlaridir.", "ui nima", listOf("interfeys", "ui", "ilova")),
            GeneralTopic("Foydalanish qulayligi nima?", "Qulaylik foydalanuvchi vazifani tushunarli, samarali va ortiqcha qiyinchiliksiz bajara olishini anglatadi.", "usability ta'rifi", listOf("qulaylik", "interfeys", "foydalanuvchi")),
            GeneralTopic("Ilovada xatoni tushunarli ko'rsatish nega kerak?", "Aniq xabar nima yuz bergani va keyin nima qilish mumkinligini ko'rsatsa, foydalanuvchiga muammoni hal qilish osonlashadi.", "xato xabarini yozish", listOf("xato", "ilova", "foydalanuvchi")),
            GeneralTopic("Ma'lumotni qidirishda kalit so'z nima?", "Kalit so'z mavzuning asosiy ma'nosini bildiradigan so'z bo'lib, kerakli ma'lumotni topishga yordam beradi.", "kalit so'z ta'rifi", listOf("kalit so'z", "qidiruv", "ma'lumot")),
            GeneralTopic("Qidiruv natijasini qanday baholayman?", "Savolga moslik, manba ishonchliligi, sana va berilgan dalillarni tekshir.", "qidiruv natijasini tekshirish", listOf("qidiruv", "manba", "sana")),
            GeneralTopic("Ma'lumotlar takrorlanishini kamaytirish qanday?", "Yangi yozuvni qo'shishdan oldin o'xshash savol va mazmunni tekshir; bir xil javobni turli savol shakllariga bog'lash mumkin.", "takroriy ma'lumotni kamaytirish", listOf("ma'lumot", "takror", "baza")),
            GeneralTopic("Bilimlar bazasi nima?", "Bilimlar bazasi savol-javoblar yoki qoidalarni tartibli saqlab, dasturga kerakli ma'lumotni topishga yordam beradi.", "knowledge base ta'rifi", listOf("bilimlar bazasi", "savol", "javob")),
            GeneralTopic("Oflayn bilimlar bazasining foydasi nima?", "Oflayn baza internet bo'lmaganda ham oldindan saqlangan ma'lumotlardan javob topishga imkon beradi.", "offline knowledge base", listOf("oflayn", "baza", "internet")),
            GeneralTopic("Oflayn ilovaning cheklovi nima?", "Oflayn ilova internetdan yangi ma'lumot ololmasligi mumkin; shu sabab bazadagi bilimlar eskirishi yoki savolga javob bermasligi mumkin.", "offline ilova cheklovi", listOf("oflayn", "internet", "cheklov")),
            GeneralTopic("Ma'lumotni yangilash nima uchun kerak?", "Yangilash yangi ma'lumot va xatolarni tuzatishni olib keladi; muhim mavzularda yangilanish manbasini ham tekshir.", "ma'lumotlar bazasini yangilash", listOf("yangilash", "ma'lumot", "xato")),
            GeneralTopic("Mahalliy saqlash nima?", "Mahalliy saqlash ma'lumotni qurilmaning o'zida saqlashdir; internet talab qilmasligi mumkin, lekin qurilma yo'qolsa ma'lumot xavf ostida qoladi.", "local storage ta'rifi", listOf("mahalliy", "saqlash", "qurilma")),
            GeneralTopic("Ma'lumotlarni qisqa saqlash nima uchun foydali?", "Faqat kerakli ma'lumotni saqlash joyni tejaydi va qidiruvni osonlashtiradi; muhim mazmun yo'qolmasligi uchun xulosa aniq bo'lishi kerak.", "xotirani tejash", listOf("xotira", "ma'lumot", "qisqa")),
            GeneralTopic("Sana bilan qayd yozish qanday yordam beradi?", "Sana qo'shilgan qayd voqea qachon sodir bo'lganini aniqlash va keyingi taraqqiyotni kuzatishga yordam beradi.", "sana bilan yozuv", listOf("sana", "qayd", "xotira")),
            GeneralTopic("Shaxsiy eslatmalarni qanday himoyalayman?", "Qurilma ekran qulfidan foydalan, maxfiy qaydlarni keraksiz ulashma va zaxira nusxalarining xavfsizligini tekshir.", "eslatmalar maxfiyligi", listOf("eslatma", "maxfiylik", "himoya")),
            GeneralTopic("Suhbat tarixini saqlashda nimani o'ylash kerak?", "Faqat kelajakda foydali bo'ladigan ma'lumotni saqla, ortiqcha shaxsiy ma'lumotlarni kamaytir va foydalanuvchiga boshqaruv imkonini ber.", "suhbat xotirasi", listOf("suhbat", "xotira", "maxfiylik")),
            GeneralTopic("Sun'iy intellekt xotirasi nima?", "AI xotirasi keyingi javoblarda foydali bo'lishi mumkin bo'lgan tanlangan ma'lumotlarni saqlash yoki qayta topish usulidir; maxfiylik va aniqlik muhim.", "ai memory ta'rifi", listOf("ai", "xotira", "maxfiylik")),
            GeneralTopic("Yordamchi ilova foydalanuvchiga qanday moslashadi?", "Foydalanuvchining tanlangan tili, maqsadlari va bildirishnoma sozlamalarini hisobga olib, lekin keraksiz shaxsiy ma'lumotni yig'masdan moslashishi mumkin.", "virtual yordamchi moslashuvi", listOf("yordamchi", "moslashish", "sozlama")),
            GeneralTopic("Bildirishnoma juda ko'p bo'lsa nima bo'ladi?", "Haddan tashqari bildirishnoma diqqatni bo'lishi mumkin. Muhimlarini tanla, vaqtini va sonini sozla.", "bildirishnomalarni tartiblash", listOf("bildirishnoma", "diqqat", "sozlama")),
            GeneralTopic("Eslatmalarni foydali qilish qanday?", "Eslatmani aniq vazifa bilan bog'la, qulay vaqtda ko'rsat va bajarilgach takrorlanishini o'chirish imkonini ber.", "foydali eslatma tuzish", listOf("eslatma", "vazifa", "vaqt")),
            GeneralTopic("Raqamli yordamchi noto'g'ri javob bersa nima qilaman?", "Javobni tekshir, xatoni qayd et va ishonchli manba bilan solishtir. Muhim qarorlarni faqat bitta AI javobiga tayanib qilma.", "ai xatosini tekshirish", listOf("ai", "xato", "manba")),
            GeneralTopic("O'quv materialini yoshga mos tushuntirish nima beradi?", "Sodda til, kichik qadamlar va misollar mavzuni tushunishni osonlashtiradi; zarur bo'lsa batafsil izohga o'tish mumkin.", "sodda tushuntirish", listOf("o'rganish", "misol", "tushuntirish")),
            GeneralTopic("Misol orqali o'rganish nima uchun foydali?", "Misol mavhum qoidani amaliy vaziyatga bog'laydi va uni qachon ishlatishni tushunishga yordam beradi.", "misol bilan o'rganish", listOf("misol", "qoida", "o'rganish")),
            GeneralTopic("Bosqichma-bosqich yo'riqnoma qanday bo'ladi?", "Har bir bosqich bitta aniq harakatni aytsin, zarur shartlarni ko'rsatsin va natijani tekshirish imkonini bersin.", "qadamli ko'rsatma", listOf("yo'riqnoma", "qadam", "aniqlik")),
            GeneralTopic("Yangi boshlovchi uchun eng yaxshi yondashuv nima?", "Asoslardan boshla, kichik vazifalarni bajar, tushunmagan joyingni so'ra va bilimni muntazam takrorla.", "boshlovchi qanday o'rganadi", listOf("boshlovchi", "asos", "mashq")),
            GeneralTopic("O'rganish jarayonida sabr nima beradi?", "Yangi ko'nikma vaqt talab qiladi. Natijani faqat tezlik bilan emas, tushunish va muntazam mashq bilan ham bahola.", "o'rganishda sabr", listOf("sabr", "o'rganish", "mashq")),
            GeneralTopic("Savol-javob bazasi qanday kengaytiriladi?", "Yangi savollarni mavzular bo'yicha guruhla, javoblarni ishonchli manbaga tayab yoz va o'xshash yozuvlarni tekshir.", "savol javob bazasini to'ldirish", listOf("savol", "javob", "baza")),
            GeneralTopic("Faktni yangilashda nima muhim?", "Eskirishi mumkin bo'lgan ma'lumotlarda sana va manbani qayd et; o'zgargan faktni tekshirib keyin almashtir.", "faktlarni yangilash", listOf("fakt", "sana", "manba")),
            GeneralTopic("Umumiy bilimni qanday tartiblash mumkin?", "Ma'lumotni tabiat, texnologiya, kundalik hayot, xavfsizlik va o'qish kabi mavzularga ajratish qidiruvni osonlashtiradi.", "bilimlarni kategoriyalash", listOf("bilim", "kategoriya", "qidiruv")),
            GeneralTopic("Kundalik hayotda xavfsiz qaror qanday qilinadi?", "Xavfni bahola, ishonchli ma'lumot izla, shoshilma va vaziyat jiddiy bo'lsa malakali odamdan yordam so'ra.", "xavfsiz qaror qabul qilish", listOf("xavfsizlik", "qaror", "maslahat")),
            GeneralTopic("Noma'lum narsani bilmasam nima qilaman?", "Bilmasligingni tan ol, savolni aniqlashtir va ishonchli manbadan o'rgan. Taxminni aniq fakt sifatida ko'rsatma.", "bilmagan narsani o'rganish", listOf("bilim", "savol", "manba")),
            GeneralTopic("To'g'ri javobning belgisi nima?", "Javob savolga mos, tushunarli, dalil yoki ishonchli manbaga tayangan va kerak bo'lsa cheklovlarini ochiq aytgan bo'lishi kerak.", "javobni baholash", listOf("javob", "dalil", "aniqlik")),
            GeneralTopic("Qisqa xulosa qanday yoziladi?", "Asosiy fikrni bir yoki ikki jumlada ayt, muhim natijani saqla va keraksiz tafsilotlarni olib tashla.", "qisqa xulosa tuzish", listOf("xulosa", "qisqa", "yozish")),
            GeneralTopic("Kundalik bilimni amalda qo'llash nima beradi?", "Bilimni real vaziyatda sinash uning foydasini ko'rsatadi va keyingi o'rganish uchun aniq savollar beradi.", "bilimni amalda ishlatish", listOf("bilim", "amaliyot", "tajriba")),
            GeneralTopic("O'zgaruvchan ma'lumotni qayerdan tekshiraman?", "Narx, jadval yoki qoidalar kabi tez o'zgaradigan ma'lumotni tegishli rasmiy yoki ishonchli manbadan qayta tekshir.", "dolzarb ma'lumot manbasi", listOf("ma'lumot", "rasmiy", "tekshirish")),
            GeneralTopic("Rasmiy ko'rsatma nima uchun muhim?", "Rasmiy ko'rsatma muayyan xizmat yoki qurilma uchun tasdiqlangan talablarni beradi; umumiy maslahatdan farq qilishi mumkin.", "rasmiy yo'riqnoma", listOf("rasmiy", "ko'rsatma", "xizmat")),
            GeneralTopic("Kundalik muammoni qayd qilish qanday?", "Muammo qachon yuz bergani, nima qilganing va qanday natija bo'lganini qisqa yoz; bu sababni topishga yordam beradi.", "muammoni yozib borish", listOf("muammo", "qayd", "natija")),
            GeneralTopic("Kutilmagan xatoga qanday munosabatda bo'laman?", "Avval xavfsiz holatga o't, nima o'zgarganini tekshir va bitta-bitta yechimni sinab ko'r; muhim ma'lumotni o'chirishga shoshilma.", "kutilmagan xatoni hal qilish", listOf("xato", "muammo", "yechim")),
            GeneralTopic("Oddiy kundalik reja qanday bo'ladi?", "Uyqu, o'qish yoki ish, ovqat, harakat, dam olish va shaxsiy maqsadlar uchun real vaqt ajrat.", "kunlik jadval", listOf("kun", "reja", "vaqt")),
            GeneralTopic("Kun tartibida moslashuvchan joy qoldirish nima uchun kerak?", "Kutilmagan vazifalar paydo bo'lishi mumkin; zaxira vaqt rejaning buzilishini kamaytiradi.", "rejadagi zaxira vaqt", listOf("reja", "vaqt", "moslashish")),
            GeneralTopic("Kundalik hayotda mustaqillik nima?", "Mustaqillik o'z vazifalarini imkon qadar o'zi bajarish, qarorlarni o'ylab qabul qilish va kerak bo'lsa yordam so'rashni ham bilishdir.", "mustaqillik ta'rifi", listOf("mustaqillik", "mas'uliyat", "ko'nikma")),
            GeneralTopic("O'rganishdagi taraqqiyotni qanday ko'raman?", "Boshlang'ich darajani qayd et, bir xil vazifani vaqt o'tib qayta bajar va natijalarni solishtir.", "o'sishni o'lchash", listOf("taraqqiyot", "o'rganish", "natija")),
            GeneralTopic("Maqsadni qayta belgilash yomonmi?", "Yo'q. Yangi ma'lumot yoki o'zgargan sharoitga qarab maqsadni moslashtirish oqilona bo'lishi mumkin.", "maqsadni o'zgartirish", listOf("maqsad", "moslashish", "reja")),
            GeneralTopic("Ishonchli odat qanday saqlanadi?", "Odatni aniq vaqt yoki vaziyatga bog'la, bajarish uchun sharoit tayyorla va qiyin kunlar uchun kichikroq variant belgilab qo'y.", "odatni saqlash usuli", listOf("odat", "reja", "muntazamlik")),
            GeneralTopic("O'zimga va'da berishda nima muhim?", "Bajara oladigan kichik va'da ber, uni yozib qo'y va bajarilganini tekshir. Juda katta reja o'rniga real qadam tanla.", "o'ziga va'da", listOf("va'da", "maqsad", "mas'uliyat")),
            GeneralTopic("Yordamchi ilovaning javobini qanday yaxshilash mumkin?", "Savolni aniqroq yoz, mavzuni ko'rsat va kerak bo'lsa misol keltir; ilova javobini esa muhim holatda tekshir.", "ai savolini yaxshilash", listOf("ilova", "savol", "javob")),
            GeneralTopic("Kundalik hayot haqidagi ma'lumotni qanday yozish kerak?", "Javobni sodda va aniq yoz, amaliy qadamlarni ajrat va xavfsizlik yoki istisnolar muhim bo'lsa ularni ham ko'rsat.", "kundalik ma'lumot yozish", listOf("ma'lumot", "aniqlik", "hayot")),
            GeneralTopic("Umumiy bilimni o'rganish uchun nima qilaman?", "Har kuni bitta kichik mavzuni tanla, ishonchli manbadan o'qi, o'z so'zing bilan xulosa qil va keyin takrorla.", "umumiy bilimni oshirish", listOf("bilim", "o'rganish", "takrorlash")),
            GeneralTopic("Foydali ma'lumotni keyin topish uchun nima qilaman?", "Mavzu nomi bilan saqla, kalit so'z qo'sh va keraksiz nusxalarni kamaytir.", "ma'lumotni saqlash", listOf("ma'lumot", "saqlash", "qidiruv")),
            GeneralTopic("Biror narsani unutmaslik uchun nima qilaman?", "Muhim ishni darhol qayd et, kerakli vaqtga eslatma qo'y va ro'yxatni muntazam tekshir.", "unutmaslik usullari", listOf("xotira", "eslatma", "ro'yxat")),
            GeneralTopic("Kundalik hayotda sabr-toqat qanday yordam beradi?", "Sabr shoshilinch javobni kamaytirib, vaziyatni o'ylab ko'rish va reja bilan harakat qilishga yordam beradi.", "sabrning kundalik foydasi", listOf("sabr", "qaror", "xulq")),
            GeneralTopic("Yaxshi savolning xususiyati nima?", "Yaxshi savol aniq, mavzuga mos va javob berish uchun yetarli kontekstga ega bo'ladi.", "yaxshi savol tuzish", listOf("savol", "aniqlik", "muloqot")),
            GeneralTopic("Tushuntirishni sodda qilish nima degani?", "Murakkab fikrni asosiy qismlarga ajrat, oddiy so'z va mos misoldan foydalan, lekin muhim ma'noni yo'qotma.", "sodda tushuntirish usuli", listOf("tushuntirish", "sodda", "misol")),
            GeneralTopic("Xulosa chiqarishda shoshmaslik nima uchun kerak?", "Yetarli dalil yig'ib, muqobil izohlarni ko'rib chiqish noto'g'ri xulosa ehtimolini kamaytiradi.", "xulosa qilishdan oldin", listOf("xulosa", "dalil", "fikrlash")),
            GeneralTopic("Kundalik bilimlarni tekshirish nima beradi?", "Bilimni tekshirish noto'g'ri tushunchalarni erta aniqlashga va kerakli joyni qayta o'rganishga yordam beradi.", "bilimni tekshirish", listOf("bilim", "tekshirish", "o'rganish")),
            GeneralTopic("Yangi ma'lumotni eslab qolish uchun nima qilaman?", "Ma'lumotni qisqa xulosa qil, o'zingga savol ber va keyin oraliq bilan qayta esla.", "yangi ma'lumotni yodlash", listOf("xotira", "savol", "takrorlash")),
            GeneralTopic("Ma'lumotni boshqaga o'rgatish qanday yordam beradi?", "Boshqaga tushuntirish bilimni tartiblaydi va qaysi qismini hali to'liq tushunmaganingni ko'rsatadi.", "boshqaga o'rgatish", listOf("o'rgatish", "bilim", "tushunish")),
            GeneralTopic("Kundalik muhitni qulay qilish qanday?", "Kerakli narsalarni qo'l yetadigan joyda tut, ortiqcha chalg'ituvchilarni kamaytir va xavfsiz, yaxshi yoritilgan joy tanla.", "qulay ish muhiti", listOf("muhit", "tartib", "diqqat")),
            GeneralTopic("O'z vaqtimni qanday himoya qilaman?", "Muhim vazifaga vaqt belgilab qo'y, chalg'ituvchi so'rovlarni muloyim rad et va tanaffuslarni ham rejalashtir.", "vaqt chegarasini belgilash", listOf("vaqt", "chegara", "reja")),
            GeneralTopic("Rejada bajarilmagan ish qolsa nima qilaman?", "Qolgan ishning sababini aniqlab, ustuvorligini qayta bahola va keyingi kunga real vaqt ajrat.", "bajarilmagan vazifalar", listOf("reja", "vazifa", "ustuvorlik")),
            GeneralTopic("Yangi narsani sinab ko'rishdan oldin nima qilaman?", "Maqsadni aniqlab, xavfsizlikni tekshir va kichik, qaytarish mumkin bo'lgan sinovdan boshlagin.", "yangi usulni sinash", listOf("sinov", "xavfsizlik", "maqsad")),
            GeneralTopic("Kundalik hayotda adolat nima?", "Adolat odamlarning huquqi va vaziyatini xolis hisobga olish, bir xil holatlarga izchil munosabatda bo'lishga intilishdir.", "adolat ta'rifi", listOf("adolat", "huquq", "xolislik")),
            GeneralTopic("Boshqa odamni tushunishga qanday urinaman?", "Uning fikrini bo'lmasdan tingla, nuqtai nazarini so'ra va o'zingning taxminingni fakt deb qabul qilma.", "boshqani tushunish", listOf("tinglash", "hurmat", "muloqot")),
            GeneralTopic("Hamkorlikda vazifani qanday bo'laman?", "Vazifalarni odamlarning vaqti va ko'nikmasiga mos taqsimla, mas'ul va muddatni aniq kelishib ol.", "vazifani taqsimlash", listOf("hamkorlik", "vazifa", "muddat")),
            GeneralTopic("Kundalik ishda sifatni qanday tekshiraman?", "Ishni tugatgach talablar ro'yxatini ko'rib chiq, xatolarni tuzat va natija kutilgan maqsadga mosligini tekshir.", "ishni tekshirish", listOf("sifat", "tekshirish", "natija")),
            GeneralTopic("Yaxshi odob nimadan boshlanadi?", "Salomlashish, tinglash, va'daga amal qilish va boshqalarning chegaralarini hurmat qilishdan boshlash mumkin.", "odobni o'rganish", listOf("odob", "hurmat", "xulq")),
            GeneralTopic("O'z fikrimni o'zgartirsam bo'ladimi?", "Yangi dalil yoki tajriba fikringni o'zgartirsa, buni tan olish o'rganish va xolis fikrlashning bir qismidir.", "fikrni o'zgartirish", listOf("fikr", "dalil", "o'rganish")),
            GeneralTopic("Kundalik hayotda ehtiyotkorlik nima?", "Ehtiyotkorlik xavfni oldindan ko'rish, kerakli chorani ko'rish va noaniq vaziyatda shoshilmaslikni anglatadi.", "ehtiyotkorlik ta'rifi", listOf("xavfsizlik", "ehtiyot", "qaror")),
            GeneralTopic("Yangi joyda yo'lni topolmasam nima qilaman?", "Xavfsiz joyda to'xta, xarita yoki ishonchli odamdan yordam ol va shaxsiy ma'lumotlarni begonalarga ortiqcha bermagin.", "yo'lni yo'qotib qo'yish", listOf("yo'l", "xarita", "yordam")),
            GeneralTopic("Kundalik hayotda hamkorlik nima beradi?", "Hamkorlik ishni taqsimlash, turli ko'nikmalardan foydalanish va muammolarni birgalikda hal qilishga yordam beradi.", "hamkorlik foydasi", listOf("hamkorlik", "jamoa", "yechim")),
            GeneralTopic("Yaxshi qaror uchun qanday savollar beraman?", "Maqsad nima, qanday variantlar bor, foyda va xavflar qanday, kimdan maslahat olish mumkin va qarorni keyin o'zgartirish mumkinmi — shularni ko'rib chiq.", "qaror oldidan savollar", listOf("qaror", "variant", "xavf")),
            GeneralTopic("Kundalik odatlarni kuzatish qanday yordam beradi?", "Bajarilgan odatlarni sodda belgilab borish muntazamlikni ko'rishga va kerak bo'lsa rejani o'zgartirishga yordam beradi.", "odat kuzatuvi", listOf("odat", "kuzatish", "reja")),
            GeneralTopic("Foydali ma'lumotni qisqa saqlash qanday?", "Asosiy fakt, sana va kerakli kontekstni saqla; bir xil ma'lumotni qayta-qayta yozishdan qoch.", "qisqa qayd yozish", listOf("qayd", "ma'lumot", "xotira")),
            GeneralTopic("Kundalik bilim bazasida xato topsam nima qilaman?", "Xato yozuvni tekshir, ishonchli manba bilan solishtir va tuzatish sababini qayd et.", "bilim bazasidagi xatoni tuzatish", listOf("baza", "xato", "tuzatish")),
            GeneralTopic("Yangi mavzuni o'zlashtirganimni qanday bilaman?", "Mavzuni kitobga qaramasdan tushuntirib ko'r, misol yech va bilmagan joylaringni qayta ko'rib chiq.", "mavzuni tushunganlikni tekshirish", listOf("o'rganish", "misol", "tekshirish")),
            GeneralTopic("Kundalik hayotda mustahkam bilim nima beradi?", "Mustahkam bilim vaziyatni yaxshiroq tushunish, xatolarni kamaytirish va mustaqil qaror qabul qilishga yordam beradi.", "bilimning kundalik foydasi", listOf("bilim", "qaror", "hayot")),
            GeneralTopic("Yakuniy natijani qanday qayd qilaman?", "Natijani qisqa yoz, ishlatilgan usulni va keyingi safar yaxshilash mumkin bo'lgan jihatni ko'rsat.", "natijani qayd etish", listOf("natija", "qayd", "tahlil")),
            GeneralTopic("Kundalik hayotda maqsadni eslab turish qanday?", "Maqsadni ko'rinadigan joyda yoz, unga mos kichik vazifani kunlik rejangga qo'sh va vaqti-vaqti bilan qayta ko'r.", "maqsadni eslab turish", listOf("maqsad", "eslatma", "reja")),
            GeneralTopic("Vaqtni rejalashda dam olishni unutmaslik nega kerak?", "Dam olish rejaning bir qismi bo'lsa, uzoq muddat davomida ishlash va o'rganish osonroq bo'lishi mumkin.", "dam olishni rejalash", listOf("vaqt", "dam", "reja")),
            GeneralTopic("Kundalik hayotda tartibni qanday saqlayman?", "Buyumlar uchun doimiy joy belgilab, kunlik kichik yig'ishtirish va haftalik tekshiruvni odat qil.", "tartibni saqlash", listOf("tartib", "odat", "uy")),
            GeneralTopic("Yangi ko'nikma uchun vaqtni qanday topaman?", "Kun jadvalini ko'rib, kamroq muhim faoliyatdan ozgina vaqt ajrat va mashqni qisqa bo'laklarga bo'l.", "o'rganishga vaqt topish", listOf("vaqt", "ko'nikma", "reja")),
            GeneralTopic("Kundalik hayotda xatoni qanday tan olaman?", "Xatoni yashirish o'rniga tan ol, oqibatini tuzatish yo'lini izla va keyingi safar uchun saboq chiqar.", "xatoni tan olish", listOf("xato", "mas'uliyat", "o'rganish")),
            GeneralTopic("Boshqa odamga fikr bildirish qanday bo'ladi?", "Fikrni aniq va hurmat bilan ayt, shaxsiyatga emas, muayyan harakat yoki natijaga e'tibor ber.", "hurmat bilan fikr bildirish", listOf("fikr", "hurmat", "muloqot")),
            GeneralTopic("Kundalik vazifalarda xavfni qanday baholayman?", "Nima noto'g'ri ketishi mumkinligini, ehtimoliy oqibatini va uni kamaytirish choralarini oldindan ko'rib chiq.", "xavfni baholash", listOf("xavf", "vazifa", "reja")),
            GeneralTopic("Yangi ma'lumotni ulashishdan oldin nima qilaman?", "Manbani tekshir, sana va kontekstni ko'r, shubhali ma'lumotni tasdiqlanmaguncha tarqatma.", "xabarni ulashishdan oldin", listOf("ma'lumot", "manba", "ulashish")),
            GeneralTopic("Kundalik hayotda o'rganish davomiyligi nima?", "O'rganishni faqat natija bilan emas, muntazam shug'ullanish va asta-sekin yaxshilanish bilan ham bahola.", "o'rganishni davom ettirish", listOf("o'rganish", "muntazamlik", "taraqqiyot")),
            GeneralTopic("O'z vaqtimni boshqarishni qanday yaxshilayman?", "Bir hafta davomida vaqt sarfini kuzat, asosiy chalg'ituvchini top va bitta kichik o'zgarishni sinab ko'r.", "vaqt boshqaruvini yaxshilash", listOf("vaqt", "reja", "odat")),
            GeneralTopic("Kundalik bilimlar uchun eng muhim qoida nima?", "Ma'lumotni tushunarli saqla, kerak bo'lganda manbani tekshir va bilmagan narsani taxmin bilan to'ldirma.", "bilim bilan ishlash qoidasi", listOf("bilim", "manba", "aniqlik"))
        )
        val prefixes = listOf(
            "Tushuntirib ber: ", "Qisqacha ayt: ", "Menga o'rgat: ", "Ma'lumot ber: ",
            "Oddiy tilda tushuntir: ", "Savolim bor: ", "Buni izohla: ", "Qanday bo'ladi: ",
            "Nimani bilishim kerak: ", "Boshlovchi uchun ayt: ", "Yordam ber: ", "Eslatib yubor: ",
            "Batafsilroq tushuntir: ", "Eng muhim jihati nima: ", "To'g'ri tushunishim uchun ayt: ",
            "Bu haqida gapirib ber: ", "Qanday o'rganaman: ", "Asosiy ma'lumot: ", "Iltimos, izohla: ",
            "Men bilmoqchiman: ", "Sodda qilib ayt: ", "Misol bilan tushuntir: ", "Qoidasi qanday: ",
            "Amalda qanday: ", "Yodlab olishim uchun ayt: ", "Yangi o'rganuvchiga tushuntir: ",
            "Qisqa ma'lumot kerak: ", "Muhim nuqtalarini ayt: ", "Savolimga javob ber: ", "Bu nimani bildiradi: ",
            "O'rganishga yordam ber: ", "Mavzuni tushuntir: ", "Aniqroq ayt: ", "Buni qanday tushunsam bo'ladi: ",
            "Oddiy javob ber: ", "Bosqichma-bosqich ayt: ", "Asoslarini tushuntir: ", "Ma'nosini ayt: ",
            "Qanday eslab qolaman: ", "Nimadan boshlay: ", "Muhim ma'lumotni ayt: ", "Buni bilish kerakmi: ",
            "Qanday bajariladi: ", "Qanday tushuniladi: ", "Qaysi qoidaga tegishli: ", "To'g'ri yo'lini tushuntir: ",
            "Menga kerakli ma'lumot: ", "Bir oz tushuntir: ", "Buni o'rganish yo'li: ", "Yodda tutish uchun ayt: "
        )
        val result = ArrayList<Fact>(9995)
        topics.forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                if (result.size < 9995) {
                    val base = topicIndex * 100 + styleIndex * 2 + 1
                    val kws = topic.keywords + listOf("umumiy bilim", "kundalik hayot")
                    result.add(fact("general_db_${base.toString().padStart(5, '0')}", Category.GENERAL,
                        prefix + topic.q1, topic.answer, listOf(prefix + topic.q2, topic.q1, topic.q2), kws))
                }
                if (result.size < 9995) {
                    val base = topicIndex * 100 + styleIndex * 2 + 2
                    val kws = topic.keywords + listOf("umumiy bilim", "kundalik hayot")
                    result.add(fact("general_db_${base.toString().padStart(5, '0')}", Category.GENERAL,
                        prefix + topic.q2, topic.answer, listOf(prefix + topic.q1, topic.q1, topic.q2), kws))
                }
            }
            if (result.size >= 9995) return result
        }
        return result
    }

    private data class LanguageTopic(val q1: String, val answer: String, val q2: String, val keywords: List<String>)
    private fun buildLanguageFacts(): List<Fact> {
        val topics = listOf(
            LanguageTopic("Hello nimani anglatadi?", "Hello — salom degani.", "hello tarjimasi", listOf("hello", "salom")),
            LanguageTopic("Good morning nimani anglatadi?", "Good morning — xayrli tong degani.", "good morning tarjimasi", listOf("morning", "tong")),
            LanguageTopic("Good night nimani anglatadi?", "Good night — xayrli tun degani.", "good night tarjimasi", listOf("night", "tun")),
            LanguageTopic("Thank you nimani anglatadi?", "Thank you — rahmat degani.", "thank you tarjimasi", listOf("thank", "rahmat")),
            LanguageTopic("Please nimani anglatadi?", "Please — iltimos degani.", "please tarjimasi", listOf("please", "iltimos")),
            LanguageTopic("Sorry nimani anglatadi?", "Sorry — kechirasiz yoki afsusdaman degani.", "sorry tarjimasi", listOf("sorry", "kechirasiz")),
            LanguageTopic("How are you nimani anglatadi?", "How are you? — Ahvoling qanday? degani.", "how are you tarjimasi", listOf("how", "ahvol")),
            LanguageTopic("My name is qanday ishlatiladi?", "My name is ... — Mening ismim ... degani.", "ismimni inglizcha aytish", listOf("name", "ism")),
            LanguageTopic("I am va I’m farqi nima?", "I’m — I am iborasining qisqartmasi; ma’nosi o‘zgarmaydi.", "i am qisqartmasi", listOf("am", "im")),
            LanguageTopic("You are nimani anglatadi?", "You are — sen/siz ...san/...siz degani.", "you are tarjimasi", listOf("you", "are")),
            LanguageTopic("He is qachon ishlatiladi?", "He is erkak kishi haqida gapirganda ishlatiladi: He is happy.", "he is misol", listOf("he", "is")),
            LanguageTopic("She is qachon ishlatiladi?", "She is ayol kishi yoki qiz haqida gapirganda ishlatiladi: She is happy.", "she is misol", listOf("she", "is")),
            LanguageTopic("It is qachon ishlatiladi?", "It is odatda narsa, hayvon yoki holat haqida gapirganda ishlatiladi.", "it is misol", listOf("it", "is")),
            LanguageTopic("We are nimani anglatadi?", "We are — biz ...miz degani.", "we are tarjimasi", listOf("we", "are")),
            LanguageTopic("They are nimani anglatadi?", "They are — ular ... degani.", "they are tarjimasi", listOf("they", "are")),
            LanguageTopic("I like qanday ishlatiladi?", "I like ... — Men ...ni yoqtiraman. Masalan: I like games.", "i like misol", listOf("like", "yoqtiraman")),
            LanguageTopic("I want to nimani bildiradi?", "I want to ... — Men ...moqchiman degani.", "i want to tarjimasi", listOf("want", "moqchi")),
            LanguageTopic("Can nimani bildiradi?", "Can qobiliyat yoki imkoniyatni bildiradi: I can swim — Men suza olaman.", "can bilan gap", listOf("can", "qobiliyat")),
            LanguageTopic("Do va does farqi nima?", "Do I/you/we/they bilan, does he/she/it bilan hozirgi oddiy zamonda ishlatiladi.", "do does qoidasi", listOf("do", "does")),
            LanguageTopic("Present simple nima?", "Present Simple odat va muntazam ishlar haqida: I play every day.", "hozirgi oddiy zamon", listOf("present", "simple")),
            LanguageTopic("Present continuous nima?", "Present Continuous ayni paytda davom etayotgan ishni bildiradi: I am reading.", "hozir davom zamoni", listOf("continuous", "ing")),
            LanguageTopic("Past simple nima?", "Past Simple o‘tmishda tugagan ishni bildiradi: I played yesterday.", "o‘tgan oddiy zamon", listOf("past", "yesterday")),
            LanguageTopic("Future simple nima?", "Future Simple kelajak haqida, ko‘pincha will bilan ishlatiladi: I will learn.", "kelasi zamon", listOf("future", "will")),
            LanguageTopic("A va an farqi nima?", "A undosh tovush bilan, an unli tovush bilan boshlanadigan birlik ot oldidan keladi.", "a an ishlatilishi", listOf("a", "an")),
            LanguageTopic("The qachon ishlatiladi?", "The tinglovchiga ma’lum yoki aniq narsani ko‘rsatishda ishlatiladi.", "the artikli", listOf("the", "article")),
            LanguageTopic("Ko‘plik ingliz tilida qanday yasaladi?", "Ko‘p otlarga -s yoki -es qo‘shiladi; ayrimlari irregular: child—children.", "inglizcha ko‘plik", listOf("plural", "s")),
            LanguageTopic("Child nimani anglatadi?", "Child — bola degani; ko‘pligi children.", "child tarjimasi", listOf("child", "bola")),
            LanguageTopic("Book nimani anglatadi?", "Book — kitob degani.", "book tarjimasi", listOf("book", "kitob")),
            LanguageTopic("Water nimani anglatadi?", "Water — suv degani.", "water tarjimasi", listOf("water", "suv")),
            LanguageTopic("Friend nimani anglatadi?", "Friend — do‘st degani.", "friend tarjimasi", listOf("friend", "do‘st")),
            LanguageTopic("Learn nimani anglatadi?", "Learn — o‘rganmoq degani.", "learn tarjimasi", listOf("learn", "o‘rgan")),
            LanguageTopic("Teach nimani anglatadi?", "Teach — o‘rgatmoq yoki dars bermoq degani.", "teach tarjimasi", listOf("teach", "o‘rgat")),
            LanguageTopic("Beautiful nimani anglatadi?", "Beautiful — chiroyli degani.", "beautiful tarjimasi", listOf("beautiful", "chiroyli")),
            LanguageTopic("Difficult nimani anglatadi?", "Difficult — qiyin degani.", "difficult tarjimasi", listOf("difficult", "qiyin")),
            LanguageTopic("Because nimani anglatadi?", "Because — chunki degani.", "because tarjimasi", listOf("because", "chunki")),
            LanguageTopic("But nimani anglatadi?", "But — lekin degani.", "but tarjimasi", listOf("but", "lekin")),
            LanguageTopic("And nimani anglatadi?", "And — va degani.", "and tarjimasi", listOf("and", "va")),
            LanguageTopic("Where nimani anglatadi?", "Where — qayerda/qayerga degani.", "where tarjimasi", listOf("where", "qayer")),
            LanguageTopic("When nimani anglatadi?", "When — qachon degani.", "when tarjimasi", listOf("when", "qachon")),
            LanguageTopic("Why nimani anglatadi?", "Why — nima uchun degani.", "why tarjimasi", listOf("why", "nima uchun")),
            LanguageTopic("How many qachon ishlatiladi?", "How many sanaladigan ko‘plikdagi narsalar sonini so‘raydi.", "how many qoidasi", listOf("many", "son")),
            LanguageTopic("How much qachon ishlatiladi?", "How much sanalmaydigan narsalar miqdori yoki narxni so‘rashda ishlatiladi.", "how much qoidasi", listOf("much", "miqdor")),
            LanguageTopic("Arab yozuvi o‘ngdan chapgami?", "Arab yozuvi o‘ngdan chapga qarab yoziladi.", "arab yozuvi yo‘nalishi", listOf("arab", "o‘ngdan")),
            LanguageTopic("Arab alifbosida nechta harf bor?", "Arab alifbosida odatda 28 ta asosiy harf sanaladi.", "arab harflari soni", listOf("alifbo", "28")),
            LanguageTopic("Alif harfi qanday yoziladi?", "ا — alif harfi; yozilish shakli so‘zdagi o‘rniga bog‘liq bo‘lishi mumkin.", "alif harfi", listOf("alif", "ا")),
            LanguageTopic("Ba harfi qaysi?", "ب — ba harfi; pastida bitta nuqta bor.", "ba harfi", listOf("ba", "ب")),
            LanguageTopic("Ta harfi qaysi?", "ت — ta harfi; yuqorisida ikki nuqta bor.", "ta harfi", listOf("ta", "ت")),
            LanguageTopic("Tha harfi qaysi?", "ث — tha harfi; yuqorisida uch nuqta bor.", "tha harfi", listOf("tha", "ث")),
            LanguageTopic("Jim harfi qaysi?", "ج — jim harfi; yozilishi joylashuviga qarab o‘zgaradi.", "jim harfi", listOf("jim", "ج")),
            LanguageTopic("Ha harfi qaysi?", "ح — arab alifbosidagi ha harfi.", "ha harfi arabcha", listOf("ح", "ha")),
            LanguageTopic("Kha harfi qaysi?", "خ — kha harfi; ustida nuqtasi bor.", "kha harfi", listOf("kha", "خ")),
            LanguageTopic("Dal harfi qaysi?", "د — dal harfi.", "dal harfi", listOf("dal", "د")),
            LanguageTopic("Ra harfi qaysi?", "ر — ra harfi.", "ra harfi", listOf("ra", "ر")),
            LanguageTopic("Sin harfi qaysi?", "س — sin harfi.", "sin harfi", listOf("sin", "س")),
            LanguageTopic("Shin harfi qaysi?", "ش — shin harfi; yuqorisida uch nuqtasi bor.", "shin harfi", listOf("shin", "ش")),
            LanguageTopic("Sad harfi qaysi?", "ص — sad harfi.", "sad harfi", listOf("sad", "ص")),
            LanguageTopic("Dad harfi qaysi?", "ض — dad harfi.", "dad harfi", listOf("dad", "ض")),
            LanguageTopic("To harfi qaysi?", "ط — to harfi.", "to harfi", listOf("to", "ط")),
            LanguageTopic("Zo harfi qaysi?", "ظ — zo harfi.", "zo harfi", listOf("zo", "ظ")),
            LanguageTopic("Ayn harfi qaysi?", "ع — ayn harfi; talaffuzi arab tiliga xos tovushdir.", "ayn harfi", listOf("ayn", "ع")),
            LanguageTopic("G‘ayn harfi qaysi?", "غ — g‘ayn harfi.", "g‘ayn harfi", listOf("g‘ayn", "غ")),
            LanguageTopic("Fa harfi qaysi?", "ف — fa harfi.", "fa harfi", listOf("fa", "ف")),
            LanguageTopic("Qof harfi qaysi?", "ق — qof harfi.", "qof harfi", listOf("qof", "ق")),
            LanguageTopic("Kaf harfi qaysi?", "ك — kaf harfi.", "kaf harfi", listOf("kaf", "ك")),
            LanguageTopic("Lam harfi qaysi?", "ل — lam harfi.", "lam harfi", listOf("lam", "ل")),
            LanguageTopic("Mim harfi qaysi?", "م — mim harfi.", "mim harfi", listOf("mim", "م")),
            LanguageTopic("Nun harfi qaysi?", "ن — nun harfi.", "nun harfi", listOf("nun", "ن")),
            LanguageTopic("Ha (ه) harfi qaysi?", "ه — ha harfi; uni ح harfidan farqlash kerak.", "ه harfi", listOf("ه", "ha")),
            LanguageTopic("Waw harfi qaysi?", "و — waw harfi; ba’zan unli tovushni ham ifodalaydi.", "waw harfi", listOf("waw", "و")),
            LanguageTopic("Ya harfi qaysi?", "ي — ya harfi.", "ya harfi", listOf("ya", "ي"))
        )
        val prefixes = listOf(
            "Tushuntirib ber: ", "Qisqacha ayt: ", "Menga o'rgat: ", "Ma'lumot ber: ",
            "Oddiy tilda tushuntir: ", "Savolim bor: ", "Buni izohla: ", "Qanday bo'ladi: ",
            "Nimani bilishim kerak: ", "Boshlovchi uchun ayt: ", "Yordam ber: ", "Eslatib yubor: ",
            "Batafsilroq tushuntir: ", "Eng muhim jihati nima: ", "To'g'ri tushunishim uchun ayt: ",
            "Bu haqida gapirib ber: ", "Qanday o'rganaman: ", "Asosiy ma'lumot: ", "Iltimos, izohla: ",
            "Men bilmoqchiman: ", "Sodda qilib ayt: ", "Misol bilan tushuntir: ", "Qoidasi qanday: ",
            "Amalda qanday: ", "Yodlab olishim uchun ayt: ", "Yangi o'rganuvchiga tushuntir: ",
            "Qisqa ma'lumot kerak: ", "Muhim nuqtalarini ayt: ", "Savolimga javob ber: ", "Bu nimani bildiradi: ",
            "O'rganishga yordam ber: ", "Mavzuni tushuntir: ", "Aniqroq ayt: ", "Buni qanday tushunsam bo'ladi: ",
            "Oddiy javob ber: ", "Bosqichma-bosqich ayt: ", "Asoslarini tushuntir: ", "Ma'nosini ayt: ",
            "Qanday eslab qolaman: ", "Nimadan boshlay: ", "Muhim ma'lumotni ayt: ", "Buni bilish kerakmi: ",
            "Qanday bajariladi: ", "Qanday talaffuz qilinadi: ", "Qaysi qoidaga tegishli: ", "To'g'ri yo'lini tushuntir: ",
            "Menga kerakli ma'lumot: ", "Bir oz tushuntir: ", "Buni o'rganish yo'li: ", "Yodda tutish uchun ayt: "
        )
        val result = ArrayList<Fact>(6992)
        topics.forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                if (result.size < 6992) {
                    val base = topicIndex * 100 + styleIndex * 2 + 1
                    val kws = topic.keywords + listOf("ingliz tili va arab yozuvi")
                    result.add(fact("language_db_${base.toString().padStart(5, '0')}", Category.LANGUAGES, prefix + topic.q1, topic.answer, listOf(prefix + topic.q2, topic.q1, topic.q2), kws))
                }
                if (result.size < 6992) {
                    val base = topicIndex * 100 + styleIndex * 2 + 2
                    val kws = topic.keywords + listOf("ingliz tili va arab yozuvi")
                    result.add(fact("language_db_${base.toString().padStart(5, '0')}", Category.LANGUAGES, prefix + topic.q2, topic.answer, listOf(prefix + topic.q1, topic.q1, topic.q2), kws))
                }
            }
            if (result.size >= 6992) return result
        }
        return result
    }

    private data class TechnologyTopic(val q1: String, val answer: String, val q2: String, val keywords: List<String>)
    private fun buildTechnologyFacts(): List<Fact> {
        val topics = listOf(
            TechnologyTopic("Kompyuter nima?", "Kompyuter ma’lumotni qabul qilish, qayta ishlash, saqlash va chiqarish uchun ishlatiladigan elektron qurilma.", "kompyuter ta’rifi", listOf("kompyuter", "ma’lumot")),
            TechnologyTopic("CPU nima?", "CPU — protsessor; dastur buyruqlarini bajaradi va hisoblashlarni amalga oshiradi.", "protsessor vazifasi", listOf("cpu", "protsessor")),
            TechnologyTopic("RAM nima?", "RAM — dasturlar ishlayotgan paytda kerak bo‘ladigan vaqtinchalik tezkor xotira.", "tezkor xotira nima", listOf("ram", "xotira")),
            TechnologyTopic("SSD va HDD farqi nima?", "SSD odatda tezroq va mexanik qismlarsiz; HDD ma’lumotni aylanuvchi magnit diskda saqlaydi.", "ssd hdd taqqoslash", listOf("ssd", "hdd")),
            TechnologyTopic("Operatsion tizim nima?", "Operatsion tizim qurilma resurslarini boshqaradi va ilovalar ishlashiga yordam beradi.", "operatsion tizim ta’rifi", listOf("os", "tizim")),
            TechnologyTopic("Windows nima?", "Windows — Microsoft ishlab chiqqan operatsion tizimlar oilasi.", "windows nima", listOf("windows", "os")),
            TechnologyTopic("Linux nima?", "Linux yadrosi asosidagi operatsion tizimlar ochiq kodli va turli qurilmalarda ishlatiladi.", "linux haqida", listOf("linux", "ochiq kod")),
            TechnologyTopic("Android nima?", "Android — ko‘plab telefon va planshetlarda ishlatiladigan operatsion tizim.", "android nima", listOf("android", "telefon")),
            TechnologyTopic("Fayl nima?", "Fayl — nom bilan saqlanadigan ma’lumot birligi, masalan rasm, matn yoki video.", "fayl ta’rifi", listOf("fayl", "ma’lumot")),
            TechnologyTopic("Papka nima?", "Papka fayl va boshqa papkalarni tartib bilan saqlashga yordam beradi.", "folder nima", listOf("papka", "folder")),
            TechnologyTopic("ZIP fayl nima?", "ZIP arxiv bir yoki bir nechta faylni bitta paketga jamlaydi va ko‘pincha hajmni kamaytiradi.", "zip arxiv nima", listOf("zip", "arxiv")),
            TechnologyTopic("Dasturlash nima?", "Dasturlash — kompyuter bajarishi uchun ko‘rsatmalar va dasturlar yaratish jarayoni.", "programming nima", listOf("dasturlash", "kod")),
            TechnologyTopic("Algoritm nima?", "Algoritm — muammoni hal qilish uchun aniq ketma-ket qadamlar to‘plami.", "algoritm ta’rifi", listOf("algoritm", "qadam")),
            TechnologyTopic("Python nima?", "Python — o‘qish oson sintaksisga ega, ko‘p sohalarda ishlatiladigan dasturlash tili.", "python tili nima", listOf("python", "kod")),
            TechnologyTopic("Kotlin nima?", "Kotlin — Android ilovalarini yaratishda keng qo‘llanadigan dasturlash tili.", "kotlin nima", listOf("kotlin", "android")),
            TechnologyTopic("Java nima?", "Java — ko‘plab platformalarda ishlaydigan obyektga yo‘naltirilgan dasturlash tili.", "java tili nima", listOf("java", "dasturlash")),
            TechnologyTopic("HTML nima?", "HTML veb-sahifaning tuzilishi va mazmunini belgilash uchun ishlatiladi.", "html vazifasi", listOf("html", "veb")),
            TechnologyTopic("CSS nima?", "CSS veb-sahifaning ko‘rinishi, ranglari, o‘lchamlari va joylashuvini belgilaydi.", "css vazifasi", listOf("css", "stil")),
            TechnologyTopic("JavaScript nima?", "JavaScript veb-sahifalarga interaktivlik qo‘shadi va boshqa muhitlarda ham ishlaydi.", "javascript nima", listOf("javascript", "veb")),
            TechnologyTopic("O‘zgaruvchi nima?", "O‘zgaruvchi dasturda qiymatni nom bilan saqlash uchun ishlatiladi.", "variable nima", listOf("o‘zgaruvchi", "variable")),
            TechnologyTopic("Funksiya nima?", "Funksiya — muayyan vazifani bajaradigan, qayta chaqirilishi mumkin bo‘lgan kod bo‘lagi.", "function nima", listOf("funksiya", "kod")),
            TechnologyTopic("Sikl nima?", "Sikl bir yoki bir nechta buyruqni shart yoki takrorlar soniga ko‘ra qayta bajaradi.", "loop nima", listOf("sikl", "loop")),
            TechnologyTopic("Shart operatori nima?", "Shart operatori shart rost yoki yolg‘onligiga qarab turli kod yo‘llarini bajaradi.", "if operatori", listOf("if", "shart")),
            TechnologyTopic("Xatolikni tuzatish nima?", "Debugging — dasturdagi xatoni topish, sababini aniqlash va tuzatish jarayoni.", "debugging nima", listOf("debug", "xato")),
            TechnologyTopic("IDE nima?", "IDE kod yozish, ishga tushirish va xatolarni topish vositalarini birlashtirgan dastur.", "ide ta’rifi", listOf("ide", "kod")),
            TechnologyTopic("Git nima?", "Git — koddagi o‘zgarishlar tarixini kuzatadigan versiyalarni boshqarish tizimi.", "git nima", listOf("git", "versiya")),
            TechnologyTopic("GitHub nima?", "GitHub Git omborlarini saqlash, ulashish va jamoa bilan ishlash platformasidir.", "github vazifasi", listOf("github", "git")),
            TechnologyTopic("Ma’lumotlar bazasi nima?", "Ma’lumotlar bazasi ma’lumotni tartibli saqlash va qidirish imkonini beradi.", "database nima", listOf("baza", "ma’lumot")),
            TechnologyTopic("SQL nima?", "SQL — relyatsion ma’lumotlar bazasidagi ma’lumotlarni so‘rash va boshqarish tili.", "sql nima", listOf("sql", "database")),
            TechnologyTopic("API nima?", "API dasturlar o‘zaro ma’lumot almashishi yoki funksiyalarni chaqirishi uchun qoidalar beradi.", "api ta’rifi", listOf("api", "integratsiya")),
            TechnologyTopic("Server nima?", "Server boshqa qurilmalar yoki dasturlarga xizmat, ma’lumot yoki resurs taqdim etadi.", "server nima", listOf("server", "tarmoq")),
            TechnologyTopic("Klient nima?", "Klient serverdan xizmat yoki ma’lumot so‘raydigan dastur yoki qurilma bo‘lishi mumkin.", "client nima", listOf("klient", "server")),
            TechnologyTopic("Internet nima?", "Internet — butun dunyodagi tarmoqlarni bog‘laydigan global tarmoq.", "internet ta’rifi", listOf("internet", "tarmoq")),
            TechnologyTopic("Wi-Fi nima?", "Wi‑Fi qurilmalarga simsiz mahalliy tarmoqqa ulanish imkonini beradi.", "wifi nima", listOf("wifi", "simsiz")),
            TechnologyTopic("IP manzil nima?", "IP manzil tarmoqdagi qurilma yoki interfeysni aniqlash uchun ishlatiladi.", "ip address nima", listOf("ip", "manzil")),
            TechnologyTopic("DNS nima?", "DNS domen nomlarini IP manzillarga moslashtirishga yordam beradi.", "dns vazifasi", listOf("dns", "domen")),
            TechnologyTopic("Brauzer nima?", "Brauzer veb-sahifalarni ochish va ko‘rish uchun ishlatiladi.", "browser nima", listOf("brauzer", "veb")),
            TechnologyTopic("Qidiruv tizimi nima?", "Qidiruv tizimi internetdagi sahifalarni topishga yordam beradi.", "search engine nima", listOf("qidiruv", "internet")),
            TechnologyTopic("Bulutli saqlash nima?", "Bulutli saqlash fayllarni internet orqali masofaviy serverlarda saqlash imkonini beradi.", "cloud storage nima", listOf("bulut", "fayl")),
            TechnologyTopic("Zaxira nusxa nima?", "Zaxira nusxa muhim fayllarning qo‘shimcha nusxasi bo‘lib, yo‘qolishdan tiklashga yordam beradi.", "backup nima", listOf("backup", "nusxa")),
            TechnologyTopic("Kiberxavfsizlik nima?", "Kiberxavfsizlik qurilmalar, tarmoqlar va ma’lumotlarni raqamli tahdidlardan himoyalashdir.", "cybersecurity nima", listOf("xavfsizlik", "kiber")),
            TechnologyTopic("Kuchli parol qanday bo‘ladi?", "Kuchli parol uzun, taxmin qilish qiyin va boshqa akkauntlarda qayta ishlatilmaydigan bo‘ladi.", "parolni qanday tanlash", listOf("parol", "xavfsizlik")),
            TechnologyTopic("Ikki bosqichli himoya nima?", "Ikki bosqichli tasdiqlash paroldan tashqari qo‘shimcha tasdiq talab qilib, akkaunt himoyasini kuchaytiradi.", "2fa nima", listOf("2fa", "tasdiqlash")),
            TechnologyTopic("Fishing nima?", "Fishing — soxta xabar yoki sayt orqali parol va boshqa maxfiy ma’lumotlarni qo‘lga kiritishga urinish.", "phishing nima", listOf("fishing", "soxta")),
            TechnologyTopic("Zararli dastur nima?", "Zararli dastur qurilma yoki ma’lumotga zarar yetkazish yoki ruxsatsiz kirish uchun yaratiladi.", "malware nima", listOf("malware", "virus")),
            TechnologyTopic("Antivirus nima?", "Antivirus zararli dasturlarni aniqlash, bloklash yoki olib tashlashga yordam beradi.", "antivirus vazifasi", listOf("antivirus", "himoya")),
            TechnologyTopic("Shifrlash nima?", "Shifrlash ma’lumotni maxsus kalitsiz o‘qish qiyin bo‘lgan ko‘rinishga aylantiradi.", "encryption nima", listOf("shifrlash", "kalit")),
            TechnologyTopic("RAM ko‘p bo‘lsa nima o‘zgaradi?", "Yetarli RAM bir vaqtning o‘zida ko‘proq ilovani ishlatishga yordam beradi; natija boshqa qurilma qismlariga ham bog‘liq.", "ramning foydasi", listOf("ram", "unumdorlik")),
            TechnologyTopic("GPU nima?", "GPU grafikani qayta ishlashga ixtisoslashgan protsessor bo‘lib, ayrim hisoblashlarda ham ishlatiladi.", "videokarta nima", listOf("gpu", "grafika")),
            TechnologyTopic("Kompyuter qizib ketsa nima qilish kerak?", "Havo yo‘llarini to‘sma, qurilmani qattiq yuzaga qo‘y, changni xavfsiz tozalat va og‘ir yukni kamaytir.", "qizishni kamaytirish", listOf("qizish", "sovutish")),
            TechnologyTopic("FPS nima?", "FPS — bir soniyada ko‘rsatiladigan kadrlar soni; yuqoriroq FPS harakatni silliqroq ko‘rsatishi mumkin.", "fps ta’rifi", listOf("fps", "kadr")),
            TechnologyTopic("Mobil ilova nima?", "Mobil ilova telefon yoki planshet operatsion tizimida ishlash uchun yaratilgan dastur.", "app nima", listOf("ilova", "mobil")),
            TechnologyTopic("APK nima?", "APK — Android ilovalarini tarqatish va o‘rnatishda ishlatiladigan paket formati.", "apk fayl nima", listOf("apk", "android")),
            TechnologyTopic("Kompilyatsiya nima?", "Kompilyatsiya kodni boshqa ko‘rinishga, masalan bajariladigan kodga, o‘girish jarayonidir.", "compile nima", listOf("kompilyatsiya", "kod")),
            TechnologyTopic("Kutubxona nima?", "Dasturlash kutubxonasi qayta ishlatish mumkin bo‘lgan tayyor funksiyalar va kodlarni beradi.", "library nima", listOf("kutubxona", "library")),
            TechnologyTopic("Framework nima?", "Framework ilova tuzilishini yaratish va keng tarqalgan vazifalarni bajarish uchun tayyor asos beradi.", "framework nima", listOf("framework", "asos")),
            TechnologyTopic("Ochiq kod nima?", "Ochiq kodli dastur manba kodini ko‘rish, litsenziyaga muvofiq o‘zgartirish va tarqatish imkonini beradi.", "open source nima", listOf("ochiq", "kod")),
            TechnologyTopic("LAN nima?", "LAN — uy, maktab yoki ofis kabi cheklangan hududdagi mahalliy tarmoq.", "lan nima", listOf("lan", "tarmoq")),
            TechnologyTopic("Bluetooth nima?", "Bluetooth yaqin masofadagi qurilmalar orasida simsiz aloqa o‘rnatadi.", "bluetooth vazifasi", listOf("bluetooth", "simsiz")),
            TechnologyTopic("USB nima?", "USB qurilmalarni ulash va ma’lumot uzatish, ayrim hollarda quvvat berish uchun ishlatiladi.", "usb nima", listOf("usb", "port"))
        )
        val prefixes = listOf(
            "Tushuntirib ber: ", "Qisqacha ayt: ", "Menga o'rgat: ", "Ma'lumot ber: ",
            "Oddiy tilda tushuntir: ", "Savolim bor: ", "Buni izohla: ", "Qanday bo'ladi: ",
            "Nimani bilishim kerak: ", "Boshlovchi uchun ayt: ", "Yordam ber: ", "Eslatib yubor: ",
            "Batafsilroq tushuntir: ", "Eng muhim jihati nima: ", "To'g'ri tushunishim uchun ayt: ",
            "Bu haqida gapirib ber: ", "Qanday o'rganaman: ", "Asosiy ma'lumot: ", "Iltimos, izohla: ",
            "Men bilmoqchiman: ", "Sodda qilib ayt: ", "Misol bilan tushuntir: ", "Qoidasi qanday: ",
            "Amalda qanday: ", "Yodlab olishim uchun ayt: ", "Yangi o'rganuvchiga tushuntir: ",
            "Qisqa ma'lumot kerak: ", "Muhim nuqtalarini ayt: ", "Savolimga javob ber: ", "Bu nimani bildiradi: ",
            "O'rganishga yordam ber: ", "Mavzuni tushuntir: ", "Aniqroq ayt: ", "Buni qanday tushunsam bo'ladi: ",
            "Oddiy javob ber: ", "Bosqichma-bosqich ayt: ", "Asoslarini tushuntir: ", "Ma'nosini ayt: ",
            "Qanday eslab qolaman: ", "Nimadan boshlay: ", "Muhim ma'lumotni ayt: ", "Buni bilish kerakmi: ",
            "Qanday bajariladi: ", "Qanday talaffuz qilinadi: ", "Qaysi qoidaga tegishli: ", "To'g'ri yo'lini tushuntir: ",
            "Menga kerakli ma'lumot: ", "Bir oz tushuntir: ", "Buni o'rganish yo'li: ", "Yodda tutish uchun ayt: "
        )
        val result = ArrayList<Fact>(5994)
        topics.forEachIndexed { topicIndex, topic ->
            prefixes.forEachIndexed { styleIndex, prefix ->
                if (result.size < 5994) {
                    val base = topicIndex * 100 + styleIndex * 2 + 1
                    val kws = topic.keywords + listOf("kompyuter dasturlash texnologiya")
                    result.add(fact("technology_db_${base.toString().padStart(5, '0')}", Category.TECHNOLOGY, prefix + topic.q1, topic.answer, listOf(prefix + topic.q2, topic.q1, topic.q2), kws))
                }
                if (result.size < 5994) {
                    val base = topicIndex * 100 + styleIndex * 2 + 2
                    val kws = topic.keywords + listOf("kompyuter dasturlash texnologiya")
                    result.add(fact("technology_db_${base.toString().padStart(5, '0')}", Category.TECHNOLOGY, prefix + topic.q2, topic.answer, listOf(prefix + topic.q1, topic.q1, topic.q2), kws))
                }
            }
            if (result.size >= 5994) return result
        }
        return result
    }

    private fun fact(
        id: String,
        category: Category,
        question: String,
        answer: String,
        aliases: List<String> = emptyList(),
        keywords: List<String> = emptyList()
    ) = Fact(id, category, question, answer, aliases, keywords)

    /** O'zbekcha harflar, apostrof va tinish belgilarini bir xil ko'rinishga keltiradi. */
    private val nonWordRe = Regex("[^\\p{L}\\p{N}+' ]")
    private val spacesRe = Regex("\\s+")

    fun normalize(text: String): String {
        return text.lowercase()
            .replace('’', '\'').replace('‘', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
            .replace('ё', 'е')
            .replace(nonWordRe, " ")
            .replace(spacesRe, " ")
            .trim()
    }

    /** Savolda ma'no bermaydigan, tayyor prefikslarda ko'p uchraydigan so'zlar (yolg'on moslik bermasin). */
    private val genericWords = setOf(
        "qanday", "tushuntir", "ayt", "nima", "nimani", "qancha", "buni", "menga", "bir", "oz",
        "haqida", "degani", "mumkin", "kerak", "savol", "javob", "oddiy", "aniqroq", "mavzuni",
        "ma'nosini", "asoslarini", "qisqa", "ma'lumot", "muhim", "qaysi"
    )

    /** Har bir yozuv uchun normallashtirilgan matnlar bir marta hisoblanadi (qidiruv tez ishlashi uchun). */
    private class Prep(val cands: List<String>, val tokens: Set<String>)

    private val prepared: List<Prep> by lazy {
        val pool = HashMap<String, String>()
        facts.map { f ->
            val cands = (listOf(f.question) + f.aliases).map { normalize(it) }
            val all = normalize((listOf(f.question) + f.aliases + f.keywords).joinToString(" "))
            val ts = HashSet<String>()
            for (t in all.split(' ')) if (t.length >= 2) ts.add(pool.getOrPut(t) { t })
            Prep(cands, ts)
        }
    }

    /** Ilova ochilganda fon oqimida chaqiriladi: birinchi savolda kutib qolmaslik uchun. */
    fun warmUp() { prepared.size }

    private fun tokens(text: String): Set<String> = normalize(text)
        .split(' ').filter { it.length >= 2 }.toSet()

    /**
     * Savolga eng yaqin bilimni topadi.
     * threshold juda past bo'lsa noto'g'ri mosliklar ko'payishi mumkin.
     */
    fun search(question: String, category: Category? = null, threshold: Int = 6): Match? {
        val q = normalize(question)
        if (q.isBlank()) return null
        val qt = tokens(q).filter { it !in genericWords }.toSet()
        var best: Match? = null
        val prep = prepared

        for ((idx, f) in facts.withIndex()) {
            if (category != null && f.category != category) continue
            val p = prep[idx]
            var score = 0

            // To'liq savol yoki aliasga moslik eng yuqori ball oladi.
            if (p.cands.any { it == q }) score += 12
            else if (p.cands.any { c -> c.contains(q) || q.contains(c) }) score += 5

            val ft = p.tokens
            var overlap = 0
            for (t in qt) if (t in ft) overlap++
            score += overlap * 2

            // Kam uchraydigan uzunroq so'zlarga ko'proq og'irlik berish.
            for (token in qt) {
                if (token.length >= 5 && ft.any { it.startsWith(token) || token.startsWith(it) }) score += 1
            }

            if (score >= threshold && (best == null || score > best!!.score)) {
                best = Match(f, score)
            }
        }
        return best
    }

    fun answer(question: String, category: Category? = null): String? = search(question, category)?.fact?.answer

    fun allCategories(): List<Category> = Category.values().toList()
    fun count(): Int = facts.size
    fun count(category: Category): Int = facts.count { it.category == category }
    fun allFacts(): List<Fact> = facts
}
