package com.zeno.virtualfriend

/** Lug‘at, poytaxtlar va kimyoviy elementlar. */
object KbWords {

    /** "o‘zbekcha=inglizcha;..." */
    val dict2 = "ayol=woman;erkak=man;qiz=girl;o'g'il=boy;bobo=grandfather;buvi=grandmother;amaki=uncle;xola=aunt;" +
        "qarindosh=relative;qo'shni=neighbor;mehmon=guest;vrach=doctor;shifokor=doctor;hamshira=nurse;muhandis=engineer;" +
        "dasturchi=programmer;haydovchi=driver;oshpaz=cook;sotuvchi=seller;rassom=painter;yozuvchi=writer;shoir=poet;" +
        "askar=soldier;politsiya=police;prezident=president;qirol=king;malika=queen;" +
        "ovqat=food;nonushta=breakfast;tushlik=lunch;kechki ovqat=dinner;ichimlik=drink;qahva=coffee;sharbat=juice;" +
        "meva=fruit;sabzavot=vegetable;banan=banana;uzum=grape;anor=pomegranate;shaftoli=peach;olxo'ri=plum;gilos=cherry;" +
        "qovun=melon;tarvuz=watermelon;limon=lemon;apelsin=orange;nok=pear;o'rik=apricot;anjir=fig;" +
        "pomidor=tomato;bodring=cucumber;kartoshka=potato;sabzi=carrot;piyoz=onion;sarimsoq=garlic;qalampir=pepper;karam=cabbage;" +
        "yog'=oil;asal=honey;pishloq=cheese;qatiq=yogurt;qaymoq=cream;sariyog'=butter;un=flour;" +
        "stakan=glass;piyola=bowl;likopcha=plate;qoshiq=spoon;pichoq=knife;sanchqi=fork;idish=dish;choynak=teapot;" +
        "kiyim=clothes;ko'ylak=shirt;shim=trousers;etik=boots;poyabzal=shoes;ro'mol=scarf;qalpoq=hat;paypoq=socks;soat=watch;" +
        "sumka=bag;kalit=key;qulf=lock;oyna=mirror;karavot=bed;ko'rpa=blanket;yostiq=pillow;gilam=carpet;" +
        "televizor=television;radio=radio;kamera=camera;printer=printer;klaviatura=keyboard;sichqoncha=mouse;ekran=screen;" +
        "xabar=message;rasm=picture;video=video;musiqa=music;qo'shiq=song;film=movie;o'yin=game;" +
        "ko'cha=street;maydon=square;ko'prik=bridge;bog'=garden;park=park;bozor=market;do'kon=shop;bank=bank;" +
        "kasalxona=hospital;dorixona=pharmacy;mehmonxona=hotel;restoran=restaurant;kutubxona=library;muzey=museum;stadion=stadium;" +
        "aeroport=airport;vokzal=station;bekat=stop;avtobus=bus;taksi=taxi;metro=subway;kema=ship;" +
        "dunyo=world;osmon=sky;yer=earth;olov=fire;havo=air;tosh=stone;qum=sand;o'rmon=forest;cho'l=desert;ko'l=lake;orol=island;" +
        "bulut=cloud;chaqmoq=lightning;tuman=fog;ob-havo=weather;harorat=temperature;" +
        "bahor=spring;yoz=summer;kuz=autumn;qish=winter;" +
        "sher=lion;yo'lbars=tiger;ayiq=bear;bo'ri=wolf;tulki=fox;quyon=rabbit;maymun=monkey;fil=elephant;jirafa=giraffe;tuya=camel;" +
        "eshak=donkey;echki=goat;tovuq=chicken;xo'roz=rooster;o'rdak=duck;g'oz=goose;kaptar=pigeon;burgut=eagle;ari=bee;kapalak=butterfly;" +
        "chumoli=ant;o'rgimchak=spider;ilon=snake;qurbaqa=frog;kit=whale;delfin=dolphin;akula=shark;" +
        "boshlamoq=to start;tugatmoq=to finish;bormoq=to go;kelmoq=to come;ko'rmoq=to see;eshitmoq=to hear;gapirmoq=to speak;" +
        "o'qimoq=to read;yozmoq=to write;o'rganmoq=to learn;o'ylamoq=to think;bilmoq=to know;tushunmoq=to understand;" +
        "yemoq=to eat;ichmoq=to drink;uxlamoq=to sleep;yugurmoq=to run;yurmoq=to walk;o'tirmoq=to sit;turmoq=to stand;" +
        "sevmoq=to love;yoqtirmoq=to like;xohlamoq=to want;berish=to give;olmoq=to take;sotmoq=to sell;sotib olmoq=to buy;" +
        "ochmoq=to open;yopmoq=to close;kutmoq=to wait;izlamoq=to search;topmoq=to find;yo'qotmoq=to lose;" +
        "yordam bermoq=to help;ishlamoq=to work;o'ynamoq=to play;kulmoq=to laugh;yig'lamoq=to cry;qo'ng'iroq qilmoq=to call;" +
        "baxtli=happy;xafa=sad;g'azabli=angry;charchagan=tired;och=hungry;chanqoq=thirsty;kasal=sick;sog'lom=healthy;" +
        "boy=rich;kambag'al=poor;aqlli=smart;dangasa=lazy;mehnatkash=hardworking;mehribon=kind;jasur=brave;halol=honest;" +
        "toza=clean;iflos=dirty;yumshoq=soft;qattiq=hard;shirin=sweet;achchiq=bitter;nordon=sour;sho'r=salty;" +
        "keng=wide;tor=narrow;yaqin=near;uzoq=far;ochiq=open;yopiq=closed;to'la=full;bo'sh=empty;" +
        "to'g'ri=correct;noto'g'ri=wrong;haqiqat=truth;yolg'on=lie;xavfsiz=safe;xavfli=dangerous;" +
        "ilgari=before;keyin=after;hozir=now;doim=always;ba'zan=sometimes;hech qachon=never;tez-tez=often;" +
        "ichida=inside;tashqarida=outside;tepada=above;pastda=below;oldinda=in front;orqada=behind;" +
        "nima=what;kim=who;qayer=where;qachon=when;nega=why;qanday=how;qancha=how much;" +
        "ha=yes;yo'q=no;balki=maybe;albatta=of course;mumkin=possible;kerak=necessary;" +
        "bilan=with;uchun=for;haqida=about;va=and;yoki=or;lekin=but;chunki=because;agar=if;" +
        "salom alaykum=peace be upon you;xush kelibsiz=welcome;omad=luck;tabriklayman=congratulations;" +
        "marhamat=here you are;arzimaydi=you are welcome;uzr=sorry;tushunarli=understood;" +
        "ism=name;familiya=surname;yosh=age;manzil=address;telefon raqam=phone number;pochta=mail;" +
        "shaxar=city;ish joyi=workplace;kasb=profession;maosh=salary;ta'til=holiday;dam olish=rest;" +
        "sport=sport;futbol=football;basketbol=basketball;suzish=swimming;yugurish=running;" +
        "matematika=mathematics;fizika=physics;kimyo=chemistry;biologiya=biology;tarix=history;geografiya=geography;adabiyot=literature;" +
        "daraja=degree;imtihon=exam;baho=grade;dars=lesson;uy vazifasi=homework;sinf=class;direktor=principal;" +
        "bir yuz=one hundred;ming=thousand;million=million;yarim=half;chorak=quarter;juft=pair;ko'p=many;oz=few"

    // ------------------------------------------------------------------ poytaxtlar
    /** "Davlat nomi:kalit1/kalit2:Poytaxt;..." */
    val capitalsRaw = "O‘zbekiston:o'zbekiston/uzbekiston/uzbekistan:Toshkent;Qozog‘iston:qozog'iston/qozogiston/kazaxiston/kazakhstan:Ostona;" +
        "Qirg‘iziston:qirg'iziston/qirgiziston/kirgiziston:Bishkek;Tojikiston:tojikiston:Dushanbe;Turkmaniston:turkmaniston:Ashxobod;" +
        "Afg‘oniston:afg'oniston/afgoniston:Kobul;Rossiya:rossiya/rusiya:Moskva;Turkiya:turkiya/turkey:Anqara;" +
        "AQSh:=aqsh/=usa/amerika/qo'shma shtat:Vashington;Buyuk Britaniya:britaniya/angliya/buyuk britan:London;" +
        "Fransiya:fransiya:Parij;Germaniya:germaniya/nemis:Berlin;Italiya:italiya:Rim;Ispaniya:ispaniya:Madrid;Portugaliya:portugaliya:Lissabon;" +
        "Yaponiya:yaponiya:Tokio;Xitoy:xitoy:Pekin;Hindiston:hindiston:Nyu-Deli;Janubiy Koreya:janubiy koreya/koreya:Seul;" +
        "Shimoliy Koreya:shimoliy koreya:Pxenyan;Mo‘g‘uliston:mo'g'uliston/mongoliston:Ulan-Bator;" +
        "Misr:misr/egipet:Qohira;Liviya:liviya:Tripoli;Tunis:=tunis:Tunis;Jazoir:jazoir:Jazoir;Marokash:marokash:Rabot;Sudan:=sudan:Xartum;" +
        "Efiopiya:efiopiya:Addis-Abeba;Keniya:keniya:Nayrobi;Nigeriya:nigeriya:Abuja;Gana:=gana:Akkra;Tanzaniya:tanzaniya:Dodoma;" +
        "Angola:=angola:Luanda;Senegal:senegal:Dakar;Janubiy Afrika:janubiy afrika:Pretoriya (ma’muriy), Keyptaun (qonunchilik), Blumfontein (sud);" +
        "Saudiya Arabistoni:saudiya:Ar-Riyod;Eron:=eron/=iran:Tehron;Iroq:=iroq/=irok:Bag‘dod;Suriya:suriya:Damashq;Livan:=livan:Bayrut;" +
        "Iordaniya:iordaniya/ordan:Ammon;Quvayt:kuvayt/quvayt:Quvayt;Qatar:=katar/=qatar:Doha;Ummon:=ummon/=uman:Maskat;Yaman:=yaman:Sano;" +
        "BAA:=baa/birlashgan arab/emirlik:Abu-Dabi;Bahrayn:bahrayn:Manama;Ozarbayjon:ozarbayjon/ozerbayjon:Boku;Gruziya:gruziya:Tbilisi;" +
        "Armaniston:armaniston:Yerevan;Ukraina:ukraina:Kiyev;Belarus:belarus/belorus:Minsk;Moldova:moldova:Kishinyov;Polsha:polsha:Varshava;" +
        "Chexiya:chexiya:Praga;Slovakiya:slovakiya:Bratislava;Vengriya:vengriya:Budapesht;Ruminiya:ruminiya:Buxarest;Bolgariya:bolgariya:Sofiya;" +
        "Serbiya:serbiya:Belgrad;Xorvatiya:xorvatiya:Zagreb;Sloveniya:sloveniya:Lyublyana;Bosniya:bosniya:Sarayevo;Albaniya:albaniya:Tirana;" +
        "Gretsiya:gretsiya/yunoniston:Afina;Belgiya:belgiya:Bryussel;Niderlandiya:niderlandiya/gollandiya:Amsterdam;Shveytsariya:shveytsariya:Bern;" +
        "Avstriya:avstriya:Vena;Daniya:daniya:Kopengagen;Shvetsiya:shvetsiya:Stokgolm;Norvegiya:norvegiya:Oslo;Finlyandiya:finlyandiya:Xelsinki;" +
        "Islandiya:islandiya:Reykyavik;Irlandiya:irlandiya:Dublin;Litva:=litva:Vilnyus;Latviya:latviya:Riga;Estoniya:estoniya:Tallin;" +
        "Kipr:=kipr:Nikosiya;Malta:=malta:Valletta;Kanada:kanada:Ottava;Meksika:meksika:Mexiko;Kuba:=kuba:Gavana;Braziliya:braziliya:Brazilia;" +
        "Argentina:argentina:Buenos-Ayres;Chili:=chili:Santyago;Peru:=peru:Lima;Kolumbiya:kolumbiya:Bogota;Venesuela:venesuela:Karakas;" +
        "Ekvador:ekvador:Kito;Urugvay:urugvay:Montevideo;Paragvay:paragvay:Asunsyon;Boliviya:boliviya:Sukre (rasmiy), La-Pas (hukumat joylashgan);" +
        "Pokiston:pokiston:Islomobod;Bangladesh:bangladesh:Dakka;Nepal:=nepal:Katmandu;Shri-Lanka:shri-lanka/shri lanka:Kolombo;" +
        "Tailand:tailand:Bangkok;Vyetnam:vyetnam:Xanoy;Indoneziya:indoneziya:Jakarta;Malayziya:malayziya:Kuala-Lumpur;Filippin:filippin:Manila;" +
        "Singapur:singapur:Singapur;Myanma:myanma/birma:Neypyido;Kambodja:kambodja:Pnompen;Laos:=laos:Vyentyan;" +
        "Avstraliya:avstraliya:Kanberra;Yangi Zelandiya:yangi zelandiya:Vellington;Isroil:isroil:(Isroilning poytaxti masalasi bahsli — iltimos, rasmiy manbaga qarang)"

    class Cap(val name: String, val keys: List<String>, val city: String)

    val caps: List<Cap> by lazy {
        capitalsRaw.split(";").mapNotNull {
            val p = it.split(":")
            if (p.size < 3) null else Cap(p[0], p[1].split("/").map { k -> Knowledge.n(k.trim()) }, p.subList(2, p.size).joinToString(":"))
        }
    }

    fun capital(flat: String, tk: List<String>): String? {
        val ask = tk.any { it.startsWith("poytaht") || it.startsWith("paytaht") }
        if (ask) {
            for (c in caps) if (c.keys.any { Kb.keyHit(tk, flat, it) }) return "${c.name} poytaxti — ${c.city}."
        }
        // teskari: "Parij qaysi davlat poytaxti"
        if (ask || flat.contains("qaysi davlat") || flat.contains("kaysi davlat")) {
            for (c in caps) {
                val city = Knowledge.n(c.city.substringBefore(" ").substringBefore("("))
                if (city.length >= 4 && tk.any { it == city || (it.length > 4 && it.startsWith(city)) }) return "${c.city.substringBefore(" (")} — ${c.name} poytaxti."
            }
        }
        return null
    }

    // ------------------------------------------------------------------ elementlar
    private val elementsRaw = "Vodorod:H:1;Geliy:He:2;Litiy:Li:3;Berilliy:Be:4;Bor:B:5;Uglerod:C:6;Azot:N:7;Kislorod:O:8;Ftor:F:9;Neon:Ne:10;" +
        "Natriy:Na:11;Magniy:Mg:12;Alyuminiy:Al:13;Kremniy:Si:14;Fosfor:P:15;Oltingugurt:S:16;Xlor:Cl:17;Argon:Ar:18;Kaliy:K:19;Kalsiy:Ca:20;" +
        "Skandiy:Sc:21;Titan:Ti:22;Vanadiy:V:23;Xrom:Cr:24;Marganets:Mn:25;Temir:Fe:26;Kobalt:Co:27;Nikel:Ni:28;Mis:Cu:29;Rux:Zn:30;" +
        "Galliy:Ga:31;Germaniy:Ge:32;Mishyak:As:33;Selen:Se:34;Brom:Br:35;Kripton:Kr:36;Rubidiy:Rb:37;Stronsiy:Sr:38;Itriy:Y:39;Sirkoniy:Zr:40;" +
        "Niobiy:Nb:41;Molibden:Mo:42;Texnetsiy:Tc:43;Ruteniy:Ru:44;Rodiy:Rh:45;Palladiy:Pd:46;Kumush:Ag:47;Kadmiy:Cd:48;Indiy:In:49;Qalay:Sn:50;" +
        "Surma:Sb:51;Tellur:Te:52;Yod:I:53;Ksenon:Xe:54;Seziy:Cs:55;Bariy:Ba:56;Lantan:La:57;Seriy:Ce:58;Prazeodim:Pr:59;Neodim:Nd:60;" +
        "Prometiy:Pm:61;Samariy:Sm:62;Evropiy:Eu:63;Gadoliniy:Gd:64;Terbiy:Tb:65;Disprozyiy:Dy:66;Golmiy:Ho:67;Erbiy:Er:68;Tuliy:Tm:69;Itterbiy:Yb:70;" +
        "Lyutetsiy:Lu:71;Gafniy:Hf:72;Tantal:Ta:73;Volfram:W:74;Reniy:Re:75;Osmiy:Os:76;Iridiy:Ir:77;Platina:Pt:78;Oltin:Au:79;Simob:Hg:80;" +
        "Talliy:Tl:81;Qo‘rg‘oshin:Pb:82;Vismut:Bi:83;Poloniy:Po:84;Astat:At:85;Radon:Rn:86;Fransiy:Fr:87;Radiy:Ra:88;Aktiniy:Ac:89;Toriy:Th:90;" +
        "Protaktiniy:Pa:91;Uran:U:92;Plutoniy:Pu:94"

    class El(val name: String, val sym: String, val z: Int)

    val elements: List<El> by lazy {
        elementsRaw.split(";").mapNotNull {
            val p = it.split(":")
            if (p.size != 3) null else El(p[0], p[1], p[2].toInt())
        }
    }

    private val metals = setOf(
        "Litiy", "Natriy", "Kaliy", "Kalsiy", "Magniy", "Alyuminiy", "Temir", "Mis", "Rux", "Kumush", "Qalay", "Oltin", "Simob",
        "Qo‘rg‘oshin", "Platina", "Nikel", "Titan", "Xrom", "Uran"
    )

    fun element(flat: String, tk: List<String>, strict: Boolean): String? {
        // "26-element", "8 raqamli element", "tartib raqami 79"
        Regex("(\\d{1,3})\\s*-?\\s*(?:chi|nchi)?\\s*(?:element|tartib raqam)").find(flat)?.let {
            val z = it.groupValues[1].toInt()
            elements.firstOrNull { e -> e.z == z }?.let { e -> return "Davriy jadvalning $z-elementi — ${e.name} (${e.sym})." }
            if (z in 1..118) return "$z-element davriy jadvalda mavjud, lekin mening qisqa jadvalimda yo‘q."
        }
        Regex("(?:tartib raqami|raqami)\\s*(\\d{1,3})").find(flat)?.let {
            val z = it.groupValues[1].toInt()
            elements.firstOrNull { e -> e.z == z }?.let { e -> if (flat.contains("element") || flat.contains("kimyoviy")) return "Tartib raqami $z bo‘lgan element — ${e.name} (${e.sym})." }
        }
        val asksSym = flat.contains("belgi") || flat.contains("simvol") || flat.contains("formula")
        val asksNum = flat.contains("tartib") || flat.contains("raqam") || flat.contains("nomer")
        for (e in elements) {
            val k = Knowledge.n(e.name)
            if (tk.any { it == k || (k.length >= 4 && it.startsWith(k) && it.length <= k.length + 4) }) {
                val explicit = asksSym || asksNum || flat.contains("element") || flat.contains("kimyo")
                if (if (strict) explicit else (explicit || flat.contains("nima"))) {
                    val kind = if (e.name in metals) "metall" else "kimyoviy element"
                    return "${e.name} (${e.sym}) — davriy jadvalning ${e.z}-elementi ($kind)."
                }
            }
        }
        return null
    }
}
