package com.zeno.virtualfriend

/**
 * Ball asosidagi qidiruv: har bir yozuv "mavzu :: tafsilot :: javob" ko‘rinishida.
 *  - mavzu kalitlaridan kamida bittasi savolda bo‘lishi shart;
 *  - tafsilot kalitlari mos kelsa, shu yozuv ustun bo‘ladi (masalan "Everest" + "balandlik");
 *  - kalit 4 harfdan qisqa bo‘lsa aniq so‘z sifatida, aks holda so‘z boshi (qo‘shimchalar bilan) va
 *    1 harfli imlo xatosi bilan solishtiriladi.
 */
object Kb {
    class F(val subj: List<String>, val topic: List<String>, val ans: String)

    private fun parse(lines: Array<String>): List<F> = lines.mapNotNull { raw ->
        // bo‘sh tafsilot maydoni: " :: :: " → " :: _ :: "
        val line = raw.replace(" :: :: ", " :: _ :: ")
        val p = line.split(" :: ")
        if (p.size < 3) return@mapNotNull null
        val subj = p[0].split(",").map { Knowledge.n(it.trim()) }.filter { it.isNotEmpty() }
        val topic = p[1].split(",").map { Knowledge.n(it.trim()) }.filter { it.isNotEmpty() && it != "_" }
        val ans = p.subList(2, p.size).joinToString(" :: ")
        if (subj.isEmpty()) null else F(subj, topic, ans)
    }

    val facts: List<F> by lazy {
        parse(KbFacts1.data) + parse(KbFacts2.data) + parse(KbFacts3.data) + parse(KbFacts4.data)
    }

    private fun lev1(a: String, b: String): Boolean {
        // a va b orasidagi tahrir masofasi <= 1 mi
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        if (i == a.length || i == b.length) return Math.abs(a.length - b.length) <= 1
        return when {
            a.length == b.length -> a.substring(i + 1) == b.substring(i + 1)
            a.length > b.length -> a.substring(i + 1) == b.substring(i)
            else -> a.substring(i) == b.substring(i + 1)
        }
    }

    private val suffix3 = setOf("da","ga","ni","dan","ning","lar","i","im","ing","si")
    private fun t3(t: String, key: String) = t.startsWith(key) && t.substring(key.length) in suffix3

    private fun tokHit(t: String, key: String): Boolean {
        if (key.length < 3) return t == key
        if (key.length == 3) return t == key || t3(t, key)
        if (t.startsWith(key)) return true
        if (key.endsWith("k") && t.startsWith(key.dropLast(1) + "g")) return true
        if (key.length >= 8 && t.length >= key.length - 2 && t.startsWith(key.substring(0, key.length - 2))) return true
        if (key.length >= 7 && t.length >= key.length - 1 && lev1(t.take(key.length), key)) return true
        return false
    }

    /** Kalit savolda topilgan token o‘rni (yo‘q bo‘lsa -1). */
    fun keyPos(tk: List<String>, flat: String, key: String): Int {
        if (key.startsWith("=")) return tk.indexOf(key.substring(1))
        if (key.contains(' ') || key.contains('-')) return flat.indexOf(key)
        for (i in tk.indices) if (tokHit(tk[i], key)) return i
        return -1
    }

    fun keyHit(tk: List<String>, flat: String, key: String) = keyPos(tk, flat, key) >= 0

    fun search(tk: List<String>, flat: String): String? {
        var best: F? = null
        var bestScore = 0
        var bestLen = 0
        var bestPos = 1000000
        for (f in facts) {
            var s = 0
            var ml = 0
            var mp = 1000000
            for (k in f.subj) {
                val p = keyPos(tk, flat, k)
                if (p >= 0) {
                    s += 10
                    if (k.length > ml) ml = k.length
                    if (p < mp) mp = p
                }
            }
            if (s == 0) continue
            if (f.topic.isNotEmpty()) {
                var th = 0
                for (k in f.topic) if (keyHit(tk, flat, k)) th++
                s += if (th > 0) 4 * th else -6
            }
            val better = s > bestScore || (s == bestScore && (ml > bestLen || (ml == bestLen && mp < bestPos)))
            if (better) {
                bestScore = s; bestLen = ml; bestPos = mp; best = f
            }
        }
        if (best == null || bestScore < 10) return null
        val parts = best.ans.split("###")
        return if (parts.size == 1) best.ans else parts[kotlin.random.Random.nextInt(parts.size)]
    }
}
